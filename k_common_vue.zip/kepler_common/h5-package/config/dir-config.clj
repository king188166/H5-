; "目录配置及规则配置，如有疑问请联系liujun842"

; --------------------------------
; @author:	liujun842
; @mail:	liujun842@pingan.com.cn
; --------------------------------

(fn [env]
{
	; 全量包需要的文件
	:all-file-regex [
		;项目dist目录所需文件正则，括号内为需要保留的目录结构
		#".+/dist/(.+\.html)$"
		#".+/dist/(static/js/.+\.js)$"
		#".+/dist/(static/css/.+\.css)$"
		#".+/dist/(static/images/.+\.(?:png|jpe?g|ico|gif))$"
		#".+/dist/(static/libs/.+\.js)$"
		#".+/dist/(static/test/.+\.html)$"
	]
	:mapping [
		; 全量文件名正则				需要移动的条件，匹配svn/git改动文件清单									移动目标路径
		;[#".+/(.+)\.html" 			["include/_header.ejs" "include/_footer.ejs" "templates/$1.ejs"] 	"$1.html"]
		;[#".+/css/(.+).css" 		["www/less/$1.less"]												"css/$1.css"]

		; less编译成css后会合并的模块需要启用并配置该规则
		;[#".+/css/o2o.css" 		[#"less/.+\.less"] 													"css/o2o.css"]

		; ejs依赖关系配置
		;[#".+/(shaw-personal-credit)\.html" ["protocol-proxy-esign.ejs" "protocol-proxy-cgi-esign.ejs"] "$1.html"]

		;[#".+/images/(.+)" 			["www/images/$1"]													"images/$1"]
		;[#".+/js/(.+)\.js" 			["www/js/$1.js"]													"js/$1.js"]

		; 生产包时 common下的任意文件改动 都需要拷贝common.js
		;[#".+/js/common/common\.js" (if (= "PRODUCTION" env)  [#"www/js/common/.+\.js"] [])				"js/common/common.js"]

		; 增量包需要考虑libs下的文件改动需要启用并配置该规则
		;[#".+/libs/.+\.js"			[]]
	]
	;模块历史增量包目录
	:prj-update-dir "upgrade/update/"
	:prj-dist "dist/"
})
