; "版本配置 该配置建议各项目组 新建upgrade/vcs-config.clj文件覆盖"
(fn [env]
{
	; 根据某一版本号生成下一版本号函数，版本号为java Long类型，最大值为9223372036854775807，注意不要越界
	; 默认下一版本号为当前版本号+1，如需定制化版本生成规则需修改该配置函数
	:next-verion #(.toString (+ (Long/valueOf %) 1))
	:full-version "0000"								;全量包名称  full-version - cur-version.zip (0000-1017.zip)
	; 匹配文件清单的正则，第一个分组为符合条件的文件绝对路径，MA开头表示修改或添加，代码迁移git后需要修改该配置
	:file-list-regex [#"^[MA]\s+\"?(.*)\"?" 1]
})
