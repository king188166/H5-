CUR_DIR=`pwd`

MODULE_NAME=${MODULE_NAME}					#模块名
VCS_TYPE=${VCS_TYPE}						#版本控制工具类型
ENV=${ENV}                                  #环境
START_VERSION=${START_VERSION}              #增量包起始版本号
H5_RES_VERSION=${H5_RES_VERSION}            #H5资源当前版本号
DOWN_URL_PREFIX=${DOWN_URL_PREFIX}          #资源更新 下载路径前缀
UPLOAD_VERSION=${UPLOAD_VERSION}            #需要自动上传增量包的app版本配置
SVN_USERNAME=${SVN_USERNAME}
SVN_PASSWORD=${SVN_PASSWORD}
BUILD_NUMBER=${BUILD_NUMBER}

GULP_COMMAND="/usr/local/lib/node_modules/gulp-cli/bin/gulp.js"

TOOL_DIR="${CUR_DIR}/h5-package/release/h5-package/"    #打包工具目录
OUTPUT="${CUR_DIR}/output/${MODULE_NAME}/"              #增量包输出目录
PRJ_SRC_DIR="${CUR_DIR}/project_src/${MODULE_NAME}/"    #项目源码目录
FILE_LIST="${PRJ_SRC_DIR}/filelist.txt"                 #改动文件清单

SVN_AUTH=""
if [ -n "${SVN_USERNAME}" ] && [ -n "${SVN_PASSWORD}" ];then
    SVN_AUTH="--username ${SVN_USERNAME} --password ${SVN_PASSWORD}"
fi

cd ${PRJ_SRC_DIR}

$GULP_COMMAND build -e ${ENV}

if [ "${VCS_TYPE}" == "git" ];then
	git diff --name-status ${START_VERSION} HEAD www > ${FILE_LIST}
	git diff --name-status ${START_VERSION} HEAD templates >> ${FILE_LIST}
else
	svn cleanup ${PRJ_SRC_DIR}
	svn diff -r ${START_VERSION}:HEAD www ${SVN_AUTH} --summarize --trust-server-cert --non-interactive > ${FILE_LIST}
	svn diff -r ${START_VERSION}:HEAD templates ${SVN_AUTH} --summarize --trust-server-cert --non-interactive >> ${FILE_LIST}
fi

echo '-----------------------------------------------------------------------'
cat ${FILE_LIST}
echo '-----------------------------------------------------------------------'
cd "${TOOL_DIR}"

java -jar h5-package-1112.jar ${PRJ_SRC_DIR} ${MODULE_NAME} ${ENV} ${H5_RES_VERSION} "${DOWN_URL_PREFIX}" ${OUTPUT} ${FILE_LIST} ${BUILD_NUMBER}

# 上传增量包到测试环境
node "${TOOL_DIR}/wcm_upload.js" ${MODULE_NAME} ${H5_RES_VERSION} "${UPLOAD_VERSION}" ${OUTPUT}
