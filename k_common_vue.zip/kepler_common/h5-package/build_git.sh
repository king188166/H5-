ENVIRONMENT="$1"
#增量包起始版本号
START_VERSION="$2"
#模块名 如：zed、ipos
MODULENAME="$3"
#工程根目录 如："/Users/Tiger/.jenkins/jobs/zed_app_upgrade/workspace/PAEM_H5/"
CHDIR="$4"
#H5在线资源版本号
H5_RES_VERSION="$5"
DOWN_URL_PREFIX="$6"
OUTPUT="$7"
BUILD_NUMBER="$8"
#需上传版本号
UPLOAD_VERSION="$9"
#当前保存目录
CURPWD=`pwd`

cd ${CHDIR}
echo '文件更新完成,构建项目...'
#gulp build -env ${ENVIRONMENT}
npm run build 

echo '开始打包...'
git diff --name-status ${START_VERSION} HEAD src > "${CURPWD}/filelist.txt"
git diff --name-status ${START_VERSION} HEAD static >> "${CURPWD}/filelist.txt"

cd ${CURPWD}

java -jar h5-package-1112.jar ${CHDIR} ${MODULENAME} ${ENVIRONMENT} ${H5_RES_VERSION} ${DOWN_URL_PREFIX} ${OUTPUT} filelist.txt ${BUILD_NUMBER}

# ==================Example=========================
# 本地打包,命令样例,根据参数说明修改对应参数
# ./build_git.sh TEST 02f435e726bfe340aaa613ebed350c55ae60b7a9 kepler_common /Users/zhoujun261/kepler_common/ 50160001 1++https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/kepler/keplercommonhtml/ /Users/zhoujun261/kepler_common/output/ 2
# 生产包
# ./build_git.sh PRODUCTION 6a6fe11b6c10bc46444a40bf57ecc040808f061b kepler_common /Users/zhoujun261/kepler_common/ 50160000 1++https://puhui-web.pingan.com.cn/manager/prd/paem/keplerStrategy/keplercommonhtml/ /Users/zhoujun261/kepler_common/output/prd/ 1
# ==================Example=========================


# ==================Upload Command=====================
# 上传测试环境命令,如果需要上传,取消注释即可
# node wcm_upload.js  ${MODULENAME} ${H5_RES_VERSION} "${UPLOAD_VERSION}" ${OUTPUT}
# ==================Upload Command=====================



# ==================Description=====================
# 参数说明
# STG1 ： 环境
# ad980e93877ddcc4ad904340cf43873a185d72d4： git或svn增量包起始版本号
# oloan： 模块名
# /Users/sissi/Documents/workSpace-GIT/o2o_H5/： 本地源码目录
# 20900028：当前资源号(输出资源号为20900029)
#http://test1-puhui-web.pingan.com.cn:10180/manager/stg/paem/cfs-ss/oloanhtml/ ： json资源下载地址前缀
# output/： 打包输出目录
# 111： build号
# 50200,50300：需要上传到测试环境的[模块名].json的app版本号
# ==================Description=====================
