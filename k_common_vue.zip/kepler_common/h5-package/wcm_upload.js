'use strict';

var _request = require('request');

var _request2 = _interopRequireDefault(_request);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _shelljs = require('shelljs');

var _shelljs2 = _interopRequireDefault(_shelljs);

var _zipLocal = require('zip-local');

var _zipLocal2 = _interopRequireDefault(_zipLocal);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// cookie
/**
 * @author: liuxixi186@pingan.com.cn
 * @date  : 2017-03-09
 * @time  : 下午16:10
 *
 */
var req = _request2.default.defaults({
    jar: true
});

// 账号
var account = {
    username: 'CHENMING974',
    password: 'Kpc515cU',
    SMAUTHREASON: '0'
};

// url
var loginUrl = 'http://10.55.64.120/cfswcm/login.do';
var uploadUrl = 'http://10.55.64.120/cfswcm/file/uploadFile.do';

/* 处理参数
*  node wcm_upload.js "oloan" "2090001111" "33333,44444" ""
*  ${module}  ${resourceNo}  ${version}  ${output}
*/
// 产品线模块名
var _module = process.argv[2];
// 产品线本次输出资源号
var resourceNo = parseInt(process.argv[3]) + 1;
// 需要上传[module].json的目录
var version = process.argv[4];
// jenkins打包输出H5资源目录
var output = process.argv[5];

// json文件需要放置的目录
var jsonPath = version.split(',');
// H5zip源文件路径
var h5Source = output + resourceNo;


// 如上传目录为空，退出
if (!version) {
    console.log('无需上传测试环境,完成！')
    process.exit();
}

// 处理H5资源包
_shelljs2.default.mkdir('-p', 'zip/' + resourceNo + '/' + resourceNo);
_shelljs2.default.cp('-r', h5Source, 'zip/' + resourceNo);
_shelljs2.default.cd('zip/');
console.log('copy增量包完成！');
_zipLocal2.default.sync.zip(resourceNo + '/').compress().save(resourceNo + '.zip');
console.log('压缩增量包完成！');

// 处理json
_shelljs2.default.mkdir('-p', 'updateH5');
_shelljs2.default.cd('updateH5');
for (var index in jsonPath) {
    _shelljs2.default.mkdir('-p', jsonPath[index]);
    _shelljs2.default.cp('-r', '../' + resourceNo + '/' + resourceNo + '/*.json', jsonPath[index]);
}
console.log('josn目录构建完成！');
_shelljs2.default.cd('../');
_zipLocal2.default.sync.zip('updateH5').compress().save('updateH5.zip');
console.log('josn文件压缩成功！');

// 登录
console.log('登录测试环境服务器...');
req.post(loginUrl, {
    form: {
        username: account.username,
        password: account.password,
        SMAUTHREASON: account.SMAUTHREASON
    },
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
}, function (err, resp, body) {
    if (err) {
        console.log('登录错误：', err);
        return;
    }
    console.log('登录接口返回：', body);
    // 上传H5资源包
    req.post({
        url: uploadUrl,
        formData: {
            path: '/paem/cfs-ss/' + _module + 'html/',
            isunZip: '1',
            file: _fs2.default.createReadStream(__dirname + '/zip/' + resourceNo + '.zip')
        }
    }, function (err, resp, body) {
        if (err) {
            console.log('H5增量包上传出错：', err);
            return;
        }
        console.log('H5资源上传返回结果：', body);
        // 上传文件json
        req.post({
            url: uploadUrl,
            formData: {
                path: '/paem/cfs-ss/updateH5',
                isunZip: '1',
                file: _fs2.default.createReadStream(__dirname + '/zip/updateH5.zip')
            }
        }, function (err, resp, body) {
            if (err) {
                console.log('json文件上传出错：', err);
                return;
            }
            console.log('json文件上传返回结果：', body);
            // 删除文件
            _shelljs2.default.cd('../');
            _shelljs2.default.rm('-rfR', 'zip');
            console.log('删除临时文件成功！');
        });
    });
});
