# ////////////////////////////////////////
# ////本地打包已放弃支持SVN，本文件不再维护////
# ///////////////////////////////////////

#CFS-SS环境 如：STG1,STG2,STG3,PRODUCTION
ENVIRONMENT="$1"

#增量包起始svn版本号 如：8625
SVNUPDATEFROM="$2"

#模块名 如：zed、ipos
MODULENAME="$3"

#工程根目录 如："/Users/Tiger/.jenkins/jobs/zed_app_upgrade/workspace/PAEM_H5/"
CHDIR="$4"

#H5在线资源版本号
H5_RES_VERSION="$5"

DOWN_URL_PREFIX="$6"

OUTPUT="$7"

BUILD_NUMBER="$8"

#当前保存目录
CURPWD=`pwd`

cd ${CHDIR}

#清空dist目录代码
gulp clean

#清除工程根目录
# svn cleanup ${CHDIR}

# echo '开始更新文件...'
svn up ${CHDIR} --trust-server-cert --non-interactive

#生成全量包
echo '文件更新完成,构建项目...'

gulp build -env ${ENVIRONMENT}

#路径指针回退到初始位置
cd ${CURPWD}

echo '开始打包...'
# 一般情况请添加svn指定账号保证svn命令能正常执行
svn diff -r ${SVNUPDATEFROM}:HEAD ${CHDIR}/www --summarize --trust-server-cert --non-interactive > filelist.txt
# svn diff -r %SVNUPDATEFROM%:HEAD %CHDIR%/www --username xxx --password xxx --trust-server-cert --non-interactive --summarize > filelist.txt
svn diff -r ${SVNUPDATEFROM}:HEAD ${CHDIR}/templates --summarize --trust-server-cert --non-interactive >> filelist.txt
# svn diff -r %SVNUPDATEFROM%:HEAD %CHDIR%/templates --username xxx --password xxx --trust-server-cert --non-interactive --summarize >> filelist.txt


java -jar h5-package-1112.jar ${CHDIR} ${MODULENAME} ${ENVIRONMENT} ${H5_RES_VERSION} ${DOWN_URL_PREFIX} ${OUTPUT} filelist.txt ${BUILD_NUMBER}

# rm -rf filelist.txt

# ./build_svn.sh STG1 12419 zed /Users/liujun_fenghen/workspace/PAEM_H5/branches/APP_v1.6.0/ 1017 http://test1-puhui-web.pingan.com.cn:10180/manager/stg/paem/cfs-ss/zedhtml/ output/ 111
