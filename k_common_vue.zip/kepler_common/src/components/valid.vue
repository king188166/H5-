<template>
  <section>
    <p class="supply-txt">请补充姓名(拼音)及身份证有效日期</p>
    <div class="supply-info">
      <ul>
        <li>
          <div>姓名(中文)：</div>
          <div class="box-flex">
            <input type="text" value="李四" class="sup-ipt" readOnly v-model="chineseName">
          </div>
        </li>
        <li class="input-edit">
          <label for="englishName">姓名(拼音)：</label>
          <div class="box-flex">
            <input type="text" style="ime-mode:disabled" id="englishName" value="ZHANGSAN" maxLength="200"
                   placeholder="请输入姓名拼音（例如WANGYIYI）" class="sup-ipt" v-model="englishName" @blur="onEnlishNameChange">
          </div>
        </li>
      </ul>
    </div>
    <div class="supply-info mt18">
      <ul>
        <li>
          <div>身份证号：</div>
          <div class="box-flex">
            <input type="text" value="3033***********1234" readOnly placeholder="" class="sup-ipt"
                   v-model="idCardFormate">
          </div>
        </li>
        <li class="input-edit">
          <div>身份证有效起始日期：</div>
          <div class="box-flex">
            <input id="startDate" type="text" value="2008年08月07日" placeholder="请选择日期" readOnly class="sup-ipt"
                   v-model="startDateString" @click="onDateChange">
          </div>
        </li>
        <li class="input-edit">
          <div>身份证有效截止日期：</div>
          <div class="box-flex">
            <input id="deadline" type="text" value="2018年08月08日" placeholder="请选择日期" readOnly class="sup-ipt"
                   v-model="deadlineString" @click="onDateChange">
          </div>
        </li>
      </ul>
    </div>
    <p class="supply-txt"><span class="icon-remark"></span>永久身份证有效截止日期，请选择或手动更改为：9999年12月31日</p>
    <div class="btn-content">
      <div class="btn-confirm" id="submitBtn" @click="onSubmitMessge">确定</div>
    </div>
  </section>
</template>

<script>
  import C from '../libs/common';

  export default {
    name: 'valid',

    data: function () {
      return {
        accountId: '',
        chineseName: '',
        englishName: '',
        idCard: '',
        startDate: '',
        deadline: '',
        startDateString: '',
        deadlineString: '',
        idCardFormate: ''
      };
    },

    created: function () {
      var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
      this.setState({
        accountId: userInfo.accountId || '',
        chineseName: userInfo.custName || '',
        idCard: userInfo.Id
      });

      //设置标题
      C.Native.setHeader({
        title: C.Constant.TITLE.IDCARD_VAILD
      });

      // 请求接口获取之前补录的身份信息
      this.getOtherCustomerInfo();

      this.render();
    },
    methods: {
      setState: function (obj) {
        C.Utils.extend(this._data, obj);
      },

      getOtherCustomerInfo: function () {
        var $this = this;

        $this.dataRequest({
          url: C.Api('GET_OTHER_CUSTOMER_INFO'),
          type: 'POST',
          data: {},
          success: function (res) {
            C.UI.stopLoading();
            if (res.flag === C.Flag.SUCCESS) {
              $this.setState({
                englishName: res.data.name,
                startDate: res.data.startingDate ? res.data.startingDate.replace(/-/g, '/') : '',
                deadline: res.data.endingDate ? res.data.endingDate.replace(/-/g, '/') : ''
              });
              $this.render();
            } else {
              C.Native.tip(res.msg);
            }
          }
        });
      },

      onEnlishNameChange: function (e) {
        var elem = e.target;
        var val = elem.value;
        val = val.toUpperCase();
        this.englishName = val;
      },

      onDateChange: function (e) {
        var elemId = e.target.id;
        var $this = this;
        var prevDayTime = new Date().getTime() - 24 * 60 * 60 * 1000; // 昨天的时间戳
        var afterTomorrowTime = new Date().getTime() + 24 * 60 * 60 * 1000 * 2; // 后天的时间戳
        var lastDate = elemId == 'startDate' ? (this.startDate || prevDayTime) : (this.deadline || afterTomorrowTime);

        C.Native.showDatePicker({
          // 起始begin，結束end
          mode: elemId == 'startDate' ? 'begin' : 'end',
          lastDate: $this.formateDate(lastDate),
          minDate: elemId == 'startDate' ? '' : $this.formateDate($this.startDate), // 最小可选日期不大于起始日起
          maxDate: '',
          callback: function (data) {
            var date = data.year + '/' + data.month + '/' + data.day;
            date = $this.formateDate(date, 1);
            if (elemId == 'startDate') {
              $this.setState({
                startDate: date
              });
            }
            if (elemId == 'deadline') {
              $this.setState({
                deadline: date
              });
            }
            $this.render();
          }
        });
      },

      onSubmitMessge: function (e) {
        var $this = this;
        var englishNameMsg = this.unEnglishName();
        var idCardMsg = this.unIdCardDate();
        if (englishNameMsg) {
          C.Native.tip(englishNameMsg);
          return;
        }
        if (idCardMsg) {
          C.Native.tip(idCardMsg);
          return;
        }

        // do submit
        var param = {
          name: $this.englishName,
          startingDate: $this.startDate.replace(/\//g, '-'),
          endingDate: $this.deadline.replace(/\//g, '-')
        };

        $this.dataRequest({
          url: C.Api('APPEND_OTHER_CUSTOMER_INFO'),
          type: 'POST',
          data: param,
          success: function (res) {
            if (res.flag === C.Flag.SUCCESS) {
              $this.redirectUrl(true);
            } else {
              C.Native.tip(res.msg);
            }
            C.UI.stopLoading();
          }
        });
      },

      // 重定义页面,让native监听跳转。returnCode:1,提交成功；0，提交失败。
      redirectUrl: function (bool) {
        location.search = location.search + '&returnCode=' + Number(bool);
      },

      unIdCardDate: function () {
        var reg = /^\d{4}[年]\d{2}[月]\d{2}[日]$/;
        var now = new Date(),
          // 只取年月日，用于选择的日期比较
          nowTime = new Date(now.getFullYear() + '/' + (now.getMonth() + 1) + '/' + now.getDate()).getTime(),
          nextDayTime = nowTime + 24 * 60 * 60 * 1000; //多加一天的时间戳

        var startTime = new Date(this.startDate).getTime();
        var endTime = new Date(this.deadline).getTime();
        var birthdayTime = new Date(this.getBirthDay(this.idCard)).getTime();

        // 起始日期不能小于出生日期,不能大于等于当前系统时间
        // 截止日期大于当前系统时间加一天
        if (!reg.test(this.startDateString) || startTime < birthdayTime || startTime >= nowTime) {
          return '您输入的身份证有效起始日期有误，请重新输入';
        }
        if (!reg.test(this.deadlineString) || startTime > endTime || endTime <= nextDayTime) {
          return '您输入的身份证有效截止日期有误，请重新输入';
        }
        return false;
      },

      // 通过身份证号码获取出生日期4****** 19910227 ****
      getBirthDay: function (idcard) {
        var year = idcard.substr(6, 4),
          mon = idcard.substr(10, 2),
          date = idcard.substr(12, 2);
        return year + '/' + mon + '/' + date;
      },

      // 校验英文名
      unEnglishName: function () {
        this.englishName = this.englishName && this.englishName.replace(/\s/g, '');
        var reg = /[^A-Z]/g;
        if (!this.englishName || this.englishName.match(reg)) {
          return '您输入的拼音有误，请重新输入';
        }
        if (this.englishName.length > 200) {
          return '姓名拼音不能大于200个字符';
        }
        return false;
      },

      // 重定义页面,让native监听跳转。returnCode:1,提交成功；0，提交失败。
      redirectUrl: function (bool) {
        location.search = location.search + '&returnCode=' + Number(bool);
      },

      // 将身份证号码 第5-15位字符替换成*
      formateIdcard: function (idcard) {
        if (!idcard) return '';
        var arr = idcard.split('');

        for (var i = 4; i < 14; i++) {
          arr[i] = '*';
        }
        return arr.join('');
      },

      // date 标准的date字符串格式（yy/mm/dd），或者日期类型
      formateDate: function (date, flag) {
        if (!date) return '';
        var newDate = new Date(date),
          mon = parseInt(newDate.getMonth() + 1),
          day = parseInt(newDate.getDate());
        if (flag) {
          return newDate.getFullYear() + '/' + (mon > 9 ? mon : '0' + mon) + '/' + (day > 9 ? day : '0' + day);
        }
        return newDate.getFullYear() + '年' + (mon > 9 ? mon : '0' + mon) + '月' + (day > 9 ? day : '0' + day) + '日';
      },

      logout: function(){
        var info = [C.Constant.DataKey.USER_LOGIN_INFO, C.Constant.DataKey.USER_LOAN_INFO];

        info.forEach(function (ele) {
          C.Utils.data(ele, null);
        });
      },

      // 请求函数
      dataRequest: function (opt) {
        var $this = this;
        C.UI.loading();
        // Ajax共用回调函数
        var _ajaxExt = {
          success: function(res) {
            // flag值不在whiteCode列表内，则显示提示框
            // 登录超时，跳转到登录页
            if (res.flag == C.Flag.LOGIN_TIMEOUT || res.flag == C.Flag.ERROR) {
              $this.logout();
              C.Native.dealTimeOut(res.msg);
            } else if (res.flag != C.Flag.SUCCESS) {
              C.Native.tip(res.msg);
            }
          },
          error: function() {
            C.Native.tip('网络异常，请稍后再试！');
          },
          complete: function() {
            // empty
          }
        };

        // 页面中自定义的回调函数
        var fn = {
          success: opt.success || function(data) {},
          error: opt.error || function(XMLHttpRequest, textStatus, errorThrown) {},
          complete: opt.complete || function(XHR, TS) {}
        };
        // 合并共用回调函数和页面回调函数
        var _opt = {};
        C.Utils.extend(opt, {
          // 设置默认参数
          type: opt.type || 'GET',
          data: opt.data || {},
          dataType: opt.dataType || 'json',
          timeout: opt.timeout || 60000,
          cache: opt.cache || false,
          //增加ajax开始的时间
          _startTime: +new Date(),
          success: function(data) {
            //执行页面回调函数之后再执行共用回调函数
            fn.success(data);
            _ajaxExt.success(data);
            //ajax插入dom
            _opt['_end'] = +new Date();
            window.watchTime && window.watchTime.setAjaxResouce(_opt);
          },
          error: function(XMLHttpRequest, textStatus, errorThrown) {
            fn.error(XMLHttpRequest, textStatus, errorThrown);
            _ajaxExt.error(XMLHttpRequest, textStatus, errorThrown);
            //增加ajax错误的标志
            _opt["Err"] = {content:fn.error};
            //触发ajax完成的函数
            window.watchTime && window.watchTime.setAjaxResouce(_opt);
          },
          complete: function(XHR, TS) {
            fn.complete(XHR, TS);
            _ajaxExt.complete(XHR, TS);
          }
        });
        C.Utils.extend(_opt, opt);
        // 合并共用入参和页面入参
        var loginInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
        if (loginInfo) {
          C.Utils.extend(_opt.data, {
            accountId: loginInfo.accountId,
            token: loginInfo.token,
            os: App.IS_IOS ? 'IOS' : 'A'
          });
        }
        // 执行ajax请求
        C.Native.request(_opt);
      },

      // 渲染整个view
      render: function () {
        var $this = this;
        this.setState({
          startDateString: $this.formateDate($this.startDate),
          deadlineString: $this.formateDate($this.deadline),
          idCardFormate: $this.formateIdcard($this.idCard)
        });
      }
    }
  };
</script>

<style>
  .supply-txt {
    font-size: .26rem;
    color: #727272;
    padding: .09rem .3rem
  }

  .supply-info {
    font-size: .32rem;
    border-top: 1px solid #d8d8d8
  }

  .supply-info li {
    height: .86rem;
    line-height: .86rem;
    padding: 0 .3rem;
    color: #313131;
    border-bottom: 1px solid #d8d8d8;
    background: #fff;
    display: -webkit-box
  }

  .sup-ipt {
    line-height: .6rem;
    font-size: .32rem;
    color: #313131;
    width: 100%
  }

  .supply-info .input-edit, .supply-info .input-edit .sup-ipt {
    transition: background .2s
  }

  .supply-info .input-edit:active, .supply-info .input-edit:active .sup-ipt {
    background: #ccc
  }
</style>
