define(["zepto","C","view"],function(t,a,e){"use strict";var i=e.extend({initialize:function(){var t=a.Utils.getParameter("key"),e=JSON.parse(a.Utils.AESDecrypt(t,"Decrypt"));

this.params={fundingModel:e.fundingModel,dataVersionNo:e.dataVersionNo||"v1.1"},this.CONTRACTHTML={dataVersion:{"v1.0":"api_data_transfer_contract.html",
"v1.1":"api_data_transfer_contract_1.1.html"}},window.location.href=this.CONTRACTHTML.dataVersion[this.params.dataVersionNo]+"?key="+t;

}});t(function(){new i({el:t("body")[0]})})});