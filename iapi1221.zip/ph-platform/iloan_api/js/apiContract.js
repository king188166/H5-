define(["zepto","C","view"],function(t,e,i){"use strict";var r=i.extend({initialize:function(){var t=e.Utils.getParameter("key").replace(/\s+/g,""),i=JSON.parse(e.Utils.AESDecrypt(t,"Decrypt"));

this.checkFiled(i)},checkFiled:function(i){var r=/^[\u4e00-\u9fa5]{2,10}$/g,n=/^([0-9])|(\d)(\.)(\d)+$/,a=/^(\d{4})\*{10}(\d{3})(\d|X|x)$/,c=/^[0-9a-zA-Z]+$/,o={
content:"经安全监测，发现您的手机处于危险状态，请确保手机系统安全",isAutoClose:!1};if(!r.test(i.custName))return void e.UI.warning(o);if(!n.test(i.credit))return void e.UI.warning(o);

if(!a.test(i.id))return void e.UI.warning(o);if(!c.test(i.applyNo))return void e.UI.warning(o);var s={applyNo:i.applyNo,custName:i.custName,
Id:i.id,credit:e.Utils.formatMoney(i.credit)};this.render(s),t(".auth").show()},render:function(e){t("#js-wrap-applyNo").html(_.template(t("#js-html-applyNo").html(),e)),
t("#js-wrap-contract").html(_.template(t("#js-html-contract").html(),e))}});t(function(){new r({el:t("body")[0]})})});