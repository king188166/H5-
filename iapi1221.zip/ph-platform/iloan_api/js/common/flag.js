define([],function(){var E={LOGIN_TIMEOUT:"0",LOGIN_SUCCESS:"001",ERROR:"004",SUCCESS:"1",FAIL:"2",REFRESH_CODE:"9"};return E;

});