define(["underscore","libs/aes"],function(r,e){var t={getParameter:function(r){var e=/&amp;/g,t=location.search;t=t.replace(e,"&");

var n=new RegExp("[&,?,&amp;]"+r+"=([^\\&]*)","i");t=decodeURIComponent(decodeURIComponent(t));var o=n.exec(t);return o?o[1]:"";

},getQueryMap:function(r){var e,t,n={},o=/[\?\&][^\?\&]+=[^\?\&#]+/g,p=/[\?\&]([^=\?]+)=([^\?\&#]+)/;if(r=r||location.href,
e=r.match(o),!e)return n;for(var a=0,c=e.length;c>a;a++)t=e[a].match(p),null!==t&&(n[t[1]]=t[2]);return n},formatMoney:function(r,e){
if(isNaN(r)||""==String(r)?!0:!1)return r;e=e>0&&20>=e?e:2,r=parseFloat((r+"").replace(/[^\d.-]/g,"")).toFixed(e)+"";for(var t=r.split(".")[0].split("").reverse(),n=r.split(".")[1],o="",p=0;p<t.length;p++)o+=t[p]+((p+1)%3==0&&p+1!=t.length?",":"");

return o.split("").reverse().join("")+"."+n},AESDecrypt:function(r,e){var t=r,n=CryptoJS.enc.Utf8.parse("kTKQL2c6IkK4umXq"),o=CryptoJS.enc.Utf8.parse("kTKQL2c6IkK4umXq"),p=function(r){
var e=CryptoJS.enc.Utf8.parse(r),t=CryptoJS.AES.encrypt(e,n,{iv:o,mode:CryptoJS.mode.CBC,padding:CryptoJS.pad.Pkcs7});return CryptoJS.enc.Base64.stringify(t.ciphertext);

},a=function(r){r=r.replace(/(\n)+|(\r\n)+/g,"");var e=CryptoJS.AES.decrypt(r,n,{iv:o,mode:CryptoJS.mode.CBC,padding:CryptoJS.pad.Pkcs7
});return e.toString(CryptoJS.enc.Utf8)};return"Encrypt"==e?t=p(r):"Decrypt"==e&&(t=a(r)),t}};return t});