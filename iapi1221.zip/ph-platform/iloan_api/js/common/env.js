define([],function(){var e=function(e){var n=new RegExp("[&,?,&amp;]"+e+"=([^\\&]*)","i"),s=location.search;s=decodeURIComponent(decodeURIComponent(s));

var o=n.exec(s);return o?o[1]:""};e("ssEnv").toUpperCase()&&sessionStorage.setItem("iLoan_ssEnv",e("ssEnv").toUpperCase()),
e("pafEnv").toUpperCase()&&sessionStorage.setItem("iLoan_pafEnv",e("pafEnv").toUpperCase());var n=sessionStorage.getItem("iLoan_ssEnv"),s=sessionStorage.getItem("iLoan_pafEnv"),o={
ssEnv:n||e("ssEnv").toUpperCase()||"PRODUCTION",pafEnv:s||e("pafEnv").toUpperCase()||"PRD"};return o});