!function(n,e){n.$$={extend:function(n,e){for(var o in e)e.hasOwnProperty(o)&&(n[o]=e[o])}};var o=n.App=n.$$.platformAdapter={},O=navigator.userAgent.toUpperCase();

o.IS_ANDROID=-1!=O.indexOf("ANDROID"),o.IS_IOS=-1!=O.indexOf("IPHONE OS"),o.IS_WP=-1!=O.indexOf("WINDOWS")&&-1!=O.indexOf("PHONE"),
o.IS_LOCAL="localhost"==location.hostname}(window);