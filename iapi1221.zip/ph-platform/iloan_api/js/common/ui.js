define(["zepto"],function(e){var t={};return t.warning=function(){var t,n,o,i=!1;return function(c){i||(i=!0,c=c||{},c.title=c.title||"",
c.content=c.content||"",c.okText=c.okText||"",c.ok=c.ok,c.cancelText=c.cancelText||"",c.cancel=c.cancel,c.sec=c.sec||3e3,
c.isAutoClose="undefined"==typeof c.isAutoClose?!0:!1,document.getElementById("_cfb_confirm_box")||(o=document.createElement("div"),
o.id="_cfb_confirm_box",o.style.display="none",o.innerHTML=['<div style="background-color:rgba(0,0,0,0.4);z-index:9999;position:fixed;top:0;left:0;width:100%;height:100%;">','    <div style="width:90%;top:50%;margin-top:-100px;text-align:center;position:absolute;left: 50%;margin-left: -45%;background-color: rgba(255, 255, 255, 0.9);border-radius:10px;">','    <div id="_cfb_confirm_box_title" style="color: #333;line-height: 24px;padding-top: 20px;font-size: 20px;"></div>','    <div id="_cfb_confirm_box_content" style="color: #333;line-height: 20px;font-size: 14px;padding: 10px;"></div>','    <div style="padding: 10px 0 10px 0;">',"    </div>","    </div>","</div>"].join(""),
document.body.appendChild(o),t=document.getElementById("_cfb_confirm_box_title"),n=document.getElementById("_cfb_confirm_box_content")),
t.innerHTML=c.title,n.innerHTML=c.content,o.style.display="block",c.isAutoClose&&setTimeout(function(){e(o).remove(),i=!1;

},c.sec))}}(),t});