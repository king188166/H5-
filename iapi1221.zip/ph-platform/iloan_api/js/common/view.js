define(["underscore","zepto"],function(t,e){"use strict";var n=/\s+/,s=function(t,e,s,i){if(!s)return!0;if("object"==typeof s){
for(var r in s)t[e].apply(t,[r,s[r]].concat(i));return!1}if(n.test(s)){for(var c=s.split(n),l=0,a=c.length;a>l;l++)t[e].apply(t,[c[l]].concat(i));

return!1}return!0},i=function(t,e){var n,s=-1,i=t.length,r=e[0],c=e[1],l=e[2];switch(e.length){case 0:for(;++s<i;)(n=t[s]).callback.call(n.ctx);

return;case 1:for(;++s<i;)(n=t[s]).callback.call(n.ctx,r);return;case 2:for(;++s<i;)(n=t[s]).callback.call(n.ctx,r,c);return;

case 3:for(;++s<i;)(n=t[s]).callback.call(n.ctx,r,c,l);return;default:for(;++s<i;)(n=t[s]).callback.apply(n.ctx,e)}},r=function(e,n){
var s,i=this;s=e&&t.has(e,"constructor")?e.constructor:function(){return i.apply(this,arguments)},t.extend(s,i,n);var r=function(){
this.constructor=s};return r.prototype=i.prototype,s.prototype=new r,e&&t.extend(s.prototype,e),s.__super__=i.prototype,s;

},c={on:function(t,e,n){if(!s(this,"on",t,[e,n])||!e)return this;this._events||(this._events={});var i=this._events[t]||(this._events[t]=[]);

return i.push({callback:e,context:n,ctx:n||this}),this},once:function(e,n,i){if(!s(this,"once",e,[n,i])||!n)return this;var r=this,c=t.once(function(){
r.off(e,c),n.apply(this,arguments)});return c._callback=n,this.on(e,c,i)},off:function(e,n,i){var r,c,l,a,h,o,u,f;if(!this._events||!s(this,"off",e,[n,i]))return this;

if(!e&&!n&&!i)return this._events={},this;for(a=e?[e]:t.keys(this._events),h=0,o=a.length;o>h;h++)if(e=a[h],l=this._events[e]){
if(this._events[e]=r=[],n||i)for(u=0,f=l.length;f>u;u++)c=l[u],(n&&n!==c.callback&&n!==c.callback._callback||i&&i!==c.context)&&r.push(c);

r.length||delete this._events[e]}return this},trigger:function(t){if(!this._events)return this;var e=[].slice.call(arguments,1);

if(!s(this,"trigger",t,e))return this;var n=this._events[t],r=this._events.all;return n&&i(n,e),r&&i(r,arguments),this}},l=function(e){
this.cid=t.uniqueId("view"),this._configure(e||{}),this._ensureElement(),this.initialize.apply(this,arguments),this.delegateEvents();

},a=/^(\S+)\s*(.*)$/,h=["model","collection","el","id","attributes","className","tagName","events"];return t.extend(l.prototype,c,{
tagName:"div",$:function(t){return this.$el.find(t)},initialize:function(){},render:function(){return this},remove:function(){
return this.$el.remove(),this},setElement:function(t,n){return this.$el&&this.undelegateEvents(),this.$el=t instanceof e?t:e(t),
this.el=this.$el[0],n!==!1&&this.delegateEvents(),this},delegateEvents:function(e){if(!e&&!(e=t.result(this,"events")))return this;

this.undelegateEvents();for(var n in e){var s=e[n];if(t.isFunction(s)||(s=this[e[n]]),s){var i=n.match(a),r=i[1],c=i[2];s=t.bind(s,this),
r+=".delegateEvents"+this.cid,""===c?this.$el.on(r,s):this.$el.on(r,c,s)}}return this},undelegateEvents:function(){return this.$el.off(".delegateEvents"+this.cid),
this},_configure:function(e){this.options&&(e=t.extend({},t.result(this,"options"),e)),t.extend(this,t.pick(e,h)),this.options=e;

},_ensureElement:function(){if(this.el)this.setElement(t.result(this,"el"),!1);else{var n=t.extend({},t.result(this,"attributes"));

this.id&&(n.id=t.result(this,"id")),this.className&&(n["class"]=t.result(this,"className"));var s=e("<"+t.result(this,"tagName")+">").attr(n);

this.setElement(s,!1)}}}),l.extend=r,l});