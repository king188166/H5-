define(["js/common/env","js/common/constant"],function(n,s){var t=n.ssEnv,c="";switch(console.log(t),t){case"DEVELOPMENT":
c="http://test1-cfs-phone-web.pingan.com.cn/cfsssfront";break;case"TEST":case"STG1":c="https://test1-cfs-phone-web.pingan.com.cn/cfsssfront";

break;case"STG2":c="https://test2-cfs-phone-web.pingan.com.cn/cfsssfront";break;case"STG3":c="https://test3-cfs-phone-web.pingan.com.cn/cfsssfront";

break;case"STG4":c="https://test4-cfs-phone-web.pingan.com.cn:16443/cfsssfront";break;case"STG5":c="https://test5-cfs-phone-web.pingan.com.cn:34081/cfsssfront";

break;default:c="https://cfs-phone-web.pingan.com.cn/cfsssfront"}var o="DEVELOPMENT"==t?{PLUGIN_LOGIN:c+"/V2/login/umLogin.do",
UPLOADPOSELECTRONICSIGNATURE:"data/uploadSignature.json"}:{PLUGIN_LOGIN:"/V2/login/umLogin.do",UPLOADPOSELECTRONICSIGNATURE:"/iloanApi/uploadPosElectronicSignature.do"
},e=function(n){return"DEVELOPMENT"==t?o[n]:c+o[n]};return e});