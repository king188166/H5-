define(["js/common/flag","js/common/env"],function(t,a){var e,n,o,c,s,i,b,w,p,h=a.ssEnv,m=a.pafEnv,d=!0;switch("PRODUCTION"==h?(m="PRD",
e="",n="https://eloan.pingan.com.cn/credit/xiaoanlogin/"):(d=!0,e="http://nts-tms-dmzstg1.pingan.com.cn:9027/html-dev/paem_public/publicForward.html",
n="https://114.141.178.31:12443/credit/xiaoanlogin/"),h){case"STG1":SS_HOST="https://test1-cfs-phone-web.pingan.com.cn/";
break;case"STG2":SS_HOST="https://test2-cfs-phone-web.pingan.com.cn/";break;case"STG3":SS_HOST="https://test3-cfs-phone-web.pingan.com.cn/";

break;default:SS_HOST="https://cfs-phone-web.pingan.com.cn/"}switch(m){case"STG1":o="https://test-www.stg.1qianbao.com",c="900000001493 33c6e8446a6c43a5adcf224e7e7a8d6f",
s="900000001493",i="33c6e8446a6c43a5adcf224e7e7a8d6f",b="https://test-www.stg.1qianbao.com/common-bindcard/enterview",w="https://test-www.stg.1qianbao.com/auth",
p="https://test-www.stg.1qianbao.com/token/user",PAPAY_GET_TOKEN="https://test-www.stg.1qianbao.com/token/exchange",PAPY_GET_BALANCE="https://test-www.stg.1qianbao.com/api/usersInfo/balance";

break;case"STG2":o="https://test2-www.stg.1qianbao.com:7443",c="900000009498 596ff9657dfb419c85e52eac931207b3",s="900000009498",
i="596ff9657dfb419c85e52eac931207b3",b="https://test2-www.stg.1qianbao.com:7443/common-bindcard/enterview",w="https://test2-www.stg.1qianbao.com:7443/auth",
p="https://test2-www.stg.1qianbao.com:7443/token/user",PAPAY_GET_TOKEN="https://test2-www.stg.1qianbao.com:7443/token/exchange",
PAPY_GET_BALANCE="https://test2-www.stg.1qianbao.com:7443/api/usersInfo/balance";break;case"PRD":o="http://www.1qianbao.com",
c="900000004158 2c147337721348908d69fbf4145dd50d",s="900000004158",i="2c147337721348908d69fbf4145dd50d",b="https://1qianbao.com/common-bindcard/enterview",
w="https://1qianbao.com/auth",p="https://1qianbao.com/token/user",PAPAY_GET_TOKEN="https://1qianbao.com/token/exchange",PAPY_GET_BALANCE="https://1qianbao.com/api/usersInfo/balance";

break;default:o="http://www.1qianbao.com",c="900000004158 2c147337721348908d69fbf4145dd50d",s="900000004158",i="2c147337721348908d69fbf4145dd50d",
b="https://1qianbao.com/common-bindcard/enterview",w="https://1qianbao.com/auth",p="https://1qianbao.com/token/user",PAPAY_GET_TOKEN="https://1qianbao.com/token/exchange",
PAPY_GET_BALANCE="https://1qianbao.com/api/usersInfo/balance"}var f={Flag:t,DataKey:{},TITLE:{PAEM:"公共组件"},MODULE_NAME:{home:"component"
},BANKCONTRACT:{"重庆银行":"cq","光大银行":"gd","九江银行":"jj","渤海银行":"bh"},index_page:"index.html"};return f});