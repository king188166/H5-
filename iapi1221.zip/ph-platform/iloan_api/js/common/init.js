define(["zepto","js/common/env","js/common/flag","js/common/constant","js/common/utils","js/common/ui","js/common/api"],function(e,n,o,c,t,s,a){
return function(){var c=n.ssEnv,a=e.ajax,r={success:function(n,c){var t=[o.SUCCESS];-1==e.inArray(n.flag,t)&&console.log(n.msg);

},error:function(e,n,o){s.warning({content:"网络异常，请稍后再试！"})},complete:function(){}};e.ajax=function(n){"DEVELOPMENT"==c&&(n.type="GET");

var o=(new Date,{success:n.success||function(e){},error:n.error||function(e,n,o){},complete:n.complete||function(e,n){}}),s=e.extend(n,{
type:n.type||"GET",data:n.data||{},dataType:n.dataType||"json",timeout:n.timeout||6e4,cache:n.cache||!1,crossDomain:"true",
_startTime:+new Date,success:function(e){console.log("success callback data:"+JSON.stringify(e)),o.success(e),r.success(e);

},error:function(e,n,c){o.error(e,n,c),r.error(e,n,c),s.Err={content:o.error}},complete:function(e,n){o.complete(e,n),r.complete(e,n);

}}),u=JSON.parse(t.AESDecrypt(t.getParameter("key"),"Decrypt"));e.extend(s.data,{accountId:u.accountId,token:u.token,channelId:u.channelId,
os:App.IS_IOS?"IOS":"A"}),console.log(s),a(s)}}});