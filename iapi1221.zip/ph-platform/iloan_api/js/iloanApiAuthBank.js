define(["zepto","C","fastclick","view"],function(e,t,n,a){"use strict";n.attach(document.body);var i=a.extend(_.extend({events:{
"tap #js-back":"back"},initialize:function(){var e=t.Utils.getParameter("key"),n=JSON.parse(t.Utils.AESDecrypt(e,"Decrypt"));

this.render(n)},render:function(n){var a=n.cgiBankName||n.newBank;if(a&&"1"===n.isCredit){var i=t.Constant.BANKCONTRACT[a];

e("."+i).removeClass("dn")}},back:function(){history.back()}}));e(function(){new i({el:e("body")[0]})})});