define(["zepto","C","view"],function(t,e,i){"use strict";var n=i.extend({initialize:function(){var t=e.Utils.getParameter("key"),i=JSON.parse(e.Utils.AESDecrypt(t,"Decrypt"));

this.checkFiled(i)},checkFiled:function(i){var n=/^[\u4e00-\u9fa5]{2,10}$/g,a=/^(\d{3})\*{4}(\d{4})$/,o=/^(\d{4})\*{10}(\d{3})(\d|X|x)$/,r=/^[0-9a-zA-Z]+$/,c={
content:"经安全监测，发现您的手机处于危险状态，请确保手机系统安全",isAutoClose:!1};return n.test(i.custName)&&a.test(i.mobile)&&o.test(i.id)&&r.test(i.applyNo)?(this.render(i),
void t(".auth").show()):void e.UI.warning(c)},render:function(e){t("#js-applyNo").html(e.applyNo),t("#js-wrap-contract").html(_.template(t("#js-html-contract").html(),e));

}});t(function(){new n({el:t("body")[0]})})});