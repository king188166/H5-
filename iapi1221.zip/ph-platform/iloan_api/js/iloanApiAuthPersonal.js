define(["zepto","C","fastclick","view"],function(e,n,t,a){"use strict";t.attach(document.body);var i=a.extend(_.extend({events:{
"tap #js-back":"back"},initialize:function(){var e=n.Utils.getParameter("key"),t=JSON.parse(n.Utils.AESDecrypt(e,"Decrypt"));

this.render(t)},render:function(n){if(n.fundingModel&&("U"==n.fundingModel||"D"==n.fundingModel)){var t=n.loanCompanyCode;

switch(t){case"C":e(".cq").removeClass("dn");break;case"H":e(".hn").removeClass("dn");break;default:e(".sz").removeClass("dn");

}}},back:function(){history.back()}}));e(function(){new i({el:e("body")[0]})})});