define(["zepto","C","view"],function(t,i,a){"use strict";var o=a.extend({initialize:function(){var t=i.Utils.getParameter("key").replace(/\s+/g,""),a=JSON.parse(i.Utils.AESDecrypt(t,"Decrypt"));

this.params={fundingModel:a.fundingModel,versionNo:a.versionNo,loanCompanycode:a.loanCompanyCode},this.PRODUCTION={cgiVersion:{
L:"v4.0",H:"v3.1",C:"v3.2"},version:"v1.2"},this.CONTRACTHTML={cgiContract:{"v2.0":"api_contract_cgi_2.0.html","v3.0":"api_contract_cgi_3.0.html",
"v3.1":"api_contract_cgi_3.1.html","v3.2":"api_contract_cgi_3.2.html","v4.0":"api_contract_cgi_4.html"},contract:{"v1.0":"api_contract_1.0.html",
"v1.1":"api_contract_1.1.html","v1.2":"api_contract_1.2.html"}},this.showContract()},showContract:function(){var t,a=i.Utils.getParameter("key");

t="U"===this.params.fundingModel.toUpperCase()||"D"===this.params.fundingModel.toUpperCase()?this.params.versionNo?this.CONTRACTHTML.cgiContract[this.params.versionNo]+"?key="+a:this.CONTRACTHTML.cgiContract[this.PRODUCTION.cgiVersion[this.params.loanCompanycode]]+"?key="+a:this.params.versionNo?this.CONTRACTHTML.contract[this.params.versionNo]+"?key="+a:this.CONTRACTHTML.contract[this.PRODUCTION.version]+"?key="+a,
window.location.href=t}});t(function(){new o({el:t("body")[0]})})});