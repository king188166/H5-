"use strict";function setAlertTitle(e){e&&(params=e);var t=document.getElementById("qian-input"),a=document.getElementById("img");

t.addEventListener("click",function(){testPopupDialog(20)}),a.addEventListener("click",function(){testPopupDialog(20)}),testAnySign(112321321),
testSetTemplateData()}function testSetTemplateData(){var e,t="<html><head></head><body><div id='colArea' class='pageFormContent' style='width:95%;background:#f9fbf9;display:block;'><div class='unit'><label class='fontLabel'>keyword：</label></div><div class='unit'><label class='fontLabel'>列名2：</label></div><div class='unit'><label class='fontLabel'>列名3：</label></div></div></body></html>",a=params.businessId,n="1#4000";

return e=apiInstance.setTemplate(TemplateType.HTML,t,a,n),e?(console.log("setTemplateData success"),e):(console.log("setTemplateData error"),
e)}function testAddSignatureObj(e){var t=e,a=new SignatureConfig(new Signer("李明","11011111111"),new SignRule_KeyWordV3(params.sign_keyword,120,0,1,1)),n=apiInstance.addSignatureObj(t,a);

return n?n:(alert("addSignatureObj "+t+" error"),n)}function testAnySign(e){var t,a=function(e,t,a){if(t!=CALLBACK_TYPE_START_RECORDING&&t!=CALLBACK_TYPE_STOP_RECORDING){
if(t==CALLBACK_TYPE_SIGNATURE){var n=(document.getElementById("qian-input"),document.getElementById("img")),i=document.getElementById("imgData");

n.style.display="",n.src="data:image/gif;base64,"+a,i.value=a,testGenData(),confirmTest()}else if(t==CALLBACK_TYPE_ON_PICTURE_TAKEN)document.getElementById("preview").src="data:image/gif;base64,"+a;
else if(t==CALLBACK_TYPE_ON_MEDIA_DATA){var r=document.createElement("audio");null!=r&&r.canPlayType&&r.canPlayType("audio/mpeg")&&(r.src="data:image/gif;base64,"+a,
r.play())}setAlertTitle()}};apiInstance=new AnySignApi,t=apiInstance.initAnySignApi(a,e),t||alert("init error"),t=testAddSignatureObj(20),
console.log(t),t||alert("testAddSignatureObj error"),t=apiInstance.commitConfig(),console.log(t?"Init ALL 初始化成功":"Init ALL 初始化失败");

}function testIsReadyToUpload(){alert("testIsReadyToUpload :"+apiInstance.isReadyToUpload())}function testGenData(){var e=document.getElementById("result");

try{e.value=apiInstance.getUploadDataGram()}catch(t){alert(t)}}function testPopupDialog(e){switch(apiInstance.showSignatureDialog(e)){
case RESULT_OK:break;case EC_API_NOT_INITED:alert("系统开小差，请退出重新尝试。");break;case EC_WRONG_CONTEXT_ID:alert("没有配置相应context_id的签字对象");

}}function testGetVersion(){alert(apiInstance.getVersion())}function testGetOsInfo(){alert(apiInstance.getOSInfo())}function base64encode(e){
var t,a,n,i,r,o,s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(e=utf16to8(e),n=e.length,a=0,t="";n>a;){
if(i=255&e.charCodeAt(a++),a==n){t+=s.charAt(i>>2),t+=s.charAt((3&i)<<4),t+="==";break}if(r=e.charCodeAt(a++),a==n){t+=s.charAt(i>>2),
t+=s.charAt((3&i)<<4|(240&r)>>4),t+=s.charAt((15&r)<<2),t+="=";break}o=e.charCodeAt(a++),t+=s.charAt(i>>2),t+=s.charAt((3&i)<<4|(240&r)>>4),
t+=s.charAt((15&r)<<2|(192&o)>>6),t+=s.charAt(63&o)}return t}function utf16to8(e){var t,a,n,i;for(t="",n=e.length,a=0;n>a;a++)i=e.charCodeAt(a),
i>=1&&127>=i?t+=e.charAt(a):i>2047?(t+=String.fromCharCode(224|i>>12&15),t+=String.fromCharCode(128|i>>6&63),t+=String.fromCharCode(128|i>>0&63)):(t+=String.fromCharCode(192|i>>6&31),
t+=String.fromCharCode(128|i>>0&63));return t}function confirmTest(e){var t=document.getElementById("result").value,a=document.getElementById("imgData").value;

"Y"==e&&(t="ESIGN_VERSION_1.0|"+base64encode(params.sign_keyword)+"|"+base64encode(params.businessId)+"|"+base64encode(t));

var n=a,i="",r="";$("#anysign_sign_01").find("p").each(function(e,t){var a=t.innerHTML.replace(/\n/g,"");r=r+a+"&"}),""!=r&&(i=r+"#");

var o="";$("#anysign_sign_02").find("p").each(function(e,t){var a=t.innerHTML.replace(/\n/g,"");o=o+a+"&"}),""!=o&&(i=i+o+"#");

var s="";return $("#anysign_sign_03").find("p").each(function(e,t){var a=t.innerHTML.replace(/\n/g,"");s=s+a+"&"}),""!=o&&(i=i+s+"#"),
{imageData:n,signData:t,p:i,signKey:"13524242834"}}var apiInstance,params;"function"==typeof define&&define.amd&&define([],function(){
return{init:setAlertTitle,toJSON:confirmTest}});