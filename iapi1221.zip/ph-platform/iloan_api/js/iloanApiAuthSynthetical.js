define(["zepto","C","fastclick","view"],function(t,e,n,a){"use strict";n.attach(document.body);var i=a.extend(_.extend({events:{
"tap #js-back":"back"},initialize:function(){var t=e.Utils.getParameter("key"),n={loanCompanyCode:JSON.parse(e.Utils.AESDecrypt(t,"Decrypt")).loanCompanyCode
};this.render(n)},render:function(e){t("#js-auth-synthetical").html(_.template(t("#js-auth-synthetical-L").html(),e))},back:function(){
history.back()}}));t(function(){new i({el:t("body")[0]})})});