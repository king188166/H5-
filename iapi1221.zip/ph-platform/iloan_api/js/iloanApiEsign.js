define(["zepto","C","view","fastclick","js/dosign"],function(t,a,i,n,e){"use strict";n.attach(document.body);var s=i.extend(_.extend({
events:{"tap #cancel":"btnCancel","tap #clear":"btnClear","tap #agreed":"submitEsign","tap #js-contract-synthetical":"toSyntheticalAuth",
"tap #js-contract-personal":"toPersonalAuth","tap #js-contract-synthetical-cgi":"toSyntheticalCgiAuth","tap #bank_contract_title":"toBankAuth"
},initialize:function(){this.barCode="iloan"+Math.round(1e3*Math.random())+(new Date).getTime(),this.config={businessId:this.barCode,
sign_keyword:"授权人（签字）："},this.isSafeLink("successLink")&&this.isSafeLink("failLink")&&(this.getQueryParams(),this.render(this.paramsObj));

},isSafeLink:function(t){var i=/javascript|<|>/gi;return i.test(a.Utils.getParameter(t))?(a.UI.warning({content:"经安全监测，发现您的手机处于危险状态，请确保手机系统安全",
isAutoClose:!1}),!1):!0},getQueryParams:function(){this.forwardParams=a.Utils.getParameter("key").replace(/\s+/g,"");var i=JSON.parse(a.Utils.AESDecrypt(this.forwardParams,"Decrypt"));

console.log(i),i.successLink?(this.successLink=i.successLink,this.failLink=i.failLink):(i.successLink=this.successLink=a.Utils.getParameter("successLink"),
i.failLink=this.failLink=a.Utils.getParameter("failLink")),this.forwardParams=a.Utils.AESDecrypt(JSON.stringify(i),"Encrypt");

var n={eType:i.eType,fundingModel:i.fundingModel,signElectSw:i.signElectSw||"Y",cgiBankName:i.cgiBankName,loanCompanyCode:i.loanCompanyCode,
isCredit:i.isCredit,ratio:i.ratio||"",newBank:i.newBank||"",bankCode:i.bankCode||"",applyNo:i.applyNo||"",payApplyNo:i.payApplyNo||""
};this.paramsObj=n,t(".auth").show()},render:function(i){var n=new Date,s=parseInt(n.getMonth())+1;if(i.today=n.getFullYear()+"-"+s+"-"+n.getDate(),
t("#contract_preview").html(_.template(t("#js-contract-pre").html(),i)),"UP"===i.eType.toUpperCase()&&t(".isShow").addClass("dn"),
"N"===i.signElectSw?t("#qian-input").html("同意并授权"):e.init(this.config),i.fundingModel&&i.isCredit&&"U"==i.fundingModel&&"1"==i.isCredit||i.newBank){
var o=a.Constant.BANKCONTRACT[i.cgiBankName]||a.Constant.BANKCONTRACT[i.newBank];t("."+o).removeClass("dn")}t("#contract_preview").show();

},submitEsign:function(){if(sign_confirm(),!t("#result").val().length)return void a.UI.warning({content:"您还没有签名，无法进行下一步！"
});var i=e.toJSON("Y");this.imgBytes=i.imageData,this.imgDenseStr=i.signData;var n={};"Y"===this.paramsObj.signElectSw&&(n.imgDenseStr=this.imgDenseStr,
n.imgBytes=this.imgBytes),n.loanCompanyCode=this.paramsObj.loanCompanyCode,n.platform=App.IS_IOS?"IOS":"A",n.businessNo=this.barCode,
n.fundingModel=this.paramsObj.fundingModel,n.cgiBankName=this.paramsObj.cgiBankName,n.ratio=this.paramsObj.ratio,n.productId="ILOANBT",
n.ocrKey="N",n.ocrNeed="Y",n.isDomesticAlgorithm="Y",n.bankName=this.paramsObj.newBank,n.bankCode=this.paramsObj.bankCode,
n.applyNo=this.paramsObj.applyNo,n.payApplyNo=this.paramsObj.payApplyNo,n.eType=this.paramsObj.eType,t(".shadding").show();

var s=this;t.ajax({url:a.Api("UPLOADPOSELECTRONICSIGNATURE"),type:"post",data:{jsonPara:JSON.stringify(n)},success:function(a){
t("#qian-input").hide(),t("#result").val(""),window.location.href="1"==a.flag?s.successLink:s.failLink},complete:function(){
t(".shadding").hide()}})},btnCancel:function(){cancelSign()},btnClear:function(){clear_canvas()},toPersonalAuth:function(){
window.location.href="iloan_api_auth_personal.html?key="+this.forwardParams},toSyntheticalAuth:function(){window.location.href="iloan_api_auth_synthetical.html?key="+this.forwardParams;

},toSyntheticalCgiAuth:function(){window.location.href="iloan_api_auth_synthetical_cgi.html?key="+this.forwardParams},toBankAuth:function(){
window.location.href="iloan_api_auth_bank.html?key="+this.forwardParams}}));t(function(){new s({el:t("body")[0]})})});