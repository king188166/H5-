define(["underscore","libs/aes"],function(e,r){var n={getParameter:function(e){var r=/&amp;/g,n=location.search;n=n.replace(r,"&");

var t=new RegExp("[&,?,&amp;]"+e+"=([^\\&]*)","i");n=decodeURIComponent(decodeURIComponent(n));var a=t.exec(n);return a?a[1]:"";

},getQueryMap:function(e){var r,n,t={},a=/[\?\&][^\?\&]+=[^\?\&#]+/g,c=/[\?\&]([^=\?]+)=([^\?\&#]+)/;if(e=e||location.href,
r=e.match(a),!r)return t;for(var o=0,i=r.length;i>o;o++)n=r[o].match(c),null!==n&&(t[n[1]]=n[2]);return t},formatMoney:function(e,r){
if(isNaN(e)||""==String(e)?!0:!1)return e;r=r>0&&20>=r?r:2,e=parseFloat((e+"").replace(/[^\d.-]/g,"")).toFixed(r)+"";for(var n=e.split(".")[0].split("").reverse(),t=e.split(".")[1],a="",c=0;c<n.length;c++)a+=n[c]+((c+1)%3==0&&c+1!=n.length?",":"");

return a.split("").reverse().join("")+"."+t},AESDecrypt:function(e,r){var n=e;if(window.CryptoJS){var t=window.CryptoJS,a=t.enc.Utf8.parse("kTKQL2c6IkK4umXq"),c=t.enc.Utf8.parse("kTKQL2c6IkK4umXq"),o=function(e){
var r=t.enc.Utf8.parse(e),n=t.AES.encrypt(r,a,{iv:c,mode:t.mode.CBC,padding:t.pad.Pkcs7});return t.enc.Base64.stringify(n.ciphertext);

},i=function(e){e=e.replace(/\\n/g,"");var r=t.AES.decrypt(e,a,{iv:c,mode:t.mode.CBC,padding:t.pad.Pkcs7});return r.toString(t.enc.Utf8);

};"Encrypt"==r?n=o(e):"Decrypt"==r&&(n=i(e))}return n}};return n});