var gulp = require('gulp');
var gutil = require('gulp-util');
var chalk = require('chalk');
var fs = require('fs');
var _ = require('underscore');
var path = require('path');
var amdOptimize = require("amd-optimize");
var concat = require('gulp-concat');
var rimraf = require('gulp-rimraf');
var uglify = require('gulp-uglify');
var through2 = require("through2");
var ejs = require("gulp-ejs");
var less = require('gulp-less');
var minifyCSS = require('gulp-minify-css');
var runSequence = require('run-sequence');
var zip = require('gulp-zip');
var eslint = require('gulp-eslint');

var pkg = require('./package.json');
var BUILD_TIMESTAMP = gutil.date(new Date(), 'yyyymmddHHMMss');
pkg.build = BUILD_TIMESTAMP;

// 设置默认工作目录为./www
process.chdir('www');

// 获取env
var argv = process.argv.slice(2);
var env = 'PRODUCTION';
(function() {
    if((envIndex = argv.indexOf("-env"))!=-1) {
        var envValue = argv[envIndex+1];
        var envs = ['DEVELOPMENT', 'TEST', 'STG2', 'STG3', 'PRODUCTION'];
        if(envValue && envs.indexOf(envValue)!=-1) {
            env = 'TEST';
        }
    }
})();

var CONTEXT_PATH = '';
if(env != 'DEVELOPMENT') {
    CONTEXT_PATH = '';
    console.log(CONTEXT_PATH);
}

gutil.log(
      'Working directory :',
      chalk.magenta(__dirname + '/www')
);

var paths = {
    src: '.',
    dest: '../dist',
    output: '../output',
    templates: '../templates',
    lintDir: '../report/lint'
}

 /*
 ** 通过eslint检查代码格式
 **/
gulp.task('lint', ['mklintdir'], function() {
    var fileName = BUILD_TIMESTAMP + '.html';
    return gulp.src(['./js/**/*.js', '!./js/common/*.js', '!./js/dosign.js', '!./js/iloanApiEsign.js'])
            .pipe(eslint({configFle: __dirname+ '/.eslintrc'}))
            .pipe(eslint.format('html', fs.createWriteStream(path.join(paths.lintDir, fileName))))
            .pipe(eslint.format())
            .pipe(eslint.failAfterError());
});

/**
 * 生成代码检查报告目录
 **/
gulp.task('mklintdir', function() {
    var mkdirsSync = function(dirname) {
        if(fs.existsSync(dirname)) {
            return true;
        } 
        if(mkdirsSync(path.dirname(dirname))) {
            fs.mkdirSync(dirname);
            return true;
        }
        
    };
    mkdirsSync(paths.lintDir);
});

/*
* 清空目标工程目录
*/
gulp.task('clean', function() {
  return gulp.src(paths.dest + '/*', { read: false })
    .pipe(rimraf({ force: true }));
});

/*
* 拷贝文件到目标工程目录
*/
gulp.task('copy', function() {
   return gulp.src([
            paths.src + '/**/*',
            '!' + paths.src + '/data',
            '!' + paths.src + '/less'
        ])
        .pipe(gulp.dest(paths.dest));
});

/*
* 拷贝源文件文件到目标工程目录
*/
gulp.task('source', function() {_
   return gulp.src(paths.src + '/js/**/*.js')
        .pipe(gulp.dest(paths.dest + '/src/js'));
});

/*
* 编译ejs页面
*/
gulp.task('ejs', function() {
    return gulp.src([paths.templates + '/**/*.ejs', '!' + paths.templates + '/include/**/*.ejs'])
        .pipe(ejs({
            ctx: CONTEXT_PATH,
            _build:{
                pkg: pkg,
                version: pkg.version
            },
            data: {},
            delimiter: '@'
        }, {
            root: __dirname + '/templates'
        }))
        .pipe(gulp.dest('.', { cwd: paths.dest }));
})

/*
* 编译less
*/
gulp.task('less', function() {
    return gulp.src(paths.src + '/less/*.less')
        .pipe(less({
            paths: [ path.join(__dirname, 'less', 'includes') ]
        }))
        .pipe(minifyCSS())
        .pipe(gulp.dest(paths.src + '/css'));
});

/*
* 编译压缩css
*/
gulp.task('minifycss', function() {
    return gulp.src(paths.src + '/css/**/*.css')
        .pipe(minifyCSS())
        .pipe(gulp.dest(paths.dest + '/css'));
});

/*
* 编译压缩js
*/
gulp.task('uglifyjs', function() {
    return gulp.src([
            paths.dest + '/js*/**/*.js',
            paths.dest + '/libs*/require-config.js'
        ])
        .pipe(uglify({output: {max_line_len:120}}).on("error", gutil.log))
        .pipe(gulp.dest(paths.dest));
});

/*
* require js 优化
*/
gulp.task('js_optimize', function() {
    // 优化common
    gulp.src(paths.src + '/js/**/*.js')
        .pipe(amdOptimize('C', {
            configFile: paths.src + '/libs/require-config.js',
            exclude: ['zepto', 'ko', 'underscore', 'fastclick']
        }))
        // 合并
        .pipe(concat('common.js'))
        .pipe(uglify().on('error', gutil.log))
        // 输出
        .pipe(gulp.dest(paths.dest + '/js/common'));

    // 优化zepto
    gulp.src(paths.src + '/libs/**/*.js')
        .pipe(amdOptimize('zepto', {
            configFile: paths.src + '/libs/require-config.js'
        }))
        // 合并
        .pipe(concat('zepto.js'))
        .pipe(uglify().on('error', gutil.log))
        // 输出
        .pipe(gulp.dest(paths.dest + '/libs'));
});

/*
* 打包zip
*/
gulp.task('archive', function() {
    return gulp.src(paths.dest + '/**/*')
        .pipe(zip(pkg.name + '_v_' + pkg.version.replace(/\./g, '_') + '_' + env.toLowerCase() + '_' + BUILD_TIMESTAMP + '.zip'))
        .pipe(gulp.dest(paths.output));
});

gulp.task('watch', function() {
    gulp.watch(paths.src + '/less/**/*.less', ['less']);
});

/**
 * 清空dist目录不必要文件
 */
gulp.task('cleanDist', function() {
    return gulp.src([paths.dest + '/less', paths.dest + '/data', paths.dest + '/src'])
        .pipe(rimraf({ force: true}));
});

/*
* 开始构建
*/
gulp.task('build', ['lint'], function(callback) {
    var args = [
        'clean',
        'copy',
        'ejs',
        'source',
        'js_optimize',
        'uglifyjs',
        'less',
        'minifycss',
        'cleanDist',
        'archive',
        function(error) {
            if(error) {
                console.log(error.message);
            } else {
                console.log('RELEASE FINISHED SUCCESSFULLY');
            }
            callback(error);
        }];
    //非生产包 去掉js压缩  方便调试
    if (env !== 'PRODUCTION') {
        args.splice(4, 2);
    }
    runSequence.apply(this, args);
});
