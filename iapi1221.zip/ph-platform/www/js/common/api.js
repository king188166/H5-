/*!
 * 环境变量，是Common模块的一部分
 * @module env
 * @require js/common/env 根据环境变量返回API
 */
define([
    "js/common/env",
    "js/common/constant"
    ],function(envJson,Constant){
    var env = envJson.ssEnv;
    var prefix = "";
    console.log(env);
    switch(env){  // ss服务器地址
        case "DEVELOPMENT" :
            prefix = "http://test1-cfs-phone-web.pingan.com.cn/cfsssfront";
            break;
        case "TEST" : case "STG1":
            prefix = "https://test1-cfs-phone-web.pingan.com.cn/cfsssfront";
            break;
        case "STG2":
            prefix = "https://test2-cfs-phone-web.pingan.com.cn/cfsssfront";
            break;
        case "STG3":
            prefix = "https://test3-cfs-phone-web.pingan.com.cn/cfsssfront";
            break;
        case "STG4":
            prefix = "https://test4-cfs-phone-web.pingan.com.cn:16443/cfsssfront";
            break;
        case "STG5":
            prefix = "https://test5-cfs-phone-web.pingan.com.cn:34081/cfsssfront";
            break;
        default:
            prefix = "https://cfs-phone-web.pingan.com.cn/cfsssfront";
    }
    var api = env == "DEVELOPMENT" ? {
        //本地开发环境模拟JSON
        PLUGIN_LOGIN                :prefix+'/V2/login/umLogin.do',
        //电子签名
        UPLOADPOSELECTRONICSIGNATURE    : 'data/uploadSignature.json'
    }:{
        PLUGIN_LOGIN                : '/V2/login/umLogin.do',
        //电子签名
        UPLOADPOSELECTRONICSIGNATURE    : '/iloanApi/uploadPosElectronicSignature.do'
    };
    var getUrl = function(name){
        return env=="DEVELOPMENT" ? (api[name]) : (prefix + api[name]);
    };
    return getUrl
});
