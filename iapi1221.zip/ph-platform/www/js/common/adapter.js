;(function(window, undefined) {
    window.$$ = {extend:function(n,o){for(var i in o)o.hasOwnProperty(i)&&(n[i]=o[i])}};

    var App = window.App = window.$$.platformAdapter = {};

    /**
     * 常量定义
     */
    var ua = navigator.userAgent.toUpperCase();
    // 当前环境是否为Android平台
    App.IS_ANDROID = ua.indexOf('ANDROID') != -1;
    // 当前环境是否为IOS平台
    App.IS_IOS = ua.indexOf('IPHONE OS') != -1;
    // 当前环境是否为WP平台
    App.IS_WP = ua.indexOf('WINDOWS') != -1 && ua.indexOf('PHONE') != -1;
    //当前环境是否为本地开发浏览器环境
    App.IS_LOCAL = (location.hostname=="localhost");

}(window));
