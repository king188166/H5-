/*!
 * ui模块 common子模块
 * @module ui
 * @author 周一平 
 * @history 2015-6-10 add
 */
define(['zepto'], function($) {
    var ui = {};
    // 带确定的提示框
    ui.warning = (function() {
        var title, content, wrap, active = false;
        return function(opt) {
            if (active) return;
            active = true;
            opt = opt || {};
            opt.title = opt.title || '';
            opt.content = opt.content || '';
            opt.okText = opt.okText || '';
            opt.ok = opt.ok;
            opt.cancelText = opt.cancelText || '';
            opt.cancel = opt.cancel;
            opt.sec = opt.sec || 3000;
            opt.isAutoClose = (typeof opt.isAutoClose === 'undefined') ? true: false; // 是否自动关闭
            if (!document.getElementById('_cfb_confirm_box')) {
                wrap = document.createElement('div');
                wrap.id = '_cfb_confirm_box';
                wrap.style.display = 'none';
                wrap.innerHTML = ['<div style="background-color:rgba(0,0,0,0.4);z-index:9999;position:fixed;top:0;left:0;width:100%;height:100%;">',
                    '    <div style="width:90%;top:50%;margin-top:-100px;text-align:center;position:absolute;left: 50%;margin-left: -45%;background-color: rgba(255, 255, 255, 0.9);border-radius:10px;">',
                    '    <div id="_cfb_confirm_box_title" style="color: #333;line-height: 24px;padding-top: 20px;font-size: 20px;"></div>',
                    '    <div id="_cfb_confirm_box_content" style="color: #333;line-height: 20px;font-size: 14px;padding: 10px;"></div>',
                    '    <div style="padding: 10px 0 10px 0;">',
                    '    </div>',
                    '    </div>',
                    '</div>'
                ].join('');
                document.body.appendChild(wrap);
                title = document.getElementById('_cfb_confirm_box_title');
                content = document.getElementById('_cfb_confirm_box_content');
            }
            title.innerHTML = opt.title;
            content.innerHTML = opt.content;
            wrap.style.display = 'block';
            if (opt.isAutoClose) {
                setTimeout(function() {
                    $(wrap).remove();
                    active = false;
                }, opt.sec);
            }
        };
    })();

    return ui;
});