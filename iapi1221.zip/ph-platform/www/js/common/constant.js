/*!
 * constant 模块常量
 * @module constant
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
    "js/common/flag", "js/common/env"
    ], function(
        Flag,
        EnvJson
    ) {

    /* 平安付配置项 */
    var Env = EnvJson.ssEnv ,PAPAY_ENV = EnvJson.pafEnv,Change_Url,phoneOauth_Url,
        PAPAY_HOST, PAPAY_AUTH, PAPAY_APP_ID, PAPAY_SECRET, PAPAY_BIND_CARD, PAPAY_BIND_YQB, PAPAY_GET_YQB_ACCOUNT,
        DEBUG_MODE = true;
    if (Env == "PRODUCTION") {
        PAPAY_ENV = "PRD";
        Change_Url = "";
        phoneOauth_Url = "https://eloan.pingan.com.cn/credit/xiaoanlogin/";
    }else{
        DEBUG_MODE = true;
        Change_Url = "http://nts-tms-dmzstg1.pingan.com.cn:9027/html-dev/paem_public/publicForward.html";
        phoneOauth_Url = "https://114.141.178.31:12443/credit/xiaoanlogin/"
    }
    switch(Env) {
        case 'STG1':
            SS_HOST = 'https://test1-cfs-phone-web.pingan.com.cn/';
            break;
        case 'STG2':
            SS_HOST = 'https://test2-cfs-phone-web.pingan.com.cn/';
            break;
        case 'STG3':
            SS_HOST = 'https://test3-cfs-phone-web.pingan.com.cn/';
            break;
        default:
            SS_HOST = 'https://cfs-phone-web.pingan.com.cn/';
    }
    switch (PAPAY_ENV) {
        case "STG1":
            PAPAY_HOST = "https://test-www.stg.1qianbao.com";
            PAPAY_AUTH = "900000001493 33c6e8446a6c43a5adcf224e7e7a8d6f";
            PAPAY_APP_ID = "900000001493";
            PAPAY_SECRET = "33c6e8446a6c43a5adcf224e7e7a8d6f";
            PAPAY_BIND_CARD = "https://test-www.stg.1qianbao.com/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://test-www.stg.1qianbao.com/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://test-www.stg.1qianbao.com/token/user";
            PAPAY_GET_TOKEN = "https://test-www.stg.1qianbao.com/token/exchange";
            PAPY_GET_BALANCE = "https://test-www.stg.1qianbao.com/api/usersInfo/balance";
            break;
        case "STG2":
            PAPAY_HOST = "https://test2-www.stg.1qianbao.com:7443";
            PAPAY_AUTH = "900000009498 596ff9657dfb419c85e52eac931207b3";
            PAPAY_APP_ID = "900000009498";
            PAPAY_SECRET = "596ff9657dfb419c85e52eac931207b3";
            PAPAY_BIND_CARD = "https://test2-www.stg.1qianbao.com:7443/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://test2-www.stg.1qianbao.com:7443/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://test2-www.stg.1qianbao.com:7443/token/user";
            PAPAY_GET_TOKEN = "https://test2-www.stg.1qianbao.com:7443/token/exchange";
            PAPY_GET_BALANCE = "https://test2-www.stg.1qianbao.com:7443/api/usersInfo/balance";
            break;
        case "PRD":
            PAPAY_HOST = "http://www.1qianbao.com";
            PAPAY_AUTH = "900000004158 2c147337721348908d69fbf4145dd50d";
            PAPAY_APP_ID = "900000004158";
            PAPAY_SECRET = "2c147337721348908d69fbf4145dd50d";
            PAPAY_BIND_CARD = "https://1qianbao.com/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://1qianbao.com/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://1qianbao.com/token/user";
            PAPAY_GET_TOKEN = "https://1qianbao.com/token/exchange";
            PAPY_GET_BALANCE = "https://1qianbao.com/api/usersInfo/balance";
            break;
        default:
            PAPAY_HOST = "http://www.1qianbao.com";
            PAPAY_AUTH = "900000004158 2c147337721348908d69fbf4145dd50d";
            PAPAY_APP_ID = "900000004158";
            PAPAY_SECRET = "2c147337721348908d69fbf4145dd50d";
            PAPAY_BIND_CARD = "https://1qianbao.com/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://1qianbao.com/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://1qianbao.com/token/user";
            PAPAY_GET_TOKEN = "https://1qianbao.com/token/exchange";
            PAPY_GET_BALANCE = "https://1qianbao.com/api/usersInfo/balance";
            break;
    }

    var Constant = {
        Flag:Flag,
        DataKey:{
        },
        // 页面标题设置
        TITLE: {
            PAEM: '公共组件',
        },
        /**
         * 配置模块名称
         * */
        MODULE_NAME: {
            home: "component"
        },
        /*银行对应的 授权书*/
        BANKCONTRACT:{
            '重庆银行': 'cq',
            '光大银行': 'gd',
            '九江银行': 'jj',
            '渤海银行': 'bh'
        },
        index_page: "index.html"
    };
    return Constant;
});
