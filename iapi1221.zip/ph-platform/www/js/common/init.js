/*!
 * 初始化 common子模块
 * @module init
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
    "zepto",
    "js/common/env",
    "js/common/flag",
    "js/common/constant",
    "js/common/utils",
    "js/common/ui",
    "js/common/api"
    ],function(
        $,
        EnvJson,
        Flag,
        Constant,
        Utils,
        UI,
        Api
        ){
    return function(){
        var Env = EnvJson.ssEnv;
        //备份ajax方法
        var _ajax = $.ajax;
        // Ajax共用回调函数
        var _ajaxExt = {
            success: function(res, url) {
                // flag值不在whiteCode列表内，则显示提示框
                var whiteCode = [Flag.SUCCESS];
                if ($.inArray(res.flag, whiteCode) == -1) {
                    // UI.warning({content: res.msg});
                    console.log(res.msg);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // console.log('XMLHttpRequest '+ XMLHttpRequest+'textStatus '+textStatus+'errorThrown '+errorThrown);
                UI.warning({content: '网络异常，请稍后再试！'});
            },
            complete: function() {
                // empty
            }
        };
        $.ajax = function(opt) {
            if (Env == 'DEVELOPMENT') {
                opt.type = 'GET';
            }
            var startTimeStamp = new Date();
            // 页面中自定义的回调函数
            var fn = {
                success: opt.success || function(data) {},
                error: opt.error || function(XMLHttpRequest, textStatus, errorThrown) {},
                complete: opt.complete || function(XHR, TS) {}
            };
            // 合并共用回调函数和页面回调函数
            var _opt = $.extend(opt, {
                // 设置默认参数
                type: opt.type || 'GET',
                data: opt.data || {},
                dataType: opt.dataType || 'json',
                timeout: opt.timeout || 60000,
                cache: opt.cache || false,
                crossDomain: 'true',
                //增加ajax开始的时间
                _startTime: +new Date(),
                success: function(data) {
                    console.log('success callback data:' + JSON.stringify(data));
                    //执行页面回调函数之后再执行共用回调函数
                    fn.success(data);
                    _ajaxExt.success(data);
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    fn.error(XMLHttpRequest, textStatus, errorThrown);
                    _ajaxExt.error(XMLHttpRequest, textStatus, errorThrown);
                    //增加ajax错误的标志
                    _opt["Err"] = {content:fn.error};
                },
                complete: function(XHR, TS) {
                    fn.complete(XHR, TS);
                    _ajaxExt.complete(XHR, TS);
                }
            });
            var keys = JSON.parse(Utils.AESDecrypt(Utils.getParameter('key'), 'Decrypt'));
            $.extend(_opt.data, {
                accountId: keys.accountId,
                token: keys.token,
                channelId: keys.channelId,
                os: App.IS_IOS ? 'IOS' : 'A'
            });
            console.log(_opt);
            // 执行ajax请求
            _ajax(_opt);
        };
    };
});
