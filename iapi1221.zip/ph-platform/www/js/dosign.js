// define('dosign', ['C'], function (C) {
    'use strict';
    //集成签名
    var apiInstance;
    var params;

    function setAlertTitle(config) {
        if(!!config) {
            params = config;
        }
        var oInput = document.getElementById('qian-input');
        var oImg = document.getElementById('img');
        oInput.addEventListener('click', function () {
            testPopupDialog(20);
        });
        oImg.addEventListener('click', function () {
            testPopupDialog(20);
        });

        testAnySign(112321321);
        testSetTemplateData();
    }


    //配置模板数据
    function testSetTemplateData() {
        var formData = '<html><head></head><body><div id=\'colArea\' class=\'pageFormContent\' style=\'width:95%;background:#f9fbf9;display:block;\'><div class=\'unit\'><label class=\'fontLabel\'>keyword：</label></div><div class=\'unit\'><label class=\'fontLabel\'>列名2：</label></div><div class=\'unit\'><label class=\'fontLabel\'>列名3：</label></div></div></body></html>';
        var businessId = params.businessId;//集成信手书业务的唯一标识
        var template_serial = '1#4000';//用于生成PDF的模板ID
        var channel = '10010';//渠道号，由信手书提供，请咨询项目经理
        var res;
        //配置JSON格式签名原文
        res = apiInstance.setTemplate(TemplateType.HTML, formData, businessId, template_serial);
        //res = apiInstance.setTemplate(TemplateType.PDF,formData,businessId,template_serial);
        if (res) {
            console.log('setTemplateData success');
            return res;
        }
        else {
            console.log('setTemplateData error');
            return res;
        }
    }

    //添加签名框
    function testAddSignatureObj(objId) {
        var context_id = objId;
        var signatureConfig = new SignatureConfig(new Signer('李明', '11011111111'), new SignRule_KeyWordV3(params.sign_keyword, 120, 0, 1, 1));

        var res = apiInstance.addSignatureObj(context_id, signatureConfig);
        if (res) {
            // alert('addSignatureObj '+context_id+' success');
            return res;
        }
        else {
            alert('addSignatureObj ' + context_id + ' error');
            return res;
        }
    }


    //demo总入口
    function testAnySign(channel) {
        var res;
        var callback = function (context_id, context_type, val) {
            if (context_type == CALLBACK_TYPE_START_RECORDING || context_type == CALLBACK_TYPE_STOP_RECORDING) {
                return;
            }

            if (context_type == CALLBACK_TYPE_SIGNATURE) {
                //签名回显
                var oInput = document.getElementById('qian-input');
                var oQmwc = document.getElementById('img');
               // var decline = document.getElementById('decline');
                var imgData = document.getElementById('imgData');
                // oInput.style.display = 'none';
               // decline.style.display = 'none';
                oQmwc.style.display = '';
                oQmwc.src = 'data:image/gif;base64,' + val;
                //oQmwc.src = val;
                imgData.value = val;
                testGenData();//生成加密字符串
                confirmTest();//进行CA验证
            }
            else if (context_type == CALLBACK_TYPE_ON_PICTURE_TAKEN) {
                document.getElementById('preview').src = 'data:image/gif;base64,' + val;
            } else if (context_type == CALLBACK_TYPE_ON_MEDIA_DATA) {
                var audio = document.createElement('audio');
                if (audio != null && audio.canPlayType && audio.canPlayType('audio/mpeg')) {
                    audio.src = 'data:image/gif;base64,' + val;
                    audio.play();
                }
            }

            setAlertTitle();
            //alert('收到浏览器回调：' + 'context_id：' + context_id + ' context_type：' + context_type + ' value：' + val);
        };//测试回调，将回调数据显示

        ////////////////////////////////////////////////
        apiInstance = new AnySignApi();

        //初始化签名接口
        res = apiInstance.initAnySignApi(callback, channel);

        if (!res) {
            alert('init error');
        } else {

        }
        ////////////////////////////////////////////////

        //注册单字签字对象20
        res = testAddSignatureObj(20);
        console.log(res);
        if (!res) {
            alert('testAddSignatureObj error');
        } else {

        }
        ////////////////////////////////////////////////

        //注册一个单位签章

        //var cachet_config = new CachetConfig(new Signer('小明', '110xxxxxx'), new SignRule_Tid('1121_cachet'), true);

        //res = apiInstance.addChachetObj(cachet_config);
        //var signer = new Signer(userData.custName,userData.Id);
        /**
         * 使用服务器规则配置签名
         * @param tid 服务器端生成的配置规则
         * @constructor
         */
        // var signerRule = new SignRule_Tid('1121_cachet');
        // var cachet_config = new CachetConfig(signer, signerRule, false);

        // res = apiInstance.addCachetObj(cachet_config);
        ////////////////////////////////////////////////

        // if (!res) {
        //     alert('addChachetObj error');
        // } else {

        // }
        ////////////////////////////////////////////////

        //将配置提交
        res = apiInstance.commitConfig();

        if (res) {
            //alert('Init ALL 初始化成功');
            console.log('Init ALL 初始化成功');
        } else {
            //alert('Init ALL 初始化失败');
            console.log('Init ALL 初始化失败');
        }

        ////////////////////////////////////////////////

    }


    function testIsReadyToUpload() {
        alert('testIsReadyToUpload :' + apiInstance.isReadyToUpload());
    }

    //生成签名加密数据
    function testGenData() {
        var res = document.getElementById('result');

        try {
            res.value = apiInstance.getUploadDataGram();
        }
        catch (err) {
            alert(err);
        }
    }

    //弹出签名框签名
    function testPopupDialog(context_id) {
        switch (apiInstance.showSignatureDialog(context_id)) {
            case RESULT_OK:
                break;
            case EC_API_NOT_INITED:
                alert('系统开小差，请退出重新尝试。');
                break;
            case EC_WRONG_CONTEXT_ID:
                alert('没有配置相应context_id的签字对象');
                break;
        }
    }

    //获取签名api版本信息
    function testGetVersion() {
        alert(apiInstance.getVersion());
    }

    //获取设备操作系统信息
    function testGetOsInfo() {
        alert(apiInstance.getOSInfo());
    }
    /**
     * base64编码码
     * @param str 需base64编码字符
     * @returns {*} base64解码后的字符
     */
    function base64encode(str) {
        var base64EncodeChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        var out, i, len;
        var c1, c2, c3;
        str = utf16to8(str);
        len = str.length;
        i = 0;
        out = '';
        while (i < len) {
            c1 = str.charCodeAt(i++) & 0xff;
            if (i == len) {
                out += base64EncodeChars.charAt(c1 >> 2);
                out += base64EncodeChars.charAt((c1 & 0x3) << 4);
                out += '==';
                break;
            }
            c2 = str.charCodeAt(i++);
            if (i == len) {
                out += base64EncodeChars.charAt(c1 >> 2);
                out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
                out += base64EncodeChars.charAt((c2 & 0xF) << 2);
                out += '=';
                break;
            }
            c3 = str.charCodeAt(i++);
            out += base64EncodeChars.charAt(c1 >> 2);
            out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
            out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
            out += base64EncodeChars.charAt(c3 & 0x3F);
        }
        return out;
    }
    function utf16to8(str) {
        var out, i, len, c;

        out = '';
        len = str.length;
        for (i = 0; i < len; i++) {
            c = str.charCodeAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                out += str.charAt(i);
            } else if (c > 0x07FF) {
                out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
                out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
                out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
            } else {
                out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
                out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
            }
        }
        return out;
    }
    //提交
    function confirmTest(type) {
        var strJSONStr = document.getElementById('result').value;
        var imgData = document.getElementById('imgData').value;
        //为了防止后台XSS过滤，暂时将加密字符串某些字符替换
        if (type == 'Y') {
            strJSONStr = 'ESIGN_VERSION_1.0|' + base64encode(params.sign_keyword) + '|' + base64encode(params.businessId) + '|' + base64encode(strJSONStr);
        }
        //var dataUrl = document.getElementById('img').src;
        var dataUrl = imgData;
        //var json = new Function('return' + strJSON)();;
        var pSign = '';
        var pSign0 = '';
        $('#anysign_sign_01').find('p').each(function (i, e) {
            var str = e.innerHTML.replace(/\n/g, '');
            pSign0 = pSign0 + str + '&';
        });
        if (pSign0 != '') {
            pSign = pSign0 + '#';
        }
        var pSign1 = '';
        $('#anysign_sign_02').find('p').each(function (i, e) {
            var str = e.innerHTML.replace(/\n/g, '');
            pSign1 = pSign1 + str + '&';
        });
        if (pSign1 != '') {
            pSign = pSign + pSign1 + '#';
        }
        var pSign2 = '';
        $('#anysign_sign_03').find('p').each(function (i, e) {
            var str = e.innerHTML.replace(/\n/g, '');
            pSign2 = pSign2 + str + '&';
        });
        if (pSign1 != '') {
            pSign = pSign + pSign2 + '#';
        }
        return {
            imageData: dataUrl,
            signData: strJSONStr,
            p: pSign,
            signKey: '13524242834'
        };
    }
    // return {
    //     init: setAlertTitle,
    //     toJSON: confirmTest
    // };
    if (typeof define === 'function' && define.amd) {
        define([], function () {
            return {
                init: setAlertTitle,
                toJSON: confirmTest
            };
        });
    }
//});