/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'fastclick', 'view'], function($, C, Fastclick, View) {
    'use strict';
    Fastclick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap #js-back': 'back'
        },
        initialize: function() {
            var keys = C.Utils.getParameter('key');
            var params = JSON.parse(C.Utils.AESDecrypt(keys, 'Decrypt'));
            this.render(params);
        },
        render: function(data) {
            var bank = data.cgiBankName || data.newBank;
            if (bank && data.isCredit === '1') {
                var bankClass = C.Constant.BANKCONTRACT[bank];
                $('.' + bankClass).removeClass('dn');
            }
        },
        back: function() {
            history.back();
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});