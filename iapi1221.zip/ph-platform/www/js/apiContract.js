/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 合同签订(借款协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';

    var Page = View.extend({
        initialize: function() {
            var keys = C.Utils.getParameter('key').replace(/\s+/g, ''); // 去除key中的空格
            var paramsObj = JSON.parse(C.Utils.AESDecrypt(keys, 'Decrypt'));
            this.checkFiled(paramsObj);
        },
        checkFiled: function(paramsObj) {
            var regName = /^[\u4e00-\u9fa5]{2,10}$/g; // 匹配汉字
            var regCredit = /^([0-9])|(\d)(\.)(\d)+$/; // 匹配数字
            var regId = /^(\d{4})\*{10}(\d{3})(\d|X|x)$/; // 匹配4个数字，10个*,3个数字，最后一个三种情况
            var regApplyNo = /^[0-9a-zA-Z]+$/; // 匹配只有数字和字母
            var warnMsg = {
                content: '经安全监测，发现您的手机处于危险状态，请确保手机系统安全',
                isAutoClose: false
            };

            if (!regName.test(paramsObj.custName)) {
                C.UI.warning(warnMsg);
                return;
            }
            if (!regCredit.test(paramsObj.credit)) {
                C.UI.warning(warnMsg);
                return;
            }
            if (!regId.test(paramsObj.id)) {
                C.UI.warning(warnMsg);
                return;
            }
            if (!regApplyNo.test(paramsObj.applyNo)) {
                C.UI.warning(warnMsg);
                return;
            }
            var params = {
                applyNo: paramsObj.applyNo,
                custName: paramsObj.custName,
                Id: paramsObj.id,
                credit: C.Utils.formatMoney(paramsObj.credit)
            };
            this.render(params);
            $('.auth').show();
        },
        // 初始页面渲染
        render: function(data) {
            $('#js-wrap-applyNo').html(_.template($('#js-html-applyNo').html(), data));
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});