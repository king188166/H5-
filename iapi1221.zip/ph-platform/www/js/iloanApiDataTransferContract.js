/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 合同签订(资料代传协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            var keys = C.Utils.getParameter('key'); 
            var paramsObj = JSON.parse(C.Utils.AESDecrypt(keys, 'Decrypt'));
            this.params = {
                fundingModel: paramsObj.fundingModel,
                dataVersionNo: paramsObj.dataVersionNo || 'v1.1'  // 默认版本为最新版本
            };
            this.CONTRACTHTML = {
                /*资料代传合同*/
                dataVersion: {
                    'v1.0': 'api_data_transfer_contract.html',  //CGI+联合放款 
                    'v1.1': 'api_data_transfer_contract_1.1.html' //新版 资料代传协议
                }
            };
            window.location.href = this.CONTRACTHTML.dataVersion[this.params.dataVersionNo] + '?key=' + keys;
           
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});