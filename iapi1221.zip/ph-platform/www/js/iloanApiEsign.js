/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view', 'fastclick', 'js/dosign'], function($, C, View, Fastclick, dosign) {
    'use strict';
    Fastclick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap #cancel': 'btnCancel',
            'tap #clear': 'btnClear',
            'tap #agreed': 'submitEsign',
            'tap #js-contract-synthetical': 'toSyntheticalAuth',
            'tap #js-contract-personal': 'toPersonalAuth',
            'tap #js-contract-synthetical-cgi': 'toSyntheticalCgiAuth',
            'tap #bank_contract_title': 'toBankAuth'
        },
        initialize: function() {
            this.barCode = 'iloan' + Math.round(Math.random() * 1000) + new Date().getTime();
            this.config = {
                businessId: this.barCode, // 集成信手书业务的唯一标识
                sign_keyword: '授权人（签字）：' // 签名关键词
            };
            if (this.isSafeLink('successLink') && this.isSafeLink('failLink')) {
                this.getQueryParams();
                this.render(this.paramsObj);
            }
        },
        isSafeLink: function(link) { // 判断链接是否安全
            var regLink = /javascript|<|>/ig;
            if (regLink.test(C.Utils.getParameter(link))) {
                C.UI.warning({
                    content: '经安全监测，发现您的手机处于危险状态，请确保手机系统安全',
                    isAutoClose: false
                });
                return false;
            }
            return true;
        },
        getQueryParams: function() {
            this.forwardParams = C.Utils.getParameter('key').replace(/\s+/g, ''); // 去除key中的空格
            var keys = JSON.parse(C.Utils.AESDecrypt(this.forwardParams, 'Decrypt'));
            console.log(keys);
            // 将url参数中的成功页面，加到key中，一起加密，传给其他授权书页面
            if (!!keys.successLink) {
                this.successLink = keys.successLink;
                this.failLink = keys.failLink;
            } else {
                keys.successLink = this.successLink = C.Utils.getParameter('successLink');
                keys.failLink = this.failLink = C.Utils.getParameter('failLink');
            }
            this.forwardParams = C.Utils.AESDecrypt(JSON.stringify(keys), 'Encrypt');
            var params = {
                // 授权书的展示相关字段
                eType: keys.eType,
                fundingModel: keys.fundingModel,
                signElectSw: keys.signElectSw || 'Y', // 电子签名开关
                cgiBankName: keys.cgiBankName,
                loanCompanyCode: keys.loanCompanyCode,
                isCredit: keys.isCredit,

                ratio: keys.ratio || '',
                // 银行变更接口所需字段
                newBank: keys.newBank || '',
                bankCode: keys.bankCode || '',
                applyNo: keys.applyNo || '',
                payApplyNo: keys.payApplyNo || ''
            };
            this.paramsObj = params;
            $('.auth').show();
        },
        // 渲染电子签名页面
        render: function(data) {
            // 显示日期
            var date = new Date();
            var month = parseInt(date.getMonth()) + 1;
            data.today = date.getFullYear() + '-' + month + '-' + date.getDate();
            // 渲染页面
            $('#contract_preview').html(_.template($('#js-contract-pre').html(), data));
            //银行变更时隐藏个人征信和综合授权书
            if (data.eType.toUpperCase() === 'UP') {
                $('.isShow').addClass('dn');
            }
            // 电子签名
            if (data.signElectSw === 'N') {
                $('#qian-input').html('同意并授权');
            } else {
                dosign.init(this.config);
            }
            // 综合授权页展示银行征信：U 并且需要征信；变更银行电子签名页必须征信，对应银行字段 newBank
            if (data.fundingModel && data.isCredit && data.fundingModel == 'U' && data.isCredit == '1' || !!data.newBank) {
                var bankClass = C.Constant.BANKCONTRACT[data.cgiBankName] || C.Constant.BANKCONTRACT[data.newBank];
                $('.' + bankClass).removeClass('dn');
            }
            $('#contract_preview').show();
        },

        // 提交电子签名信息
        submitEsign: function() {
            sign_confirm();
            if (!$('#result').val().length) {
                C.UI.warning({
                    content: '您还没有签名，无法进行下一步！'
                });
                return;
            }
            var sign = dosign.toJSON('Y');
            this.imgBytes = sign.imageData;
            this.imgDenseStr = sign.signData;
            var params = {};
            if (this.paramsObj.signElectSw === 'Y') {
                params.imgDenseStr = this.imgDenseStr;
                params.imgBytes = this.imgBytes;
            }
            params.loanCompanyCode = this.paramsObj.loanCompanyCode;
            params.platform = App.IS_IOS ? 'IOS' : 'A';
            params.businessNo = this.barCode;
            params.fundingModel = this.paramsObj.fundingModel;
            params.cgiBankName = this.paramsObj.cgiBankName;
            params.ratio = this.paramsObj.ratio;
            params.productId = 'ILOANBT';
            // ocr参数可写成固定配置
            params.ocrKey = 'N';
            params.ocrNeed = 'Y';
            params.isDomesticAlgorithm = 'Y';
            // 银行变更接口所需参数
            params.bankName = this.paramsObj.newBank;
            params.bankCode = this.paramsObj.bankCode;
            params.applyNo = this.paramsObj.applyNo;
            params.payApplyNo = this.paramsObj.payApplyNo;
            params.eType = this.paramsObj.eType;
            $('.shadding').show();
            var self = this;
            $.ajax({
                url: C.Api('UPLOADPOSELECTRONICSIGNATURE'),
                type: 'post',
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function(res) {
                    $('#qian-input').hide();
                    $('#result').val('');
                    if (res.flag == '1') {
                        window.location.href = self.successLink;
                    } else {
                        window.location.href = self.failLink;
                    }
                },
                complete: function() {
                    $('.shadding').hide();
                }
            });
        },
        // 处理电子签名
        btnCancel: function() {
            cancelSign();
        },
        btnClear: function() {
            clear_canvas();
        },
        // 跳转至个人征信页
        toPersonalAuth: function() {
            window.location.href = 'iloan_api_auth_personal.html?key=' + this.forwardParams;
        },
        // 跳转至综合授权书页 担保
        toSyntheticalAuth: function() {
            window.location.href = 'iloan_api_auth_synthetical.html?key=' + this.forwardParams;
        },
        // 跳转至综合授权书页 联合放款
        toSyntheticalCgiAuth: function() {
            window.location.href = 'iloan_api_auth_synthetical_cgi.html?key=' + this.forwardParams;
        },
        // 跳转至银行征信
        toBankAuth: function() {
            window.location.href = 'iloan_api_auth_bank.html?key=' + this.forwardParams;
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});