/**
 * @author: ex-zhangkeming001@pingan.com.cn
 * @date  : 2017-11-29
 * @describe: 资料代传合同
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            var paramsObj = C.Utils.getParameter('key');
            var data = JSON.parse(C.Utils.AESDecrypt(paramsObj, 'Decrypt'));
            // 校验字段
            this.checkFiled(data);
        },
        checkFiled: function(data) {
            var regName = /^[\u4e00-\u9fa5]{2,10}$/g; //汉字
            var regMobile = /^(\d{3})\*{4}(\d{4})$/; // 匹配中有4个*
            var regId = /^(\d{4})\*{10}(\d{3})(\d|X|x)$/; // 匹配4个数字，10个*,3个数字，最后一个三种情况
            var regApplyNo = /^[0-9a-zA-Z]+$/;
            var warnMsg = {
                content: '经安全监测，发现您的手机处于危险状态，请确保手机系统安全',
                isAutoClose: false
            };

            if (!regName.test(data.custName)) {
                C.UI.warning(warnMsg);
                return;
            }
            if (!regMobile.test(data.mobile)) {
                C.UI.warning(warnMsg);
                return;
            }
            if (!regId.test(data.id)) {
                C.UI.warning(warnMsg);
                return;
            }
            if (!regApplyNo.test(data.applyNo)) {
                C.UI.warning(warnMsg);
                return;
            }
            this.render(data);
            $('.auth').show();
        },
        render: function(data) {
            $('#js-applyNo').html(data.applyNo);
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});