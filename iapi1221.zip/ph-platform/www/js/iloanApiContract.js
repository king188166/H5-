/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 合同签订(借款协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            var keys = C.Utils.getParameter('key').replace(/\s+/g, ''); // 去除key中的空格
            var paramsObj = JSON.parse(C.Utils.AESDecrypt(keys, 'Decrypt'));
            this.params = {
                fundingModel: paramsObj.fundingModel,
                versionNo: paramsObj.versionNo,
                loanCompanycode: paramsObj.loanCompanyCode // 贷款公司(LCH)
            };
            /*担保协议，借款协议默认值*/
            this.PRODUCTION = {     
                cgiVersion: {
                    'L': 'v4.0',    // 联合放款 普惠小贷
                    'H': 'v3.1',    // 联合放款 湖南小贷
                    'C': 'v3.2'     // 联合放款 重庆小贷
                },
                version: 'v1.2'  // 默认担保协议
            };
            this.CONTRACTHTML = {
                /*CGI+联合放款 借款协议*/
                cgiContract: {
                    'v2.0': 'api_contract_cgi_2.0.html',
                    'v3.0': 'api_contract_cgi_3.0.html',  // 深圳小贷
                    'v3.1': 'api_contract_cgi_3.1.html',  // 湖南小贷
                    'v3.2': 'api_contract_cgi_3.2.html',  // 重庆小贷
                    'v4.0': 'api_contract_cgi_4.html'  //新版 CGI+联合放款 借款协议
                },
                /*担保协议*/
                contract: {
                    'v1.0': 'api_contract_1.0.html',
                    'v1.1': 'api_contract_1.1.html',
                    'v1.2': 'api_contract_1.2.html'   // 九江银行新增 担保协议
                }
            };
            this.showContract();
        },
        showContract: function() {
            // 显示协议内容
            var key = C.Utils.getParameter('key');
            var url;
            if (this.params.fundingModel.toUpperCase() === 'U' || this.params.fundingModel.toUpperCase() === 'D') {
                if (!!this.params.versionNo) { // versionNo有值
                    url = this.CONTRACTHTML.cgiContract[this.params.versionNo] + '?key=' + key;
                } else {
                    url = this.CONTRACTHTML.cgiContract[this.PRODUCTION.cgiVersion[this.params.loanCompanycode]] + '?key=' + key;
                }
            } else {
                if (!!this.params.versionNo) {
                    url = this.CONTRACTHTML.contract[this.params.versionNo] + '?key=' + key;
                } else {
                    url = this.CONTRACTHTML.contract[this.PRODUCTION.version] + '?key=' + key;
                }
            }
            window.location.href = url;
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});