/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 综合授权书（联合放款）
 */
define(['zepto', 'C', 'fastclick', 'view'], function($, C, Fastclick, View) {
    'use strict';
    Fastclick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap #js-back': 'back'
        },
        initialize: function() {
            var key = C.Utils.getParameter('key');
            var keys = JSON.parse(C.Utils.AESDecrypt(key, 'Decrypt'));
            this.render(keys);
        },
        render: function(data) {
            if (data.fundingModel && (data.fundingModel == 'U' || data.fundingModel == 'D')) {
                var loanCompanyCode = data.loanCompanyCode;
                switch (loanCompanyCode) {
                    case 'C':
                        $('.cq').removeClass('dn'); //重庆小贷
                        break;
                    case 'H':
                        $('.hn').removeClass('dn'); // 湖南小贷
                        break;
                    default:
                        $('.sz').removeClass('dn'); //深圳小贷
                }
            }
        },
        back: function() {
            history.back();
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});