/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 综合授权书（担保）
 */
define(['zepto', 'C', 'fastclick', 'view'], function($, C, Fastclick, View) {
    'use strict';
    Fastclick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap #js-back': 'back'
        },
        initialize: function() {
            var keys = C.Utils.getParameter('key');
            var data = {
                loanCompanyCode: JSON.parse(C.Utils.AESDecrypt(keys, 'Decrypt')).loanCompanyCode
            };
            this.render(data);
        },
        render: function(data) {
            $('#js-auth-synthetical').html(_.template($('#js-auth-synthetical-L').html(), data));
        },
        back: function() {
            history.back();
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});