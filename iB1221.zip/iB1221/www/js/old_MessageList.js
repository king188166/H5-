/**
 * 头部消息列表气泡提醒
 * @date 10/30/2015
 * @author <a href='mailto:ex-huxinwei001@pingan.com.cn'>Shinvey Hu</a>
 */
define(['zepto', 'C', 'js/common/Events'], function ($, C, Events) {
    'use strict';
    function Model(opt) {
        var _this = this;
        this.url = opt.url || '';
        this.fetch = function fetch(params) {
            return $.ajax({
                url: this.url,
                data: params,
                type: 'post',
                success: function (res) {
                    var data = res.data;
                    if (res.flag == C.Flag.SUCCESS) {
                        _this.trigger('success', data);
                    } else {
                        var err = new Error();
                        err.data = data;
                        err.message = res.msg;
                        _this.trigger('error', err);
                    }
                },
                error: function (XHR, textStatus, errThrown) {
                    var err = new Error();
                    err.message = textStatus;
                    _this.trigger('error', err);
                },
                complete: function (res) {
                    C.UI.stopLoading();
                }
            });
        };
    }

    _.extend(Model.prototype, Events);

    function Push() {
        this.initialize = function () {
            var _this = this;
            this.model = new Model({
                url: C.Api('getMessage')
            });

            this.model.on('success', function (data) {
                var count = '';
                C.Utils.data(C.Constant.DataKey.MSG_LIST, data);
                for (var i = 0; i < data.msgInfo.length; i++) {
                    if (data.msgInfo[i].status == '0') {
                        count++;
                    }
                }
                _this.bubble(count);
            }).on('error', function (err) {
                _this.bubble(0);
                console.log(err.message);
                //C.Native.tip(err.message);
            });

            // $$.EventListener.off('back.msg_list').on('back.msg_list', function (data, opts) {
            //     data = data || {};
            //     if(data.msgRead =='Y'){
            //     	_this.bubble(0);
            //     	_this.pull();
            //     }                
            // });


        };
        this.pull = function () {
            /**
             * Fetch messages
             */
            return this.model.fetch({
                count: '0',
                queryDate: '0'
            });
        };
        /**
         * Count bubble
         */
        this.bubble = function (msgCount) {
            var _this = this;
            console.log('MessageList/bubble: ' + msgCount);
            var headerOpts = C.Native.header();
            if (!headerOpts) return;
            headerOpts = $.extend({}, headerOpts, {
                rightText: '消息',
                rightCallback: function () {

                    C.Native.forward({
                        url: 'old_message.html', //跳转消息列表页
                        data: {},
                        callback: function (data) {
                            console.log(data);
                            if (data.msgRead == 'Y') {
                                _this.bubble(0);
                                _this.pull();
                            }

                        }
                    });
                },
                data: {'msgCount': msgCount},
                noSave: 1,
                silent: 1
            });
            C.Native.header(headerOpts);
        };
        /**
         * recover header
         * @private
         */
        // this._recoverHeader = function () {
        // };

        this.initialize.apply(this, arguments);
    }

    return Push;
});