/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2016-03-21
 * @time  : pm 16:54
 *
 * @describe: iLoan定期-产品详情
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {},
        initialize: function () {
            //埋点 8.29新增，统计所有进入详细介绍页的总数
            C.Native.TDOnEvent({
                eventId: 'iBT-0209-产品详细介绍页',
                eventLable: 'iBT-020901-进入产品详情页'
            });
            //埋点 产品详情介绍页  访问次数
            C.Native.TDOnEvent({
                eventId: '$_03_5_3_15_01_产品详情介绍页'
            });
            C.Native.setHeader({
                title: 'i贷代还信用卡',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});