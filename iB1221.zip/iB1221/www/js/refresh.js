/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-11-05
 * @time  : 下午16:10
 *
 * @describe: iLoan定期-申请状态查询公共方法
 */
/*global define:false*/
define(['zepto', 'C'], function ($, C) {
    'use strict';
    function refreshState(callback, failCallback) {
        var request = function () {
            var cityName = C.Utils.data(C.Constant.DataKey.BT_ILOAN_CITYNAME);
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
            var source = '',
                sourceType = '';
            if (!cityName) {
                C.Native.forward({
                    url: 'try_get_cityname.html'
                });
                return;
            }
            var param = {};
            C.UI.loading();
            if (sourceInfo) {
                source = sourceInfo.source;
                sourceType = sourceInfo.sourceType;
            }
            C.Native.getDeviceInfo(function (res) {
                if (res.code == '1') {
                    param = {
                        cityName: cityName,
                        longitude: (res.result.longitude).toString(),
                        latitude: (res.result.latitude).toString()
                    };
                    if (App.IS_SDK) {
                        param.thirdChannel = source;
                        param.channelType = sourceType; 
                    }
                    $.ajax({
                        url: C.Api('QUERY_USER_APPLY_STATE_2'),
                        type: 'post',
                        data: {
                            jsonPara: JSON.stringify(param)
                        },
                        success: function (res) {
                            if (res.flag == '1' && res.data) {
                                if (res.data.resultCode == '1') {
                                    if (res.data.subProcessCode == 'RJ') {
                                        res.data.applyNo = null;
                                    }
                                    if (typeof callback == 'function') {
                                        callback(res);
                                    }
                                } else {
                                    C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
                                }
                            }
                        },
                        complete: function (res) {
                            if (typeof failCallback == 'function') {
                                failCallback(res);
                            }
                            C.UI.stopLoading();
                        }
                    });
                }
            });

        };
        var userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
        if (userdata) {
            request();
        } else {
            C.Native.getUserInfo(function (data) {
                C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                request();
            });
        }
    }

    return {
        init: refreshState
    };
});