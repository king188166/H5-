/**
 * @author: qiuxiaoqiang292@pingan.com.cn
 * @date  : 2015-10-12
 * @time  : 上午09:25
 *@modified by ex-guojingjing001@pinggan.com.cn on 2015-10-14
 * @describe: 修改还款方式
 */
/*global define:false*/
define(['zepto', 'C', 'view', 'js/old_encrypt'], function ($, C, View, Encrypt) {
    'use strict';

    var acctNo = C.Utils.getParameter('acctNo');
    var custNo = C.Utils.getParameter('custNo');
    var status = C.Utils.getParameter('status');

    var Page = View.extend(_.extend({
        events: {
            'tap .js_tap': 'choose',
            'tap .icon-add': 'addCard',
            'tap .btn': 'save'
        },
        initialize: function () {
            var self = this;
            // 设置标题
            C.Native.setHeader({
                title: '还款方式',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            C.UI.loading();
            this.getChangeRepayType(function (res) {
                C.UI.stopLoading();
                if (res.flag == C.Flag.SUCCESS) {
                    var data = res.data;
                    //C.Native.TD({
                    //	event:"应急钱包",
                    //	label:"详情页_点击_还款方式",
                    //	map:{
                    //		"结果":"成功"
                    //	}
                    //});
                    //data={"data":{"defualtRpAcct":"884875","rpType":"mix","disbAcountList":[{"accountNo":"","accountTypeName":"壹钱包账户","bindNo":"884874","bindType":"YQB","bankCode":" "},{"accountNo":"**** **** ****8698","accountTypeName":"建设银行","bindNo":"884875","bindType":"BANK","bankCode":"CCB"}]},"msg":"操作成功","flag":"1"}
                    self.render(data);
                } else {
                    //C.Native.TD({
                    //	event:"应急钱包",
                    //	label:"详情页_点击_还款方式",
                    //	map:{
                    //		"结果":"失败",
                    //		"失败原因":res.msg
                    //	}
                    //});

                    C.UI.error(res.msg);
                }

            }, function (err) {
                C.UI.stopLoading();
            });
            //C.Native.getUserInfo(function (data) {
            //console.info(JSON.stringify(data));
            //var data = '{"custId":"6591","platform":"android","accountId":"6558","changepwdFlag":"","isNew":"N","cityName":"","machineId":"3b24e4e9d259517bd4d0971c8ca256260","msgCnt":"2","city":"","pointsSwitch":"Y","sysDate":"2015年09月16日","token":"1FD9AF81F5454869E053A30B1F0AB7A8","paPayToken":"CdmeNNta05bGAacNXm8eUgygrnw","isOrangebankCust":"N","account":"18120152001","ad":["/ad/3.jpg","/ad/4.jpg"],"Id":"441202197505137634","custName":"一号","mobile":"18120152001"}';
            //C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
            //});
        },
        render: function (data) {
            var rpType = data.rpType;
            if (rpType == 'max') {
                $('#rp-type-max').addClass('focus');
                $('#hideRpType').text('max');
                $('#rp-type-mix').removeClass('focus');
            } else { // mix
                $('#rp-type-mix').addClass('focus');
                $('#hideRpType').text('min');
                $('#rp-type-max').removeClass('focus');
            }
            console.log(rpType);
            console.log('hidetype:  ' + $('#hideRpType').text());
            //加载银行列表
            var defualtRpAcct = data.defualtRpAcct;

            var html = '';
            for (var item in data.disbAcountList) {
                console.log('bindNo: ' + data.disbAcountList[item].bindNo);
                console.log('defualtRpAcct: ' + defualtRpAcct);
                var activeClass = 'js_tap';
                var bindNo = data.disbAcountList[item].bindNo;
                if (bindNo == defualtRpAcct) {
                    activeClass = 'focus js_tap';
                }
                var accountNo = data.disbAcountList[item].accountNo;
                accountNo = accountNo.replace(/(\*|\s)/ig, '');
                var accountTypeName = data.disbAcountList[item].accountTypeName;

                if (accountTypeName != '壹钱包账户') {
                    html += '<li data-bind-no="' + bindNo + '" data-rp-type="' + rpType + '" class="' + activeClass + '"><div>' + accountTypeName + '</div><div class="tail">尾号' + accountNo + '</div></li>';
                }
            }
            $('#choose_bank').html(html);

        },
        choose: function (e) {
            var node = $(e.currentTarget);
            var currentId = node[0].id;
            if (node.hasClass('focus')) {
                return;
            }
            node.addClass('focus').siblings().removeClass('focus');
            if (currentId == 'rp-type-mix') {
                C.Native.TDOnEvent({
                    eventId: '0206-还款方式',
                    eventLable: '020601-最低还款额'
                });
            }
            if (currentId == 'rp-type-max') {
                C.Native.TDOnEvent({
                    eventId: '0206-还款方式',
                    eventLable: '020602-全部还款'
                });
            }

        },
        addCard: function () {
            C.Native.TDOnEvent({
                eventId: '0206-还款方式',
                eventLable: '020605-选择银行卡'
            });
            require(['js/bindcard'], function (bindcard) {
                bindcard('add').done(function (data) {
                    console.log('bindcard().done', data);
                    location.reload(true);
                }).fail(function () {
                    console.error('bindcard().fail');
                });
            });
        },
        //获取还款方式信息
        getChangeRepayType: function (success, error) {

            $.ajax({
                url: C.Api('QUERY_CHANGE_REPAY_TYPE'),
                type: 'get',
                data: {
                    custNo: custNo,
                    acctNo: Encrypt.rsaEncrypt(acctNo)
                },
                success: success,
                error: error
            });
        },
        //提交还款方式
        save: function (baseData) {

            var defualtRpAcct = $('#choose_bank li.focus').attr('data-bind-no'),
                rpType = $('#rp-type li.focus').attr('data-rp-type');
            if (status == 'OD') {
                rpType = $('#hideRpType').text();
            }
            //alert(defualtRpAcct);
            $.ajax({
                url: C.Api('SUBMIT_CHANGE_REPAY_TYPE'),
                type: 'POST',
                data: {
                    ACCOUNT_VER: '2.1.0',
                    curVer: '9.9.0',
                    _RSAVER: '2.1.0',
                    custNo: custNo,
                    acctNo: Encrypt.rsaEncrypt(acctNo),
                    defualtRpAcct: defualtRpAcct,
                    rpType: rpType,
                    merReserved: baseData.merReserved || ''
                },
                success: function (res) {
                    if (res.flag == C.Flag.SUCCESS) {
                        C.Native.TDOnEvent({
                            eventId: '0206-还款方式',
                            eventLable: '02060601-提交成功'
                        });
                        C.UI.dialog({
                            'btnnum': '1',
                            'position': 'bottom',
                            'content': '设置成功',
                            'okText': '确定',
                            'ok': function () {
                                C.Native.back();
                            }
                        });
                    }
                    else {
                        //alert(res.msg);
                        C.UI.error(res.msg);
                    }
                    //C.UI.stopLoading();
                },
                complete: function (res) {
                    C.UI.stopLoading();
                }
            });
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});