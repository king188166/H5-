/**
 * @author: EX-ZHANGKEMING001
 * @date  : 2016-10-14
 * @describe: icardBT-申请还卡
 */
define(['zepto', 'C', 'view'], function($, C, View){
    'use strict';
    C.FastClick.attach(document.body);
    var Page = View.extend(_.extend({
        /**绑定事件**/
        events: {
            'tap #bank-list': 'skipBankList', //跳转到信用卡列表页
            'tap #add-bank': 'skipAdd', //跳转到增加信用卡页面
            'tap #plane': 'skipPlan', //跳转到还款计划列表页
            'tap #js-btn-back': 'skipMyi', //当客户额度不足时跳转到我的i贷页面
            'blur #figure': 'doTry', //失去焦点，调用试算接口
            'focus #figure': 'showAmountInput', //当输入框获得焦点的时候重置页面
            'tap #next-btn>.btn': 'doSubmit', //点击下一步按钮
            'tap .js_showLeayer': 'showWindow', //点击蒙层。
            'tap #goRepayment': 'goRepayment', //去还款
            'tap #doStopApply': 'doStopApply',
            'tap #stopPolicy': 'stopPolicy',
            'tap #goPolicy': 'goPolicy',
            'tap .know-detail': 'knowDetail', //点击了解更多
            'tap .js-prompt-close': 'closePrompt',  //关闭投保须知
            'change #select-yt': 'chooseUse'
        },
        /**指定根元素**/
        el: 'body',
        pageHead: $('#page-header'), //页面头部展示元素
        addDiv: $('#add-content'), //获取同级div元素
        infoTpl: _.template($('#content-info').html()), //信息展示模板
        tryTpl: _.template($('#try-calculate').html()), //试算模板
        talkingDate: function(key){
            var first = {
                '还卡试算页': {
                    eventId: '$_03_0_4_21_借款试算页'
                },
                '下一步': {
                    eventId: '$_03_1_4_21_05_借款试算页'
                },
                '还款计划': {
                    eventId: '$_03_1_4_21_02_借款试算页'
                }
            };
            var noFirst = {
                '还卡试算页': {
                    eventId: '$_03_0_4_52_还卡再贷试算页'
                },
                '下一步': {
                    eventId: '$_03_1_4_52_01_还卡再贷试算页'
                },
                '还款计划': {
                    eventId: '$_03_1_4_52_02_还卡再贷试算页'
                }
            };
            return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
        },
        /**初始化**/
        initialize: function(){
            var $this = this,
                sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO),
                idvalidData = C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID) || {},
                migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
            $this.userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
            $this.thirdChannel = sourceInfo ? sourceInfo.source : '';
            $this.channelType = sourceInfo ? sourceInfo.sourceType : '';
            $this.isFirstPay = (idvalidData && idvalidData.isFirstPay) ? idvalidData.isFirstPay : '';
            //借款用途
            $this.purpose = '';
            //是否迁徙
            $this.isMigrate = (migrateData && migrateData.isMigrate) ? migrateData.isMigrate : '';
            if ($this.isMigrate && $this.isMigrate == 'Y') {
                C.Native.TDOnEvent({
                    eventId: '$_03_0_0_58_无欠款迁徙试算页'
                });
            } else {
                //埋点 借款试算页
                C.Native.TDOnEvent($this.talkingDate('还卡试算页'));
                C.Native.TDOnEvent({
                    eventId: 'iBT-03-还卡',
                    eventLable: 'iBT-0303-申请借款'
                });
            }
            //设置头部信息
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.PINNED,
                rightText: '还卡攻略',
                isBack: false,
                rightCallback: function(){
                    //埋点 借款试算页 还卡攻略
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_21_01_借款试算页'
                    });
                    C.Native.forward({
                        url: 'icard_product_detail.html'
                    });
                }
            });
            //产险剥离需求
            C.Native.getAppVersion(function(res){
                $this.appVersion = parseInt(res.version);
            });
            //判定申请号是否存在（如不存在则重新获取）
            var queryApplyNoByAccuntid = function(){
                var dtd = $.Deferred();
                    //发起AJAX请求，调用申请号接口
                $this.createRequest({
                    url: C.Api('QUERYAPPLYNOBYACCOUNTID'),
                    type: 'post',
                    data: {
                        tel: $this.tel, //手机号
                        cityName: $this.userInfo.cityName || $this.userInfo.city, //城市名称
                        applyNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO) ? C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO) : '', //申请号(非必传字段)
                        thirdChannel: $this.thirdChannel,
                        channelType: $this.channelType
                    }, //accountId 为公共入参
                    callback: function(data, dtd){
                        if(data.resultCode == '1'){
                            $this.applyNo = data.applyNo;
                            //存储申请号 SDK的BT_ICARD_APPLYNO与APP的BTAPPLYNO统一
                            C.Utils.data(C.Constant.DataKey.BTAPPLYNO, $this.applyNo);
                            dtd.resolve();
                        }else{
                            dtd.reject();
                        }
                    },
                    dtd: dtd
                });
                return dtd.promise();
            };
            //身份证有效期无效时，需要跳转到账户制的补录信息页
            if(idvalidData && idvalidData.idvalid == 'N'){
                var jsonData = {}, //用于以后native扩展字段，此版本先传空
                    params = {},
                    iloanVersion = C.Utils.data(C.Constant.DataKey.SDK_VERSION);
                if (App.IS_SDK && !iloanVersion) {
                    $.when($this.getTel({tel: $this.userInfo.mobile})).then(queryApplyNoByAccuntid).then($this.render.bind($this));
                    return;
                }
                C.Native.paPresent(C.Constant.DataUrl.TRANSPAGE.IDCARDVALID, jsonData, function(res){
                    console.log(res);
                    if(res.code == '1'){
                        params.idvalid = 'Y';
                        params.isFirstPay = $this.isFirstPay;
                        C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, params);//完成信息补录后，将身份有效期有效性置为有效
                        //执行借款查询接口并渲染页面数据
                        $.when($this.getTel({tel: $this.userInfo.mobile})).then(queryApplyNoByAccuntid).then($this.render.bind($this));
                    }else if(res.code == '2'){//当未完成信息补录，点左上角返回到该页面时
                        // 迁徙失败跳转至原渠道账户页
                        if (migrateData && migrateData.fromPage && migrateData.fromPage === 'old_home') {
                            // SDK1.0账户页
                            C.Native.back({
                                url: 'old_home.html'
                            });
                            return;
                        }
                        if (migrateData && migrateData.fromPage && migrateData.fromPage === 'shaw_account') {
                            // APP1.0账户页
                            C.Native.backModule({
                                module: 'iloan',
                                url: 'shaw_account.html'
                            });
                            return;
                        }
                        if($this.isFirstPay == 'Y'){//首贷，再贷返回不同页面
                            C.Native.back({
                                url: C.Constant.DataUrl.TRANSPAGE.LOANSELECT
                            });
                        }else{
                            C.Native.back({
                                url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
                            });
                        }
                    }
                });
                return;
            }
            //执行借款查询接口并渲染页面数据
            $.when($this.getTel({tel: $this.userInfo.mobile})).then(queryApplyNoByAccuntid).then($this.render.bind($this));

        },
        /**渲染页面数据**/
        render: function(){
            var $this = this,
                isLoading = C.Utils.getQueryMap().isLoading,
                data = {
                    tel: $this.tel, //手机号
                    cityName: $this.userInfo.cityName || $this.userInfo.city, //城市名称
                    applyNo: $this.applyNo, //申请号
                    payApplyNo: $this.payApplyNo || C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO), //支用申请号
                    thirdChannel: $this.thirdChannel,
                    channelType: $this.channelType
                };
                //迁徙新增入参
            if ($this.isMigrate) {
                data.isMigrate = $this.isMigrate;
            }
            //发起AJAX请求，调用借款查询接口
            $this.createRequest({
                url: C.Api('QUERYAPPLYINFO'), //借款查询接口
                type: 'post',
                data: data, //accountId 为公共入参
                callback: function(data){
                    $this.isFirstPay = data.isFirstPay;

                    //设置头部信息
                    C.Native.setHeader({
                        title: C.Constant.Enum.TITLE.PINNED,
                        isBack: 1,
                        leftCallback: function(){
                            var isFirstPay = $this.isFirstPay,
                                first = !isNaN(isLoading) && parseInt(isLoading);
                            first = isFirstPay? String(isFirstPay).toUpperCase() == 'Y' : first;
                            console.log(isFirstPay, isLoading);
                            if(!isFirstPay){ return; }
                            //loan_select.html 首次动用,//account_iloan.html 再次动用
                            first ? C.Native.back({
                                title: C.Constant.Enum.TITLE.LOANSELECT,
                                url: C.Constant.DataUrl.TRANSPAGE.LOANSELECT,
                                data: { reload: true }
                            }) : C.Native.loadPage({
                                title: C.Constant.Enum.TITLE.ACCOUNTILOAN,
                                url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN,
                                data: { reload: true }
                            });
                        },
                        rightText: '还卡攻略',
                        rightCallback: function(){
                            //埋点 借款试算页 还卡攻略
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_4_21_01_借款试算页'
                            });
                            C.Native.forward({
                                url: 'icard_product_detail.html'
                            });
                        }
                    });

                    if(parseInt(data.maxLoanAmt) < parseInt(data.minLoanAmt)){
                        //当客户额度不足时执行的操作
                        $('#js-block-limit').show();
                    }
                    //渲染页面头部
                    if(data.creditCardName && data.loanBindNo){
                        //再贷头部  
                        $this.renderCredit(data.creditCardName, data.loanBindNo);
                    }else{
                        var isEnter = true;
                        $this.accountId = $this.userInfo.accountId;
                        $this.enterList = C.Utils.data('ICARD_ENTER_INFO') || [];

                        if($this.enterList.length >0){
                            for(var i=0;i<$this.enterList.length;i++){
                                if($this.enterList[i] == $this.accountId ){
                                    isEnter = false;
                                } 
                            }
                        }
                        //首贷头部
                        if(isEnter){
                            //首次进来 增加蒙层的需求
                            $('#add-content').html('<ul class="guide-show js_showLeayer"><div class="leayer dn"></div><li class="z-big"><div class="guide4"></div><div class="tac"><p class="red"><span class="icon-sm icon-add"></span>添加收款信用卡</p></div></li></ul>');                            
                        }else{
                            //再次进来
                            $this.pageHead.html('<div class="tac" id="add-bank"><p class="red"><span class="icon-sm icon-add"></span>添加收款信用卡</p></div>');
                        }
                        //备注：针对SDK部分，重新渲染头部后，左上角的回退操作依然是初始化中对头部的设置
                    }
                    //从添加成功页面过来获取两个字段
                    var map = C.Utils.getQueryMap();
                    if(map && map.cardName && map.loanBindNo){
                        $this.renderCredit(decodeURI(decodeURI(map.cardName)), map.loanBindNo);
                    }
                    //渲染页面主体信息(01等额本息02先息后本03等额本金)
                    data.formatMaxLoanAmt = C.Utils.formatMoney(parseInt(Number(data.maxLoanAmt)/Number(data.loanLimit))*Number(data.loanLimit));
                    data.formatMinLoanAmt = C.Utils.formatMoney(data.minLoanAmt);
                    $this.addDiv.append($this.infoTpl(data));
                    $('#figure').val(data.formatMaxLoanAmt);
                    // 设置全局数据:本地存储以供借款确认,调用试算接口时做输入金额验证,调用试算接口时入参,跳转信用卡列表时传送
                    $this.fundingModel = data.fundingModel;
                    $this.APPLYINFO = data;
                    if($this.fundingModel.toUpperCase() === 'U' || $this.fundingModel.toUpperCase() === 'D'){
                        $('.prompt').removeClass('dn');
                    }
                    $this.doTry();
                }
            });
        },
        renderCredit: function(cardName, loanBindNo){
            if(cardName && loanBindNo){
                if($('#page-header').length !== 0){
                    $('#page-header').html('<div class="row" id="bank-list"><div class="col-l">收款信用卡</div><div class="col-r"><span id="loanBinNo" data-cardName=' + cardName + ' data-bindNo=' + loanBindNo +'>'+ 
                    (cardName.length < 18 ? cardName : (cardName.slice(0, cardName.length - 9) +'<br>'+ cardName.slice(cardName.length - 9) ))
                  +'</span><span class="icon-sm icon-arrow"></span></div></div>');
                }else{
                    $('#add-bank').remove();
                    $('#add-content ul').remove();
                    $('#add-content').prepend('<ul><li id="add-header"><div class="row" id="bank-list"><div class="col-l">收款信用卡</div><div class="col-r"><span id="loanBinNo" data-cardName=' + cardName + ' data-bindNo=' + loanBindNo +'>'+ 
                    (cardName.length < 18 ? cardName : (cardName.slice(0, cardName.length - 9) +'<br>'+ cardName.slice(cardName.length - 9) ))
                  +'</span><span class="icon-sm icon-arrow"></span></div></div></li></ul>');
                }
            }
        },
        createRequest: function(option, keepLoading){
            this.startLoading = true;
            var $this = this;
            C.UI.loading();
            //发起AJAX请求，调用相应接口
            $.ajax({
                url: option.url,
                type: option.type,
                data: option.data,
                success: function(res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        console.log(res);
                        option.callback.call($this, res.data, option.dtd);
                    }
                },
                error: function(res){
                    C.Native.tip('网络错误，请稍后再试！');
                    option.dtd.reject();
                },
                complete: function(res) {
                    if (keepLoading) return;
                    $this.startLoading = false;
                    C.UI.stopLoading();
                }
            });
        },
        chooseUse: function(e) {
            var $target = $(e.currentTarget),
                val = $target.val();

            this.purpose = val; 
        },
        getTel: function(tel){
            var $this = this,
                dtd = $.Deferred();
            C.Native.rSAEncode(tel, function(data) {
                if(data.code == '1'){
                    $this.tel = data.result.tel;
                    dtd.resolve();
                }
            });
            return dtd.promise();
        },
        //跳转信用卡列表
        skipBankList: function(){
            var $this = this;
            if($this.isFirstPay == 'Y'){
                C.Native.TDOnEvent({
                    eventId: 'iBT-0304-信用卡',
                    eventLable: 'iBT-030402-选择信用卡'
                });
                //埋点 借款试算页 选择信用卡
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_21_03_借款试算页'
                });
            }else{
                C.Native.TDOnEvent({
                    eventId: 'iBT-0606-信用卡',
                    eventLable: 'iBT-060602-选择信用卡'
                });
            }
            C.Native.forward({
                title: C.Constant.Enum.TITLE.CREDITLIST,
                url: C.Constant.DataUrl.TRANSPAGE.CREDITLIST, //跳转到信用卡列表页
                data: {
                    from: C.Constant.DataUrl.TRANSPAGE.PINNED,
                    loanBindNo: $('#loanBinNo').attr('data-bindNo'), //传送默认的银行卡绑定号
                    bindCreditCardTimes: $this.APPLYINFO.bindCreditCardTimes, //传送当天绑定信用卡次数
                    bindCreditCardTimesLimit: $this.APPLYINFO.bindCreditCardTimesLimit//传送信用卡绑定次数限制
                },
                callBack: function(data){
                    $this.renderCredit(data.cardName, data.loanBindNo);
                    $this.payApplyNo = data.payApplyNo ? data.payApplyNo : '';
                }
            });
        },
        //点击蒙层
        showWindow: function(){
            var $this =this;
            $this.enterList.push($this.accountId);
            C.Utils.data('ICARD_ENTER_INFO', $this.enterList);
            $('.js_showLeayer').removeClass('guide-show').attr('id', 'add-bank').find('.guide4').remove();
        },
        //跳转到添加信用卡
        skipAdd: function(){
            var $this = this;
            if($this.isFirstPay == 'Y'){
                C.Native.TDOnEvent({
                    eventId: 'iBT-0304-信用卡',
                    eventLable: 'iBT-030401-添加信用卡'
                });
                //埋点 借款试算页 添加信用卡
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_21_04_借款试算页'
                });
            }else{
                C.Native.TDOnEvent({
                    eventId: 'iBT-0606-信用卡',
                    eventLable: 'iBT-060601-添加信用卡'
                });
            }
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.ADDCREDIT, //跳转到增加信用卡页
                data: {from: 'icard_pinned.html'},
                callBack: function(data){
                    console.log(data);
                    $this.renderCredit(decodeURI(decodeURI(data.cardName)), data.loanBindNo);
                    location.reload();
                }
            });
        },
        skipPlan: function(){
            var $this =this;
        //埋点
            if($this.isFirstPay == 'Y'){
                C.Native.TDOnEvent({
                    eventId: 'iBT-0303-申请借款',
                    eventLable: 'iBT-030302-还款计划'
                });
            }else{
                C.Native.TDOnEvent({
                    eventId: 'iBT-0605-还卡再贷',
                    eventLable: 'iBT-060501-还款计划'
                });
            }
            //埋点 借款试算页 还款计划
            C.Native.TDOnEvent(this.talkingDate('还款计划'));
            
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTPLAN, //跳转到还款计划列表页
                data: {
                    from: 'pinned',
                    fundingModel: $this.fundingModel
                }
            });
        },
        skipMyi: function(){
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN//跳转到我的i贷页面（8.0页面）
            });
        },
        // 验证金额范围
        amountRange: function(val) {
            var $this = this;
            if (val && C.Utils.RegexMap.moneyTest.test(val)) {
                var min = parseInt($this.APPLYINFO.minLoanAmt),
                    step = parseInt($this.APPLYINFO.loanLimit),
                    max = parseInt($this.APPLYINFO.maxLoanAmt / step) * step,
                    amount = parseInt(val);
                if (amount > max) {
                    $this.topTip('输入金额不能超过最高可申请金额，请重新输入');
                    return max;
                } else if (amount < min) {
                    $this.topTip('不能低于最低金额' + min + '元，请重新输入');
                    return min;
                } else if (amount % step) {
                    $this.topTip('请输入' + step + '的整数倍');
                    return parseInt(val / step) * step;
                }
                return amount;
            }
            $this.topTip('请输入金额并符合正确格式');
            return '';
        },
        // 显示格式化后的贷款金额
        showAmountText: function(value, element) {
            var amount = C.Utils.formatMoney(value);
            element.prop('placeholder', '0.00').val(amount);
        },
        // 失去焦点，执行还卡试算
        doTry: function(){
            var $this = this,
                //target = $(e.currentTarget),
                amt = $('#figure').val().split('.')[0].split(',').join(''),
                amount = $this.loanAmt = $this.amountRange(amt);
            if (amount != '') {
                //发起AJAX请求，调用试算接口
                var data = {
                    applyNo: $this.applyNo,
                    payApplyNo: $this.payApplyNo || C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO), //支用申请号
                    loanAmt: amount, //借款金额
                    rpyDay: $this.APPLYINFO.rpyDay, //还款日
                    thirdChannel: $this.thirdChannel,
                    channelType: $this.channelTyp
                };
                //迁徙新增入参
                if ($this.isMigrate) {
                    data.isMigrate = $this.isMigrate;
                }
                $this.createRequest({
                    url: C.Api('REPAYMENTTRIAL'),
                    type: 'post',
                    data: data, //accountId 公共入参
                    callback: function(data){
                        if ($('#figure').is(':focus')) return;
                        $('#counterFee').text(C.Utils.formatMoney(data.counterFee) + '元');//渲染手续费数据
                        //console.log(data);
                        data.interestFee =Math.round(Number(data.interestFee) * 100 /Number(data.term))/100;
                        $('#try-wrap').html($this.tryTpl(data));//渲染试算模板
                        $('#next-btn').show();//显示下一步按钮
                        //在还卡试算接口拿到借款查询数据
                        data.loanAmt = amount;
                        $this.term = data.term;
                        // 还款计划数据存储到本地
                        C.Utils.data(C.Constant.DataKey.BT_REPAYMENT, data);
                        // 设置全局数据，本地存储以供借款确认使用
                        $this.REPAYMENTTRY = data;
                    }
                });
            }
            // 显示格式化后的提现金额
            $this.showAmountText(amount, $('#figure'));
        },
        //点击下一步，执行银联认证
        doSubmit: function(){
            var $this = this,
                bindNo = $('#loanBinNo').attr('data-bindNo'),
                borrowDate = $this.APPLYINFO;

            if ($('#select-yt').val() === '') {
                C.Native.tip('请选择借款用途!');
                return;
            }
            if(!bindNo){
                $this.topTip('请先添加收款信用卡！');
                return;
            }
            // 清除本地缓存的投保单号
            C.Utils.data(C.Constant.DataKey.BT_INSURANCE_NO, null);

            if(borrowDate.isLoan && borrowDate.isLoan == 'N'){
                $('#frequency-limit').html(borrowDate.frequencyLimit);
                $('#js-frequency-limit').removeClass('dn');
                return;
            }
            if ($this.isMigrate && $this.isMigrate == 'Y') {
                //埋点 无欠款迁徙试算页 下一步
                C.Native.TDOnEvent({
                    eventId: '$_03_1_0_58_01_无欠款迁徙试算页'
                });
            } else {
                if($this.isFirstPay == 'Y'){
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0303-申请借款',
                        eventLable: 'iBT-030301-下一步'
                    });
                }else{
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0605-还卡再贷',
                        eventLable: 'iBT-060502-下一步'
                    });
                }
                //埋点 借款试算页 下一步
                C.Native.TDOnEvent(this.talkingDate('下一步'));
            }
            //发起AJAX请求，调用银联认证接口
            if (this.startLoading) return;//防止重复调用
            $this.createRequest({
                url: C.Api('CREDITCARDUNIONPAYCERTIFICATION'), //银联卡认证
                type: 'post',
                data: {
                    loanBindNo: bindNo, //绑定号
                    applyNo: $this.applyNo, //申请号
                    payApplyNo: C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO)||$this.payApplyNo, //支用申请号
                    bankCardNo: ''
                }, //accountId 为公共入参
                callback: function(data){
                    //银联认证拒绝
                    if (data.apvFlag == C.Constant.Enum.FLAG.APVFLAG_RJ) {
                        C.Native.TDOnEvent({
                            eventId: 'iBT-030301-下一步',
                            eventLable: 'iBT-03030102-被拒'
                        });
                        //埋点 借款试算页 事件结果 被拒
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_4_21_01_借款试算页'
                        });
                        C.Native.forward({
                            url: C.Constant.DataUrl.TRANSPAGE.CREDITFAILRESULT//跳转到3.2审核拒绝页面
                        });
                        return;
                    }
                    //重新绑卡
                    if (data.reBindFlag == C.Constant.Enum.FLAG.REBINGFLAG_Y) {
                        C.Native.TDOnEvent({
                            eventId: 'iBT-030301-下一步',
                            eventLable: 'iBT-03030103-提示换卡'
                        });
                        //埋点 借款试算页 事件结果 提示还卡
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_4_21_02_借款试算页'
                        });
                        $this.topTip('此信用卡不符合放款要求，请更换信用卡');
                        return;
                    }
                    //银联认证通过 跳转
                    borrowDate.term = $this.REPAYMENTTRY.term;
                    borrowDate.counterFee = $this.REPAYMENTTRY.counterFee;
                    borrowDate.loanBindNo = $('#loanBinNo').attr('data-bindNo');
                    borrowDate.creditCardName = $('#loanBinNo').attr('data-cardName');
                    borrowDate.loanAmt = $('#figure').val();
                    borrowDate.loanAmtFormat = $this.loanAmt;
                    borrowDate.payApplyNo = $this.payApplyNo || C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
                    borrowDate.purpose = $this.purpose;
                    //存储本地数据（以供借款确认使用） SDK与APP统一存储字段
                    C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA, borrowDate);
                    if($this.isFirstPay == 'Y'){
                        C.Native.TDOnEvent({
                            eventId: $this + '-030301-下一步',
                            eventLable: $this + '-03030101-借款信息'
                        });
                    }else{
                        C.Native.TDOnEvent({
                            eventId: $this + '-060502-下一步',
                            eventLable: $this + '-06050201-确认信息'
                        });
                    }
                    if(borrowDate.fundingModel == 'D' || borrowDate.fundingModel == 'U'){
                        if($this.appVersion >= 50400 || App.IS_SDK){
                            //走产险子系统的流程
                            $this.getH5Link();
                        }else{
                            //走旧的投保流程
                            if($this.isFirstPay == 'Y'){
                                $('#js-policy-prompt').removeClass('dn');
                            }else{
                                $this.goPolicy();
                            }
                        }
                    } else {
                        C.Native.forward({
                            url: C.Constant.DataUrl.TRANSPAGE.BORROW, //跳转到借款确认页面
                            callBack: function(data){
                                $this.renderCredit(data.cardName, data.loanBindNo);
                            }
                        });
                    }
                }
            }, true);
        },
        getH5Link: function(){
            var self = this;
            var postData = {//账户id在init.js中已统一传入，不需要重复传入
                success_link: C.Constant.DataUrl.TRANSPAGE.BORROW,  //页面成功链接函数
                fail_link: C.Constant.DataUrl.TRANSPAGE.BORROWFAIL,  //页面失败链接函数
                h5_link_addr_expire_date: '1',  //H5链接的有效天数
                is_rebuild: 'Y',  //是否重新生成链接
                ln_amt: String(self.loanAmt),  //借款金额
                ln_term: String(self.term),  //借款期限
                is_send_insured_SMS: 'N',  //是否发送投保短信
                appl_no: self.payApplyNo || C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO),  //支用申请号
                funding_model: self.fundingModel,
                use_type: (self.isMigrate && self.isMigrate == 'Y') ? 'Y' : self.isFirstPay
            };
            this.createRequest({
                url: C.Api('GET_INSURANCE_H5_lIANK'),
                type: 'post',
                data: postData,
                callback: function(data){
                    console.log(data.cover_no);
                    var piUrl = data.h5_link_addr,
                        tipMsg = '您正在进入保险公司网页，保险相关服务由保险公司提供。',
                        backMsg = '投保完成，正返回平安普惠继续申请流程。',
                        needForward = 1;//是否由native来使用forward跳转：是传1，否传0
                    C.Native.processPIBussnise(piUrl, tipMsg, backMsg, needForward, function(res){
                        if(res.code == '1'){//将投保单号存本地，供借款确认页使用
                            //埋点 还卡投保页 成功
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_4_25_01_还卡投保页'
                            });
                            C.Utils.data(C.Constant.DataKey.BT_INSURANCE_NO, data.cover_no);
                        }else if(res.code == '0'){
                            //埋点 还卡投保页 失败
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_4_25_02_还卡投保页'
                            });
                        }
                    });
                }
            });
        },
        // 提示信息内容
        topTip: function(text) {
            var $this = this,
                tip = $('#error-tip'),
                tipText = $('#tip-text');
            $this.handler && clearTimeout($this.handler);
            tip.removeClass('dn');
            tipText.text(text);
            $this.handler = setTimeout(function(){
                tip.addClass('dn');
                tipText.text('');
            }, 2000);
        },
        // 输入框获取焦点时，显示贷款金额数字
        showAmountInput: function(e) {
            var $this = this,
                val = $this.loanAmt || '';
            setTimeout(function(){
                $(e.currentTarget).prop('placeholder', '').val(val);
            }, 100);
            $this.hideRepayment();
        },
        // 在输入框获取焦点时，重置还款信息
        hideRepayment: function() {
            $('#try-wrap').html('');
            $('#next-btn').hide();
            $('#counterFee').text('0.00元');
        },
        //去还款
        goRepayment: function(){
            C.Native.forward({
                //moduleName: 'icard',
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENT //还款列表
            });
        },
        doStopApply: function(){
            $('#js-frequency-limit').addClass('dn');
        },
        stopPolicy: function(){
            $('#js-policy-prompt').addClass('dn');
        },
        //去投保
        goPolicy: function(){
            var $this = this;
            $this.stopPolicy();
            C.Native.TDOnEvent({
                eventId: 'iBT-0213-投保单',
                eventLable: 'iBT-021301-投保单确定'
            });
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.POLICY
            });
        },
        knowDetail: function(){
            //埋点 借款试算页 投保了解详情
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_21_06_借款试算页'
            });
            $('#js-insurance-prompt').removeClass('dn');
        },
        closePrompt: function(){
            //埋点 投保须知弹窗页 关闭弹窗
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_24_01_投保须知弹窗页'
            });
            $('#js-insurance-prompt').addClass('dn');
        }
    }));

    $(function(){
        new Page();
    });

});