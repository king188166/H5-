/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2016-03-17
 * @time  : pm 19:53
 *
 * @describe: 选择产品---我的i贷
 */

define(['zepto', 'C', 'view', 'js/refresh', 'js/callback'], function ($, C, View, RE, CB) {
    'use strict';
    C.FastClick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap .js-tixian-notSEG1': 'toTixian',
            'tap .js-tixian-SEG1': 'toTixianSEG1',
            'tap .js-updatecredit': 'toUpdateCredit',
            'tap .js-addCredit': 'toAddCredit',
            'tap .js-bt': 'toBT',
            'tap .js-wait': 'toWait',
            'tap .js-now-tixian': 'toNowTixian1',
            'tap #disagree_btn': 'hideEsignTpl',
            'tap #agree_btn': 'submitEsign',
            'tap .qianming': 'esign',
            'tap #to-product-detail': 'topToProDetail',
            'tap .js_showLeayer': 'showWindow',
            'tap .guide3': 'leayerToProDetail',
            'tap #goTest': 'goTest',
            'tap #cancelTest': 'hideTest'
        },
        initialize: function () {
            var self = this;
            //埋点 我的I贷账户页
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_13_我的I贷账户页'
            });
            
            C.Native.getUserInfo(function (data) {
                self.loginInfo = data;
            });
            //清空迁徙数据
            C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, null);
            self.times = 0;//点击次数默认3次；
            self.isPosting = false;
            self.eleFlag = false;//是否有电子签名 true 有；false 没有
            self.bankCardFlag = 'N';
            self.barCode = '';
            self.online_domesticAlgorithm = 'Y';
            self.online_OcrKey = 'N';
            self.online_OcrNeed = 'N';
            self.isNowTixian = false;
            self.resultData = {};
            self.isLoanApply = true; //标志当前点击的产品,区分电子签名 提现 则为true；还卡 则为false
            self.iloanVersion = C.Utils.data(C.Constant.DataKey.SDK_VERSION);//是否是Native最新版本
            C.UI.stopLoading();
            self.getSwitch();
            self.getProductionInfo();

            if (App.IS_SDK) {
                C.Native.getUIParams(function (data) {
                    //广告栏图片
                    C.Utils.data(C.Constant.DataKey.AD_IMG, data.advImg);
                    var productName = data.productName || data.proName;
                    C.Native.setHeader({
                        title: productName ? ('我的' + productName) : '我的i贷',
                        leftCallback: function () {
                            CB.init();
                        }
                    });
                });
            } else {
                C.Native.setHeader({
                    title: '我的i贷',
                    leftCallback: function () {
                        C.Native.backModule({
                            moduleName: C.Constant.MODULE_NAME.home,
                            url: C.Constant.index_page
                        });
                    }
                });

                //异常用户验证
                C.Native.pah_loanSuccess();
            }
        },
        //心理测评资格获取
        showTest: function() {
            if (App.IS_SDK) return;
            C.UI.loading();
            $.ajax({
                url: C.Api('IS_NEED_EVALUATION'),
                type: 'POST',
                success: function(data){
                    if(data.flag == C.Flag.SUCCESS) {
                        var times = C.Utils.data('CLOSE_TEST_TIMES') || 0; 
                        if(data.data.answerStatus === '1' && times < 8) {
                            times++;                                // 测评次数，每请求一次，就记录一次，并缓存起来
                            C.Utils.data('CLOSE_TEST_TIMES', times);
                            $('#testTip').show();
                        }
                    }                    
                },
                complete: function(){
                    C.UI.stopLoading();
                }
            });
        },
        //判断是否是第一次进入
        isFirstEnter: function () {
            var self = this;
            self.tapTime = 0;//记录点击次数
            self.account = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).accountId || ''; //获取用户的ID
            self.group = C.Utils.data('iloanbt_passed_users') || [];//存储用户登录信息（用户id 和 点击次数）
            for (var i = 0, len = self.group.length; i < len; i++) {
                if (self.account == self.group[i].account && self.group[i].tapTime == 3) {
                    return false;
                } else if (self.account == self.group[i].account && self.group[i].tapTime < 3) {
                    self.tapTime = self.group[i].tapTime;
                }
            }
            //记录用户数据
            var userLogin = {};
            userLogin.account = self.account;
            userLogin.tapTime = self.tapTime;
            return userLogin;
        },
        //点击蒙层
        showWindow: function (e) {
            var self = this;
            e = e || window.event;
            e.stopPropagation();
            var arrnode = $('.js_show_flag');
            var num = 'false';
            for (var i = 0; i < arrnode.length; i++) {
                if ($(arrnode[i]).hasClass('guide-show')) {
                    num = i;
                }
            }
            if (num === 'false') {return;}
            var userLogin = {};
            if (num == arrnode.length - 1) {
                //第三次点击
                $(arrnode[num]).removeClass('guide-show');
                self.times = 3;
                self.tapTime = self.times;
                userLogin.account = self.account;
                userLogin.tapTime = self.tapTime;
                self.group.push(userLogin);
                C.Utils.data('iloanbt_passed_users', self.group);
                self.showTest();
            } else {
                //第一次和第二次   
                self.times = num + 1;
                self.tapTime = self.times;
                userLogin.account = self.account;
                userLogin.tapTime = self.tapTime;
                self.group.push(userLogin);
                C.Utils.data('iloanbt_passed_users', self.group);
                $(arrnode[num]).removeClass('guide-show');
                $(arrnode[num + 1]).addClass('guide-show');
            }
        },

        // 获取用户信息
        getProductionInfo: function () {
            var self = this;
            if (self.isPosting) {
                return;
            }
            self.isPosting = true;
            RE.init(function (res) {
                self.isPosting = false;
                C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, res.data);
                if (res.data.subProcessCode && res.data.subProcessCode == 'RP') {
                    // 再贷入错首贷账户页时，提示重新登录，并且点击提现或者还卡禁止跳转
                    self.subProcessCode = res.data.subProcessCode;
                    C.Native.tip('唉哟，页面出错了，请重新登录i贷');
                }
                self.showView(res.data);
                // 出额度页面显示引导层
                if (res.data.BTCreditInfo.creditStatus == 'PS') {
                    //埋点 蒙板介绍页 
                    C.Native.TDOnEvent({
                        eventId: '$_03_0_3_14_蒙板介绍页'
                    });
                    var firstData = self.isFirstEnter();
                    if (firstData.tapTime == 0) {
                        $($('.js_show_flag')[0]).addClass('guide-show');
                    } else if (firstData.tapTime == 1) {
                        $($('.js_show_flag')[1]).addClass('guide-show');
                    } else if (firstData.tapTime == 2) {
                        $($('.js_show_flag')[2]).addClass('guide-show');
                    } else {
                        self.showTest();
                    }
                } else {
                    self.showTest();
                }
            }, function (res) {
                self.isPosting = false;
            });
        },
        // 渲染页面
        showView: function (data) {
            var self = this,
                html = '',
                advImg = C.Utils.data(C.Constant.DataKey.AD_IMG);
            self.resultData = data;
            data.availableCredit = C.Utils.formatMoney(data.availableCredit);
            data.IS_SDK = App.IS_SDK;
            if (data.ICreditInfo && (typeof data.BTCreditInfo) == 'undefined') {
                html = _.template($('#tpl-only-iloan').html(), {
                    data: data
                });
            } else if (data.ICreditInfo && data.BTCreditInfo && data.BTCreditInfo.creditStatus != 'NN') {
                html = _.template($('#tpl-bt-iloan').html(), {
                    data: data
                });
            } else if (data.ICreditInfo && data.BTCreditInfo && data.BTCreditInfo.creditStatus == 'NN') {
                html = _.template($('#tpl-only-iloan').html(), {
                    data: data
                });
            }
            $('section#content-body').html(html);
            //广告栏图片展示
            if(App.IS_SDK){
                if($('#to-product-detail')[0]){
                    advImg? $('#to-product-detail')[0].src = advImg : $('#to-product-detail')[0].src = 'images/ads1.png';
                }else{
                    advImg? $('#iloan-ads')[0].src =advImg : $('#iloan-ads')[0].src = 'images/ads.png';
                }
            }

            //0119版本进入生成额度页面时埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0206-生成额度',
                eventLable: 'iBT-020605-生成额度'
            });
            //埋点 I贷账户页  额度变更
            C.Native.TDOnEvent({
                eventId: '$_03_2_4_16_02_I贷账户页'
            });
            self.initAnimation(C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).availableCredit, data.credit);
        },
        //仪表盘进度
        initAnimation: function (availableNum, allNum) {
            var dior = availableNum / allNum;
            var num1 = Math.floor(471 * dior),
                num2 = 471 - num1;
            $('#path').css('stroke-dasharray', num1 + ' ' + num2);
            if (availableNum == '0' || availableNum == 0) {
                $('.account-svg').addClass('account-zreo');
            }
        },
        //提现-SEG2/3
        toTixian: function (e) {
            if(this.isPosting) return;
            var self = this,
                $target = $(e.currentTarget);
            if ($target.hasClass('btn-dis')) {
                return;
            }
            self.loanCode = $target.attr('data-loanCode');
            self.toNowTixian();
        },
        //提现-SEG1
        toTixianSEG1: function (e) {
            var arrnode = $('.js_show_flag');
            for (var i = 0; i < arrnode.length; i++) {
                if ($(arrnode[i]).hasClass('guide-show')) {
                    return;
                }
            }

            var self = this,
                $target = $(e.currentTarget);
            self.loanCode = $target.attr('data-loanCode');
            self.toNowTixian();

        },
        toNowTixian: function (e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-0206-生成额度',
                eventLable: 'iBT-020602-提现'
            });
            //埋点 I贷账户页  申请提现
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_01_I贷账户页'
            });
            var self = this;
            // 入再贷错入首贷账户页，禁止支用
            if (self.subProcessCode == 'RP') {
                C.Native.tip('唉哟，页面出错了，请重新登录i贷');
                return;
            }
            var param = {
                applyNo: self.resultData.applyNo,
                loanCode: self.loanCode
            };
            if (App.IS_SDK) {
                param.channelType = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO).sourceType;
            }
            if(self.isLoading){
                return;
            }
            $('.js_hidetip').remove();
            //新的传参方式，complete里面执行其他页面样式更改
            self.dataRequest({
                url: C.Api('SELECT_PRODUCTION'),
                callback: self.toNowTixianCallback,
                type: 'POST',
                data: param
            });
        },
        //马上提现--温馨提示
        toNowTixian1: function (e) {
            var self = this;
            //埋点 I贷账户页  提额中马上提现
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_06_I贷账户页'
            });
            self.isNowTixian = true;
            self.toNowTixian();
        },
        //马上提现callback
        toNowTixianCallback: function (res) {
            console.log(res);
            var self = this,
                params = {};
            if (res.data.resultCode != '0') {
                //循环动用开关-删除一期的资金开关
                if (res.data.signSwitch && res.data.signSwitch == '0') {
                    C.Native.tip(res.data.switchMsg);
                } else {
                    params.idvalid = res.data.idvalid;
                    params.isFirstPay = res.data.infoMap.isFisrtPay;
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, params); //将身份证有效性本地存储，给到试算页使用
                    console.log(C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID));
                    self.fundingModel = res.data.fundingModel;//必传字段
                    self.loanCompanyCode = res.data.loanCompanyCode || 'L';
                    self.isCredit = res.data.isCredit;
                    self.newBankName = res.data.newBank;
                    self.bankCode = res.data.bankCode;
                    if (res.data.infoMap.apvFlag == 'PS') {
                        self.toLoanApply(res);
                    } else if (res.data.infoMap.apvFlag == 'RJ') {
                        C.Native.forward({
                            url: 'credit_fail_result.html'
                        });
                    } else if (res.data.infoMap.apvFlag == 'PA') {
                        if (self.isNowTixian) {
                            self.toLoanApply(res);
                        } else {
                            var html = _.template($('#info-layer').html(), {
                                data: self.resultData
                            });
                            $('body').append(html);                        
                        }
                    }
                }
            } else {
                C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
            }
        },
        //在跳转到loan_apply之前，进行银行有效性的校验
        toLoanApply: function(res){
            var self = this;
            console.log(res);
            C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO, res.data.payApplyNo);
            //新增迁徙无欠款校验逻辑
            var migrateMap = res.data.migrateMap ? res.data.migrateMap : '';
            if (migrateMap && migrateMap.isMigrate == 'Y' && migrateMap.isDebt == 'N' && (self.iloanVersion || !App.IS_SDK)) {
                //埋点 无欠款迁徙
                C.Native.TDOnEvent({
                    eventId: '$_03_2_0_13_01_我的I贷账户页'
                });
                migrateMap.loanCode = (res.data.infoMap && res.data.infoMap.loanCode) ? res.data.infoMap.loanCode : '';
                C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, migrateMap);
                if (migrateMap.isSign == 'Y') {
                    //需要电子签名
                    if (App.IS_SDK) {
                        //SDK3.0用户 跳转到H5电子签名
                        C.Native.forward({
                            url: 'old_personal-credit.html',
                            data: {
                                fromPage: 'loan_select',
                                fundingModel: migrateMap.fundingModel,
                                loanCompanyCode: migrateMap.loanCompanyCode,
                                isCredit: migrateMap.isCredit,
                                newBankName: migrateMap.signCode == 'S00002'?migrateMap.newBank : migrateMap.cgiBankName,
                                bankCode: migrateMap.bankCode
                            }
                        });
                        return;
                    }
                    //APP2.0用户 跳转到迁徙综合授权书
                    C.Native.forward({
                        url: 'migrate_shouquan.html',
                        data: {
                            fromPage: 'loan_select',
                            applyNo: res.data.applyNo
                        }
                    });
                    return;
                }
                //已电子签名 跳转到申请提现页
                C.Native.forward({
                    url: 'loan_apply.html'
                });
                return;
            }
            if(res.data.isValidity && res.data.isValidity == '0'){
                //银行无效
                if(res.data.fundingModel && res.data.fundingModel == 'U'){//cgi+小贷+银行
                    if(!res.data.newBank){
                        //新银行无效,弹出今日额度已抢光提示
                        C.Native.tip(res.data.resultMsg);
                    }else{//新银行有效
                        if(res.data.isCredit && res.data.isCredit == '1'){
                            var bankClass = C.Constant.BANKCONTRACT[res.data.newBank];
                            //需要征信，去电子签名，显示银行征信
                            $('.model_L').hide();
                            $('.model_UD').show();
                            $('.bankItem').addClass('dn');
                            $('.'+bankClass).removeClass('dn');
                            $('.isShow').addClass('dn');//隐藏个人征信和综合授权书
                            self.isLoanApply = true;
                            self.eleFlag = false;
                            self.isSigned();
                        }else{
                            //不需要征信，调用银行变更接口
                            self.isLoanApply = true;
                            self.doBankAlert(res);
                        }
                    }
                }else if(res.data.fundingModel && res.data.fundingModel == 'D'){//cgi+小贷
                    C.Native.forward({
                        url: 'loan_apply.html'
                    });
                }else{//担保+小贷，弹出新日额度已抢光提示
                    C.Native.tip(res.data.resultMsg); 
                }
            }else{
                //银行有效，直接跳转到试算页
                C.Native.forward({
                    url: 'loan_apply.html'
                });
            }
        },
        doBankAlert: function(res){
            var self = this;
            console.log(res);
            var params = {
                payApplyNo: res.data.payApplyNo,
                applyNo: res.data.applyNo,
                bankCode: res.data.bankCode,
                bankName: res.data.newBank //变更后的银行
            };
            C.UI.loading();
            $.ajax({
                url: C.Api('ALERT'),
                type: 'POST',
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function(data){
                    console.log(data);
                    if(data.flag == C.Flag.SUCCESS){
                        if(data.data.resultCode == '1'){
                            if(self.isLoanApply){//提现,跳转到loan_apply
                                C.Native.forward({
                                    url: 'loan_apply.html'
                                });
                            }else{//还卡，跳转到小车轮询
                                C.Native.forward({
                                    url: 'icard_loading.html'
                                });
                            }
                        }else{
                            C.Native.tip(data.data.resultMsg);
                        }
                    }                    
                },
                complete: function(){
                    C.UI.stopLoading();
                }
            });
        },
        //刷新额度
        toUpdateCredit: function (e) {
            //埋点 I贷账户页  额度不足刷新额度
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_04_I贷账户页'
            });
            var $target = $(e.currentTarget);
            if ($target.hasClass('btn-dis')) {
                return;
            }
            $target.addClass('btn-dis');
            window.location.reload();
        },
        //提升额度
        toAddCredit: function (e) {
            if (App.IS_SDK) {
                C.Native.tip('如需提升额度请下载平安普惠APP继续操作');
                return;
            }
            C.Native.TDOnEvent({
                eventId: 'iBT-0206-生成额度',
                eventLable: 'iBT-020603-提升额度'
            });
            //埋点 I贷账户页  提升额度
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_03_I贷账户页'
            });
            var $target = $(e.currentTarget);
            if ($target.hasClass('btn-dis')) {
                return;
            }
            $target.addClass('btn-dis');
            C.UI.loading();
            C.Native.forwardModule({
                moduleName: 'paehome',
                url: 'credit-information.html?module=iloanbt'
            });
            setTimeout(function () {
                $target.removeClass('btn-dis');
                C.UI.stopLoading();
            }, 3000);
        },
        //还卡
        toBT: function (e) {
            var arrnode = $('.js_show_flag');
            for (var i = 0; i < arrnode.length; i++) {
                if ($(arrnode[i]).hasClass('guide-show')) {
                    return;
                }
            }
            C.Native.TDOnEvent({
                eventId: 'iBT-0206-生成额度',
                eventLable: 'iBT-020601-还卡'
            });
            //埋点 I贷账户页  申请还卡
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_02_I贷账户页'
            });
            var self = this,
                $target = $(e.currentTarget);
            self.BTloanCode = $target.attr('data-loanCode');
            // 入再贷错入首贷账户页，禁止支用
            if (self.subProcessCode == 'RP') {
                C.Native.tip('唉哟，页面出错了，请重新登录i贷');
                return;
            }
            var param = {
                applyNo: self.resultData.applyNo,
                loanCode: self.BTloanCode
            };
            if (App.IS_SDK) {
                param.channelType = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO).sourceType;
            }
            if(self.isLoading){
                return;
            }
            self.dataRequest({
                url: C.Api('SELECT_PRODUCTION'),
                callback: self.toBTCallback,
                type: 'POST',
                data: param
            }, false, function(){
                //
            });
        },

        //还卡callback
        toBTCallback: function (res) {
            var self = this,
                params = {},
                migrateMap = res.data.migrateMap ? res.data.migrateMap : '';
            console.log(res.data);
            if (res.data.resultCode != '0') {
                //BLAZE开关关闭
                if (res.data.blazeSwitch && res.data.blazeSwitch == '0') {
                    C.Native.tip(res.data.blazeSwitchMsg);
                } else if (res.data.signSwitch && res.data.signSwitch == '0') { //资金开关关闭--删除一期的资金开关
                    C.Native.tip(res.data.switchMsg);
                } else {
                    params.idvalid = res.data.idvalid;
                    params.isFirstPay = res.data.infoMap.isFisrtPay;
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, params); //将身份证有效性本地存储，给到试算页使用
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO, res.data.payApplyNo);
                    self.isAuthFlag = res.data.infoMap.isAuthFlag;
                    self.fundingModel = res.data.fundingModel || C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).fundingModel;//当客户打标银行不为U时，产品选择接口不返回该字段
                    self.loanCompanyCode = res.data.loanCompanyCode || 'L';
                    self.isCredit = res.data.isCredit;
                    self.newBankName = res.data.newBank;
                    self.bankCode = res.data.bankCode;
                    self.apvFlag = res.data.infoMap.apvFlag;
                    self.isLoanApply = false;//标志现在去电子签名的是提现流程还是还卡流程，false为还卡

                    // 新增迁徙判断逻辑
                    if (migrateMap && migrateMap.isMigrate == 'Y' && migrateMap.isDebt == 'N') {
                        // 如果是PBOC且符合迁徙的用户，使用migrateMap中返回的数据
                        self.fundingModel = migrateMap.fundingModel;
                        self.loanCompanyCode = migrateMap.loanCompanyCode;
                        self.isCredit = migrateMap.isCredit;
                        self.newBankName = migrateMap.signCode == 'S00002' ? migrateMap.newBank : migrateMap.cgiBankName; // 用于电子签名展示银行协议内容
                        self.bankCode = migrateMap.bankCode;
                        self.isMigrate = migrateMap.isMigrate;
                        self.isSign = migrateMap.isSign;
                        self.signCode = migrateMap.signCode;
                        self.ratio = migrateMap.ratio;
                        // 存储产品编码
                        migrateMap.loanCode = (res.data.infoMap && res.data.infoMap.loanCode) ? res.data.infoMap.loanCode : '';
                        // 本地存储迁徙数据
                        C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, migrateMap);
                    }

                    //渲染电子签名授权书内容
                    if(self.fundingModel && (self.fundingModel == 'U' || self.fundingModel == 'D')){
                        $('.model_L').hide();
                        $('.model_UD').show();
                    }else{
                        $('.model_UD').hide();
                        $('.model_L').show();
                        $('#esign_section').find('.agreement').removeClass('.agreement-sm');
                    }
                    
                    //显示对应的银行征信，若无则不显示
                    var bankClass;
                    if (migrateMap && migrateMap.isMigrate == 'Y' && migrateMap.isCredit == '1' && migrateMap.fundingModel == 'U') {
                        // 新增迁徙逻辑 展示银行授权书
                        bankClass = C.Constant.BANKCONTRACT[self.newBankName];
                        $('.bankItem').addClass('dn');
                        $('.'+bankClass).removeClass('dn');
                    } else if (parseInt(res.data.isCredit)) {
                        bankClass = C.Constant.BANKCONTRACT[res.data.newBank];
                        $('.bankItem').addClass('dn');
                        $('.'+bankClass).removeClass('dn');
                    } else {
                        $('.bankItem').addClass('dn');
                    }

                    if(res.data.isValidity == '0' && ((!res.data.newBank && res.data.fundingModel == 'U') || res.data.fundingModel == 'L')){
                        //当变更之后的资金模式为U且新银行无效 或者 变更后资金模式为L，则弹出提示
                        C.Native.tip(res.data.resultMsg);
                        return;
                    }
                    //过了30天需要鉴权,或者银行失效&&需要征信
                    if (self.isAuthFlag == 'Y') {
                        C.Native.TDOnEvent({
                            eventId: 'iBT-03-还卡',
                            eventLable: 'iBT-0301-重查征信'
                        });
                        //埋点 I贷账户页 BT重查征信
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_4_16_01_I贷账户页'
                        });
                        //目前eleFlag一直=Y，一直需要电子签名
                        if ((migrateMap && migrateMap.isMigrate == 'Y') || res.data.eleFlag == 'Y') { //需要电子签名
                            self.eleFlag = false;
                            self.bankCardFlag = res.data.bankCardFlag;//保存绑卡开关标志：开：平安付；关：列表
                            if($('.isShow').hasClass('dn')){//显示个人征信和综合授权书
                                //$('.isShow').removeClass('dn');
                                $('.mt30').find('.isShow').removeClass('dn');
                                switch (self.loanCompanyCode) {
                                    case 'C':
                                        $('.zxsq_cgi_c').removeClass('dn');
                                        break;
                                    case 'H':
                                        $('.zxsq_cgi_h').removeClass('dn');
                                        break;
                                    default:
                                        $('.zxsq_cgi_l').removeClass('dn');
                                        break;
                                }
                            }
                            self.isSigned();
                        } else { //pboc不需要电子签名
                            if(res.data.isCredit && res.data.isCredit == '1'){//银行无效，新银行需要征信
                                self.eleFlag = false;
                                $('.isShow').addClass('dn');//隐藏个人征信和综合授权书
                                self.isSigned();
                            }else{//银行无效，新银行不需要征信
                                self.toLoading(res);
                            }   
                        }
                    } else { //没过30天
                        // 新增迁徙无欠款校验逻辑 PBOC无过期，迁徙开关打开，用户符合无欠款迁徙条件
                        if (migrateMap && migrateMap.isMigrate == 'Y' && migrateMap.isDebt == 'N' && (self.iloanVersion || !App.IS_SDK)) {
                            //埋点 无欠款迁徙
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_0_13_01_我的I贷账户页'
                            });
                            if (migrateMap.isSign == 'Y') {
                                //需要电子签名
                                if (App.IS_SDK) {
                                    //SDK3.0用户 跳转到H5电子签名
                                    C.Native.forward({
                                        url: 'old_personal-credit.html',
                                        data: {
                                            fromPage: 'loan_select',
                                            fundingModel: migrateMap.fundingModel,
                                            loanCompanyCode: migrateMap.loanCompanyCode,
                                            isCredit: migrateMap.isCredit,
                                            newBankName: migrateMap.signCode == 'S00002'?migrateMap.newBank : migrateMap.cgiBankName, // 用于电子签名展示银行协议内容
                                            bankCode: migrateMap.bankCode,
                                            isAuthFlag: self.isAuthFlag
                                        }
                                    });
                                    return;
                                }
                                //APP2.0用户 跳转到迁徙综合授权书
                                C.Native.forward({
                                    url: 'migrate_shouquan.html',
                                    data: {
                                        fromPage: 'loan_select',
                                        applyNo: res.data.applyNo
                                    }
                                });
                                return;
                            }
                            //已电子签名 跳转到跑小车页 调用小车轮询接口
                            C.Native.forward({
                                url: 'icard_loading.html'
                            });
                            return;
                        }
                        if(res.data.isCredit && res.data.isCredit == '1'){//PBOC有效，但需要征信,只显示银行征信授权书
                            self.eleFlag = false;
                            $('.isShow').addClass('dn');//隐藏个人征信和综合授权书
                            self.isSigned();
                        }else{//PBOC有效，但不需要征信
                            if (res.data.infoMap.apvFlag == 'BTPS' || res.data.infoMap.apvFlag == 'PA') {
                                self.toLoading(res);
                            } else if (res.data.infoMap.apvFlag == 'RJ') {
                                C.Native.forward({
                                    url: 'credit_fail_result.html'
                                });
                            }
                        }
                    }
                }
            } else {
                C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
            }
        },
        toLoading: function(res){
            var self = this;
            if(res.data.isValidity && res.data.isValidity == '0'){
                //银行无效，需要变更
                if(self.fundingModel == 'U' && res.data.newBank){
                    //U,新银行有效，不征信，则调用银行变更接口
                    self.isLoanApply = false;
                    self.doBankAlert(res);
                }else if(self.fundingModel == 'D'){
                    C.Native.forward({
                        url: 'icard_loading.html'
                    });
                }
            }else{
                C.Native.forward({
                    url: 'icard_loading.html'
                });
            }
        },
        //继续等待
        toWait: function (e) {
            //埋点 I贷账户页  提额中继续等待
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_05_I贷账户页'
            });
            $('.js-infolayer').remove();
        },
        //判断是否可以电子签名
        isSigned: function () {
            var self = this,
                userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            self.productType = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).productType;
            if (self.eleFlag) {
                //显示大白圆
                self.hideEsignTpl();
                if(self.isLoanApply){//若是提现的电子签名,直接跳转页面
                    C.Native.forward({
                        url: 'loan_apply.html'
                    });
                    return;
                }
                //已电子签名
                if (userdata.paPayToken){
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0301-重查征信',
                        eventLable: 'iBT-030102-绑银行卡'
                    });
                    //埋点 重查征信绑卡页 绑银行卡（还卡流程）
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_18_02_重查征信绑卡页'
                    });
                    if(self.isAuthFlag == 'Y'){//PBOC失效并且需要电子签名，签名之后需要绑卡
                        //电子签名--同意--开关打开-卡列表-确定-2.1.5-预留手机号-验证码-结果页面
                        if (self.bankCardFlag == 'Y'){
                            self.queryCardList();
                        } else { //电子签名--同意--开关关闭--偷偷传递第一张卡--过度页面
                            self.queryCardList();
                        }
                    }else{//PBOC有效 但 银行无效且需要征信
                        if (self.apvFlag == 'BTPS' || self.apvFlag == 'PA') {
                            C.Native.forward({
                                url: 'icard_loading.html'
                            });
                        } else if (self.apvFlag == 'RJ') {
                            C.Native.forward({
                                url: 'credit_fail_result.html'
                            });
                        }
                    }   
                } else {
                    //没有静默注册成功
                    C.Native.loginOrRegistPaOne(function () {
                        C.Native.getUserInfo(function (data) {
                            C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                        });
                    });
                }
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0301-重查征信',
                    eventLable: 'iBT-030101-综合授权书'
                });
                //埋点 重查征信页  
                C.Native.TDOnEvent({
                    eventId: '$_03_0_4_17_重查征信页'
                });
                if (App.IS_SDK) {
                    //跳转到H5电子签名
                    C.Native.forward({
                        url: 'old_personal-credit.html',
                        data: {
                            fromPage: 'loan_select',
                            fundingModel: self.fundingModel,
                            isCredit: self.isCredit,
                            loanCompanyCode: self.loanCompanyCode,
                            newBankName: self.newBankName,
                            bankCode: self.bankCode,
                            isAuthFlag: self.isLoanApply ? '' : self.isAuthFlag
                        }
                    });
                    return;
                }

                //未电子签名弹出综合授权书,分老流程和联合放款;L 担保+小贷（默认值）, D CGI+小贷,U CGI+联合放款
                if (self.fundingModel && (self.fundingModel == 'U' || self.fundingModel == 'D')) {
                    $('#zxsq_cgi').show();
                    self.authText = $('#zxsq_cgi').html();
                } else {
                    if (self.loanCompanyCode == 'C') {
                        $('#zxsq_l').hide();
                        $('#zxsq_c').show();
                        self.authText = $('#zxsq_c').html();
                    } else {
                        $('#zxsq_c').hide();
                        $('#zxsq_l').show();
                        self.authText = $('#zxsq_l').html();
                    }
                }
                //否则会有一个大白圆
                $('.account-svg').addClass('dn');
                $('#esign_section').find('.signature').show();
                $('#esign_section').show();
            }
        },

        //隐藏授权书电子签名
        hideEsignTpl: function () {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010103-不同意'
            });
            //埋点 重查征信页  不同意
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_17_03_重查征信页'
            });
            $('#esign_section').hide();
            $('#img').hide().attr('src', '');
            $('#result').val('');
            $('#qian-input').show();
            $('.account-svg').removeClass('dn');
        },

        // 提交电子签名
        submitEsign: function () {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010102-同意'
            });
            //埋点 重查征信页  同意
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_17_02_重查征信页'
            });
            var self = this;
            var isSigned = !$('#result')[0].value ? false : true;
            if (!isSigned) {
                C.Native.tip('请先签名');
                return;
            }
            var params = {
                imgDenseStr: self.imgDenseStr,
                imgBytes: self.imgBytes,
                productType: self.productType,
                loanCompanyCode: self.loanCompanyCode,
                platform: App.IS_IOS ? 'IOS' : 'A',
                businessNo: self.barCode
            };
            params.ocrKey = self.online_OcrKey;
            params.ocrNeed = self.online_OcrNeed;
            params.productId = 'ILOANBT';
            params.isDomesticAlgorithm = self.online_domesticAlgorithm;
            //传给SS，用于标识是否需要调用银行变更接口，若为空，SS则不需调用
            params.applyNo = self.resultData.applyNo;
            params.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
            params.bankName = self.newBankName || '';
            params.bankCode = self.bankCode || '';
            // 迁徙新增入参
            if (self.isMigrate && self.isMigrate == 'Y') {
                params.isMigrate = self.isMigrate; //迁徙电子签名入参
                params.isSign = self.isSign; //迁徙电子签名入参
                params.signCode = self.signCode; //迁徙电子签名入参
                params.fundingModel = self.fundingModel; //迁徙电子签名入参
                params.ratio = self.ratio; //迁徙电子签名入参
            }
            if(self.isLoading){
                return;
            }
            self.dataRequest({
                url: C.Api('BT_UPLOADPOSELECTRONICSIGNATURE'),
                callback: self.toSubmitEsign,
                type: 'POST',
                data: params
            }, false, function () {
                // empty
            });
        },
        //提交电子签名callBack
        toSubmitEsign: function (res) {
            var self = this;
            if (res.flag == '1') {
                if(res.data.resultCode && res.data.resultCode == '0'){//银行变更接口失败
                    C.Native.tip(res.data.resultMsg);
                    return;
                }
                C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO, res.data);
                self.eleFlag = true;
                self.isSigned();               
            } else { //OCR识别的结果校验，=3代表校验不通过需要重新签名;=2代表接口有问题
                $('#img').hide().attr('src', '');
                $('#result').val('');
                $('#qian-input').show();
            }
        },
        // 调用Native电子签名接口
        esign: function (e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010101-电子签名'
            });
            //埋点 重查征信页  电子签名
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_17_01_重查征信页'
            });
            var self = this;
            var $target = $(e.currentTarget);
            var barCode = 'iloanbt' + Math.round(Math.random() * 1000) + new Date().getTime();
            
            if ($target.hasClass('justClick')) {
                return;
            }
            $target.addClass('justClick');
            setTimeout(function () {
                $target.removeClass('justClick');
            }, 2000);

            C.Native.esign3({
                domesticAlgorithm: self.online_domesticAlgorithm,
                barCode: barCode,
                enText: self.authText,
                keyWord: ''
            }, function (res) {
                console.log(res);
                if (typeof res == 'string') {
                    res = JSON.parse(res);
                }
                if (typeof res.signData == 'string') {
                    res.signData = JSON.parse(res.signData);
                }
                if (res.code == '1') {
                    if (res.result && res.result.imageData) {
                        //全局保存barCode
                        self.barCode = barCode;
                        self.imgBytes = res.result.imageData;
                        self.imgDenseStr = res.result.signData;
                        $('#qian-input').hide();
                        var srcStr = 'data:image/jpg;base64,' + self.imgBytes;
                        $('#img').attr('src', srcStr).show();
                        $('#result').attr('value', self.imgDenseStr);
                    }
                } else {
                    C.Native.tip('电子签名出错' + res.msg);
                }
            });
        },

        //查询该账号是否有已绑定卡列表
        queryCardList: function () {
            var self = this,
                userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            if (!userdata) return;
            C.Native.getDeviceInfo(function (data) {
                var param = {
                    curVer: data.result.appVersion,
                    machineSN: data.result.MachineSN,
                    mobileNo: userdata.mobile,
                    loanType: '2'
                };
                self.dataRequest({
                    url: C.Api('BINDBANKCARDS'),
                    callback: self.toJudgeChooseCard,
                    type: 'POST',
                    data: param
                }, true);
            });
        },
        //查询该账号是否有已绑定卡列表callback
        toJudgeChooseCard: function (res) {
            var self = this;
            if (res.flag == C.Flag.SUCCESS && res.data) {
                if (res.data.bankCards && res.data.bankCards.length > 0) {
                    //电子签名--同意--开关打开-卡列表-确定-2.1.5-预留手机号-验证码-结果页面
                    if (self.bankCardFlag == 'Y') {
                        C.Native.TDOnEvent({
                            eventId: 'iBT-030102-绑银行卡',
                            eventLable: 'iBT-03010201-选择银行卡'
                        });
                        C.Utils.data(C.Constant.DataKey.BT_BINDCARD_FLAG, '1');
                        C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST, res.data);
                        C.Native.forward({
                            url: 'select_auther_card_list.html',
                            data: {
                                route: 'forward',
                                url: 'icard_loading.html',
                                moduleName: 'iloanbt',
                                failRoute: 'back',
                                failUrl: 'loan_select.html',
                                failModuleName: ''
                            }
                        });
                    } else { //电子签名--同意--开关关闭--偷偷传递第一张卡--过度页面
                        C.Native.TDOnEvent({
                            eventId: 'iBT-030102-绑银行卡',
                            eventLable: 'iBT-03010201-选择银行卡'
                        });
                        var momoBank = res.data.bankCards[0];
                        var param = {
                            id: self.loginInfo.Id,
                            name: self.loginInfo.custName,
                            bankCardNo: momoBank.bankNo,
                            bankCardTel: momoBank.reservePhone,
                            paPayAccount: momoBank.paPayAccount,
                            bankName: momoBank.bankName
                        };
                        C.Native.rSAEncode(param, function (res) {
                            if (res.code == '1') {
                                param = {
                                    id: res.result.id,
                                    name: res.result.name,
                                    bankCardNo: res.result.bankCardNo,
                                    bankCardTel: res.result.bankCardTel,
                                    paPayAccount: res.result.paPayAccount,
                                    bankName: res.result.bankName,
                                    payApplyNo: C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO),
                                    applyNo: C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).applyNo,
                                    businessNo: C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO).businessNo,
                                    imgDenseStrFileId: C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO).imgDenseStrFileId,
                                    imgFileId: C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO).imgFileId,
                                    bankType: momoBank.cardType,
                                    bindingSource: 'BT',
                                    bankCode: momoBank.bankShortName,
                                    cardType: momoBank.cardType,
                                    platform: App.IS_IOS ? 'IOS' : 'A'
                                };
                                C.UI.loading();
                                $.ajax({
                                    url: C.Api('BT_REGULARBINDBANCARD'),
                                    data: {
                                        jsonPara: JSON.stringify(param)
                                    },
                                    type: 'POST',
                                    success: function (res) {
                                        //默默传递第一张卡，请求邦卡接口--成功--loading
                                        if (res.flag == C.Flag.SUCCESS && res.data) {
                                            if (res.data.resultCode == '1') {
                                                C.Native.forward({
                                                    url: 'icard_loading.html'
                                                });
                                            } else { //默默传递第一张卡，请求邦卡接口--失败，给用户的感觉相当于签名失败，停留在当前页面
                                                self.hideEsignTpl();
                                                if (res.data.blazeSwitch && res.data.blazeSwitch == '0') {
                                                    C.Native.tip(res.data.blazeSwitchMsg);
                                                }
                                            }
                                        } else { //默默传递第一张卡，请求邦卡接口--失败，给用户的感觉相当于签名失败，停留在当前页面
                                            self.hideEsignTpl();
                                        }
                                    },
                                    complete: function () {
                                        C.UI.stopLoading();
                                    }
                                });
                            } else {
                                C.Native.tip('安全数据加密失败');
                            }
                        });
                    }
                } else {
                    C.Native.tip('已绑定银行卡列表为空');
                    self.hideEsignTpl();
                }
            }
        },

        // Ajax请求数据isold:true:老传参方式；false：新方式
        dataRequest: function (json, isOld, otherCallback) {
            var self = this,
                param = {};
            self.isLoading = true;
            C.UI.loading();
            if (isOld) {
                param = json.data;
            } else {
                param = {
                    jsonPara: JSON.stringify(json.data)
                };
            }
            $.ajax({
                url: json.url,
                type: json.type,
                data: param,
                success: function (res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        json.callback.call(self, res);
                    }
                },
                complete: function () {
                    if (typeof otherCallback != 'undefined') {
                        otherCallback();
                    }
                    C.UI.stopLoading();
                    self.isLoading = false;
                }
            });
        },

        // 跳转产品详情页
        toProDetail: function () {
            var self = this;
            if (self.isPosting) {
                return;
            }
            self.isPosting = true;
            C.UI.loading();

            C.Native.forward({
                url: 'product-detail.html'
            });
            setTimeout(function () {
                C.UI.stopLoading();
                self.isPosting = false;
            }, 2000);
        },
        //从顶部跳转到产品详情页
        topToProDetail: function (e) {
            //埋点 I贷账户页 广告banner
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_07_I贷账户页'
            });
            var self = this;
            self.toProDetail();
            //埋点 8.29新增，强制跳转产品后出现蒙板，在蒙板页面点击了解详情
            C.Native.TDOnEvent({
                eventId: 'iBT-0206-生成额度',
                eventLable: 'iBT-020604-产品详细介绍页'
            });
            //埋点 产品详情介绍页  首次出额
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_15_产品详情介绍页'
            });
        },
        //从蒙板跳转到产品详情页
        leayerToProDetail: function (e) {
            e = e || window.event;
            e.stopPropagation();
            var self = this;
            self.toProDetail();
            //埋点 8.29新增，强制跳转产品后出现蒙板，在蒙板页面点击了解详情
            C.Native.TDOnEvent({
                eventId: 'iBT-0208-蒙板产品详细介绍页',
                eventLable: 'iBT-020801-蒙板了解详情'
            });
            //埋点 蒙板介绍页 了解更多
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_14_01_蒙板介绍页'
            });

        },
        //获取电子签名在线开关文件
        getSwitch: function () {
            var self = this;
            $.ajax({
                url: C.Api('ALL_ILOAN_SWITCH', 'SWITCH'),
                cache: false,
                type: 'GET',
                success: function (res) {
                    if (res.code == '1' && res.data) {
                        self.online_domesticAlgorithm = res.data.esignOCR.domesticAlgorithm;
                        self.online_OcrNeed = res.data.esignOCR.OcrNeed;
                        self.online_OcrKey = res.data.esignOCR.OcrKey;
                    }
                }
            });
        },
        //心理测评跳转
        goTest: function() {
            C.Native.forwardModule({
                moduleName: 'paehome',
                url: 'psychological-test.html?iloanUrl=loan_select.html'
            });
        },
        //关闭心理测评弹窗
        hideTest: function() {
            $('#testTip').hide();
        }
    }));
    (function () {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function () {
            location.reload();
        };
    })();
});