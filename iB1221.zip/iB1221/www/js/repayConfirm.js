/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2017-03-9
 * @describe: BT-还款确认页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        earlyTpl: _.template($('#early').html()), //提前还款
        overTpl: _.template($('#overdue').html()), //逾期
        lpTpl: _.template($('#lpView').html()), //理赔
        events: {
            'tap #tar-rule': 'showRule', //展开扣款规则
            'tap div.close': 'hideRule', //收起扣款规则
            'tap #early-show': 'earlyReverse', //展开提前还款费用明细
            'tap #overDue-show': 'overReverse', //展开逾期费用明细
            'tap #divInput': 'triggerFocus',
            'focus input.ipt': 'inputFocus', //输入框获得焦点
            'blur input.ipt': 'inputBlue', //输入框失去焦点
            'keyup input.ipt': 'inputKey',
            'tap div.head': 'addBank', //跳转至添加储蓄卡,
            'tap span.link-udr': 'goPlan', //跳转至还款计划
            'tap div.btn': 'submitDate', //提交还款数据
            'tap #close-tip': 'closeTip' //关闭提前还款提示窗
        },
        initialize: function () {
            console.log('屏幕高度' + window.screen.height);
            console.log('body高度' + document.body.height);
            console.log('body全文高度' + document.body.scrollHeight);

            var $this = this;
            //$this.paramer = C.Utils.getQueryMap();//loanId 借款id
            C.UI.loading();
            $.ajax({
                url: C.Api('LOANDETAIL'),
                type: 'post',
                data: {
                    loanId: C.Utils.data('loanId')//入参借款id 理赔该参数为空
                },
                success: function (res) {
                    C.UI.stopLoading();
                    if (res && res.flag == C.Flag.SUCCESS) {
                        var data = res.data;
                        //设置头部
                        if (data.payState.toUpperCase() == 'RP') {
                            //埋点 待还款时 提前还款页
                            C.Native.TDOnEvent({
                                eventId: '$_03_0_3_42_提前还款页'
                            });
                            C.Native.setHeader({
                                title: (data.isRepayDate && data.isRepayDate == 'Y') ? C.Constant.Enum.TITLE.NOWREPAYMENT : C.Constant.Enum.TITLE.EARLYREPAYMENT, //区分还款日还款和非还款日还款
                                isBack: 1,
                                rightText: '还款指引',
                                rightCallback: function () {
                                    //埋点 还款指引
                                    C.Native.TDOnEvent({
                                        eventId: '$_03_1_3_42_01_提前还款页'
                                    });
                                    //跳转至i贷还款展示页
                                    C.Native.forward({
                                        url: [C.Constant.DataUrl.TRANSPAGE.INTRO].join('')
                                    });
                                }
                            });
                        } else {
                            //埋点 立即还款页
                            C.Native.TDOnEvent({
                                eventId: '$_03_0_3_44_立即还款页'
                            });
                            C.Native.setHeader({
                                title: C.Constant.Enum.TITLE.NOWREPAYMENT,
                                isBack: 1
                            });
                        }
                        $this.payState = data.payState.toUpperCase();
                        $this.rpyBankName = data.rpyBankName;//还款储蓄卡银行
                        $this.rpyDate = data.rpyDate;//还款日
                        $this.rpyTotalAmt = data.rpyTotalAmt;//应还金额
                        $this.remainAmt = data.remainAmt;//剩余本金
                        $this.rpyBinkNo = data.rpyBinkNo;//还款卡绑定号
                        $this.loanId = $this.payState != 'LP' ? data.loanId : ''; //借款ID
                        $this.rpyAmt = data.rpyAmt; //还款本金
                        $this.rateFee = data.rateFee; //还款利息
                        $this.guaranteeFee = data.guaranteeFee; //还款保费
                        $this.overInt = data.overInt; //还款罚息
                        $this.penalty = data.penalty; //理赔违约金
                        $this.counterFee = data.counterFee; //手续费
                        $this.insuranceFee = data.insuranceFee;//日保险费
                        $this.serviceCharge = data.serviceCharge;//日服务费
                        $this.limitAmt = data.limitAmt ? parseInt(data.limitAmt) : 10;//提前还款输入金额限制
                        //存储本地数据，为添加储蓄卡页面准备数据
                        data.yqbList && (data.yqbList instanceof Array) && (data.yqbList.length > 0 )? data.debitCarList.unshift(data.yqbList[0]) : '';
                        C.Utils.data('ICARD_DEBITICARDLIST', data.debitCarList);
                        //应还息费
                        data.sumFee = (!isNaN(data.counterFee) ? Number(data.counterFee) : 0) +
                            (!isNaN(data.rateFee) ? Number(data.rateFee) : 0) +
                            (!isNaN(data.guaranteeFee) ? Number(data.guaranteeFee) : 0) +
                            (!isNaN(data.overInt) ? Number(data.overInt) : 0) +
                            (!isNaN(data.penalty) ? Number(data.penalty) : 0) +
                            (!isNaN(data.insuranceFee) ? Number(data.insuranceFee) : 0) +
                            (!isNaN(data.serviceCharge) ? Number(data.serviceCharge) : 0);
                        switch ($this.payState) {
                            case 'RP':
                                if (data.isRepayDate == 'Y') {
                                    $this.payAmt = data.rpyAmt;//还款确认接口：还款金额
                                }
                                $this.subAmt = data.sumFee;
                                data.rpyAmtTota = Number(data.rpyAmt) + data.sumFee; //应还金额 = 还款本金 + 应还息费
                                data.rpyAmtTota = isNaN(data.rpyAmtTota) ? data.rpyAmtTota : [C.Utils.formatMoney(Number(data.rpyAmtTota)), '元'].join('');
                                break;
                            case 'OD':
                                data.rpyAmtTota = Number(data.rpyAmt) + data.sumFee; //应还金额 = 还款本金 + 应还息费
                                $this.payAmt = data.rpyAmt;//还款确认接口：还款金额
                                data.overInt = isNaN(data.overInt) ? data.overInt : [C.Utils.formatMoney(Number(data.overInt)), '元'].join('');//罚息
                                data.rpyAmtTota = isNaN(data.rpyAmtTota) ? data.rpyAmtTota : [C.Utils.formatMoney(Number(data.rpyAmtTota)), '元'].join('');
                                break;
                            case 'LP':
                                data.rpyAmtTota = Number(data.rpyAmt) + data.sumFee;//应还金额 = 还款本金 + 应还息费
                                data.overInt = isNaN(data.overInt) ? data.overInt : [C.Utils.formatMoney(Number(data.overInt)), '元'].join('');//罚息
                                data.penalty = isNaN(data.penalty) ? data.penalty : [C.Utils.formatMoney(Number(data.penalty)), '元'].join('');//违约金
                                data.rpyAmtTota = isNaN(data.rpyAmtTota) ? data.rpyAmtTota : [C.Utils.formatMoney(Number(data.rpyAmtTota)), '元'].join('');
                                break;
                        }
                        //数据处理
                        data.sumFee = isNaN(data.sumFee) ? data.sumFee : [C.Utils.formatMoney(Number(data.sumFee)), '元'].join('');//应还息费
                        data.rpyAmt = isNaN(data.rpyAmt) ? data.rpyAmt : [C.Utils.formatMoney(Number(data.rpyAmt)), '元'].join('');//当期应还本金
                        data.remainAmt = isNaN(data.remainAmt) ? data.remainAmt : [C.Utils.formatMoney(Number(data.remainAmt)), '元'].join('');//剩余本金
                        data.guaranteeFee = isNaN(data.guaranteeFee) ? data.guaranteeFee : [C.Utils.formatMoney(Number(data.guaranteeFee)), '元'].join('');//担保费
                        data.rpyTotalAmt = isNaN(data.rpyTotalAmt) ? data.rpyTotalAmt : [C.Utils.formatMoney(Number(data.rpyTotalAmt)), '元'].join('');//应还金额
                        data.rateFee = isNaN(data.rateFee) ? data.rateFee : [C.Utils.formatMoney(Number(data.rateFee)), '元'].join('');//利息
                        data.counterFee = isNaN(data.counterFee) ? data.counterFee : [C.Utils.formatMoney(Number(data.counterFee)), '元'].join('');//动用手续费
                        data.serviceCharge = isNaN(data.serviceCharge) ? data.serviceCharge : [C.Utils.formatMoney(Number(data.serviceCharge)), '元'].join('');//服务费
                        data.insuranceFee = isNaN(data.insuranceFee) ? data.insuranceFee : [C.Utils.formatMoney(Number(data.insuranceFee)), '元'].join('');//保险费
                        //渲染页面
                        $this.render(data);
                    }
                }
            });
        },
        render: function (data) {
            var $this = this,
                $Elm = $('body');
            switch ($this.payState) {
                case 'RP':
                    if (data.isRepayDate && data.isRepayDate == 'Y') {
                        $Elm.html($this.overTpl(data));
                        $('#show-early').show();
                        $('#text-tip').text('还款总额');
                    } else {
                        $Elm.html($this.earlyTpl(data));
                        $this.localData = C.Utils.data('REPAY_EARLY_ACCOUNTID') || [];//存储首次进入的提前还款用户ID
                        $this.accountId = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).accountId || ''; //获取用户的ID
                        if($this.localData.indexOf($this.accountId) == -1){
                            $('#tip-early').show();//显示提前还款提示窗
                        }
                    }
                    break;
                case 'OD':
                    $Elm.html($this.overTpl(data));
                    $('div.red').css('color', '#eb0000');
                    $('#show-over').show();
                    $('#text-tip').text('逾期应还');
                    break;
                case 'LP':
                    $Elm.html($this.lpTpl(data));
                    break;
            }
            if (data.fundingModel.toUpperCase() == 'L') {
                $('span#isCig').text('担保费');
            } else {
                $('span#isCig').text('保费、服务费');
            }
        },
        triggerFocus: function (e) {
            $(e.currentTarget).hide();
            $('input').show().trigger('focus').val('');
        },
        inputFocus: function () {
            $('footer').addClass('dn');
        },
        inputBlue: function () {
            console.log('屏幕高度' + window.screen.height);
            console.log('body高度' + document.body.height);
            console.log('body全文高度' + document.body.scrollHeight);
            var $this = this;
            $('div#subAmt').show();//显示还款总额
            $this.initRender();//执行金额验证
            if ($this.payState == 'RP') {
                $('div.prompt-text').html('');
                $this.doTry();//执行还款试算
            }
            $('footer').removeClass('dn');//显示底部按钮
            console.log('屏幕高度' + window.screen.height);
            console.log('body高度' + document.body.height);
            console.log('body全文高度' + document.body.scrollHeight);
            if(App.IS_SDK){
                C.Native.getUIParams(function (data) {
                    var btnBgColor = data.btnBgColor || data.buttonColor ||'#eb6100',
                        btnTitleColor = data.btnTitleColor || '#FFF';
                    $('.btn').css({
                        'background': btnBgColor,
                        'color': btnTitleColor,
                        'border': '1px solid' + btnBgColor
                    });
                });
            }
        },
        doTry: function () {
            var $this = this;
            C.UI.loading();
            $.ajax({
                url: C.Api('REPAYSUBMITTRY'),
                type: 'post',
                data: {
                    jsonPara: JSON.stringify({
                        loanSeq: C.Utils.data('loanId'), //借款id
                        rayAmt: $this.payAmt//还款金额
                    })
                },
                success: function (res) {
                    C.UI.stopLoading();
                    if (res && res.flag == C.Flag.SUCCESS) {
                        if (res.data.resultCode == '1' && res.data.isSettleFlag && res.data.isSettleFlag == 'N') {
                            $('div.prompt-text').html(['还款计划发生变更，系统将于<span class="red">', res.data.rpyDate.split('-')[1], '月', res.data.rpyDate.split('-')[2], '日', '</span>扣除当期剩余应还金额<span class="red">', C.Utils.formatMoney(Number(res.data.rpyAmt)), '元</span>，请确保账户金额充足。<span class="link-udr">查看还款计划></span>'].join(''));
                            res.data.rpyBankName = $this.rpyBankName;
                            res.data.rpyDate = $this.rpyDate;
                            C.Utils.data(C.Constant.DataKey.BT_REPAYMENT, res.data); //存储数据给到还款计划
                        }
                    }
                }
            });
        },
        inputKey: function (ev) {
            var $this = this,
                _currKey = ev.keyCode,
                inputWarp = $('#input-contain'),
                _loanAmt = $('input.ipt').val();
            //输入金额为0 字体为灰色 非0 字体为红色
            _loanAmt == 0 ? inputWarp.addClass('ipt-gray') : inputWarp.removeClass('ipt-gray');
            if (_currKey == 13 && _loanAmt.length > 0) {
                $('input').blur();
                return;
            }
            //还款总额跟随处理
            $('div#subAmt strong').text([C.Utils.formatMoney(Number(_loanAmt) + Number($this.subAmt)), '元'].join(''));
        },
        //输入框 金额验证模块 start
        __isSuccess__Amt__: function (loanAmt) {
            var $this = this,
                _minLoanAmt = 0, //最低还款金额(可以为0)
                _maxLoanAmt = $this.payState == 'LP' ? Number($this.rpyTotalAmt) : Number($this.remainAmt), //最高还款金额(提前还款：remainAmt剩余本金；追偿状态：rpyTotalAmt应还金额)
                _result = {flag: 0, msg: ''};
            //无效输入
            if (isNaN(loanAmt)) {
                _result.msg = '请输入金额并符合正确格式';
                return _result;
            }
            //输入金额范围校验
            if (Number(loanAmt) < _minLoanAmt) {
                _result.msg = ['您本次还款金额不得低于', C.Utils.regMoneyAndDous(_minLoanAmt), '元'].join('');
                _result.flag = -1;
            } else if (Number(loanAmt) > _maxLoanAmt) {
                _result.msg = ['您本次还款金额不得超过', C.Utils.regMoneyAndDous(_maxLoanAmt), '元'].join('');
                _result.flag = -2;
            } else if ($this.payState == 'RP'&& _maxLoanAmt - $this.limitAmt <= Number(loanAmt) && Number(loanAmt) < _maxLoanAmt) {
                _result.msg = ['提前还款后的剩余本金应该大于', $this.limitAmt, '元，您可还清所有欠款金额'].join('');
                _result.flag = -3;
            } else {
                _result.flag = 1;
            }
            //返回校验结果
            return _result;
        },
        __format__Amt__: function (loanAmt) {
            if (isNaN(loanAmt) || !loanAmt) {
                return loanAmt || '0.00';
            }
            return C.Utils.formatMoney(loanAmt);
        },
        initRender: function () {
            var $this = this,
                _loanAmt = $this.$('input').val(),
                inputWarp = $('#input-contain'),
                $btn = $('div.btn'),
                _isSuccess = $this.__isSuccess__Amt__(_loanAmt);
            /*** 无效金额执行动作 ***/
            if (_isSuccess.flag != 1) {
                if (_isSuccess.flag == -3) {
                    C.Native.tip(_isSuccess.msg);

                } else {
                    C.UI.toptip({
                        className: 'error-top',
                        tip: ['<span class="icon-sm icon-tip"></span>&nbsp;&nbsp;', _isSuccess.msg].join('')
                    });
                }
                //吸顶提示
                // C.UI.toptip({
                //     className: 'error-top',
                //     tip: ['<span class="icon-sm icon-tip"></span>&nbsp;&nbsp;', _isSuccess.msg].join('')
                // });
                //默认状态
                if (_isSuccess.flag == 0) {
                    _loanAmt = '0.00';
                    inputWarp.removeClass('ipt-gray').find('input').val(_loanAmt);
                    return;
                }
                //还款金额低于最低金额
                if (_isSuccess.flag == -1) {
                    _loanAmt = 0;
                }
                //还款金额高于最高金额
                if (_isSuccess.flag == -2 || _isSuccess.flag == -3) {
                    _loanAmt = $this.payState == 'LP' ? $this.rpyTotalAmt : $this.remainAmt;
                    $this.payAmt = _loanAmt;//还款确认接口：还款金额
                }
                //还款总额二次处理
                $('div#subAmt strong').text([C.Utils.formatMoney(Number(_loanAmt) + Number($this.subAmt)), '元'].join(''));
                //输入框 还款额
                inputWarp.removeClass('ipt-gray').find('input').val(_loanAmt || '0.00');
                $btn.addClass('btn-dis');//禁用按钮
                //执行重新验证操作
                $this.initRender();
                return;
            }
            /*** 有效金额执行动作 ***/
            _loanAmt = $this.__format__Amt__(_loanAmt);
            inputWarp.removeClass('ipt-gray').find('input').val('');
            $('input').hide();
            $('#divInput').text(_loanAmt).show();
            if (_loanAmt.indexOf(',') != -1) {
                _loanAmt = _loanAmt.split(',').join('');
            }
            $('div#subAmt strong').text([C.Utils.formatMoney(Number(_loanAmt) + Number($this.subAmt)), '元'].join(''));
            $this.payAmt = _loanAmt;
            $btn.removeClass('btn-dis');//点亮按钮
        },
        //输入框 金额验证模块 end

        addBank: function () {
            var $this = this;
            // 埋点 扣款账户
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_42_02_提前还款页'
            });
            C.Native.forward({
                url: 'repay_saving_card.html',
                data: {
                    from: 'repay_confirm.html',
                    loanBindNo: $this.rpyBinkNo

                },
                callBack: function (data) {
                    console.log(data);
                    if (data && data.rpyBindNo && data.rpyBankName) {
                        //重新渲染
                        $('div.js_changeBank').html(data.rpyBankName + '<span class="icon-sm icon-arrow"></span>');
                        $this.rpyBankName = data.rpyBankName;
                        $this.rpyBinkNo = data.rpyBindNo;//修改客户选择的储蓄卡绑定号
                    } else if (data && !!data.reload && data.bindNo) {
                        //调用更改默认储蓄卡接口
                        C.UI.loading();
                        $.ajax({
                            url: C.Api('CHANGELOANCARD'),
                            data: {
                                bindNo: data.bindNo
                            },
                            type: 'POST',
                            success: function (res) {
                                C.UI.stopLoading();
                                if (res.data && res.flag == C.Flag.SUCCESS) {
                                    location.reload();
                                } else {
                                    C.Native.tip(res.msg);
                                }
                            }
                        });
                    }
                }
            });
        },

        //提交还款数据
        submitDate: function (e) {
            var $this = this;
            if ($(e.currentTarget).hasClass('btn-dis') || $this.isLoading) {
                return;
            }
            $this.isLoading = true;//防重标识
            $(e.currentTarget).addClass('btn-dis');
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0601010101-提前还款',
                eventLable: 'iBT-060101010101-确定还款'
            });
            if($this.payState == 'RP'){
                // 埋点 提前还款页  确定还款
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_42_05_提前还款页'
                });
            }else{
                // 埋点 立即还款页  确定还款
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_44_01_立即还款页'
                });
            }
            
            C.Native.getDeviceInfo(function (deviceParams) {
                if (!isNaN(deviceParams.code) && deviceParams.code == '1' && deviceParams.result) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('SUBMITRPY'),
                        data: {
                            loanId: $this.loanId, //借款ID
                            payAmt: $this.payAmt, //还款金额
                            rpyBindNo: $this.rpyBinkNo, //还款卡绑定号
                            rpyAmt: $this.payAmt, //还款本金
                            rateFee: $this.rateFee, //还款利息
                            guaranteeFee: $this.guaranteeFee, //还款保费
                            overInt: $this.overInt, //还款罚息
                            penalty: $this.penalty, //理赔违约金
                            counterFee: $this.counterFee, //手续费
                            address: deviceParams.result.address || '',
                            longitude: deviceParams.result.longitude || '',
                            latitude: deviceParams.result.latitude || '',
                            insuranceFee: $this.insuranceFee, //日保险费
                            serviceCharge: $this.serviceCharge//日服务费
                        },
                        type: 'post',
                        dataType: 'json',
                        success: function (res) {
                            C.UI.stopLoading();
                            if (res && res.flag == C.Flag.SUCCESS) {
                                res.data.rpyBankName = $this.rpyBankName;
                                C.Utils.data('ICARD_SUBMIT_REPAY', res.data);
                                //是否是逾期页面
                                if ($this.payState == 'OD' || $this.payState == 'RP') {
                                    //清除客户在理赔状态还款成功后非正常操作下（强制退出App）缓存的标识符数据
                                    if (C.Utils.data('isLp')) {
                                        C.Utils.data('isLp', null);
                                    }
                                }
                                C.Utils.data('loanId', null);
                                //跳转至还款成功页
                                C.Native.forward({
                                    url: [C.Constant.DataUrl.TRANSPAGE.REPAYSUBMITSUC].join('')
                                });
                                // 埋点 还款提交结果页  事件结果 成功
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_3_45_01_还款提交结果页'
                                }); 
                            }else{
                                // 埋点 还款提交结果页  事件结果 失败
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_3_45_02_还款提交结果页'
                                }); 
                            }
                        },
                        complete: function () {
                            $this.isLoading = null;//释放该变量
                            $(e.currentTarget).removeClass('btn-dis');
                        }
                    });
                }
            });
        },

        showRule: function () {
            // 埋点 扣款规则
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_42_03_提前还款页'
            });
            //显示还款提醒
            $('#tip-alert').removeClass('dn');
        },
        hideRule: function () {
            //关闭还款提醒
            $('#tip-alert').addClass('dn');
        },
        earlyReverse: function () {
            //控制收缩展示费用栏
            $('#early-show').toggleClass('reverse-toggle');
        },
        overReverse: function () {
            //控制收缩展示费用栏
            $('#overDue-show').toggleClass('reverse-toggle');
        },
        closeTip: function () {
            var $this = this;
            // 埋点 我知道了
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_43_01_提前还款弹窗页'
            });
            if($('input#check').attr('checked')) {
                $this.localData.push($this.accountId);
                C.Utils.data('REPAY_EARLY_ACCOUNTID', $this.localData);
                // 埋点 不再提示
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_43_02_提前还款弹窗页'
                });
            }
            $('#tip-early').hide();
        },
        goPlan: function () {
            // 埋点 查看还款计划
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_42_04_提前还款页'
            });
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTPLAN,
                data: {
                    from: 'detail' //进入还款金额计划页 detail标识符
                }
            });
        }

    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});