/**
 * @author: EX-ZHANGKEMING001
 * @date  : 2016-10-17
 * @describe: icardBT-添加信用卡
 */
define(['zepto', 'C', 'view'], function($, C, View){
    'use strict';

    var Page = View.extend(_.extend({
        /**绑定事件**/
        events: {
            'tap #tip': 'doOpen', //查看支持的银行卡列表信息
            'input #card_input': 'doControl', //触发change事件时调整页面提示以及光标定位
            'blur #card_input': 'doTest', //调用卡BIN校验接口
            'tap #verify': 'doSubmit'//调用新增信用卡接口
        },
        /**指定根元素**/
        el: 'body',
        //记录客户填写的信用卡卡号
        recordNo: '',
        //信用卡号
        creditCardNo: '',
        //从constant.js文件中获取到银行卡信息配置数据
        list: C.Constant.Enum.BANKINFO.BANKLIST,
        /**初始化**/
        initialize: function(){
            var self = this;
            self.currenttimes = 1;//记录轮询次数
            self.userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
            $('#userName').text(self.userInfo.custName);
            //埋点 添加信用卡页
            C.Native.TDOnEvent({
                eventId: '$_03_0_4_23_添加信用卡页'
            });
            //设置头部信息
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.ADDCREDIT,
                isBack: 1
            });
            //发起获取支持银行卡列表请求 //在初始化的时候就调用该口
            C.UI.loading();
            $.ajax({
                url: C.Api('QUERYBANKLIST'), //可用银行列表查询接口
                type: 'post',
                data: {},
                dataType: 'json',
                success: function(data){
                    console.log(data);
                    C.UI.stopLoading();
                    if(data.data && data.flag == C.Flag.SUCCESS){
                        //渲染所支持的银行卡列表页面
                        $.each(data.data.bankInfoList, function(index, elm){
                            if(elm.bankShortName in self.list){
                                self.$el.find('#list').append('<li><span class="bank-'+self.list[elm.bankShortName].logo+' icon-fix"></span>'+self.list[elm.bankShortName].bankName+'</li>');
                            }
                        });
                    }
                }
            });
            //self.render();
        },
        /**渲染页面数据**/
        render: function(){
			// empty
        },
        
        // 查看支持的银行卡列表信息
        doOpen: function(e){
            e.preventDefault();
            /**埋点**/
            C.Native.TDOnEvent({
                eventId: 'iBT-030401-添加信用卡',
                eventLable: 'iBT-03040101-查看支持银行'
            });
            //埋点 添加信用卡页 查看支持银行
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_23_01_添加信用卡页'
            });
            $('#card_input').blur();
            $('#alert').removeClass('dn');
            $('#hidd').on('tap', function(){
                $('#alert').addClass('dn');
                $('#card_input').focus();
            });
        },
        //触发change事件时调整页面提示以及光标定位
        doControl: function(){
            var self = this,
                $target = $('#card_input');
            //兼容android4.2的input中光标不在最后面问题
            self.val = $target.val().replace(/[^0-9]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ');
            $target.val(self.val);
            setTimeout(function () {
                if ($target[0].setSelectionRange) {
                    $target[0].setSelectionRange(self.val.length, self.val.length);
                    $target.focus();
                }
            }, 10);
            $('#error-tip').addClass('dn');
            $('#bankInfo').html(' ');
            $('#verify').addClass('btn-dis');
            //按钮置灰，移除按钮颜色
            $('#verify')[0].removeAttribute('style');
        },
        //调用卡BIN校验接口
        doTest: function(){
            var self = this,
                lengths = $('#card_input').val().length;
            (self.blurhandler && (clearTimeout(self.blurhandler)));
            if(lengths >= 18){
                var getCreditCardNo = function () {
                    var dtd = $.Deferred();
                    var param = {
                        creditCardNo: _.reduce($('#card_input').val().split(' '), function (a, b) {
                            return a + b;
                        })
                    };
                    C.Native.rSAEncode(param, function (data) {
                        self.creditCardNo = data.result.creditCardNo;
                        dtd.resolve();
                    });
                    return dtd.promise();
                };
                var btqueryCardinfo = function () {
                    //发起AJAX请求，调用卡BIN校验接口
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('BTQUERYCARDINFO'),
                        type: 'post',
                        data: {
                            applyNo: C.Utils.data('BT_ICARD_APPLYNO'), //申请号
                            creditCardNo: self.creditCardNo
                        },
                        dataType: 'json',
                        success: function (data) {
                            console.log(data);
                            C.UI.stopLoading();
                            if (data.data && data.flag == C.Flag.SUCCESS) {
                                //渲染银行logo以及银行名称
                                self.binData = data.data;//存储卡BIN校验数据
                                if (data.data.queryResult == 'N') {
                                    $('#error-tip').removeClass('dn');
                                    $('#bankInfo').html(' ');
                                    $('#verify').addClass('btn-dis');
                                    return;
                                }
                                if (data.data.bankShortName in self.list) {
                                    $('#error-tip').addClass('dn');
                                    $('#bankInfo').html('<div class="icon-fix bank-' + self.list[data.data.bankShortName].logo + '"></div>' + self.list[data.data.bankShortName].bankName);
                                    $('#verify').removeClass('btn-dis');
                                    if(App.IS_SDK){
                                        C.Native.getUIParams(function (data) {
                                            var btnBgColor = data.btnBgColor || data.buttonColor ||'#eb6100',
                                                btnTitleColor = data.btnTitleColor ||'#FFF';
                                            $('#verify').css({
                                                //有边框
                                                'color': btnTitleColor,
                                                'background': btnBgColor,
                                                'border': '1px solid' + btnBgColor
                                            });
                                        });
                                    }
                                }
                            }
                        },
                        complete: function () {
                            C.UI.stopLoading();
                        }
                    });
                };
                $.when(getCreditCardNo()).then(btqueryCardinfo);
            }else if(lengths > 0){
                $('#error-tip').removeClass('dn');
                self.blurhandler = setTimeout(function(){$('#error-tip').addClass('dn');}, 3000);
            }
        },
        //调用新增信用卡接口
        doSubmit: function(){
            var self = this,
                code = $('#card_input').val();
                //SDK中用到的入参
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
            self.thirdChannel = sourceInfo ? sourceInfo.source : '';
            self.channelType = sourceInfo ? sourceInfo.sourceType : '';   
            if(!code || $('#verify').hasClass('btn-dis')){
                return;
            }
            $('#verify').addClass('btn-dis');
            if(self.recordNo != code){
                self.recordNo = code;
                self.currenttimes = 1;//记录轮询次数
            }
            /**埋点**/
            C.Native.TDOnEvent({
                eventId: 'iBT-030401-添加信用卡',
                eventLable: 'iBT-03040102-确定'
            });
            //埋点 添加信用卡页 确定
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_23_02_添加信用卡页'
            });
            //发起AJAX请求，调用新增信用卡接口
            var getTel = function () {
                var dtd = $.Deferred();
                C.Native.rSAEncode({tel: self.userInfo.mobile}, function (data) {
                    self.mobile = data.result.tel;
                    dtd.resolve();
                });
                return dtd.promise();
            };
            var submitCardinfo = function () {
                //发起AJAX请求，调用新增信用卡接口
                C.UI.loading();
                $.ajax({
                    url: C.Api('SUBMITCARDINFO'),
                    type: 'post',
                    data: {
                        creditCardNo: self.creditCardNo, //绑定银行卡号
                        tel: self.mobile, //银行卡预留手机
                        applyNo: C.Utils.data('BT_ICARD_APPLYNO'), //申请号
                        bankNo: self.binData.bankShortName, //银行代码
                        bankName: self.binData.bankName, //银行名称
                        thirdChannel: self.thirdChannel,
                        channelType: self.channelType 
                    }, //入参
                    dataType: 'json',
                    success: function (data) {
                        console.log(data);
                        //如果存在orderno，则存储到本地存储覆盖之前的。
                        if (data.data.orderNo) {
                            C.Utils.data(C.Constant.DataKey.BT_SAVE_BINDORDERNO, data.data.orderNo);
                        }
                        if (data.data && data.flag == C.Flag.SUCCESS) {
                            //根据返回的应答码执行相应的动作
                            var goStr = '此卡正在验证中';
                            self.addData = data.data;//记录新增信用卡接口返回的数据，提供给轮询接口用
                            if (data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[21] || data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[16] || data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[24]) {
                                if (self.currenttimes >= 11) {
                                    C.UI.stopLoading();
                                    self.doTip(goStr);
                                    //重新发起打小钱的流程
                                    $('#verify').removeClass('btn-dis');
                                } else {
                                    //第一次发起请求且返回应答码为S3或者20或者88的情况(触发轮询接口),验证中的
                                    C.UI.loading();
                                    self.doTurnsRequest();
                                }
                            } else {
                                //第一次发起请求且返回应答码为非S3或者20的情况，成功时
                                C.UI.stopLoading();
                                self.doPlay(data.data);
                            }
                        }
                    },
                    complete: function () {
                        C.UI.stopLoading();
                    }
                });
            };
            $.when(getTel()).then(submitCardinfo);
        },
        //第一次发起请求且返回应答码为S3的情况(S3此卡正在验证)
        doTurnsRequest: function(){
            var self = this;
            //一分钟轮询
            self.turnsHandler && (clearTimeout(self.turnsHandler));
            //发起AJAX请求，调用轮询接口
            $.ajax({
                url: C.Api('ICARDTAKETURNS'), //信用卡小钱轮询接口
                type: 'post',
                data: {
                    applyNo: C.Utils.data('BT_ICARD_APPLYNO'), //申请号
                    orderNo: self.addData.orderNo || C.Utils.data(C.Constant.DataKey.BT_ORDERNO)//小钱支付订单号，优先取返回值，否则取之前的缓存值，防止返回空
                }, //入参
                dataType: 'json',
                success: function(data){
                    console.log(data);
                    if(data.data && data.flag == C.Flag.SUCCESS){
                        var ageinStr = '此卡正在验证中，您也可以先添加其他信用卡';
                        if((data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[21] || data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[16] || data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[24]) && self.currenttimes<12){
                            /**再次发起轮询请求**/
                            self.currenttimes ++;
                            /**埋点**/
                            C.Native.TDOnEvent({
                                eventId: 'iBT-03040102-确定',
                                eventLable: 'iBT-0304010203-验证中'
                            });
                            //埋点 添加信用卡页 验证中
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_4_23_03_添加信用卡页'
                            });
                            self.turnsHandler = setTimeout(function(){
                                self.doTurnsRequest();
                            }, 5000);
                        }else if((data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[21] || data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[16] || data.data.pafRespCode == C.Constant.Enum.ICARD.RESPONDCODE[24]) && self.currenttimes>=12){
                            /**轮询一分钟之后的情况**/
                            /**埋点**/
                            C.Native.TDOnEvent({
                                eventId: 'iBT-03040102-确定',
                                eventLable: 'iBT-0304010202-重新添加'
                            });
                            //埋点 添加信用卡页 重新添加
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_4_23_02_添加信用卡页'
                            });
                            C.UI.stopLoading();
                            self.doTip(ageinStr);
                            //重新发起打小钱的流程
                            $('#verify').removeClass('btn-dis');
                            //self.currenttimes = 1;
                        }else{
                            /**轮询一分钟内非S3或者20应答码的情况**/
                            C.UI.stopLoading();
                            self.doPlay(data.data);
                        }
                    }
                }
            });
        },
        /**应答码为非S3执行的动作**/
        doPlay: function(data){
            var self = this,
                errorTip = $('#error-tip'),
                pafRespCode = data.pafRespCode, //平安付应答码
                busyText = '系统繁忙，请稍后再试',
                fullText = '今日添加次数已满，您可明日继续添加';
            (self.handler && (clearTimeout(self.handler)));
            switch (pafRespCode){
                case C.Constant.Enum.ICARD.RESPONDCODE[0]:
                    //添加信用卡1min内-添加成功
                    var paramData = C.Utils.getQueryMap();//从6.0或者6.1页面获取页面标识符
                    /**埋点**/
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03040102-确定',
                        eventLable: 'iBT-0304010205-成功'
                    });
                    //埋点 添加信用卡页 成功
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_4_23_06_添加信用卡页'
                    });
                    C.Native.forward({
                        url: C.Constant.DataUrl.TRANSPAGE.ADDCARDSUCCESS,
                        data: {
                            from: paramData.from,
                            success: paramData.success,
                            loanBindNo: data.loanBindNo,
                            cardName: self.binData.bankName + '信用卡(' + $('#card_input').val().replace(/\s/g, '').slice(-4) + ')'
                        }
                    });
                    break;
                case C.Constant.Enum.ICARD.RESPONDCODE[20]:
                case C.Constant.Enum.ICARD.RESPONDCODE[8]:
                    //该卡已添加过且成功(应答码为S2)
                    /**埋点**/
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03040102-确定',
                        eventLable: 'iBT-0304010201-已添加过'
                    });
                    //埋点 添加信用卡页 已添加过
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_4_23_01_添加信用卡页'
                    });
                    errorTip.removeClass('dn').html('<span class="icon-sm icon-tip"></span> 您已添加过此卡，请勿重复添加!');
                    break;
                case C.Constant.Enum.ICARD.RESPONDCODE[22]:
                    //该卡已添加过且失败(应答码为S4)
                    /**埋点**/
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03040102-确定',
                        eventLable: 'iBT-0304010206-失败'
                    });
                    //埋点 添加信用卡页 失败
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_4_23_05_添加信用卡页'
                    });
                    errorTip.removeClass('dn').html('<span class="icon-sm icon-tip"></span> 添加失败，请填写您本人名下的有效信用卡!');
                    break;
                case C.Constant.Enum.ICARD.RESPONDCODE[1]:
                case C.Constant.Enum.ICARD.RESPONDCODE[2]:
                case C.Constant.Enum.ICARD.RESPONDCODE[5]:
                case C.Constant.Enum.ICARD.RESPONDCODE[10]:
                case C.Constant.Enum.ICARD.RESPONDCODE[11]:
                case C.Constant.Enum.ICARD.RESPONDCODE[12]:
                    //添加信用卡1min内-添加失败
                    /**埋点**/
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03040102-确定',
                        eventLable: 'iBT-0304010206-失败'
                    });
                    //埋点 添加信用卡页 失败
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_4_23_05_添加信用卡页'
                    });
                    C.Native.forward({
                        url: C.Constant.DataUrl.TRANSPAGE.ADDCARDFAIL,
                        callBack: function (){
                            window.location.href = window.location.href;
                        }
                    });
                    break;
                case C.Constant.Enum.ICARD.RESPONDCODE[6]:
                case C.Constant.Enum.ICARD.RESPONDCODE[7]:
                case C.Constant.Enum.ICARD.RESPONDCODE[9]:
                case C.Constant.Enum.ICARD.RESPONDCODE[14]:
                case C.Constant.Enum.ICARD.RESPONDCODE[15]:
                case C.Constant.Enum.ICARD.RESPONDCODE[17]:
                case C.Constant.Enum.ICARD.RESPONDCODE[18]:
                case C.Constant.Enum.ICARD.RESPONDCODE[23]:
                    //账号资金不足，银行卡问题、系统问题等导致平安付指令无法发出
                    /**埋点**/
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03040102-确定',
                        eventLable: 'iBT-0304010204-系统繁忙'
                    });
                    //埋点 添加信用卡页 系统繁忙
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_4_23_04_添加信用卡页'
                    });
                    self.doTip(busyText);
                    //重新发起打小钱的流程
                    break;
                case C.Constant.Enum.ICARD.RESPONDCODE[19]:
                    //添加次数超过5次(应答码为S1)
                    /**埋点**/
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03040102-确定',
                        eventLable: 'iBT-0304010206-失败'
                    });
                    //埋点 添加信用卡页 失败
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_4_23_05_添加信用卡页'
                    });
                    self.doTip(fullText);
                    break;
            }
            self.handler = setTimeout(function (){
                errorTip.addClass('dn');
            }, 3000);
            $('#verify').removeClass('btn-dis');
        },
        /**应答码为S1 S5或者轮询超过1分钟时应答码仍然为S3时执行的动作**/
        doTip: function(str){
            var errorTip = $('#error'),
                verify = $('#verify');
            errorTip.removeClass('dn').children('div.opa').html('<span>'+str+'</span>');
            setTimeout(function(){
                errorTip.addClass('dn');
                verify.removeClass('btn-dis');
            }, 3000);
        }
    }));

    $(function(){
        new Page;
    });
});
