/**
 * @author: zhoujun261@pingan.com.cn
 * @date  : 2017-06-12
 * @time  : 上午09:40
 * @describe: yqb-添加信用卡
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';

    var Page = View.extend(_.extend({
        /**绑定事件**/
        events: {
            'tap #yqb-back': 'goback',
            'keyup #yqb-tel': 'checknum',
            'tap #next': 'next'
        },
        /**初始化**/
        initialize: function () {
            C.Native.setHeader({
                title: '添加银行卡',
                isBack: false
            });
            this.cardNo = C.Utils.getParameter('cardNo');
            this.render();
        },
        goback: function() {
            history.back(-1);
        },
        checknum: function(e) {
            var $target = $(e.currentTarget);
            var val = $target.val();
            if (val.length === 6) {
                $('#next').removeClass('dis');
            } else {
                $('#next').addClass('dis');
            }
        },
        next: function(e) {
            var $target = $(e.currentTarget);
            if (!$target.hasClass('dis')) {
                location.href = 'credit_bindcard_suc.html?fromPage=credit_info_list.html';
            }
        },
        /**
         * 格式化名字
         * */
        formatName: function (str) {
            if (typeof str == 'string') {
                return '***' + str.substr(str.length - 1);
            }
        },
        /**
         * 格式化身份证
         * */
        formatId: function (str) {
            if (typeof str == 'string') {
                return str.substr(0, 2) + '************' + str.substr(str.length - 3);
            }
        },
        render: function() {
            var self = this;
            var data = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO),
                id = data.Id,
                name = data.custName,
                lastfour;

            if (self.cardNo) {
                lastfour = self.cardNo.substr(self.cardNo.length - 4);
            }
            $('#name').text(self.formatName(name));
            $('#icard').text(self.formatId(id));
            $('#num').text(lastfour);

            self.count();
        },

        /**
         * 倒计时
         * */
        count: function() {
            var i = 59,
                text = '重新获取';

            var timer = setInterval(function() {
                i--;
                if (i === 0) {
                    $('#count').text(text);
                    clearInterval(timer);
                } else {
                    $('#count').text(i);
                }
            }, 1000);

        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
