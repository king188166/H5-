/**
 * @author: EX-ZGANGKEMING001@pingan.com.cn
 * @date  : 2016-11-03
 * @describe: 资料代传合同
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        //事件
        events: {
            
        },
        initialize: function() {
            var self = this ;
            //设置头部
            C.Native.setHeader({
                title: '资料代传合同签订',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            //本地获取协议编号
            var arrData =[
                C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, //申请状态查询接口的数据
                C.Constant.DataKey.USER_LOGIN_INFO
            ];

            self.applyNo = self.concatLocalData(arrData).applyNo;

            $('#js-applyNo').html(self.applyNo);

            self.render(self.concatLocalData(arrData));
                     
        },
        // 初始页面渲染
        render: function(data ) {   
            var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            data.Id = userInfo.Id.replace(/^(\d{4})\d{10}(.{4})$/, '$1**********$2');//渲染的时候用正则样式代替
            data.mobile = userInfo.mobile.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2');
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        },
        // 拼接本地数据
        concatLocalData: function(arr) {
            var obj = {};
            for (var i = 0; i < arr.length; i++) {
                var sources = C.Utils.data(arr[i]);
                if (_.isObject(sources)) {
                    obj = _.extend(obj, sources);
                }
            }
            return obj;
        }
        
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});