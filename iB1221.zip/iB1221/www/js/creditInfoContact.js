/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-添加联系人
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    C.FastClick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap .icon-cont': 'openContactList',
            'tap .contact_to_book': 'openContactList',
            'tap #next-step': 'submitContacts',
            'tap .close_tip_win': 'closeTipWin',
            'click .select_relation_tab': 'selectRelationNew',
            'blur .contact_name': 'checkSingle',
            'blur .contact_mobile': 'checkSingle'
        },
        initialize: function () {
            var _this = this;
            //埋点 添加联系人页
            C.Native.TDOnEvent({
                eventId: '$_03_0_2_08_添加联系人页'
            });
            C.Native.setHeader({
                title: '添加联系人',
                leftCallback: function () {
                    C.Native.back({
                        url: 'credit_info_list.html'
                    });
                }
            });
            _this.contactStr = '';
            _this.contactListNum = 0;
            _this.uploadTelBookFlag = C.Utils.data(C.Constant.DataKey.NEED_CONTACT);
            _this.isContactEdit = C.Utils.data(C.Constant.DataKey.EDIT_CONTACT) == 'Y' ? 'Y' : 'N';
            _this.userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            if (!_this.userdata) {
                C.Native.getUserInfo(function (data) {
                    _this.userdata = data;
                });
            }
            //进入页面清空联系人数目
            C.Utils.data('iloan_contact_num', '');
            _this.maxContactNum = 200;
            C.UI.stopLoading();
        },

        /**
         * 关闭提示框
         * */
        closeTipWin: function () {
            $('#first_in_tip').hide();
        },

        /**
         * 打开通讯录
         * */
        openContactList: function (e) {
            //输入框失去焦点
            $('input').blur();
            var _this = this, $target = $(e.currentTarget);
            var parent = $target.closest('.contacts-con');
            _this.code = parent.attr('data-code');
            C.Native.getContactList(_this.maxContactNum, function (data) {
                if (data.result.paem) {
                    C.Utils.data('iloan_contact_num', data.result.paem.split('|').length);
                }

                if (data.code == '1') {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0203-添加联系人',
                        eventLable: 'iBT-020301-进入通讯录选择'
                    });
                    // 进入通讯录选择按钮  选择1，选择2，选择3
                    switch(_this.code){
                        case '0':
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_2_08_01_添加联系人页'
                            });
                            break;
                        case '1':
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_2_08_02_添加联系人页'
                            });
                            break;
                        case '2':
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_2_08_03_添加联系人页'
                            });
                            break;
                    }
                    if (data.result.paem) {
                        var tempData = data.result.paem.split('|');
                        _this.contactListNum = tempData.length > 0 ? tempData.length - 1 : 0;
                    } else {
                        _this.contactListNum = 0;
                    }

                    _this.contactStr = data.result.paem;

                    var rendData = {
                        name: data.result.name,
                        phone: data.result.phone,
                        canedit: _this.isContactEdit
                    };
                    var html = _.template($('#contact_detail').html(), {rendData: rendData});
                    $('.contacts-con[data-code="' + _this.code + '"]').html(html);
                    $('#next-step').addClass('btn-dis');
                    $('#next-step')[0].removeAttribute('style');
                    _this.checkSingle(null, rendData);
                } else if (data.code == '2') {
                    C.Native.tip('未打开通讯录权限，请打开后重试');
                } else {
                    C.Native.tip('读取通讯录失败');
                }
            });
        },

        checkSingle: function(e, data) {
            var $parent = null;
            C.UI.loading();
            var param = {};

            if (data) {
                param.contactName = data.name;
                param.mobile = data.phone;
            } else {
                $parent = $(e.currentTarget).closest('ul');
                param.contactName = $parent.find('.contact_name')[0].value;
                param.mobile = $parent.find('.contact_mobile')[0].value.replace(/[-]/g, '');
            }

            C.Native.rSAEncode(param, function (res) {
                if (res.code == '1') {
                    param = {
                        contactName: res.result.contactName,
                        mobile: res.result.mobile
                    };
                    $.ajax({
                        url: C.Api('SINGLERELATIONSHIP'),
                        type: App.IS_IOS ? 'post' : 'POST',
                        data: param,
                        success: function (res) {
                            if (res.flag == C.Flag.SUCCESS && res.data) {
                                if (res.data.resultCode != '1') {
                                    C.UI.tip({
                                        tip: res.data.resultMsg,
                                        time: 2000
                                    });
                                }
                            }
                        },
                        complete: function () {
                            C.UI.stopLoading();
                        }
                    });
                } else {
                    C.Native.tip('安全数据加密失败');
                }
            });
        },

        heartbeat: function (param) {
            $.ajax({
                url: C.Api('heartbeat'),
                type: App.IS_IOS ? 'post' : 'POST',
                data: param,
                success: function (res) {
                    console.log(JSON.stringify(res));
                }
            });
        },

        /**
         * 获取选择联系人信息
         * */
        getSubmitData: function (index) {
            var _this = this;
            var param = {
                contactName: $('.contacts-con[data-code="' + index + '"]').find('.contact_name')[0].value,
                mobile: $('.contacts-con[data-code="' + index + '"]').find('.contact_mobile')[0].value.replace(/[-]/g, ''),
                relation: $('.relation_show').eq(index).text()
            };
            //参数验证（手机号、姓名）
            if (!C.Utils.RegexMap.MobileNo.test(param.mobile)) {
                _this.legalData = false;
            }
            var regName = /^[\u4e00-\u9fa5]{2,10}$/g;
            if (!regName.test(param.contactName)) {
                _this.legalData = false;
            }
            return param;
        },

        /**
         * 上传联系人
         * */
        submitContacts: function (e) {
            var _this = this, callLogs = '', $target = $(e.currentTarget);
            if (_this.isLoading) return;
            C.Native.TDOnEvent({
                eventId: 'iBT-0203-添加联系人',
                eventLable: 'iBT-020303-下一步'
            });
            //埋点  下一步
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_08_04_添加联系人页'
            });

            if ($target.hasClass('btn-dis')) {
                return false;
            }
            C.UI.loading();

            var submit = function () {
                _this.legalData = true;
                var contactlist = [];
                for (var i = 0; i < 3; i++) {
                    contactlist[i] = _this.getSubmitData(i);
                }
                if (contactlist[0].mobile == contactlist[1].mobile || contactlist[0].mobile == contactlist[2].mobile || contactlist[1].mobile == contactlist[2].mobile) {
                    C.UI.stopLoading();
                    C.Native.tip('手机号码输入不能相同');
                    return false;
                }
                var param = {
                    paem: _this.contactStr,
                    callLogs: callLogs,
                    contactList: JSON.stringify(contactlist),
                    idNumber: _this.userdata.Id,
                    cardNumber: '',
                    mobile: _this.deviceInfo.simMobile || ''
                };
                C.Native.rSAEncode(param, function (res) {
                    if (res.code == '1') {
                        param = {
                            idNumber: res.result.idNumber,
                            cardNumber: res.result.cardNumber,
                            paem: res.result.paem,
                            callLogs: res.result.callLogs,
                            contactList: res.result.contactList,
                            mobile: res.result.mobile,
                            applyNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO),
                            sysType: App.IS_IOS ? 'IOS' : 'A',
                            contactNum: (_this.contactListNum).toString(),
                            callType: '上传联系人',
                            callChannel: '平安易贷',
                            registNo: _this.userdata.mobile,
                            appVersion: _this.deviceInfo.appVersion,
                            mobileBrand: _this.deviceInfo.mobileBrand,
                            mobileOsVer: _this.deviceInfo.mobileOsVer,
                            platform: App.IS_IOS ? 'IOS' : 'A',
                            sdkReturnStr: _this.deviceInfo.sdkReturnStr,
                            ip: _this.deviceInfo.ip,
                            mac: _this.deviceInfo.mac || '',
                            city: _this.deviceInfo.gpsCity || '',
                            machineSN: _this.deviceInfo.MachineSN || ''
                        };
                        if (App.IS_SDK) {
                            param.channelType = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO).sourceType;
                        }
                        _this.isLoading = true;
                        $.ajax({
                            url: C.Api('SAVERELATIONSHIP'),
                            type: App.IS_IOS ? 'post' : 'POST',
                            data: {
                                jsonPara: JSON.stringify(param)
                            },
                            success: function (res) {
                                _this.heartbeat({
                                    type: 'iloan_contact_num_success',
                                    contactNum: C.Utils.data('iloan_contact_num')
                                });
                                if (res.flag == C.Flag.SUCCESS && res.data) {
                                    if (res.data.resultCode == '1') {
                                        C.Native.TDOnEvent({
                                            eventId: 'iBT-02030302-下一步',
                                            eventLable: 'iBT-0203030201-成功'
                                        });
                                        //埋点  下一步成功
                                        C.Native.TDOnEvent({
                                            eventId: '$_03_2_2_08_01_添加联系人页'
                                        });
                                        if (res.data.subProcessCode == 'AM') {
                                            C.UI.stopLoading();
                                            //联系人上传成功后下一步非人脸识别处理情况
                                            if (res.data.uploadTelBookFlag) {
                                                C.Utils.data(C.Constant.DataKey.NEED_CONTACT, res.data.uploadTelBookFlag);
                                            }
                                            if (res.data.isContactEdit) {
                                                C.Utils.data(C.Constant.DataKey.EDIT_CONTACT, res.data.isContactEdit);
                                            }
                                            if (res.data.transferContactNum) {
                                                C.Utils.data(C.Constant.DataKey.UPLOAD_CONTACT_NUM, res.data.transferContactNum);
                                            }
                                            C.Native.tip(res.data.businessMsg || res.data.resultMsg);
                                        } else {
                                            C.UI.stopLoading();
                                            C.Native.back({
                                                url: 'credit_info_list.html'
                                            });
                                        }
                                    } else {
                                        C.Native.TDOnEvent({
                                            eventId: 'iBT-02030302-下一步',
                                            eventLable: 'iBT-0203030202-失败'
                                        });
                                        //埋点  下一步失败
                                        C.Native.TDOnEvent({
                                            eventId: '$_03_2_2_08_02_添加联系人页'
                                        });
                                        C.UI.stopLoading();
                                        C.Native.tip(res.data.resultMsg);
                                    }
                                }
                            },
                            complete: function (res) {
                                _this.isLoading = false;
                            }
                        });
                    } else {
                        C.Native.tip('安全数据加密失败');
                    }
                });
            };
            C.Native.getDeviceInfo(function (res) {
                if (res.code == '1') {
                    _this.deviceInfo = res.result;
                    //判断是否需要上传通讯录和通话记录
                    if (C.Utils.data(C.Constant.DataKey.NEED_CONTACT) == '1') {
                        if (!App.IS_IOS) {
                            C.Native.getContactRecord(function (data) {
                                console.log(data);
                                if (data.code == '1') {
                                    callLogs = data.callLog;
                                }
                                submit();
                            });
                        } else {
                            submit();
                        }
                    } else {
                        //如果是不需要上传联系人和通话记录的，不管IOS还是ANdroid，通话记录和通讯录均不上传
                        callLogs = '';
                        _this.contactStr = '';
                        submit();
                    }
                } else {
                    C.UI.stopLoading();
                    C.Native.tip('获取提交信息失败');
                }
            });
        },
        /**
         * 选择关系-new
         * */
        selectRelationNew: function (e) {
            var $target = $(e.currentTarget);
            var $show = $target.find('.relation_show');
            C.Native.TDOnEvent({
                eventId: 'iBT-0203-添加联系人',
                eventLable: 'iBT-020302-选择联系人关系'
            });
            // 埋点 选择关系 1，2，3
            switch(this.code){
                case '0':
                    C.Native.TDOnEvent({
                        eventId: '$_03_4_2_08_01_添加联系人页'
                    });
                    break;
                case '1':
                    C.Native.TDOnEvent({
                        eventId: '$_03_4_2_08_02_添加联系人页'
                    });
                    break;
                case '2':
                    C.Native.TDOnEvent({
                        eventId: '$_03_4_2_08_03_添加联系人页'
                    });
                    break;
            }
            var showtext = $show.text(), selectArray = ['父母', '子女', '配偶', '朋友', '同事', '亲戚', '房东'], title = '请选择联系人关系';
            C.UI.select({
                title: title,
                selectArray: selectArray,
                showtext: showtext,
                callback: function (data) {
                    var relation = data.text;
                    $show.text(relation);
                    if (relation == '请选择联系人关系') {
                        $('#next-step').addClass('btn-dis');
                    }
                    //三个联系人都添加且选择关系后设置按钮可点
                    if ($('#next-step').hasClass('btn-dis')) {
                        var flag = true;
                        if ($('.relation_show').length == 3) {
                            for (var key in $('.relation_show')) {
                                if ($('.relation_show').eq(key).text() == '请选择联系人关系') {
                                    flag = false;
                                }
                            }
                        } else {
                            flag = false;
                        }
                        if (flag) {
                            if(App.IS_SDK){
                                C.Native.getUIParams(function (data) {
                                    var btnBgColor = data.btnBgColor || data.buttonColor || '#eb6100',
                                        btnTitleColor = data.btnTitleColor || '#FFF';
                                    $('#next-step').removeClass('btn-dis').css({
                                        'background': btnBgColor,
                                        'color': btnTitleColor,
                                        'border': '1px solid' + btnBgColor
                                    });
                                });
                            }else{
                                $('#next-step').removeClass('btn-dis');
                            }
                        }
                    }
                }
            });
        }

    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
