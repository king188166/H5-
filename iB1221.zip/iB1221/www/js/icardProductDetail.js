/**
 * @author: EX-ZHANGKEMING001
 * @date  : 2016-10-20
 * @describe: ICARD-还卡攻略
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {

        },
        initialize: function() {
			//埋点 8.29新增，统计所有进入详细介绍页的总数
            C.Native.TDOnEvent({
                eventId: 'iBT-0209-产品详细介绍页',
                eventLable: 'iBT-020901-进入产品详情页'
            });
            C.Native.setHeader({
                title: '还卡攻略',
                leftCallback: function() {
                    C.Native.back();
                }
            });
        }
		
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});