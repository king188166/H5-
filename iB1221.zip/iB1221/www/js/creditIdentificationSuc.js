/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-人脸识别成功
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #make_sure_btn': 'faceNext'
        },
        initialize: function () {
            C.Native.setHeader({
                title: '验证成功',
                isBack: false
            });
            //埋点 人脸识别成功页
            C.Native.TDOnEvent({
                eventId: '$_03_0_2_09_人脸识别成功页'
            });
            C.Native.TDOnEvent({
                eventId: 'iBT-0204010101-活体检测',
                eventLable: 'iBT-020401010101-成功'
            });
            C.UI.stopLoading();
        },

        /**
         * 人脸识别成功下一步
         * */
        faceNext: function () {
            //埋点 确定
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_09_01_人脸识别成功页'
            });
            C.Native.TDOnEvent({
                eventId: 'iBT-020401010101-成功',
                eventLable: 'iBT-02040101010101-确定'
            });
            C.Native.back({
                url: 'credit_info_list.html'
            });
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});