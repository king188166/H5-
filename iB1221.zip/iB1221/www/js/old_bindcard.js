/**
 * 绑卡流程业务公共模块
 * 这里要照顾申请步骤的“绑卡”和增加银行卡的“添加”
 * @date 10/12/2015
 * @author <a href="mailto:ex-huxinwei001@pingan.com.cn">Shinvey Hu</a>
 */
define(['zepto', 'C', 'js/old_encrypt'], function ($, C, JSEncrypt) {
    'use strict';
    var userData = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
    var applInfo = C.Utils.data(C.Constant.DataKey.APPL_INFO);
    C.rsaEncrypt = JSEncrypt.rsaEncrypt;
    var params = {
            //external params accountId, paPayToken from local storage which is set by {@link home.js 我的账户}
            accountId: userData.accountId,
            paPayToken: C.rsaEncrypt(userData.paPayToken),

            // RSA加密版本号  API版本控制参数
            _RSAVER: C.Constant._RSAVER,
            ACCOUNT_VER: C.Constant.ACCOUNT_VER,
            curVer: C.Constant.curVer
        },
        err = new Error();

    var prepareData = function () {
        return $.when(
            /*//地址信息
             function () {
             var def = $.Deferred();
             /!**
             * define native api getAddressInfo
             *!/
             C.Native.getAddressInfo(function (data) {
             console.info(data);
             def.resolve(data);
             });
             return def;
             }(),
             //同盾设备信息
             function () {
             var def = $.Deferred();
             C.Native.getTDDeviceInfo(function (data) {
             console.info(data);
             data.flag == 1 ?
             def.resolve(data.tdDeviceInfo) :
             def.reject(data.msg);
             });
             return def;
             }(),*/
            //设备信息
            function () {
                var def = $.Deferred();
                C.Native.getDeviceInfo(function (data) {
                    console.info(data);
                    (data.flag || data.code) == 1 ? def.resolve(data.result) :
                        def.reject(data.msg);
                });
                return def;
            }()
        ).then(function (/*addr, TDDeviceInfo,*/ DeviceInfo) {
            console.info(arguments);
            //@todo bankCard 埋点信息
            $.extend(params, {
                lng: DeviceInfo.longitude,
                lat: DeviceInfo.latitude,
                address: DeviceInfo.address,
                city: DeviceInfo.gpsCity,
                //duplicated
                longitude: DeviceInfo.longitude,
                latitude: DeviceInfo.latitude,
                cityName: DeviceInfo.gpsCity,
                sdkReturnStr: DeviceInfo.sdkReturnStr,
                mobileBrand: DeviceInfo.mobileBrand,
                mobileOsVer: DeviceInfo.mobileOsVer
            });
            params.merReserved = {};
            params.merReserved.deviceRand = DeviceInfo.MachineSN;
            //@todo 缺失Native.getPhoneInfo方法的信息
            var phoneInfo = {} || {
                    //businessNo:'abce3123',
                    //clientName:'guoj',
                    //idNo:'1232143'
            };
            params.merReserved.GPS = params.lng + ',' + params.lat;
            $.extend(params.merReserved, phoneInfo);
            params.merReserved = JSON.stringify(params.merReserved);
            return params;

        }).done(function (params) {
            //Here we are waiting for last doneCallback of then() is resolved

        });
    };

    var defPrepareData = prepareData();
    var _callback = function () {
        // console.log()
    };

    var self = {
        init: function (callback, act) {
            var self = this;
            if (typeof callback === 'function') {
                _callback = callback;
            } else {
                _callback = function () {
                    // console.log()
                };
            }

            var urls = Object.keys(this.url);
            if (urls.indexOf(act) == -1) throw new Error("Unexpected the value of 'act', it should be " + urls.join('or'));

            this.act = act;

            //查询该账号是否有和壹钱包关联
            if (userData.paPayToken) {
                self.bindCardFunc();
            } else {
                //调用客户端鉴权壹钱包接口
                C.Native.loginOrRegistPaOne(function (data) {
                    data.flag = data.flag || data.code;
                    if (data.flag == 1 && data.paPayToken) {
                        userData.paPayToken = data.paPayToken;
                        C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, userData);
                        self.bindCardFunc();

                    } else {
                        err.message = '用户未完成壹钱包账户绑定';
                        _callback(false, err);
                    }
                });
            }
        },
        url: {
            apply: C.Api('bindCard'),
            add: C.Api('addBankCard')
        },
        bindCardFunc: function () {
            var self = this;
            $$.EventListener.off('back.bindcard').once('back.bindcard', function (data) {
                //flag＝1表示成功，＝0表示失败
                /*
                 data = {
                 'phoneNum': '13249394149',
                 'flag': '1',
                 'bankMark': 'CEB',
                 'userId': '1000010002615589',
                 'bankName': '光大银行',
                 'from': 'bindCard',
                 'bankCardId': '',
                 'bankCardType': 'D',
                 'bankCardNo': '6214915228855280'
                 }
                 */
                err.message = data.msg;
                err.data = data;

                console.log('$$.EventListener back.bindcard data: ', data);
                console.assert(data.from == 'bindCard', 'data.from != bindCard');
                console.assert(data.flag == '1', 'data.flag != 1');
                console.log('加密前的手机号:' + data.bankCardTel + '银行卡号' + data.bankCardNo + '壹钱包账号' + data.paPayAccount);

                if (data.from == 'bindCard' && data.flag == '1') {
                    $.extend(params, {
                        //绑定银行卡号
                        bankCardNo: C.rsaEncrypt(data.bankCardNo),
                        //银行卡预留手机
                        bankCardTel: C.rsaEncrypt(data.phoneNum),
                        //银行卡种类
                        cardType: data.bankCardType,
                        //银行名称
                        bankName: data.bankName,
                        //平安付银行代码
                        bankNo: data.bankMark,
                        //电子签名新算法参数
                        isDomesticAlgorithm: C.Utils.data('isDomesticAlgorithm'),
                        paPayAccount: C.rsaEncrypt(data.userId)//壹钱包账号
                        //bankCardId: C.rsaEncrypt(data.bankCardId)
                    });

                    switch (self.act) {
                        case 'add':
                            $.extend(params, {
                                name: userData.custName,
                                id: C.rsaEncrypt(userData.Id)
                            });
                            break;
                        default://apply
                            $.extend(params, {
                                mobile: C.rsaEncrypt(userData.mobile),
                                //external params businessNo, productType from local storage which is set by {@link home.js 我的账户}
                                businessNo: applInfo.businessNo,
                                productType: applInfo.productType
                            });
                            break;
                    }

                    console.log('加密后的手机号:' + params.bankCardTel + '银行卡号' + params.bankCardNo + '壹钱包账号' + params.paPayAccount);
                    console.log('js old_bindcard.js defPrepareData.state():', defPrepareData.state());
                    defPrepareData.state() == 'pending' && defPrepareData.done(function () {
                        self.submitBankData(params);
                    });
                    defPrepareData.state() == 'resolved' && self.submitBankData(params);
                    defPrepareData.state() == 'rejected' && _callback(false, err);

                } else _callback(false, err);
            });
            C.Native.forwardModule({
                moduleName: 'keplerhome',
                //@todo query string: production ? saveKey ?
                url: 'bind-card.html?production=keplerSDK&saveKey=1&loanType=1'
            });
        },
        submitBankData: function (data) {
            console.log('js old_bindcard.js submitBankData:' + JSON.stringify(data));
            C.UI.loading();
            //C.checkAccount();
            $.ajax({
                url: this.url[this.act],
                type: 'post',
                data: data,
                success: function (res) {
                    if (res.flag == C.Flag.SUCCESS) {
                        _callback(true, res.data);
                    } else {
                        C.Constant.DEBUG_MODE && C.Native.tip(res.msg);
                        err.message = res.msg;
                        err.data = res;
                        _callback(false, err);
                    }
                },
                error: function (XHR, textStatus, errorThrown) {
                    err.message = '网络连接错误';
                    err.data = {};
                    _callback(false, err);
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        }
    };

    /**
     * 绑卡流程
     * 这里要照顾申请步骤的“绑卡”和增加银行卡的“添加”
     * @param {String} act=apply apply代表走鉴权绑卡流程会请求/V3/business/bindCard.do接口，add表示添加银行卡会请求/V2/business/addBankCard.do接口
     * @returns {Promise}
     */
    function bindcard(act) {
        var def = $.Deferred();
        self.init(function (bool, resOrErr) {
            bool ? def.resolve(resOrErr) : def.reject(resOrErr);
        }, act || 'apply');
        return def.promise();
    }
    return bindcard;
});