/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2017/03/08
 * @describe: 当期应还明细页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #cutCountBank': 'cutFun', //跳转至储蓄卡列表页
            'tap #btn': 'overFun' //逾期 追偿代偿跳转
        },
        /*** 初始化：设置头部，埋点 ***/
        initialize: function () {
            var $this = this,
                params = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT),
                robotInfo = C.Utils.getQueryMap();//获取在线客服参数
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.REPAYDETAIL,
                isBack: true,
                leftCallback: function () {
                    if (robotInfo && robotInfo.from == 'robot' && !App.IS_SDK) {
                        //在线客服进来后跳转至再贷账户页
                        C.Native.forward({
                            url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN,
                            data: {
                                lastURL: robotInfo.lastURL,
                                lastModule: robotInfo.lastModule
                            }
                        });
                        return;
                    }
                    C.Native.back({
                        url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
                    });
                }
            });
            C.Native.TDOnEvent({
                eventId: 'iBT-0602-当期应还金额',
                eventLable: 'iBT-060201-明细'
            });
            //埋点 当期应还明细页
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_38_当期应还明细页'
            });
            //调用/icard/rpy/queryRepayment.do接口
            $this.dataRequest({
                url: C.Api('QUERYREPAYMENT'),
                callback: $this.render,
                type: 'POST',
                data: {
                    applyNo: params.applyNo
                }
            });
        },
        /*** 渲染页面元素 ***/
        render: function (res) {
            var $this = this,
                data = res.data,
                $btn = $('#btn'),
                fixedWrap = $('.fixed-wrap');
            //存储本地数据给储蓄卡页面
            $this.rpyBinkNo = data.rpyBinkNo;
            data.yqbList && (data.yqbList instanceof Array) && (data.yqbList.length > 0 )? data.debitCarList.unshift(data.yqbList[0]) : '';
            C.Utils.data('ICARD_DEBITICARDLIST', data.debitCarList);
            //还款总金额
            $('#money').text(data && data.payAmt && C.Utils.formatMoney(data.payAmt));
            //还款储蓄卡
            $('#cutCountBank').html([data && data.bankCardName || '', '<span class="icon-sm icon-arrow"></span>'].join(''));
            //顶部还款提示
            if (data.overDueCount > 0) {
                $('#red').text(['您有', data.overDueCount, '笔逾期超过80天的欠款，请先还清'].join(''));
                $('.money').addClass('overdue');
            }
            //渲染借款数据
            if (data && data.loanList) {
                data = $this.handleData(data);
                $('#detail').append(_.template($('#tpl').html())({data: data.loanList}));
            }
            //底部 追偿代偿 扣款中提示
            if ($this.isPayState_LP || $this.isOver == '1') {
                fixedWrap.removeClass('dn');
                $btn.removeClass('dn');
                $('.money').addClass('overdue');
                if ($this.isLP == '1' || $this.isDeduct == '1') {
                    //理赔状态但已扣款
                    if ($this.isLP == '1') {
                        if (data.fundingModel.toUpperCase() == 'L') {
                            $('p.tac').removeClass('dn').text('担保公司理赔中，请稍后进行还款操作');
                        } else {
                            $('p.tac').removeClass('dn').text('保险公司理赔中，请稍后进行还款操作');
                        }
                    } else {
                        $('p.tac').removeClass('dn').text('扣款中，请稍后进行还款操作');
                    }
                    //禁用按钮
                    $btn.addClass('btn-dis');
                }
            }
        },
        /*** 数据处理 ***/
        handleData: function (data) {
            var $this = this,
                newStr = [],
                loanId = [];
            $this.isOver = data.isOver == '1' ? 1 : 0; //是否逾期
            $this.isLP = data.isLP == '1' ? 1 : 0;  //是否理赔中
            for (var index = 0; index < data.loanList.length; index++) {
                loanId.push(data.loanList[index].loanId);
            }
            loanId = _.uniq(loanId);
            for (var i = 0; i < data.loanList.length; i++) {
                data.loanList[i]['index'] = loanId.indexOf(data.loanList[i].loanId);
                data.loanList[i]['loanType'] = Number(data.loanList[i]['loanType']) == 0 ? '提现' : '还卡';
                data.loanList[i]['totalCount'] = (function () {
                    return (isNaN(data.loanList[i].shouldPay) ? 0 : Number(data.loanList[i].shouldPay)) +
                        (isNaN(data.loanList[i].counterFee) ? 0 : Number(data.loanList[i].counterFee)) +
                        (isNaN(data.loanList[i].interest) ? 0 : Number(data.loanList[i].interest)) +
                        (isNaN(data.loanList[i].guaranteeFee) ? 0 : Number(data.loanList[i].guaranteeFee)) +
                        (isNaN(data.loanList[i].overInt) ? 0 : Number(data.loanList[i].overInt)) +
                        (isNaN(data.loanList[i].serviceCharge) ? 0 : Number(data.loanList[i].serviceCharge)) +
                        (isNaN(data.loanList[i].insuranceFee) ? 0 : Number(data.loanList[i].insuranceFee)) +
                        (isNaN(data.loanList[i].penalty) ? 0 : Number(data.loanList[i].penalty));
                })();
                switch (data.loanList[i].payState.toUpperCase()) {
                    case 'TD':
                        data.loanList[i].payState = C.Constant.Enum.ICARD.PAYSTATE.TD.title;
                        data.loanList[i].overdue = 'pending';
                        data.loanList[i].red = 'red';
                        break;
                    case 'DB':
                        data.loanList[i].payState = C.Constant.Enum.ICARD.PAYSTATE.DB.title;
                        data.loanList[i].overdue = '';
                        data.loanList[i].red = 'red';
                        break;
                    case 'RP':
                        data.loanList[i].payState = data.loanList[i].isDeduct == C.Constant.Enum.ICARD.PAYSTATE.isDeduct ?
                            C.Constant.Enum.ICARD.PAYSTATE.HK.title : C.Constant.Enum.ICARD.PAYSTATE.RP.title;
                        data.loanList[i].overdue = '';
                        data.loanList[i].red = 'red';
                        break;
                    case 'OD':
                        data.loanList[i].payState = C.Constant.Enum.ICARD.PAYSTATE.OD.title;
                        data.loanList[i].overdue = 'overdue';
                        data.loanList[i].red = 'overdue';
                        break;
                    case 'SE':
                        data.loanList[i].payState = C.Constant.Enum.ICARD.PAYSTATE.SE.title;
                        data.loanList[i].overdue = 'settled';
                        data.loanList[i].red = 'red';
                        break;
                    case 'LP':
                        data.loanList[i].payState = C.Constant.Enum.ICARD.PAYSTATE.LP.title;
                        data.loanList[i].overdue ='overdue';
                        data.loanList[i].red = 'overdue';
                        $this.isPayState_LP = true; //是否追偿代偿
                        break;
                }
                $this.isDeduct = data.loanList[i].isDeduct == '1' ? 1 : 0;//是否报盘中
                data.loanList[i]['totalCount'] = [C.Utils.formatMoney(data.loanList[i]['totalCount']), '元'].join('');
                data.loanList[i]['shouldPay'] = [C.Utils.formatMoney(data.loanList[i]['shouldPay']), '元'].join('');
                data.loanList[i]['loanAmt'] = [C.Utils.formatMoney(data.loanList[i]['loanAmt']), '元'].join('');
                data.loanList[i]['interest'] = [C.Utils.formatMoney(data.loanList[i]['interest']), '元'].join('');
                data.loanList[i]['guaranteeFee'] = [C.Utils.formatMoney(data.loanList[i]['guaranteeFee']), '元'].join('');
                data.loanList[i]['counterFee'] = [C.Utils.formatMoney(data.loanList[i]['counterFee']), '元'].join('');
                data.loanList[i]['overInt'] = [C.Utils.formatMoney(data.loanList[i]['overInt']), '元'].join('');
                data.loanList[i]['serviceCharge'] = [C.Utils.formatMoney(data.loanList[i]['serviceCharge']), '元'].join('');
                data.loanList[i]['insuranceFee'] = [C.Utils.formatMoney(data.loanList[i]['insuranceFee']), '元'].join('');
                data.loanList[i]['penalty'] = data.loanList[i].penalty ? [C.Utils.formatMoney(data.loanList[i]['penalty']), '元'].join('') : '';
                data.loanList[i]['fundingModel'] = data.fundingModel.toUpperCase();
                newStr.push(data.loanList[i]);
            }
            return data;
        },
        /*** 跳转至银行卡列表，修改扣款帐户 ***/
        cutFun: function () {
            var $this = this;
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0602-当期应还金额',
                eventLable: 'iBT-060202-修改银行卡'
            });
            //埋点 当期应还明细页 扣款账户
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_38_01_当期应还明细页'
            });
            C.Native.forward({
                url: 'repay_saving_card.html',
                data: {
                    from: 'repay_current_detailed.html',
                    loanBindNo: $this.rpyBinkNo
                },
                callBack: function (data) {
                    if (data && data.rpyBindNo && data.rpyBankName) {
                        //从储蓄卡列表页回来直接重新渲染还款银行
                        $('#cutCountBank').html(data.rpyBankName + '<span class="icon-sm icon-arrow"></span>');
                        $this.rpyBinkNo = data.rpyBindNo;
                    } else if (data && !!data.reload && data.bindNo) {
                        //添加储蓄卡成功返回后调用/icard/rpy/changeTolerantLoanCard.do接口
                        $this.dataRequest({
                            url: C.Api('CHANGELOANCARD'),
                            callback: function () { location.reload(); },
                            type: 'POST',
                            data: {
                                bindNo: data.bindNo
                            }
                        });
                    }
                }
            });
        },
        /*** 逾期 追偿代偿 分别跳转至还款列表页，还款确认页 ***/
        overFun: function (e) {
            var $this = this;
            if ($(e.currentTarget).hasClass('btn-dis')) {
                return;
            }
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0602-当期应还金额',
                eventLable: 'iBT-060203-立即还款'
            });
            //埋点 当期应还明细页 立即还款
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_38_02_当期应还明细页'
            });
            //追偿代偿 跳转至还款确认页时约定loanId为空
            if ($this.isPayState_LP) {
                C.Utils.data('isLp', true);
                C.Utils.data('loanId', '');
                C.Native.forward({
                    url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTOPERATION
                });
                return;
            }
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENT
            });
        },
        /*** Ajax请求数据 ***/
        dataRequest: function (json) {
            C.UI.loading();
            var self = this;
            $.ajax({
                url: json.url,
                type: json.type,
                data: json.data,
                success: function (res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        json.callback.call(self, res);
                    } else {
                        C.Native.tip(res.msg);
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});