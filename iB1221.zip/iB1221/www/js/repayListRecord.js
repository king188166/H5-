/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2017/03/13
 * @describe: 还款列表页
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        /***	事件代理start	***/
        events: {
            //:not([disabled])'tap #choose_spouse,#choose_friend,#choose_clerk': 'chooseLinkman'
            'tap .js_payList': 'changePage',
            'tap .js_payDateList': 'changePage',
            'tap .js_goToPage:not([disabled])': 'goToPage',
            'tap li.re-detail': 'toggleReverse'
        },
        /***	事件代理end	***/

        /***	初始化start	***/
        initialize: function() {
            var self = this,
                robotInfo = C.Utils.getQueryMap();

            //缓存在线客服来源
            C.Utils.data(C.Constant.DataKey.ROBOT_INFO, robotInfo);
            //埋点 还款列表页
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_39_还款列表页'
            });
            //  native头部配置
            C.Native.setHeader({
                title: '还款',
                rightText: '还款计划',
                isBack: 1,
                rightCallback: function() {
                    self.rpyPlan();
                },
                leftCallback: function() {
                    if (robotInfo && robotInfo.from == 'robot') {
                        //机器人跳转逻辑
                        C.Native.forward({
                            url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN,
                            data: {
                                lastURL: robotInfo.lastURL,
                                lastModule: robotInfo.lastModule
                            }
                        });
                        return;
                    }
                    C.Native.back({
                        url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
                    });
                }
            });
            C.UI.loading();
            self.getUserInfo();
            self.countPV('iBT-0601-立即还款', 'iBT-060101-我要还款');
            //埋点 我要还款页 
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_40_我要还款页'
            });
        },
        render: function(dataList) {
            var self = this;
            self.creatRepaymentListTpl(dataList);
        },
        /***	初始化end		***/

        /***	功能函数start	***/
        //格式化日期
        parseDate: function(date) {
            if (!date) {
                return '';
            }
            var year = date.substring(0, 4);
            var month = date.substring(4, 6);
            var day = date.substring(6, 8);
            return year + '-' + month + '-' + day;

        },
        //格式化数据
        formatloanList: function(res) {
            var self = this,
                dataList = res.data.loanList,
                payStateObj = C.Constant.Enum.ICARD.PAYSTATE;
            for (var i = 0; i < dataList.length; i++) {
                dataList[i].isShow = '';
                dataList[i].loanTypeTxt = dataList[i].loanType == 1 ? '还卡' : '提现';
                switch (dataList[i].payState) {
                    case 'TD':
                        dataList[i].payStateClass = payStateObj.TD.className;
                        dataList[i].payStateName = payStateObj.TD.title;
                        dataList[i].isShow = 'dn';
                        dataList[i].styleShow = 'dn';
                        break;
                    case 'RP':
                        dataList[i].payStateClass = payStateObj.RP.className;
                        dataList[i].payStateName = payStateObj.RP.title;
                        dataList[i].payOpt = dataList[i].isDeduct == '1' ? '扣款中' : (dataList[i].isRepayDate && dataList[i].isRepayDate == 'Y') ? '立即还款' : '提前还款';
                        dataList[i].styleShow = dataList[i].isDeduct == '1' ? 'color' : 'red';
                        dataList[i].isOver = res.data.isOver == '1' ? 1 : 0; //有逾期 详情页“提前还款”按钮不点亮
                        break;
                    case 'OD':
                        dataList[i].payStateClass = payStateObj.OD.className;
                        dataList[i].payStateName = payStateObj.OD.title;
                        dataList[i].payOpt = dataList[i].isDeduct == '1' ? '扣款中' : '立即还款';
                        dataList[i].styleShow = dataList[i].isDeduct == '1' ? 'color' : 'red';
                        dataList[i].odName = '逾期应还';
                        break;
                    case 'DB':
                        dataList[i].payStateClass = payStateObj.DB.className;
                        dataList[i].payStateName = payStateObj.DB.title;
                        dataList[i].styleShow = 'dn';
                        break;
                    case 'SE':
                        dataList[i].payStateClass = payStateObj.SE.className;
                        dataList[i].payStateName = payStateObj.SE.title;
                        dataList[i].styleShow = 'dn';
                        break;
                    case 'HK':
                        dataList[i].payStateClass = payStateObj.HK.className;
                        dataList[i].payStateName = payStateObj.HK.title;
                        dataList[i].styleShow = 'dn';
                        break;
                }
            }
            dataList = self.formatAmt(dataList);
            return dataList;
        },
        formatAmt: function(dataList) {
            for (var j = 0; j < dataList.length; j++) {
                dataList[j].loanAmt = C.Utils.formatMoney(dataList[j].loanAmt || 0);
                dataList[j].rpyTotalAmt = C.Utils.formatMoney(dataList[j].rpyTotalAmt || 0);
            }
            return dataList;
        },
        formatRpyList: function(res) {
            var dataList = res.data.rpyList;
            for (var k = 0; k < dataList.length; k++) {
                dataList[k].payAmt = dataList[k].payAmt ? C.Utils.formatMoney(dataList[k].payAmt) : 0;
                dataList[k].rpyAmt = dataList[k].rpyAmt ? C.Utils.formatMoney(dataList[k].rpyAmt) : 0;
                dataList[k].rateFee = dataList[k].rateFee ? C.Utils.formatMoney(dataList[k].rateFee) : 0;
                dataList[k].counterFee = dataList[k].counterFee ? C.Utils.formatMoney(dataList[k].counterFee) : 0;
                dataList[k].insuranceFee = dataList[k].insuranceFee ? C.Utils.formatMoney(dataList[k].insuranceFee) : 0;
                dataList[k].serviceCharge = dataList[k].serviceCharge ? C.Utils.formatMoney(dataList[k].serviceCharge) : 0;
                dataList[k].guaranteeFee = dataList[k].guaranteeFee ? C.Utils.formatMoney(dataList[k].guaranteeFee) : 0;
                dataList[k].overInt = dataList[k].overInt ? C.Utils.formatMoney(dataList[k].overInt) : 0;
                dataList[k].penalty = dataList[k].penalty ? C.Utils.formatMoney(dataList[k].penalty) : 0;
                if (dataList[k].fundingModel == 'L') {
                    // 担保模式 还款模式为空
                    dataList[k].trxCode = '';
                } else {
                    // 联合放款模式
                    dataList[k].trxCode = dataList[k].trxCode == '02' || dataList[k].trxCode == '03' || dataList[k].trxCode == '04' ? '手动还款' : '自动还款';
                }
            }
            return dataList;
        },
        //埋点
        countPV: function(eventId, eventLable, jsonData) {
            jsonData = jsonData || '';
            C.Native.TDOnEvent({
                eventId: eventId,
                eventLable: eventLable,
                jsonData: jsonData
            });
        },
        /***	功能函数end	***/

        /***	页面跳转控制start	***/
        goToPage: function(e) {
            var self = this,
                $dom = $(e.currentTarget),
                loanId = $dom.attr('data-loanId'),
                isOver = $dom.attr('data-isOver'),
                payOpt = $dom.find('.js_payOpt').html();
            if (payOpt == '提前还款') {
                self.countPV('iBT-060101-我要还款', 'iBT-06010101-提前还款');
                // 新埋点 我要还款页 提前还款 根据接口返回判断
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_40_01_我要还款页'
                });
            } else if (payOpt == '立即还款') {
                self.countPV('iBT-060101-我要还款', 'iBT-0601-立即还款');
                // 新埋点 我要还款页 立即还款 根据接口返回判断
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_40_02_我要还款页'
                });
            }
            setTimeout(function() {
                C.Native.forward({
                    url: C.Constant.DataUrl.TRANSPAGE.BORROWDETAIL,
                    data: {
                        loanId: loanId,
                        isOver: isOver
                    },
                    callBack: function(data) {
                        location.reload();
                    }
                });
            }, 50);
        },
        changePage: function(e) {
            var self = this,
                $dom = $(e.target);
            switch ($dom.attr('class')) {
                case 'js_payList':
                    $dom.addClass('active');
                    $('.record').addClass('dn');
                    $('.js_payDateList').removeClass('active');
                    self.getUserInfo();
                    self.countPV('iBT-0601-立即还款', 'iBT-060101-我要还款');
                    //埋点 还款列表页 我要还款
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_3_39_01_还款列表页'
                    });
                    break;
                case 'js_payDateList':
                    $dom.addClass('active');
                    $('.record').removeClass('dn');
                    $('.js_payList').removeClass('active');
                    $('#repayment_Panel').empty();
                    self.alreadyRpyList();
                    self.countPV('iBT-0601-立即还款', 'iBT-060102-还款记录');
                    //埋点 还款列表页 还款记录
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_3_39_02_还款列表页'
                    });
                    break;
            }
        },
        /***	页面跳转控制end		***/

        /***	渲染功能start	***/
        creatRepaymentListTpl: function(dataList) {
            var self = this;
            var repaymentListTpl = _.template($('#repaymentList-tpl').html(), {
                dataList: dataList
            });
            $('#repayment_Panel').empty();
            $('#repayment_Panel').html(repaymentListTpl);
            self.changePageStatus(dataList.length);
            if (!dataList.length) {
                $('#repayment_Panel').addClass('no-list').find('ul').addClass('no-tip');
                $('.noList').show();
            } else {
                $('#repayment_Panel').removeClass('no-list').find('ul').removeClass('no-tip');
            }
        },
        creatRepaymentDateListTpl: function(dataList) {
            var $elm = $('#repayment_Panel'),
                repaymentDateListTpl = _.template($('#repaymentDateList-tpl').html(), {
                    dataList: dataList
                });
            $elm.empty();
            $elm.html(repaymentDateListTpl);
            if (!dataList.length) {
                $('.tit').addClass('dn');
                $('#repayment_Panel').addClass('no-list').find('ul').addClass('no-tip');
                $('.noList').show();
            } else {
                $('#repayment_Panel').removeClass('no-list').find('ul').removeClass('no-tip');
                $('.noList').hide();
            }
        },
        creatCgiDateListTpl: function(dataList) {
            var $elm = $('#repayment_Panel'),
                cigDateListTpl = _.template($('#cgiDateList-tpl').html(), {
                    dataList: dataList
                });
            $('div.record').hide();
            $elm.empty();
            $elm.html(cigDateListTpl);
            if (!dataList.length) {
                $('.tit').addClass('dn');
                $('#repayment_Panel').addClass('no-list').find('ul').addClass('no-tip');
                $('.noList').show();
            } else {
                $('#repayment_Panel').removeClass('no-list').find('ul').removeClass('no-tip');
                $('.noList').hide();
            }
        },
        //页面状态操作
        changePageStatus: function(length) {
            var payState = $('.js_repaymentItem').eq(0).attr('data-payState'),
                isDeduct = $('.js_repaymentItem').eq(0).attr('data-isDeduct');
            if (payState == 'OD' && isDeduct == '0') {
                $('.js_payOpt').addClass('dn'); //隐藏
                for (var i = 0; i < length; i++) {
                    var itemPayState = $('.js_repaymentItem').eq(i).attr('data-payState');
                    if (itemPayState == 'OD') {
                        $('.js_payOpt').eq(i).removeClass('dn');
                        $('.js_goToPage').eq(i).removeAttr('disabled');
                    }
                }
            }
        },
        toggleReverse: function(e) {
            var dom = e.currentTarget,
                list = $(dom).siblings('li');
            $(list).removeClass('reverse-toggle');
            $(dom).toggleClass('reverse-toggle');
        },
        /***	渲染功能send	***/

        /***	业务start		***/
        getUserInfo: function() {
            var self = this;
            self.queryAllRepayment();
        },
        /***	业务end		***/

        /***	数据start		***/
        queryAllRepayment: function() {
            var self = this,
                postData = {
                    applyNo: C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).applyNo || ''
                };
            C.UI.loading();
            $.ajax({
                type: 'post',
                url: C.Api('QUERYALLREPAYMENT'),
                dataType: 'json',
                data: postData,
                cache: false,
                success: function(res) {
                    self.queryAllRepaymentCallBack(res);
                },
                error: function() {
                    C.Native.tip('网络错误，请稍后再试！');
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        alreadyRpyList: function() {
            var self = this;
            C.UI.loading();
            $.ajax({
                type: 'post',
                url: C.Api('ALREADYRPYLIST'),
                dataType: 'json',
                data: {},
                cache: false,
                success: function(res) {
                    self.alreadyRpyListCallBack(res);
                },
                error: function() {
                    C.Native.tip('网络错误，请稍后再试！');
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        rpyPlan: function() {
            var self = this;
            C.UI.loading();
            //埋点 还款列表页 还款计划
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_39_03_还款列表页'
            });
            $.ajax({
                type: 'post',
                url: C.Api('RPYPLAN'),
                dataType: 'json',
                data: {},
                cache: false,
                success: function(res) {
                    self.rpyPlanCallBack(res);
                },
                error: function() {
                    C.Native.tip('网络错误，请稍后再试！');
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        /***	数据end		***/

        /***	回调start		***/
        queryAllRepaymentCallBack: function(res) {
            if (res && res.flag == C.Flag.SUCCESS) {
                var self = this,
                    dataList = self.formatloanList(res);
                self.render(dataList);
            } else {
                C.Native.tip(res.msg || '网络错误，请稍后再试！');
            }
        },
        alreadyRpyListCallBack: function(res) {
            if (res && res.flag == C.Flag.SUCCESS) {
                var self = this,
                    dataList = self.formatRpyList(res);
                console.log(dataList);
                // 迁徙修改点  担保模式、联合放款模式还款记录数据统一使用联合放款记录模板
                self.creatCgiDateListTpl(dataList);
                // if (res.data.fundingModel.toUpperCase() == 'D' || res.data.fundingModel.toUpperCase() == 'U') {
                //     self.creatCgiDateListTpl(dataList);
                // } else {
                //     self.creatRepaymentDateListTpl(dataList);
                // }

            } else {
                C.Native.tip(res.msg || '网络错误，请稍后再试！');
            }
        },
        rpyPlanCallBack: function(res) {
            if (res && res.flag == C.Flag.SUCCESS) {
                C.Utils.data(C.Constant.DataKey.BT_REPAYMENT, res.data); //存储数据给到还款计划
                C.Native.forward({
                    url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTPLAN,
                    data: {
                        from: 'repayment'
                    },
                    callback: function(data) {
                        location.reload();
                    }
                });
            } else {
                C.Native.tip(res.msg || '网络错误，请稍后再试！');
            }
        }
            /***	回调end		***/
    });

    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});