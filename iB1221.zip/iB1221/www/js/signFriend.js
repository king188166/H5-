/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-开关关闭的友情提示页面
 */
define(['zepto', 'C', 'view', 'js/refresh'], function ($, C, View, RE) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #back-home': 'toBackHome'
        },
        initialize: function () {
            var self = this;
            //埋点 I贷额度已抢光页
            C.Native.TDOnEvent({
                eventId: '$_03_0_2_12_I贷额度已抢光页'
            });
            C.Native.setHeader({
                title: 'i贷',
                isBack: false
            });
            C.UI.stopLoading();
            self.isPosting = false;
        },

        toBackHome: function (e) {
            var self = this;
            //埋点 I贷额度已抢光页 返回首页
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_12_01_I贷额度已抢光页'
            });
            if (self.isPosting) {
                return;
            }
            self.isPosting = true;
            C.UI.loading();
            C.Native.backModule({
                moduleName: C.Constant.MODULE_NAME.home,
                url: C.Constant.index_page
            });
            setTimeout(function () {
                self.isPosting = false;
                C.UI.stopLoading();
                console.log(self.isPosting);
            }, 2000);
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
