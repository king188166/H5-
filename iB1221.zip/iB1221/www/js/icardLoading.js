/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2016-07-04
 * @time  : 首次贷款需要，再贷款不需要
 * @describe: BT-跑小车
 */
define(['zepto', 'C', 'view'], function($, C, View){
    'use strict';

    var Page = View.extend(_.extend({
        /**指定根元素**/
        el: 'body',
        /**初始化**/
        initialize: function(){
            var $this = this;
            $this.from = C.Utils.getQueryMap().from;
            
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
            $this.thirdChannel = sourceInfo ? sourceInfo.source : '';
            $this.channelType = sourceInfo ? sourceInfo.sourceType : '';
            
            C.Native.setHeader({ 
                title: C.Constant.Enum.TITLE.LOADING,
                isBack: 1
            });
            //发起AJAX请求，调用小车轮询接口
            $this.createRequest({
                url: C.Api('QUERYCREDITBIND'), //获取最新额度(轮询)
                type: 'post',
                data: {
                    applyNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO), //获取本地存储的申请号
                    accountId: C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).accountId,
                    thirdChannel: $this.thirdChannel,
                    channelType: $this.channelType 
                }, //accountId 为公共入参
                callback: function(data){
                    console.log(data);
                    $this.doJude(data);
                }
            });
        },
        /**渲染页面数据**/
        //render: function(){},
        createRequest: function(option){
            var $this = this;
            C.UI.loading();
            //发起AJAX请求，调用相应接口
            $.ajax({
                url: option.url,
                type: option.type,
                data: option.data,
                success: function(res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        option.callback.call($this, res.data);
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        doJude: function(data){
            var $this = this,
                _flag = data.pageFlag.toUpperCase();
            ($this.handler) && (clearTimeout($this.handler));
            switch(_flag) {
                //错误
                default:C.Native.tip('系统错误');
                    break;
                //继续询问
                case C.Constant.Enum.LOADING.A7:
                    $this.handler = setTimeout(function(){
                        //发起AJAX请求，调用小车轮询接口
                        $this.createRequest({
                            url: C.Api('QUERYCREDITBIND'),
                            type: 'post',
                            data: {
                                applyNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO), //获取本地存储的申请号
                                accountId: C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).accountId,
                                thirdChannel: $this.thirdChannel,
                                channelType: $this.channelType 
                            },
                            callback: function(data){
                                console.log(data);
                                $this.doJude(data);
                            }
                        });
                    }, 3000);
                    return;
                //额度变化
                case C.Constant.Enum.LOADING.A1:
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0302-额度变更',
                        eventLable: 'iBT-030201-确认'
                    });
                    //埋点 额度变更页  
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_20_01_额度变更页'
                    });
                    C.Native.forward({
                        title: C.Constant.Enum.TITLE.ALTER,
                        url: C.Constant.DataUrl.TRANSPAGE.ALTER,
                        data: { isLoading: data.isFisrtPay == 'Y'? 1 : 0 }
                    });
                    break;
                //bt支用打点规则通过 跳转6.0申请还卡
                case C.Constant.Enum.LOADING.A2:
                    C.Native.forward({
                        title: C.Constant.Enum.TITLE.PINNED,
                        url: C.Constant.DataUrl.TRANSPAGE.PINNED,
                        data: { isLoading: data.isFisrtPay == 'Y'? 1 : 0 }
                    });
                    break;
                //提现拒绝规则通过 首次动用 跳转3.1
                case C.Constant.Enum.LOADING.A3:
                    C.Native.forward({
                        url: C.Constant.DataUrl.TRANSPAGE.LOANSELECT
                    });
                    break;
                //提现拒绝规则通过 再次动用 跳转8.0
                case C.Constant.Enum.LOADING.A4:
                case C.Constant.Enum.LOADING.A5:
                    C.Native.forward({
                        url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
                    });
                    break;
                //未动用 跳转3.2 审核拒绝
                case C.Constant.Enum.LOADING.A6:
                    C.Native.forward({
                        url: C.Constant.DataUrl.TRANSPAGE.CREDITFAILRESULT
                    });
                    break;
            }
        }
    }));

    $(function(){
        new Page();
    });
});
