define(['zepto', 'C', 'view', 'js/common/iloanInside'], function ($, C, View, L) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #main-part': 'toMain',
            'tap #to-test': 'toTest',
            'tap #to-xinyong': 'toXinyong'
        },
        initialize: function () {
            C.Native.setHeader({
                title: 'iLoan',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
        },
        toXinyong: function () {
            console.log('调用信用加油...');
            C.Native.forwardModule({
                moduleName: 'paehome',
                url: 'credit-information.html?module=iloan'
            });
        },
        /**
         * 测试页面
         * */
        toTest: function () {
//			$.ajax({
//				url:C.Api('BINDBANKCARDS'),
//				// data:JSON.stringify({"jsonPara":{loanType:"1"}}),
//                data:{"jsonPara":JSON.stringify({loanType:"1"})},
//				type:"POST",
//				success:function(res){
//					C.UI.stopLoading();
//					console.log(JSON.stringify(res));
//				}
//			})
            L.toJumpWhichIloan();
        },
        toMain: function () {
            L.iLoanBTClick();
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});