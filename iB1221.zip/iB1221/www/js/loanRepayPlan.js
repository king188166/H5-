/**
 * @author: yerencheng501@pingan.com.cn
 * @date  : 2016-3-22
 * @describe: 还款计划
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            C.Native.setHeader({
                title: '还款计划',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            this.fundingModel = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO).fundingModel || '';
            var arr =[
                C.Constant.DataKey.LOAN_APPLY_INFO,
                C.Constant.DataKey.LOAN_REPAY_PLAN
            ];
            this.render(this.concatLocalData(arr));
        },
        // 初始页面渲染
        render: function(data) {
            $('#js-wrap-plan').html(_.template($('#js-html-plan').html(), data));
        },
        // 拼接本地数据
        concatLocalData: function(arr) {
            var obj = {};
            for (var i = 0; i < arr.length; i++) {
                var sources = C.Utils.data(arr[i]);
                if (_.isObject(sources)) {
                    obj = _.extend(obj, sources);
                }
            }
            return obj;
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});