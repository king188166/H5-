/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-产品展示页
 */
define(['zepto', 'C', 'view', 'js/refresh'], function ($, C, View, RE) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .go-on-dai': 'experienceLoan'
        },
        nodeObj: {
            'AU': 'credit_info_list.html',
            'AM': 'credit_info_list.html',
            'AF': 'credit_info_list.html',
            'AC': 'credit_info_list.html',
            'AY': 'credit_info_list.html',
            'AP': 'loan_select.html',
            'RP': 'account_iloan.html',
            'RJ': 'credit_fail_result.html',
            'XX': ''
        },
        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '预授信额度',
                leftCallback: function () {
                    var adflag = C.Utils.data(C.Constant.DataKey.AD_FLAG);
                    if (adflag && adflag == '0') {
                        C.Native.back({
                            data: {
                                'exitSDK': 1
                            }
                        });
                        return;
                    } 
                    C.Native.back();
                }
            });
            self.isPosting = false;
            var pre_money = C.Utils.formatMoney(C.Utils.data(C.Constant.DataKey.BT_ILOAN_PRE_CREDIT));
            $('.pre_money').text(pre_money);
        },
        experienceLoan: function (e) {
            var self = this;
            if (self.isPosting) {
                return false;
            }
            self.isPosting = true;
            RE.init(function (res) {
                C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, res.data);
                C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, res.data.applyNo || null);
                if (res.data.applySwitch && res.data.applySwitch == '0') {//关闭
                    C.Native.tip(res.data.switchMsg);
                } else {//打开
                    if (self.nodeObj[res.data.subProcessCode] == '') {
                        C.Native.tip(res.data.resultMsg);
                    } else {
                        C.Native.forward({
                            url: self.nodeObj[res.data.subProcessCode]
                        });
                    }
                }
                self.isPosting = false;
            }, function (res) {
                self.isPosting = false;
            });
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
