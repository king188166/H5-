/**
 * @author: EX-ZHANGKEMING001
 * @date  : 2016-07-14
 * @describe: icardBT-信用卡列表页
 */
define(['zepto', 'C', 'view'], function($, C, View){
    'use strict';

    var Page = View.extend(_.extend({
        /**指定根元素**/
        el: 'body',
        liTpl: _.template($('#checkBank').html()),
        /**初始化**/
        initialize: function(){
            var $this = this,
                paramers = C.Utils.getQueryMap();//获取6.0页面传送过来的参数
            $this.userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
            //埋点 选择信用卡页
            C.Native.TDOnEvent({
                eventId: '$_03_0_4_22_选择信用卡页'
            }); 
            //设置头部
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.CREDITLIST,
                isBack: 1,
                rightIcon: 'add',
                leftCallback: function() {
                    if(C.Utils.getQueryMap().success == 1){
                        C.Native.loadPage({
                            url: C.Constant.DataUrl.TRANSPAGE.PINNED
                        }); 
                    }else{
                        C.Native.back({
                            url: C.Constant.DataUrl.TRANSPAGE.PINNED
                        });  
                    }
                }
            });
            //执行下一步操作
            $.when($this.getTel({tel: $this.userInfo.mobile})).then($this.render.bind($this, paramers));
        },
        /**渲染页面数据**/
        render: function(option){
            var $this = this,
                bindNo = option.loanBindNo, //获取6.0页面传送过来的参数
                list = C.Constant.Enum.BANKINFO.BANKLIST ; //获取到本地银行配置信息
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
            self.thirdChannel = sourceInfo ? sourceInfo.source : '';
            self.channelType = sourceInfo ? sourceInfo.sourceType : '';
            //发起AJAX请求，调用借款查询接口
            $this.createRequest({
                url: C.Api('QUERYAPPLYINFO'),
                type: 'post',
                data: {
                    tel: $this.tel, //手机号
                    cityName: $this.userInfo.cityName || $this.userInfo.city, //城市名称
                    applyNo: C.Utils.data('BT_ICARD_APPLYNO'), //申请号
                    payApplyNo: C.Utils.data('BT_ICARD_PAYAPPLYNO'), //支用申请号
                    thirdChannel: $this.thirdChannel,
                    channelType: $this.channelType 
                }, //accountId 为公共入参
                callback: function(data){
                    C.Native.setHeader({
                        title: C.Constant.Enum.TITLE.CREDITLIST,
                        isBack: 1,
                        rightIcon: 'add',
                        leftCallback: function() {
                            if(C.Utils.getQueryMap().success == 1){
                                C.Native.loadPage({
                                    url: C.Constant.DataUrl.TRANSPAGE.PINNED
                                }); 
                            }else{
                                C.Native.back({
                                    url: C.Constant.DataUrl.TRANSPAGE.PINNED
                                });  
                            }
                        },
                        rightCallback: function() {
                            /**埋点**/
                            C.Native.TDOnEvent({
                                eventId: 'iBT-030402-选择信用卡',
                                eventLable: 'iBT-03040202-添加信用卡'
                            });
                             //埋点 选择信用卡页 添加信用卡
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_4_22_02_选择信用卡页'
                            }); 
                            if (!isNaN(data.bindCreditCardTimes) && !isNaN(data.bindCreditCardTimesLimit) && parseInt(data.bindCreditCardTimes, 10) < parseInt(data.bindCreditCardTimesLimit, 10)) {
                                C.Native.forward({
                                //跳转至增加信用卡页面
                                    url: C.Constant.DataUrl.TRANSPAGE.ADDCREDIT,
                                    data: {
                                        from: C.Constant.DataUrl.TRANSPAGE.CREDITLIST,
                                        success: C.Utils.getQueryMap().success
                                    },
                                    callback: function(data){
                                        location.reload();
                                    }
                                });
                            } else {
                                C.Native.tip('今日添加次数已满');
                            }
                        }
                    });
                    var bankInfo = data.creditCardList;
                    //bankInfo.unshift(data.yqbList[0]);//信用卡暂不支持壹钱包
                    //处理数据，增加logo字段
                    $.each(bankInfo, function(index, item){
                        if(item.loanBindNo == bindNo){
                            item.isChoosed = true;
                            $('#verify').removeClass('btn-dis');
                        }else{
                            item.isChoosed = false;
                        }
                        if(item.bankNo in list){
                            item.logo = list[item.bankNo].logo;
                        }else{
                            item.logo = '';
                        }
                    });
                    //渲染页面
                    $('#getBank').html($this.liTpl({data: bankInfo}));
                    //设置全局信息，用于选择信用卡操作
                    $this.bankList = bankInfo;
                }
            });
        },
        /**绑定事件**/
        events: {
            'tap .js_tap': 'doSelect', //选择信用卡
            'tap #verify': 'skipPinned'//点击下一步，跳转至6.0页面
        },
        createRequest: function(option){
            var $this = this;
            C.UI.loading();
            //发起AJAX请求，调用相应接口
            $.ajax({
                url: option.url,
                type: option.type,
                data: option.data,
                success: function(res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        option.callback.call($this, res.data);
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        doSelect: function(e){
            var target = $(e.currentTarget);
            if (target.hasClass('active')) {
                return;
            }
            target.addClass('active').siblings().removeClass('active');
            $('#verify').removeClass('btn-dis');
        },
        skipPinned: function(){
            var $this = this, loanBindNo, selectInfo;
            $.each($('.js_tap'), function(index, item){
                if($(item).hasClass('active')){
                    loanBindNo = $(item).attr('data-BindNo');
                }
            });
            $.each($this.bankList, function(index, item){
                if(item.loanBindNo == loanBindNo){
                    selectInfo = $this.bankList[index];
                }
            });
            //埋点 选择信用卡页  确定
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_22_01_选择信用卡页'
            }); 
            C.Native.TDOnEvent({
                eventId: 'iBT-030402-选择信用卡',
                eventLable: 'iBT-03040201-确定',
                jsonData: selectInfo
            });
            console.log(selectInfo);
            // 获取选定的银行卡信息
            if(selectInfo.loanBindNo && selectInfo.cardName){
                if(C.Utils.getQueryMap().success == 1){
                    C.Native.loadPage({
                        url: C.Constant.DataUrl.TRANSPAGE.PINNED, //跳转到6.0申请还卡页
                        data: {
                            loanBindNo: selectInfo.loanBindNo,
                            cardName: selectInfo.cardName
                        }
                    }); 
                }else{
                    C.Native.loadPage({
                        url: C.Constant.DataUrl.TRANSPAGE.PINNED, //跳转到6.0申请还卡页
                        data: {
                            loanBindNo: selectInfo.loanBindNo,
                            cardName: selectInfo.cardName
                        }
                    });  
                }               
            }
        },
        getTel: function(tel){
            var $this = this,
                dtd = $.Deferred();
            C.Native.rSAEncode(tel, function(data) {
                if(data.code == '1'){
                    $this.tel = data.result.tel;
                    dtd.resolve();
                }
            });
            return dtd.promise();
        }
    }));

    $(function(){
        new Page();
    });
    $$.EventListener.onBack = function(){
        location.reload();// 该方法是返回之后重新加载
    };
});