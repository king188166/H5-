/**
 * @author: EX-ZHANGKEMING001
 * @date  : 2016/10/18
 * @describe: icard添加信用卡失败
 * @addCardFail-bt
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #failSure': 'failFun'
        },
        initialize: function(){
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.ADDCARDFAIL,
                isBack: false,
                leftCallback: function(){return this;}
            });
        },
        failFun: function(){
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0304010206-失败',
                eventLable: 'iBT-030401020601-返回'
            });
            //埋点 添加信用卡页 失败返回
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_23_04_添加信用卡页'
            });
            //跳转至添加信用卡页面
            C.Native.back({
                url: C.Constant.DataUrl.TRANSPAGE.ADDCREDIT,
                data: {
                    isReflash: App.IS_SDK ? C.Utils.getQueryMap().isReflash :''
                }
            });
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});