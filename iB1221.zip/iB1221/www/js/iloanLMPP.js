/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2016-03-21
 * @time  : pm 16:54
 *
 * @describe: iLoan定期-亮明品牌
 */
define(['zepto', 'C', 'view'], function($, C, View){
    'use strict';
    var Page = View.extend(_.extend({
        events: {
        },
        initialize: function(){
            //埋点 产品详细介绍页
            C.Native.TDOnEvent({
                eventId: '$_03_0_1_02_产品详细介绍页'
            });
            C.Native.setHeader({
                title: '关于i贷',
                leftCallback: function(){
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
        }
    }));
    $(function(){
        new Page({
            el: $('body')[0]
        });
    });
});
