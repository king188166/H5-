/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2017/04/11
 * @describe: 还款成功页
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap div.btn': 'goIloan',
            'tap div.btn-full': 'continueRepay'
        },
        initialize: function() {
            var $this = this;
            // 埋点 还款成功
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_46_还款成功'
            });
            //设置标题
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.REPAYSUBMITSUC,
                isBack: false,
                leftCallback: function() {
                    return this; //禁用android物理回退键
                }
            });
            //渲染页面数据
            $this.render();
        },
        render: function() {
            var $this = this,
                paramer = C.Utils.data('ICARD_SUBMIT_REPAY'), //获取还款确认页参数
                $elm = $('.red');
            $elm.eq(0).text(C.Utils.formatMoney(Number(paramer.payAmt)) + '元');
            $elm.eq(1).text(paramer.rpyBankName);
            if (paramer.remainAmt && paramer.remainAmt > 0) {
                //提前还款 当期未结清
                $('#tip-text').html(['<div class="snow-sm"><p><span class="icon-sm icon-snow"></span>系统将于<span class="red">', paramer.rpyDate, '</span>还从您<span class="red">', paramer.rpyBankName, '</span>中扣除当期剩余应还<span class="red">', C.Utils.formatMoney(Number(paramer.remainAmt)), '元</span>，请确保账户金额充足。</p> </div>'].join(''));
                //只显示"我的i贷"按钮
                $('div.btn').show();
            } else if (paramer.munOver > 0 && paramer.overAmt > 0) {
                //munOver 逾期笔数  overAmt 逾期金额
                $this.$el.find('footer').prepend('<p class="red tac">您还有' + paramer.munOver + '笔逾期，逾期金额为' + C.Utils.formatMoney(Number(paramer.overAmt)) + '元。</p>');
                //只显示"继续还款"按钮
                $('div.btn-full').show();
            } else if (paramer.overAmt > 0) {
                //追偿代偿 约定 munOver 为0 overAmt 为理赔尚欠金额
                $this.$el.find('footer').prepend('<p class="overdue tac">您还有逾期超过80天的欠款未还清哦～</p>');
                //只显示"继续还款"按钮
                $('div.btn-full').show();
            } else {
                //提前还款 当期已结清  逾期、追偿代偿均已结清的情况
                $('div.btn').show();
                $('div.btn-full').show();
            }
        },
        goIloan: function() {
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-060101010101-确定还款',
                eventLable: 'iBT-06010101010101-我的i贷'
            });
            // 埋点 还款成功  我的i贷
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_46_01_还款成功'
            });
            //清空理赔状态下存储的本地数据
            if (C.Utils.data('isLp')) {
                C.Utils.data('isLp', null);
            }

            var robotInfo = C.Utils.data(C.Constant.DataKey.ROBOT_INFO);
            //跳转账户页
            if (robotInfo && robotInfo.from === 'robot') {
                C.Utils.data(C.Constant.DataKey.ROBOT_INFO, null);
                C.Native.loadPage({
                    url: [C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN].join('/')
                });
            } else {
                C.Native.back({
                    url: [C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN].join('/')
                });
            }
        },
        continueRepay: function() {
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-060101010101-确定还款',
                eventLable: 'iBT-06010101010102-继续还款'
            });
            // 埋点 还款成功  继续还款
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_46_02_还款成功'
            });
            if (C.Utils.data('isLp')) {
                //清空本地数据
                C.Utils.data('isLp', null);
                //跳转至当期应还明细页
                C.Native.loadPage({
                    url: [C.Constant.DataUrl.TRANSPAGE.REPAYDETAIL].join('/')
                });
            } else {
                C.Native.back({
                    url: [C.Constant.DataUrl.TRANSPAGE.REPAYMENT].join('/')
                });
            }
        }


    }));

    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});