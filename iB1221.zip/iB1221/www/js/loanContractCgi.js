/**
 * @author: EX-ZHANGKEMING001@pingan.com.cn
 * @date  : 2016-11-08
 * @describe: 合同签订(CGI模式下 借款协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            C.Native.setHeader({
                title: '合同签订',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            var arr = [
                C.Constant.DataKey.BT_ILOAN_QUAS_RESULT,
                C.Constant.DataKey.USER_LOGIN_INFO
            ];
            this.render(this.concatLocalData(arr));
        },
        // 初始页面渲染
        render: function(data) {
            var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            data.Id = userInfo.Id.replace(/^(\d{4})\d{10}(.{4})$/, '$1**********$2');//渲染的时候用正则样式代替
            $('#js-wrap-applyNo').html(_.template($('#js-html-applyNo').html(), data));
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        },
        // 拼接本地数据
        concatLocalData: function(arr) {
            var obj = {};
            for (var i = 0; i < arr.length; i++) {
                var sources = C.Utils.data(arr[i]);
                if (_.isObject(sources)) {
                    obj = _.extend(obj, sources);
                }
            }
            return obj;
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});