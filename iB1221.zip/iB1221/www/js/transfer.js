/**
 * @Author : liujinhuan647@pingan.com.cn
 * @Date   : 2015-12-22
 * @Time   : 16:29:35
 * @Description ：新战略机器人中转页
 * @Description : iloan定期+新战略入口中转页
 */
/* global define: false */
define(['zepto', 'C', 'view', 'js/common/iloan'], function ($, C, View, L) {

    'use strict';

    var Page = View.extend(_.extend({
        // 初始化
        initialize: function () {
            var self = this,
                paramer = C.Utils.getQueryMap();//获取页面参数
            if(paramer && paramer.from == 'robot' && paramer.to){
                var _url = paramer.to;
                //获取城市定位信息
                C.Native.getCityName(function(data){
                    C.Utils.data('BT_ILOAN_CITYNAME', data.cityName);
                });
                //获取登陆信息
                C.Native.getUserInfo(function(data){
                    C.Utils.data('BT_ILOAN_USER_LOGIN_INFO', data);//iloan模块登陆信息
                    C.Utils.data('ILOAN_USER_LOGIN_INFO', data);//icard模块登陆信息
                });
                switch (_url){
                    case 'repaymentPage':
                        //跳转还款列表页
                        C.Native.loadPage({
                            url: C.Constant.DataUrl.TRANSPAGE.REPAYMENT,
                            data: {
                                from: paramer.from,
                                lastURL: paramer.lastURL ? paramer.lastURL : 'IOS',
                                lastModule: paramer.lastModule ? paramer.lastModule : 'IOS'
                            }
                        });
                        break;
                    case 'mRepaymentMethodPage':
                        //跳转当期应还明细
                        C.Native.loadPage({
                            url: C.Constant.DataUrl.TRANSPAGE.REPAYDETAIL,
                            data: {
                                from: paramer.from,
                                lastURL: paramer.lastURL ? paramer.lastURL : 'IOS',
                                lastModule: paramer.lastModule ? paramer.lastModule : 'IOS'
                            }
                        });
                        break;
                }
            }else{
                //保持原有定期逻辑不变
                C.UI.loading();
                C.Native.setHeader({
                    title: ' ',
                    leftCallback: function () {
                        C.Native.backModule({
                            moduleName: C.Constant.MODULE_NAME.home,
                            url: C.Constant.index_page
                        });
                    }
                });
                self.render();
            }
        },
        // 渲染页面
        render: function () {
            L.goIloan('inside');
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function () {
            location.reload();
        };
    });
});
