/**
 * @author: qiuxiaoqiang292@pingan.com.cn
 * @date  : 2015-10-12
 * @time  : 上午09:25
 *@modified by ex-guojingjing001@pinggan.com.cn on 2015-10-14
 * @describe: 立即还款
 */
/*global define:false*/
define(['zepto', 'C', 'view', 'js/old_encrypt'], function ($, C, View, Encrypt) {
    'use strict';

    var acctNo = C.Utils.getParameter('acctNo');
    var custNo = C.Utils.getParameter('custNo');
    var windowHeight = $(window).height();
    var Page = View.extend(_.extend({
        events: {
            'tap .js_tap': 'choose',
            'tap .icon-add': 'addCard',
            'tap #_ipos_confirm_box': 'nextStep',
            'tap #fixed-wrap2 .btn': 'doRepay'
        },
        initialize: function () {
            var self = this;
            // 设置标题
            C.Native.setHeader({
                title: '立即还款',
                leftCallback: function () {
                    C.Native.back({
                        data: {
                            'checkReload': '1'
                        }
                    });
                }
            });
            //C.UI.loading();
            this.getRepaymentPromise(function (res) {
                //C.UI.stopLoading();
                if (res.flag == C.Flag.SUCCESS) {
                    var data = res.data;
                    //data={'rpAmt':'2032.00','disbAcountList":[{"accountNo":"","accountTypeName":"壹钱包账户","bindNo":"884874","bindType":"YQB","bankCode":" "},{"accountNo":"**** **** ****8698","accountTypeName":"建设银行","bindNo":"884875","bindType":"BANK","bankCode":"CCB"}],"rpDate":"20151109","mixRpAmt":null}
                    C.Utils.data('RP_DATA', data, 1);
                    self.render(data);
                    C.Native.TDOnEvent({
                        eventId: '0204-立即还款',
                        eventLable: '020401-录入金额'
                    });
                } else {
                    //C.UI.error(res.msg);
                    C.Native.tip(res.msg);
                }
            }, function (err) {
                //C.UI.stopLoading();
            });
            self.bind();
        },
        bind: function () {
            $(window).on('resize', function () {
                var nowWindowHeight = $(window).height();
                if (windowHeight > nowWindowHeight) {
                    $('.fixed-wrap2').hide();
                } else if (windowHeight == nowWindowHeight) {
                    $('.fixed-wrap2').show();
                }
            });
        },
        render: function (data) {
            // 最低金额
            data.mixRpAmt = data.mixRpAmt || '0';
            //if(data.mixRpAmt=='0'){
            $('#mix-rp-amt').text(C.Utils.formatMoney(data.mixRpAmt, 2));
            //}
            //else{
            //    $("#mix-rp-amt").setAmt(data.mixRpAmt);
            //}

            // 应还款全额
            //if(data.rpAmt=='0'){
            //    $("#rpAmt").text("0")
            $('#rpAmt').text(C.Utils.formatMoney(data.rpAmt, 2));
            //}
            //else{
            //    $("#rpAmt").setAmt(data.rpAmt);
            //}

            //还款日期
            var date = data.rpDate;
            if (date && date.length == 8) {
                date = date.substr(0, 4) + '-' + date.substr(4, 2) + '-' + date.substr(6, 2);
            }
            $('#rp-date').val(date);
            //加载银行列表
            var activeClass = 'js_tap';
            var html = '';
            for (var item in data.disbAcountList) {
                //if(item==0){activeClass = 'js_tap focus';}
                var accountNo = data.disbAcountList[item].accountNo;
                accountNo = accountNo.replace(/(\*|\s)/ig, '');
                var accountTypeName = data.disbAcountList[item].accountTypeName;
                //console.log(accountTypeName);

                var bindNo = data.disbAcountList[item].bindNo;
                if (accountTypeName != '壹钱包账户') {
                    html += '<li data-bind-no="' + bindNo + '" class="' + activeClass + '"><div>' + accountTypeName + '</div><div class="tail">尾号' + accountNo + '</div></li>';
                }
            }
            $('#choose_bank').html(html);
            $('#choose_bank li').eq(0).removeClass('js_tap').addClass('js_tap focus');
        },
        // 获取还款信息
        getRepaymentPromise: function (success, error) {

            $.ajax({
                url: C.Api('DRAW_CREDIT_AMT_QUERY'),
                type: 'get',
                data: {
                    custNo: custNo,
                    acctNo: Encrypt.rsaEncrypt(acctNo),
                    _RSAVER: '2.1.0'
                },
                success: success,
                error: error
            });
        },
        // 确认还款
        doRepay: function () {
            var rpData = C.Utils.data('RP_DATA', void 0, 1);
            var talkingData = {};
            // 到期还款日
            var rpDate = rpData.rpDate,
                // 还款金额
                trxAmt = $.trim($('#rp-amt').val());
            //应还款金额
            var rpAmt = rpData.rpAmt;

            // 选择的银行卡号
            var disbBindNo = Encrypt.rsaEncrypt($('#choose_bank li.focus').attr('data-bind-no'));
            // 还款金额
            if (trxAmt == '') {
                C.Native.tip('还款金额不能为空');
                return;
            } else if (trxAmt <= 0) {
                C.Native.tip('还款金额必须大于0');
                return;
            } else if (trxAmt > parseFloat(rpAmt)) {
                C.Native.tip('还款额不能大于最大的还款额' + rpAmt);
                return;
            }
            C.Native.TDOnEvent({
                eventId: '020402-下一步',
                eventLable: '02040204-确认还款'
            });
            $.ajax({
                url: C.Api('SUBMIT_REPAYMENT'),
                type: 'POST',
                data: {
                    custNo: custNo,
                    acctNo: Encrypt.rsaEncrypt(acctNo),
                    disbBindNo: disbBindNo,
                    rpDate: rpDate,
                    trxAmt: trxAmt,
                    merReserved: talkingData.merReserved || '',
                    _RSAVER: '2.1.0'
                },
                success: function (res) {
                    var dialogNo = 'dialog_' + ~~(Math.random() * 1000000);
                    if (res.flag == C.Flag.SUCCESS) {
                        $('#_ipos_confirm_box').attr('style', 'display:block');
                        $(document.body).prepend('<div class="mask" id=' + dialogNo + ' style="display:block;"></div>');
                        $('.font_size_15').html(res.msg);
                        //C.UI.dialog({
                        //    "btnnum": "1",
                        //    "position": "bottom",
                        //    "content": ""+res.msg+"",
                        //    "okText": "确定",
                        //    "ok":function(){
                        //        C.Native.back({
                        //            data: {
                        //                "checkReload" : "1"
                        //            }
                        //        });
                        //    }
                        //});


                    }
                    else {
                        $('#_ipos_confirm_box').attr('style', 'display:block');
                        $(document.body).prepend('<div class="mask" id=' + dialogNo + ' style="display:block;"></div>');
                        $('.font_size_15').html(res.msg);
                    }
                    C.UI.stopLoading();
                },
                error: function (err) {
                    $('#_ipos_confirm_box').attr('style', 'display:block');
                    var dialogNo = 'dialog_' + ~~(Math.random() * 1000000);
                    $(document.body).prepend('<div class="mask" id=' + dialogNo + ' style="display:block;"></div>');
                    $('.font_size_15').html(err);
                    console.log(JSON.stringify(err));
                    C.UI.stopLoading();
                }
            });
        },
        nextStep: function () {
            C.Native.back({
                data: {
                    'checkReload': '1'
                }
            });
        },
        amtString: function (val) {
            val = ((val || '0') * 1).toFixed(2);
            val = C.Utils.parseThousands(val);
            var n1 = val.split('.')[0];
            var n2 = val.split('.')[1];
            return '¥' + n1 + '. <sup>' + n2 + '</sup> ';
        },
        choose: function (e) {
            var node = $(e.currentTarget);
            if (node.hasClass('focus')) {
                return;
            }
            node.addClass('focus').siblings().removeClass('focus');
        },
        addCard: function () {
            C.Native.TDOnEvent({
                eventId: '020402-下一步',
                eventLable: '02040203-选择银行卡'
            });
            require(['js/bindcard'], function (bindcard) {
                bindcard('add').done(function (data) {
                    console.log('bindcard().done', data);
                    location.reload(true);
                }).fail(function () {
                    console.error('bindcard().fail');
                });
            });

        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});