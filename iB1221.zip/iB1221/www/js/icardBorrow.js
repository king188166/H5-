/**
 * by xuke163@pingan.com.cn
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        events: {
            'tap #js-arrow-rate': 'toggleRateDetail',
            'tap #js-btn-submit': 'loanConfirm',
            'tap #js-link-contract': 'goLoanContract', //借款及担保协议
            'tap #js-check-contract': 'isAgreeContract',
            'tap #js-borrow-contract': 'borrowContract', //借款协议
            'tap #js-transfer-contract': 'transferContract' //资料代传合同
        },
        talkingDate: function(key){
            var first = {
                '确认借款页': {
                    eventId: '$_03_0_4_27_确认借款页'
                },
                '确认借款按钮': {
                    eventId: '$_03_1_4_27_05_确认借款页'
                },
                '事件结果成功': {
                    eventId: '$_03_2_4_27_01_确认借款页'
                },
                '事件结果失败': {
                    eventId: '$_03_2_4_27_02_确认借款页'
                }
            };
            var noFirst = {
                '确认借款页': {
                    eventId: '$_03_0_4_53_还卡再贷确认页'  
                },
                '确认借款按钮': {
                    eventId: '$_03_1_4_53_01_还卡再贷确认页'
                },
                '事件结果成功': {
                    eventId: '$_03_2_4_53_01_还卡再贷确认页'
                },
                '事件结果失败': {
                    eventId: '$_03_2_4_53_02_还卡再贷确认页'
                }
            };
            return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
        },
        initialize: function() {
            C.Native.setHeader({
                title: '确认借款信息',
                isBack: 1
            });
            // 获取迁徙存储数据
            this.migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
            // 获取接口入参
            this.getRequestParams();
            // 首贷需要获取同盾
            if (this.isFirstPay == 'Y') {
                // 获取同盾参数
                this.getDeviceParams();
                //929版本新增两个参数:获取恶意app数量maliciousAppCnt 和 网络连接类型connectionType
				//联合放款需求新增参数 sparta设备号sparta_deviceid 和 IMEI编号imei
                this.getIriskParams();
            }
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                //埋点 无欠款迁徙提现确认页
                C.Native.TDOnEvent({
                    eventId: '$_03_0_0_59_无欠款迁徙确认页'
                });
            } else {
                //埋点 确认借款页 还卡再贷确认页
                C.Native.TDOnEvent(this.talkingDate('确认借款页'));
            }
            C.UI.stopLoading();
        },
        // 获取接口请求的入参
        getRequestParams: function() {
            var repaymentTrial = C.Utils.data(C.Constant.DataKey.BT_REPAYMENT),  
                queryApplyInfo = C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA),
                userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            this.isFirstPay = C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA).isFirstPay;
            this.fundingModel = queryApplyInfo.fundingModel;
            this.productType = queryApplyInfo.productType;
            // 新增借款用途字段
            this.purpose = queryApplyInfo.purpose;
            this.loanCompanyCode = queryApplyInfo.loanCompanyCode || 'L'; //小贷编码
            this.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
            this.accountId = userInfo.accountId;
            this.applyNo = queryApplyInfo.applyNo;
            this.insuranceNo = C.Utils.data(C.Constant.DataKey.BT_INSURANCE_NO);
            this.isAccountValid = queryApplyInfo.isAccountValid;
            // 保费率码值 525产险剥离二期添加
            this.insuranceRateCode = C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA).insuranceRateCode || '';
            this.repayInfo = {
                creditCardName: queryApplyInfo && queryApplyInfo.creditCardName || '', //默认放款卡名称
                loanBindNo: queryApplyInfo && queryApplyInfo.loanBindNo || '', //绑定号
                rpyBnakName: queryApplyInfo && queryApplyInfo.rpyBnakName || '', //默认还款卡
                rpyBnakNo: queryApplyInfo && queryApplyInfo.rpyBnakNo || '', //默认还款卡绑定号
                rpyDay: queryApplyInfo && queryApplyInfo.rpyDay || '', //还款日
                rateSum: queryApplyInfo && queryApplyInfo.rateSum || '',
                rate: queryApplyInfo && queryApplyInfo.rate || '', //日利率
                guaranteeRate: queryApplyInfo && queryApplyInfo.guaranteeRate || '', //日担保费率
                serviceCharge: queryApplyInfo && queryApplyInfo.serviceCharge || '', 
                premium: queryApplyInfo && queryApplyInfo.premium || '', 
                fundingModel: queryApplyInfo && queryApplyInfo.fundingModel || '',  
                rpyType: queryApplyInfo && queryApplyInfo.rpyType || '', //还款方式
                loanAmt: repaymentTrial && repaymentTrial.loanAmt || '', //申请贷款金额
                counterFee: repaymentTrial && repaymentTrial.counterFee, //动用手续费
                term: repaymentTrial && repaymentTrial.term || '', //还款期数
                //isActive: queryApplyInfo && queryApplyInfo.isAccountValid || 0, //是否在有效期内
                credit: queryApplyInfo && queryApplyInfo.credit || 0,
                cgiBankName: queryApplyInfo && queryApplyInfo.cgiBankName || '',
                loanCompanyName: queryApplyInfo && queryApplyInfo.loanCompanyName || '',
                isUpdateAgreement: queryApplyInfo && queryApplyInfo.isUpdateAgreement || '',  //是否更新协议
                isAccountValid: queryApplyInfo && queryApplyInfo.isAccountValid || '',
                isFirstPay: queryApplyInfo && queryApplyInfo.isFirstPay || ''
            };
            var repayInfo = this.repayInfo;
            $.extend(repayInfo, userInfo);
            repayInfo.rateSum = isNaN(repayInfo.rateSum) ? repayInfo.rateSum : [C.Utils.formatFloat(repayInfo.rateSum), '%'].join('');
            repayInfo.rate = isNaN(repayInfo.rate) ? repayInfo.rate : [C.Utils.formatFloat(repayInfo.rate), '%'].join('');
            repayInfo.guaranteeRate = isNaN(repayInfo.guaranteeRate) ? repayInfo.guaranteeRate : [C.Utils.formatFloat(repayInfo.guaranteeRate), '%'].join('');
            repayInfo.serviceCharge = isNaN(repayInfo.serviceCharge) ? repayInfo.serviceCharge : [C.Utils.formatFloat(repayInfo.serviceCharge), '%'].join('');
            repayInfo.premium = isNaN(repayInfo.premium) ? repayInfo.premium : [C.Utils.formatFloat(repayInfo.premium), '%'].join('');
            //repayInfo.isActive = isNaN(repayInfo.isActive) ? 0 : Number(repayInfo.isActive);
            repayInfo.Id = repayInfo.Id.replace(/^(\d{4})\d{10}(.{4})$/, '$1**********$2');

            this.version = C.Constant.PRODUCTION.cgiVersionNo[this.loanCompanyCode]; //协议书版本

            this.getUnderwritingRes();        
        },
        //核保结果
        getUnderwritingRes: function(){
            var self = this,
                insuranceRate = parseFloat(this.repayInfo.premium),
                params = {
                    insuranceRate: insuranceRate,  //日保费费率
                    insuranceRateCode: self.insuranceRateCode, // 保费率码值 525产险剥离二期添加
                    term: self.repayInfo.term,  //贷款期数
                    applyNo: self.applyNo,  //申请号
                    insuranceNo: self.insuranceNo,  //投保单号
                    ln_amt: self.repayInfo.loanAmt  //借款金额
                };
            // 新增迁徙入参
            if(this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                params.isMigrate = this.migrateData.isMigrate;
            }
            console.log(this.repayInfo.loanAmt);
            if(this.fundingModel.toUpperCase() === 'U' || this.fundingModel.toUpperCase() === 'D'){
                C.UI.loading();
                $.ajax({
                    url: C.Api('ADVISE_UNDERWRITING'),
                    type: 'post',
                    data: params,
                    success: function(res){
                        console.log(res);
                        if(res.flag && res.flag == C.Flag.SUCCESS){
                            var data = res.data;
                            if(data.resultCode == '1'){
                                //埋点 还卡核保页 成功
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_4_26_01_还卡核保页'
                                });
                                self.render(); 
                            }else{
                                //埋点 还卡核保页 失败
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_4_26_02_还卡核保页'
                                });
                                C.Native.forward({ 
                                    title: C.Constant.Enum.TITLE.BORROWFAIL,
                                    url: C.Constant.DataUrl.TRANSPAGE.BORROWFAIL
                                });
                            }
                        }else{
                            C.Native.tip(res.msg || res.data.resultMsg);
                        }
                    },
                    complete: function(res){
                        C.UI.stopLoading();
                    }
                });
            }else{
                this.render(); 
            }     
        },
        // 初始页面渲染
        render: function(data) {
            // 增加迁徙逻辑
            this.repayInfo.isMigrate = 'N';
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                this.repayInfo.isMigrate = this.migrateData.isMigrate;
            }
            $('#js-wrap-info').html(_.template($('#js-html-info').html(), this.repayInfo));
            $('#js-wrap-submit').html(_.template($('#js-html-submit').html(), this.repayInfo));
            
            if(App.IS_SDK){
                //按钮的颜色
                var btnTitleColor='#fff',
                    btnBgColor='#eb6100',
                    border = '1px solid #eb6100';
                C.Native.getUIParams(function (data) {
                    btnBgColor = data.btnBgColor || data.buttonColor || btnBgColor;
                    btnTitleColor = data.btnTitleColor || btnTitleColor;
                    border = '1px solid' + btnBgColor;
                    $('#js-btn-submit').css({
                        'color': btnTitleColor,
                        'border': border,
                        'background': btnBgColor
                    });
                });
            }
        },
        //展示费率
        toggleRateDetail: function(e){
            var arrow = $(e.currentTarget).children('.icon-sm');
            if (arrow.hasClass('icon-down')) {
                arrow.removeClass('icon-down').addClass('icon-up');
            } else if (arrow.hasClass('icon-up')) {
                arrow.removeClass('icon-up').addClass('icon-down');
            }
            $('.sprend').toggleClass('dn');
        },
        //确认借款
        loanConfirm: function(e){
            if ($(e.currentTarget).hasClass('btn-dis')) {
                return;
            }
            C.Native.TDOnEvent({
                eventId: 'iBT-03030101-借款信息',
                eventLable: 'iBT-0303010102-确认借款'
            });
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                //埋点 无欠款迁徙提现确认页 同意
                C.Native.TDOnEvent({
                    eventId: '$_03_1_0_59_01_无欠款迁徙确认页'
                });
            } else {
                //埋点 确认借款页 还卡再贷确认页 按钮 确认借款
                C.Native.TDOnEvent(this.talkingDate('确认借款按钮'));
            }
            this.loanConfirmRequest(C.Api('SUBMITSIGNCONTRACT'));  //首贷签约接口
        },
        /*借款协议1.0*/
        goLoanContract: function(e){
            C.Native.TDOnEvent({
                eventId: 'iBT-03030101-借款信息',
                eventLable: 'iBT-0303010101-借款及担保协议'
            });
            //埋点 确认借款页 借款及担保协议
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_27_02_确认借款页'
            });
            // 跳转到借款协议页面
            C.Native.forward({
                title: C.Constant.Enum.TITLE.CONTRACT, 
                url: C.Constant.CONTRACT[C.Constant.PRODUCTION.lastVersionNo]
            });
        },
        loanConfirmRequest: function (url) {
            var deviceParams = this.DeviceParams;
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
            var data = $.extend({
                accountId: this.accountId,
                isFirstPay: this.isFirstPay,
                applyNo: this.applyNo,
                payApplyNo: this.payApplyNo,
                loanBindNo: this.repayInfo.loanBindNo,
                loanAmt: this.repayInfo.loanAmt,
                thirdChannel: App.IS_SDK ? sourceInfo.source : '',
                channerType: App.IS_SDK ? sourceInfo.sourceType : '',
                platform: App.IS_IOS ? 'IOS' : 'A',
                isUpdateAgreement: this.repayInfo.isUpdateAgreement, //新增是否更新协议入参
                insuranceNo: this.insuranceNo, // 511版本,首贷/再贷确认借款增加投保单号入参
                versionNo: (this.fundingModel == 'D' || this.fundingModel == 'U') ? this.version : C.Constant.PRODUCTION.lastVersionNo,
                dataVersionNo: (this.fundingModel == 'D' || this.fundingModel == 'U') ? C.Constant.PRODUCTION.dataVersionNo : '', //资料代传合同版本号
                purpose: this.purpose
            }, deviceParams, this.IriskParams);
            // 新增迁徙入参
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isDebt) {
                data.isMigrate = this.migrateData.isMigrate;
                data.isDebt = this.migrateData.isDebt;
            }
            if (this.isAccountValid && this.isAccountValid == '0') {
                //新增是否变更借款合同有效期
                data.isAccountValid = '1';
                data.isUpdateAgreement = 'Y';
            }
            C.UI.loading();
            var self = this;
            $.ajax({
                url: url,
                type: 'POST',
                data: data,
                success: function(res) {
                    if(res && res.flag == C.Flag.SUCCESS){
                        var data = res.data;
                        if(String(data.subProcessCode).toUpperCase() == C.Constant.Enum.FLAG.APVFLAG_RJ){
                            C.Native.forward({
                                title: C.Constant.Enum.TITLE.CREDITFAILRESULT,
                                url: C.Constant.DataUrl.TRANSPAGE.CREDITFAILRESULT
                            });
                            return;
                        }
                        // 签约重新评级情况
                        if (data.levelChange == '1') {
                            self.showReApply();
                            return;
                        }
                        if(data.signSwitch == '1'){
                            //迁徙开关关闭，提示额度已抢光
                            if (data.migrateSwitch && data.migrateSwitch == '0') {
                                C.Native.tip(data.migrateMsg);
                                return;
                            }
                            if(data.resultCode == '1'){
                                // 跳转到成功页面
                                self.goLoanResult(data);
                            }else{
                                if (self.migrateData && this.migrateData.isMigrate && self.migrateData.isMigrate == 'Y') {
                                    //埋点 迁徙提交失败
                                    C.Native.TDOnEvent({
                                        eventId: '$_03_2_0_59_02_无欠款迁徙确认页'
                                    });
                                } else {
                                    //埋点 确认借款页 还卡再贷确认页
                                    C.Native.TDOnEvent(self.talkingDate('事件结果失败'));
                                }
                                 // 跳转到失败页面
                                C.Native.forward({ 
                                    title: C.Constant.Enum.TITLE.BORROWFAIL,
                                    url: C.Constant.DataUrl.TRANSPAGE.BORROWFAIL,
                                    data: {
                                        isSignSuccess: data.isSignSuccess
                                    }
                                });
                            }
                        }else {
                            C.Native.tip(data.switchMsg || data.resultMsg);
                        }  
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        isAgreeContract: function(e) {
            //埋点 确认借款页 同意单选框
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_27_01_确认借款页'
            });
            $(e.currentTarget).toggleClass('checked');
            $('#js-btn-submit').toggleClass('btn-dis');
        },
        //跳到成功页面
        goLoanResult: function(data){
            C.Utils.data(C.Constant.DataKey.BT_SIGNCONTRACT, data);
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                //埋点 迁徙提交成功
                C.Native.TDOnEvent({
                    eventId: '$_03_2_0_59_01_无欠款迁徙确认页'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-06050201-确认信息',
                    eventLable: 'iBT-0605020101-确认借款'                  
                });
                //埋点 确认借款页 还卡再贷确认页
                C.Native.TDOnEvent(this.talkingDate('事件结果成功'));
            }
            C.Native.forward({ 
                title: C.Constant.Enum.TITLE.BORROWSUC, 
                url: [C.Constant.DataUrl.TRANSPAGE.BORROWSUC].join('') 
            });
        },
        // 获取同盾参数
        getDeviceParams: function() {
            var self = this;
            C.Native.getDeviceInfo(function(json) {
                console.log(json);
                if (json.code == '1' && json.result) {
                    self.DeviceParams = {
                        //增加imei和Sparta_deviceid这2个参数（SDK是从这个方法获取这两个参数）
                        imei: json.result.imei || '',
                        sparta_deviceid: json.result.sparta_deviceid || '',

                        mac: json.result.mac || '',
                        city: json.result.gpsCity || '',
                        isRoot: json.result.isRoot || '',
                        address: json.result.address || '',
                        machineSN: json.result.MachineSN || '',
                        appVersion: json.result.appVersion || '',
                        mobileBrand: json.result.mobileBrand || '',
                        mobileOsVer: json.result.mobileOsVer || '',
                        sdkReturnStr: json.result.sdkReturnStr || '',
                        longitude: json.result.longitude || '',
                        latitude: json.result.latitude || ''
                    };
                    // 敏感信息加密
                    C.Native.rSAEncode({
                        idNumber: C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).Id,
                        registNo: C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).mobile,
                        mobile: json.result.simMobile || '',
                        cardNumber: ''
                    }, function(res) {
                        if (res.code == '1' && res.result) {
                            console.log(res);
                            self.DeviceParams = _.extend(self.DeviceParams, res.result);
                        } else {
                            C.Native.tip('加密信息失败');
                        }
                    });
                } else {
                    C.Native.tip('获取同盾参数失败');
                }
            });
        },
        //首贷需要获取获取恶意app数量maliciousAppCnt 网络连接类型connectionType sparta设备号sparta_deviceid 和 IMEI编号imei
        getIriskParams: function() {
            var self = this;
            C.Native.getTDParams(function(res){
                self.IriskParams = {
                    maliciousAppCnt: res.maliciousAppCnt || '',
                    connectionType: res.connectionType || '',
                    sparta_deviceid: res.sparta_deviceid || '',
                    imei: res.imei || '',
                    totalstorage_n: res.totalstorage_n || '',
                    screenres_length1: res.screenres_length1 || '',
                    screenres_length2: res.screenres_length2 || '',
                    black_box: res.black_box || ''              // 设备加密串
                };
            });
        },
        /*联合放款的跳转*/
        borrowContract: function(){
            var self = this;

            if(this.fundingModel == 'U'|| this.fundingModel == 'D'){
                //埋点 确认借款页 借款协议
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_27_03_确认借款页'
                });
                C.Native.forward({
                    url: C.Constant.CONTRACTCGI[self.version]//loan_contract_cgi.html
                });   
            }else{
                //埋点 确认借款页 借款及担保协议
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_27_02_确认借款页'
                });
                C.Native.forward({
                    url: C.Constant.CONTRACT[C.Constant.PRODUCTION.lastVersionNo]//loan_contract.html
                });
            }
        },
        transferContract: function(){//资料代传合同
            //埋点 确认借款页 资料代传合同
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_27_04_确认借款页'
            });
            C.Native.forward({ 
                url: C.Constant.DATAVERSION[C.Constant.PRODUCTION.dataVersionNo]
            });
        },
        // 签约重新评级情况
        showReApply: function() {
            var self = this;
            $('#js-block-reApply').show().find('.dialog-flex').tap(function(){
                if (self.isFirstPay == 'Y') {
                    C.Native.back({
                        url: C.Constant.DataUrl.TRANSPAGE.LOANSELECT
                    });
                } else {
                    C.Native.back({
                        url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
                    });
                }
            });
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});