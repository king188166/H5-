/**
 * @author: yerencheng501@pingan.com.cn
 * @date  : 2016-3-18
 * @describe: 选择银行卡
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        events: {
            'tap #js-wrap-card li': 'selectBankCard',
            'tap #js-btn-select': 'goLoanInfo'
        },
        initialize: function() {
            C.Native.setHeader({
                title: '选择银行卡',
                leftCallback: function() {
                    C.Native.back();
                },
                rightIcon: 'add',
                rightCallback: function() {
                    
                    C.Native.forward({
                        url: 'credit_bind_card.html',
                        data: {
                            route: 'back',
                            url: 'loan_info.html'
                        }
                    });
                }
            });
       
            this.render(this.concatLocalData([C.Constant.DataKey.LOAN_APPLY_INFO]));
            this.defaultCard();//默认的银行卡和卡号
            
        },
        // 初始页面渲染
        render: function(data) {
            $('#js-wrap-card').html(_.template($('#js-html-card').html(), data));
        },
        // 拼接本地数据
        concatLocalData: function(arr) {
            var obj = {};
            for (var i = 0; i < arr.length; i++) {
                var sources = C.Utils.data(arr[i]);
                if (_.isObject(sources)) {
                    obj = _.extend(obj, sources);
                }
            }
            return obj;
        },
        defaultCard: function() {
            this.modifyData = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO);
            this.cardName = this.modifyData.creditCardName;
            this.bindNo = this.modifyData.loanBindNo;
        },
        // 点击列表银行卡
        selectBankCard: function(e) {
            var target = $(e.currentTarget);
            target.addClass('active').siblings().removeClass('active');
            this.cardName = target.data('cardname');
            this.bindNo = target.data('bindno');
        },
        // 返回提现信息确认页面
        goLoanInfo: function() {
            C.Native.back({
                url: 'loan_info.html',
                data: {
                    reload: true,
                    bindNo: String(this.bindNo),
                    cardName: this.cardName,
                    loanBindNo: this.bindNo
                }
            });
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});