/**
 * 个人征信
 * @date 10/12/2015
 * @author <a href='mailto:ex-huxinwei001@pingan.com.cn'>Shinvey Hu</a>
 */
define('dosign', ['C'], function (C) {
    'use strict';
    //集成签名
    var apiInstance;
    var userData = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
    var barCode = 'iloansdk' + Math.round(Math.random() * 1000) + new Date().getTime();
    C.Utils.data('barCode', barCode, '1');

    function setAlertTitle() {
        var oInput = document.getElementById('qian-input');
        var oImg = document.getElementById('img');
        var fromPage = C.Utils.getParameter('fromPage');
        var migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
        oInput.addEventListener('click', function () {
            testPopupDialog(20);
            if (fromPage == 'credit_info_list') {
                //埋点 电子签名 综合授权书
                C.Native.TDOnEvent({
                    eventId: '$_03_1_2_04_01_综合授权书页'
                });
            } else if (migrateData && migrateData.isMigrate == 'Y') {
                C.Native.TDOnEvent({
                    eventId: '$_03_1_0_57_01_无欠款迁徙授权页'
                });
            } else {
                //埋点 重查征信页  电子签名
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_17_01_重查征信页'
                });
            }
        });
        oImg.addEventListener('click', function () {
            testPopupDialog(20);
        });

        testAnySign(112321321);
        testSetTemplateData();
        // $('#xss_20').hide();
    }


    //配置模板数据
    function testSetTemplateData() {

        // var formData = '{\'bjcaxssrequest\':{\'submitinfo\':[{\'username\':\'测星雨\',\'identitycardnbr\':\'320902198901191012\'},{\'username\':\'测星雨123\',\'identitycardnbr\': \'320902198901191012\'}]}}';

        var formData = '<html><head></head><body><div id=\'colArea\' class=\'pageFormContent\' style=\'width:95%;background:#f9fbf9;display:block;\'><div class=\'unit\'><label class=\'fontLabel\'>keyword：</label></div><div class=\'unit\'><label class=\'fontLabel\'>列名2：</label></div><div class=\'unit\'><label class=\'fontLabel\'>列名3：</label></div></div></body></html>';
        var businessId = barCode;//集成信手书业务的唯一标识
        //businessId='123123';
        var template_serial = '1#4000';//用于生成PDF的模板ID
        //template_serial='4000';
        var channel = '10010';//渠道号，由信手书提供，请咨询项目经理
        var res;
        //配置JSON格式签名原文
        res = apiInstance.setTemplate(TemplateType.HTML, formData, businessId, template_serial);
        //res = apiInstance.setTemplate(TemplateType.PDF,formData,businessId,template_serial);
        if (res) {
            //alert('setTemplateData success');
            console.log('setTemplateData success');
            return res;
        }
        else {
            //alert('setTemplateData error');
            console.log('setTemplateData error');
            return res;
        }
    }

    //添加签名框
    function testAddSignatureObj(objId) {
        //userData.custName='郭妞';
        //userData.Id='13164654646445465';
        var context_id = objId;
        //var signerRule = new SignRule_XYZ(20.0, 750.1, 80.2, 650.3, 1, 'pt');

        var signatureConfig = new SignatureConfig(new Signer(userData.custName, userData.Id), new SignRule_KeyWordV3('授权人（签字）', 120, 0, 1, 1));

        var res = apiInstance.addSignatureObj(context_id, signatureConfig);
        if (res) {
            // alert('addSignatureObj '+context_id+' success');
            return res;
        }
        else {
            alert('addSignatureObj ' + context_id + ' error');
            return res;
        }
    }


    //demo总入口
    function testAnySign(channel) {

        var res;
        var callback = function (context_id, context_type, val) {
            if (context_type == CALLBACK_TYPE_START_RECORDING || context_type == CALLBACK_TYPE_STOP_RECORDING) {
                return;
            }

            if (context_type == CALLBACK_TYPE_SIGNATURE) {
                //签名回显
                var oInput = document.getElementById('qian-input');
                var oQmwc = document.getElementById('img');
               // var decline = document.getElementById('decline');
                var imgData = document.getElementById('imgData');
                oInput.style.display = 'none';
               // decline.style.display = 'none';
                oQmwc.style.display = '';
                oQmwc.src = 'data:image/gif;base64,' + val;
                //oQmwc.src = val;
                imgData.value = val;
                testGenData();//生成加密字符串
                confirmTest();//进行CA验证
            }
            else if (context_type == CALLBACK_TYPE_ON_PICTURE_TAKEN) {
                document.getElementById('preview').src = 'data:image/gif;base64,' + val;
            } else if (context_type == CALLBACK_TYPE_ON_MEDIA_DATA) {
                var audio = document.createElement('audio');
                if (audio != null && audio.canPlayType && audio.canPlayType('audio/mpeg')) {
                    audio.src = 'data:image/gif;base64,' + val;
                    audio.play();
                }
            }

            setAlertTitle();
            //alert('收到浏览器回调：' + 'context_id：' + context_id + ' context_type：' + context_type + ' value：' + val);
        };//测试回调，将回调数据显示

        ////////////////////////////////////////////////
        apiInstance = new AnySignApi();

        //初始化签名接口
        res = apiInstance.initAnySignApi(callback, channel);

        if (!res) {
            alert('init error');
        } else {

        }
        ////////////////////////////////////////////////

        //注册单字签字对象20
        res = testAddSignatureObj(20);
        console.log(res);
        if (!res) {
            alert('testAddSignatureObj error');
        } else {

        }
        ////////////////////////////////////////////////

        //注册一个单位签章

        //var cachet_config = new CachetConfig(new Signer('小明', '110xxxxxx'), new SignRule_Tid('1121_cachet'), true);

        //res = apiInstance.addChachetObj(cachet_config);
        //var signer = new Signer(userData.custName,userData.Id);
        /**
         * 使用服务器规则配置签名
         * @param tid 服务器端生成的配置规则
         * @constructor
         */
        // var signerRule = new SignRule_Tid('1121_cachet');
        // var cachet_config = new CachetConfig(signer, signerRule, false);

        // res = apiInstance.addCachetObj(cachet_config);
        ////////////////////////////////////////////////

        // if (!res) {
        //     alert('addChachetObj error');
        // } else {

        // }
        ////////////////////////////////////////////////

        //将配置提交
        res = apiInstance.commitConfig();

        if (res) {
            //alert('Init ALL 初始化成功');
            console.log('Init ALL 初始化成功');
        } else {
            //alert('Init ALL 初始化失败');
            console.log('Init ALL 初始化失败');
        }

        ////////////////////////////////////////////////

    }


    function testIsReadyToUpload() {
        alert('testIsReadyToUpload :' + apiInstance.isReadyToUpload());
    }

    //生成签名加密数据
    function testGenData() {
        var res = document.getElementById('result');

        try {
            res.value = apiInstance.getUploadDataGram();
        }
        catch (err) {
            alert(err);
        }
    }

    //弹出签名框签名
    function testPopupDialog(context_id) {
        switch (apiInstance.showSignatureDialog(context_id)) {
            case RESULT_OK:
                break;
            case EC_API_NOT_INITED:
                alert('系统开小差，请退出重新尝试。');
                break;
            case EC_WRONG_CONTEXT_ID:
                alert('没有配置相应context_id的签字对象');
                break;
        }
    }

    //获取签名api版本信息
    function testGetVersion() {
        alert(apiInstance.getVersion());
    }

    //获取设备操作系统信息
    function testGetOsInfo() {
        alert(apiInstance.getOSInfo());
    }

    //提交
    function confirmTest(type) {
        var strJSONStr = document.getElementById('result').value;
        var imgData = document.getElementById('imgData').value;
        //为了防止后台XSS过滤，暂时将加密字符串某些字符替换
        if (type == 'Y') {
            strJSONStr = 'ESIGN_VERSION_1.0|' + C.Utils.base64encode('授权人（签字）') + '|' + C.Utils.base64encode(barCode) + '|' + C.Utils.base64encode(strJSONStr);
        }
        //var dataUrl = document.getElementById('img').src;
        var dataUrl = imgData;
        //var json = new Function('return' + strJSON)();;
        var pSign = '';
        var pSign0 = '';
        $('#anysign_sign_01').find('p').each(function (i, e) {
            var str = e.innerHTML.replace(/\n/g, '');
            pSign0 = pSign0 + str + '&';
        });
        if (pSign0 != '') {
            pSign = pSign0 + '#';
        }
        var pSign1 = '';
        $('#anysign_sign_02').find('p').each(function (i, e) {
            var str = e.innerHTML.replace(/\n/g, '');
            pSign1 = pSign1 + str + '&';
        });
        if (pSign1 != '') {
            pSign = pSign + pSign1 + '#';
        }
        var pSign2 = '';
        $('#anysign_sign_03').find('p').each(function (i, e) {
            var str = e.innerHTML.replace(/\n/g, '');
            pSign2 = pSign2 + str + '&';
        });
        if (pSign1 != '') {
            pSign = pSign + pSign2 + '#';
        }
        return {
            imageData: dataUrl,
            signData: strJSONStr,
            p: pSign,
            signKey: '13524242834'
        };
    }
    return {
        init: setAlertTitle,
        toJSON: confirmTest
    };
});
define(['zepto', 'C', 'view', 'dosign', 'js/common/Events', 'fastclick'], function ($, C, View, dosign, Events, Fastclick) {
    //处理点击延迟问题
    'use strict';
    Fastclick.attach(document.body);
    // 设置标题
    C.Native.setHeader({
        title: '综合授权书',
        leftCallback: function () {
            C.Native.back();
        }
    });

    var applInfo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT) || {};
    var userData = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
    var migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
    var isSubmit = !1;
    var fromPage = C.Utils.getParameter('fromPage');
    var newBankName = C.Utils.getParameter('newBankName');
    var bankCode = C.Utils.getParameter('bankCode');
    var fundingModel = C.Utils.getParameter('fundingModel');
    var loanCompanyCode = C.Utils.getParameter('loanCompanyCode');
    var isCredit = C.Utils.getParameter('isCredit');
    var isAuthFlag = C.Utils.getParameter('isAuthFlag');

    var barCode = C.Utils.data('barCode', barCode, '1');
    var Page = View.extend({
        events: {
            'tap #decline': 'decline',
            'tap #cancel': 'btnCancel',
            'tap #clear': 'btnClear',
            'click #agreed:not(.disabled)': 'agree'
        },
        initialize: function () {
            var _this = this;
            var applicationStatus = C.Utils.data('BT_ILOAN_QUAS_RESULT');
            //电子签名
            applicationStatus.electronicSignature = 0;
            C.Utils.data('BT_ILOAN_QUAS_RESULT', applicationStatus);
            if (fromPage == 'credit_info_list') {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0201-综合授权书',
                    eventLable: 'iBT-020101-电子签名'
                });
            } else if (migrateData && migrateData.isMigrate == 'Y') {
                C.Native.TDOnEvent({
                    eventId: '$_03_0_0_57_无欠款迁徙授权页'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-030101-综合授权书',
                    eventLable: 'iBT-03010101-电子签名'
                });
            }

            dosign.init();
            var agreedBtn = this.$('#agreed');
            this.model.on('pending', function () {
                agreedBtn.addClass('disabled');
                C.UI.loading();
            })
                .on('success', function (data) {
                    if (!data.esignOCR) {
                        //去绑卡 跳转页面
                        if (fromPage == 'credit_info_list') {
                            C.Native.getDeviceInfo(function (data) {
                                var param = {
                                    curVer: data.appVersion,
                                    machineSN: data.MachineSN || data.machinesn,
                                    loanType: '2'
                                };
                                $.ajax({
                                    url: C.Api('BINDBANKCARDS'),
                                    data: param,
                                    type: 'post',
                                    success: function (res) {
                                        if (res.flag == C.Flag.SUCCESS && res.data) {
                                            if (res.data.bankCards && res.data.bankCards.length > 0) {
                                                C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST, res.data);
                                                C.Native.forward({
                                                    url: 'select_auther_card_list.html', //已绑卡
                                                    data: {
                                                        route: 'back',
                                                        url: 'credit_info_list.html',
                                                        moduleName: '',
                                                        failRoute: 'back',
                                                        failUrl: 'credit_info_list.html',
                                                        failModuleName: '',
                                                        from: 'old_personal-credit.html',
                                                        previewUrl: 'credit_info_list.html',
                                                        originFromUrl: 'old_personal-credit.html',
                                                        Page: 'credit_info_list.html'
                                                    }
                                                });
                                            } else {
                                                C.Native.forward({  //首次
                                                    url: 'credit_bind_card.html',
                                                    data: {
                                                        route: 'back',
                                                        url: 'credit_info_list.html',
                                                        moduleName: '',
                                                        failRoute: 'back',
                                                        failUrl: 'credit_info_list.html',
                                                        failModuleName: '',
                                                        from: 'credit_info_list.html',
                                                        originFromUrl: 'old_personal-credit.html',
                                                        Page: 'credit_info_list.html'
                                                    }

                                                });
                                            }
                                        }
                                    },
                                    error: function() {
                                        C.UI.stopLoading();
                                    }
                                });
                            });
                        } else {
                            if (isAuthFlag && isAuthFlag == 'Y') {
                                // 首贷还卡 PBOC过期
                                C.Native.forward({
                                    url: 'select_auther_card_list.html',
                                    data: {
                                        route: 'forward',
                                        url: 'icard_loading.html',
                                        moduleName: 'iloanbt',
                                        failRoute: 'back',
                                        failUrl: 'loan_select.html',
                                        failModuleName: '',
                                        Page: 'loan_select.html'
                                    }
                                });
                            } else if (isAuthFlag && isAuthFlag == 'N' && fromPage == 'loan_select') {
                                // 首贷还卡，PBOC未过期，执行银行变更或者迁徙
                                C.Native.forwardInCurPage({
                                    url: 'icard_loading.html'
                                });
                            } else if (isAuthFlag && isAuthFlag == 'BTRP' && fromPage == 'account_iloan') {
                                // 再贷还卡，执行银行变更或者迁徙
                                C.Native.forwardInCurPage({
                                   url: 'icard_pinned.html'
                                });
                            } else {
                                // 提现，SDK1.0迁徙
                                C.Native.forwardInCurPage({
                                    url: 'loan_apply.html'
                                });
                            }
                        }
                    }
                })
                .on('error', function (err) {
                    if (err.flag == C.Flag.LOGIN_TIMEOUT || err.data == '尚未登录,请重新登录！') {
                        C.Native.dealTimeOut(err.data);
                        return;
                    }

                    C.UI.error({
                        //content: '未能成功提交电子签名数据',
                        content: err.data,
                        okText: '重试',
                        cancelText: '返回',
                        cancel: function () {
                            C.Native.back();
                        },
                        ok: function () {
                            _this.model.fetch(_this.model.toJSON());
                        },
                        btnnum: 2
                    });
                    C.UI.stopLoading();
                })
                .on('complete', function () {
                    agreedBtn.removeClass('disabled');
                });
        },
        decline: function () {
            if (fromPage == 'credit_info_list') {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0201-综合授权书',
                    eventLable: 'iBT-020103-不同意'
                });

                //埋点 不同意 综合授权书
                C.Native.TDOnEvent({
                    eventId: '$_03_1_2_04_03_综合授权书页'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-030101-综合授权书',
                    eventLable: 'iBT-03010103-不同意'
                });

                //埋点 重查征信页  不同意
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_17_03_重查征信页'
                });
            }

            C.Native.back();
        },
        btnClear: function () {
            isSubmit ? C.Native.back() : clear_canvas();
        },
        btnCancel: function () {
            isSubmit ? C.Native.back() : cancelSign();
        },
        agree: function () {
            if (fromPage == 'credit_info_list') {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0201-综合授权书',
                    eventLable: 'iBT-020102-同意'
                });

                //埋点 同意 综合授权书
                C.Native.TDOnEvent({
                    eventId: '$_03_1_2_04_02_综合授权书页'
                });
            } else if (migrateData && migrateData.isMigrate == 'Y') {
                C.Native.TDOnEvent({
                    eventId: '$_03_1_0_57_02_无欠款迁徙授权页'
                })
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-030101-综合授权书',
                    eventLable: 'iBT-03010102-同意'
                });

                //埋点 重查征信页  同意
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_17_02_重查征信页'
                });
            } 

            var _this = this;
            if (sign_confirm() || this.isSigned()) {
                //alert(_this.$el.find('#result').val());
                isSubmit = !0;
                _this.model.toJSON();
            } else {
                C.UI.warm({
                    content: '您还没有签名,无法进行下一步。',
                    okText: '好的',
                    btnnum: 1
                });
            }
        },
        isSigned: function () {
            var applicationStatus = C.Utils.data('BT_ILOAN_QUAS_RESULT');
            applicationStatus.electronicSignature = 1;
            C.Utils.data('BT_ILOAN_QUAS_RESULT', applicationStatus);
            return !!this.$el.find('#result').val().length;

        },
        showAgreement: function (data) {
            var bankname = newBankName || data.cgiBankName,
                frame = this.$('iframe'),
                frameDoc = null,
                html = '',
                title = '',
                bankCode = 'bank-' + C.Constant.BANKCONTRACT[bankname];

            if(fundingModel && (fundingModel == 'U' || fundingModel == 'D')) {
                frame.get(0).onload = function() {
                    frameDoc = frame.get(0).contentWindow.document;

                    if (isCredit && isCredit == 1 && fundingModel == 'U') {
                        html = frameDoc.getElementById(bankCode).innerHTML;
                        title = frameDoc.getElementById(bankCode).querySelector('.title').innerText;

                        frameDoc.getElementById('bank_contract_title').style.display = 'block';
                        frameDoc.getElementById('bank_contract_title').querySelector('span').innerText = title;
                        frameDoc.getElementById('bank_contract').style.display = 'block';
                        frameDoc.getElementById('bank_contract').innerHTML = html;
                    }
                    //迁徙修改点：新增migrateData.isMigrate迁徙开关的判断逻辑
                    if (fromPage == 'credit_info_list' || (isAuthFlag && isAuthFlag == 'Y') || (migrateData && migrateData.isMigrate == 'Y')) {
                        Array.prototype.slice.call(frameDoc.querySelectorAll('.js-cgi-sqs')).forEach(function(e) {
                            e.style.display = 'block';
                        });
                        switch (loanCompanyCode) {
                            case 'C':
                                Array.prototype.slice.call(frameDoc.querySelectorAll('.ozxsq_cgi_c')).forEach(function(e) {
                                    e.style.display = 'block';
                                });
                                break;
                            case 'H':
                                Array.prototype.slice.call(frameDoc.querySelectorAll('.ozxsq_cgi_h')).forEach(function(e) {
                                    e.style.display = 'block';
                                });
                                break;
                            default:
                                Array.prototype.slice.call(frameDoc.querySelectorAll('.ozxsq_cgi_l')).forEach(function(e) {
                                    e.style.display = 'block';
                                });
                                break;
                        }
                    }
                };
                
                frame.attr('src', 'old_zhengxinshouquan_cgi.html');
            } else {
                var agreements = {
                    c: 'old_zhengxinshouquan_c.html',
                    l: 'old_zhengxinshouquan_l.html'
                };
                loanCompanyCode = loanCompanyCode || 'l';
                this.$('iframe').attr('src', agreements[loanCompanyCode.toLowerCase()]);
            }
            $(document.body).show();
        }
    });

    function Model(opt) {
        var _this = this;
        this.url = opt.url || '';
        var switchJson = '';
        this.fetch = function fetch(params) {
            C.UI.loading();
            //this.trigger('pending');
            //alert(JSON.stringify(params));
            var submitUrl = '';
            if (fromPage == 'credit_info_list') {
                // 授信电子签名接口
                submitUrl = C.Api('UPLOADPOSELECTRONICSIGNATURE');
            } else {
                // PBOC电子签名接口 SDK1.0迁徙用户 SDK3.0迁徙用户（提现、还卡且PBOC未过期）
                submitUrl = C.Api('BT_UPLOADPOSELECTRONICSIGNATURE');
            }
            if (!!switchJson && !!switchJson.esignOCR && switchJson.esignOCR.isNewInterface == 'Y') {

                return $.ajax({
                    url: submitUrl,
                    type: 'post',
                    data: {
                        jsonPara: JSON.stringify(params)
                    },
                    success: function (res) {
                        var data;
                        if (res.data) {
                            data = res.data;
                        }
                        if (res.flag == C.Flag.SUCCESS) {
                            if (migrateData && migrateData.isMigrate == 'Y') {
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_0_57_01_无欠款迁徙授权页'
                                })
                            }
                            data = res.data;
                            if (fromPage != 'credit_info_list') {
                                C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO, data);
                            }
                            _this.trigger('success', data);
                        } else if (res.flag == '3') {
                            if (migrateData && migrateData.isMigrate == 'Y') {
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_0_57_02_无欠款迁徙授权页'
                                })
                            }
                            //=3代表校验不通过需要重新签名
                            C.Native.tip('请重新校验');
                            $('#result').val('');
                            $('#qian-input').show();
                            var err = new Error();
                            err.data = res.msg;
                            _this.trigger('error', err);
                        }
                        else {
                            if (migrateData && migrateData.isMigrate == 'Y') {
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_0_57_02_无欠款迁徙授权页'
                                })
                            }
                            //=2代表接口有问题
                            C.Native.tip(res.msg);
                            $('#result').val('');
                            $('#qian-input').show();
                            var err = new Error();
                            err.data = res.msg;
                            _this.trigger('error', err);
                        }

                    },
                    error: function() {
                        C.UI.stopLoading();
                    },
                    complete: function (res) {
                        //C.UI.stopLoading();
                    }
                });
            }
        };
        this.toJSON = function () {
            var params = {},
                sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO),
                self = this;
            C.UI.loading();
            var sign = dosign.toJSON('Y');

            $.ajax({
                url: C.Constant.SWITCH_SIGN_URL,
                //url: C.Api('SWITCH_SIGN'),
                data: params,
                type: 'GET',
                success: function (res) {
                    if (res.code == C.Flag.SUCCESS) {
                        switchJson = res.data;
                        _this.trigger('success', switchJson);

                        //isDomesticAlgorithm字段传给bindcard.do接口
                        C.Utils.data('isDomesticAlgorithm', switchJson.esignOCR.domesticAlgorithm);
                        if (switchJson != '' && switchJson.esignOCR.isNewInterface == 'Y') {
                            userData = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
                            //params.accountId = userData.accountId || '';
                            //params.os = '';//手机系统 A、IOS
                            params.businessNo = barCode;
                            params.productType = applInfo.productType;
                            //params.loanCompanyCode = loanCompanyCode;
                            params.platform = App.IS_IOS ? 'IOS' : 'A';
                            params.isPlugin = 'Y';
                            params.imgDenseStr = sign.signData;
                            params.imgBytes = sign.imageData;
                            params.ocrKey = switchJson.esignOCR.OcrKey;
                            params.ocrName = userData.custName || '';
                            params.productId = 'iloan';
                            params.isDomesticAlgorithm = switchJson.esignOCR.domesticAlgorithm;
                            params.ocrNeed = switchJson.esignOCR.OcrNeed;
                        } else {
                            params.platform = App.IS_IOS ? 'IOS' : 'A';
                            params.businessNo = barCode;
                            params.productType = applInfo.productType || '';
                            //params.loanCompanyCode = loanCompanyCode;
                            params.isPlugin = 'Y';
                            params.imgDenseStr = sign.signData;
                            params.imgBytes = sign.imageData;
                            params.ocrKey = 'N';
                            params.ocrNeed = 'N';
                            //params.productId = 'iloan';
                            params.isDomesticAlgorithm = 'Y';
                        }
                        params.productId = migrateData.loanCode || 'iloan';
                        params.ratio = migrateData.ratio || ''; //授信、迁徙电子签名入参
                        params.channelType = (sourceInfo &&  sourceInfo.sourceType) ? sourceInfo.sourceType : '';

                        if (fromPage == 'credit_info_list') {
                            //联合放款新增入参
                            if (!!applInfo.cgiBankName) {
                                params.cgiBankName = applInfo.cgiBankName;
                            }
                            if (!!applInfo.ratio) {
                                params.ratio = applInfo.ratio
                            }
                        } else {
                            params.applyNo = applInfo.applyNo;
                            params.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
                            params.bankName = newBankName || '';
                            params.bankCode = bankCode || '';
                        }
                        // SDK迁徙新增电子签名入参
                        params.isMigrate = migrateData.isMigrate || ''; //迁徙电子签名入参
                        params.isSign = migrateData.isSign || ''; //迁徙电子签名入参
                        params.signCode = migrateData.signCode || ''; //迁徙电子签名入参
                        params.loanCompanyCode = loanCompanyCode || migrateData.loanCompanyCode;
                        params.fundingModel = fundingModel || ''; //授信、迁徙电子签名入参
                        // 触发请求相应的电子签名接口
                        self.fetch(params);
                    } else {
                        var err = new Error();
                        err.data = switchJson;
                        _this.trigger('error', err);
                    }
                },
                error: function (xhr, textStatus, errThrown) {
                    var err = new Error();
                    err.message = textStatus;
                    _this.trigger('error', err);
                },
                complete: function (res) {
                    _this.trigger('complete');
                    //switchJson = res.data;
                }
            });


        };
    }

    _.extend(Model.prototype, Events);

    var $page = $(document.body);

    var view = new Page({
        el: $page,
        model: new Model({
            //url: C.Api('electronicSignature')
        })
    });

    view.showAgreement(applInfo);
});
