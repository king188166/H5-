/**
 * @author: 郭晶晶
 * @date  : 2015-9-30
 * @time  : 上午09:45
 *
 * @describe: 开普勒-我的账户页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';

    var summaryInfo = {};
    var applInfo = {};

    var Page = View.extend(_.extend({

        events: {
            'tap #btn-repay': 'repayNow',
            'tap #trade-detail': 'tradeDetail',
            'tap #btn-withdraw': 'withdrawMoney',
            'tap #btn-apply': 'withdrawMoney',
            'tap #btn-repay-mode': 'repayMode',
            'tap #btn-increase-quota': 'increaseQuota'
        },
        initialize: function () {
            C.UI.loading();
            var self = this;
            //埋点 老i贷1.0我的账户页
            C.Native.TDOnEvent({
                eventId: '$_03_0_0_56_我的I贷1.0账户页'
            });
            C.Native.setHeader({
                title: '随借随还首页',
                leftCallback: function () {
                    C.Native.back({
                        data: {
                            'exitSDK': '1'
                        }
                    });
                }
            });
            //清空迁徙数据
            C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, null);
            C.Native.getDeviceInfo(function (res) {
                var gpsData = res.result;
                console.log('城市及地理位置信息：' + JSON.stringify(gpsData));
                self.searchAppInfo(gpsData, function (res) {
                    if (res.data && res.flag == C.Flag.SUCCESS) {
                        applInfo = res.data;
                        C.Utils.data('OLD_APPL_INFO', res.data);
                    }
                }, function (error) {
                    C.UI.tip(JSON.stringify(error));
                });
            });
            this.searchSummaryInfo(function (res) {
                if (res.flag && res.flag == C.Flag.SUCCESS) {
                    var inSumLst = res.data.lnSumLst;
                    for (var i = 0, len = inSumLst.length; i < len; i++) {
                        if (inSumLst[i].applType.toUpperCase() == 'WX') {
                            summaryInfo = inSumLst[i];
                            break;
                        }
                    }
                    self.render(summaryInfo);
                    C.UI.stopLoading();
                    C.Utils.data('OLD_SUMMARY_INFO', summaryInfo);
                } else {
                    if (res.msg) {
                        C.Native.tip('请求失败，请重试');
                        //C.Native.back();
                    } else {
                        console.log(JSON.stringify(res));
                        C.UI.stopLoading();
                        C.UI.error(res.msg);
                    }

                }
            }, function (error) {
                console.log('error: ' + JSON.stringify(error));
                C.UI.stopLoading();
            });
            require(['js/old_MessageList'], function (Msg) {
                new Msg().pull();
            });
        },
        /*
         加载概要
         V2/account/searchSummaryInfo.do   还款概要，可用额度等
         */
        searchSummaryInfo: function (success, error) {
            $.ajax({
                url: C.Api('SEARCH_SUMMARY_INFO'),
                data: {
                    _SEARCHSUMMARYINFOVER: '2.0'
                },
                type: 'GET',
                success: success,
                error: error
            });
        },
        render: function (result) {
            //C.UI.stopLoading();
            if (!result) {
                return;
            }
            $('#account-status').show();
            var method = {
                // 网销申请     (status=OD)
                AP: function (result) {
                    $('#account-top').addClass('account-top application');
                    $('#loan-state').text('已申请');
                    $('#loan-state').addClass('btn-state');

                    $('#amt-apply').show();
                    $('#account-summary').hide();
                    $('#account-bottom').hide();

                    // 可用额度、信用额度
                    $('#abled-amt').setAmt(result.creditAmt);

                    //有额度还未取现
                    //$('#trade-detail').addClass('disabled');


                },
                // 逾期     (status=OD)
                OD: function (result) {

                    $('#account-top').addClass('account-top overdue');
                    $('#loan-state').text('已逾期');
                    $('#loan-state').addClass('btn-state');
                    $('#amt-state').text('逾期');

                    $('#btn-repay').removeClass('disabled');
                    $('#btn-repay').addClass('focus');
                    $('#btn-repay-mode').removeClass('disabled');
                    $('#btn-repay-mode').addClass('focus');

                    $('#btn-increase-quota').hide();
                    $('#overday').show();
                    $('#overdure-mix-rp-amt').show();


                    $('#btn-withdraw').addClass('focus');


                    $('#abled-amt').setAmt(result.dueAmt);
                    $('#over-day').text(result.overDay);

                },
                // 网销正常还款     (status=RP)
                RP: function (result) {
                    $('#loan-state').text('还款中');
                    $('#loan-state').addClass('btn-state');

                    $('#btn-withdraw').removeClass('disabled');
                    $('#btn-repay').removeClass('disabled');
                    $('#btn-repay-mode').removeClass('disabled');
                    $('#btn-withdraw').addClass('focus');
                    $('#btn-repay').addClass('focus');
                    $('#btn-repay-mode').addClass('focus');
                    $('#btn-increase-quota').hide();
                    $('#mix-amt').show();

                    //已经还完款
                    if (result.rpAmt == 0) {
                        $('#loan-state').text('');
                        $('#loan-state').removeClass('btn-state');
                        $('#repay').addClass('disabled');
                    }
                    //可用额度为0
                    if (result.abledAmt == 0) {
                        $('#btn-withdraw').addClass('disabled');
                    }

                }
            };
            if (applInfo.netAccountStatus == '0') {
                $('#btn-increase-quota').removeClass('disabled');
                $('#btn-increase-quota').addClass('focus');
            }
            //submitStatus	提交签约按钮是否可以点击	0:不能，1：可以点击
            if (applInfo.mark == 'BN' && applInfo.submitStatus == '0') {
                $('#btn-withdraw').removeClass('focus');
                $('#btn-withdraw').addClass('disabled');
            }
            // 是否还款
            if (result.rpFlag == 'Y') {
                $('#repay').addClass('focus');
            }
            //i贷num
            $('#iloan-num').text(result.acctNo);
            // 可用额度
            $('#abled-amt').setAmt(result.abledAmt);
            // 授信额度
            $('#credit-amt').setAmt(result.creditAmt);
            // 已用额度
            $('#used-amt').setAmt(result.usedAmt);
            // 到期还金额
            $('#rp-amt').setAmt(result.rpAmt);
            // 最低还款额
            $('#mix-rp-amt').setAmt(result.mixRpAmt);
            // rpDate	到期还日期
            var date = result.rpDate;
            if (date && date.length == 8) {
                date = date.substr(0, 4) + '-' + date.substr(4, 2) + '-' + date.substr(6, 2);
            }
            $('#rp-date').html(date);
            if (result.status && method[result.status]) {
                method[result.status](result);
            }
            // 额度盘
            result.usedAmt ? !0 : result.usedAmt = '0';
            if (result.usedAmt && result.creditAmt) {
                var percent = Math.round((1 - result.usedAmt / result.creditAmt) * 330);
                var unPercent = 534 - percent;
                $('#svg_circle').css('stroke-dasharray', '' + percent + ',' + unPercent + '');
                $('#keyframes-style').text('@keyframes dash {from {stroke-dasharray: 0 534; } to {stroke-dasharray: ' + percent + '  ' + unPercent + '; }}');
                //alert($('#keyframes-style').text())
            }
        },

        repayNow: function () {
            if ($('#btn-repay').hasClass('disabled')) return;
            C.Native.TDOnEvent({
                eventId: '0204-立即还款',
                eventLable: '020402-下一步'
            });
            C.Native.forward({
                url: 'old_immediate_repayment.html?' + $.param({
                    acctNo: summaryInfo.acctNo,
                    custNo: summaryInfo.custNo
                })
            });

        },
        tradeDetail: function () {
            if (summaryInfo.acctNo == undefined) {
                return;
            }
            if ($('#trade-detail').hasClass('disabled')) return;
            C.Native.forward({
                url: 'old_trade_detail.html?applNo=' + (applInfo.applNo || summaryInfo.acctNo) + '&acctNo=' + summaryInfo.acctNo
            });

        },
        withdrawMoney: function (e) {
            var node = $(e.currentTarget);
            var currentId = node[0].id;
            //console.log(node[0].id);
            if (currentId != 'btn-apply') {
                if ($('#btn-withdraw').hasClass('disabled')) return;
            }
            C.Native.TDOnEvent({
                eventId: '02-我的账户',
                eventLable: '0205-动用额度'
            });
            // SDK1.0迁徙修改点 调用新增迁徙接口
            var iloanVersion = C.Utils.data(C.Constant.DataKey.SDK_VERSION);
            C.UI.loading();
            $.ajax({
                url: C.Api('MIGRATE_CHECK'),
                type: 'POST',
                data: {
                    jsonPara: JSON.stringify({
                        applyNo: summaryInfo.applyNo || applInfo.applNo,
                        channelType: 'SDK', // SDK固定入参
                        loanCode: '' // SDK1.0固定入参为空
                    })
                },
                success: function (res) {
                    var data = res.data;
                    if (res && res.flag == C.Flag.SUCCESS) {
                        if (data.resultCode && data.resultCode != '1') {
                            C.Native.tip(data.resultMsg || '网络异常，请稍后再试！');
                            return;
                        }
                        if (data.isMigrate == 'Y' && data.isDebt == 'N' && iloanVersion) {
                            //埋点 无欠款迁徙
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_0_56_01_我的I贷1.0账户页'
                            });
                            if (data.signSwitch && data.signSwitch == '0') {
                                // 动用开关关闭，提示"额度已抢光"
                                C.Native.tip(data.switchMsg);
                                return;
                            }
                            //存储返回的数据 上传电子签名信息以及申请提现等支用页面使用
                            data.fromPage = 'old_home';
                            //存储授信额度字段 用于确认信息页借款协议展示初始额度
                            data.credit = summaryInfo.creditAmt || applInfo.creditAmt;
                            C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, data); // 将迁徙数据统一存储该字段，用以支用页面埋点，确认信息页再贷接口入参，系统开小差等页面校验使用
                            C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, data); // 储存数据在试算页面进行身份信息补录校验
                            C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, data); // 存储数据在电子签名接口入参
                            C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO, data.payApplyNo); // 存储数据在电子签名接口以及借款查询接口等入参
                            if (data.isSign == 'Y') {
                                //需要电子签名 跳转至综合授权书
                                C.Native.forward({
                                    url: 'old_personal-credit.html',
                                    data: {
                                        fromPage: 'old_home',
                                        newBankName: data.signCode === 'S00002' ? data.newBank : data.cgiBankName, // 用于电子签名展示银行协议内容
                                        bankCode: data.bankCode,
                                        fundingModel: data.fundingModel, // 用于电子签名时根据资金模式D、U辅助判定是否需要展示银行协议
                                        loanCompanyCode: data.loanCompanyCode, // 用于电子签名展示小贷公司内容
                                        isCredit: data.isCredit // 用于电子签名银行变更时判定是否需要展示银行协议
                                    }
                                });
                                return;
                            }
                            //已电子签名 跳转至申请提现页
                            C.Native.forward({
                                url: 'loan_apply.html'
                            });
                            return;
                        }
                        //不符合迁徙条件执行原有逻辑
                        if (applInfo.mark != 'BN') {
                            //非首次取现
                            C.Native.forward({
                                url: 'old_amount_use2.html?' + $.param({
                                    acctNo: summaryInfo.acctNo,
                                    custNo: summaryInfo.custNo
                                })
                            });
                        }
                    }

                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });

        },

        repayMode: function () {
            if ($('#btn-repay-mode').hasClass('disabled')) return;
            C.Native.TDOnEvent({
                eventId: '02-我的账户',
                eventLable: '0206-还款方式'
            });
            C.Native.forward({
                url: 'old_modified_repayment.html?' + $.param({
                    acctNo: summaryInfo.acctNo,
                    custNo: summaryInfo.custNo,
                    status: summaryInfo.status
                })
            }) ;

        },
        searchAppInfo: function (params, success, error) {
            var searchInfoParam = {
                // 经度
                longitude: params.longitude || '114.1013',
                // 维度
                latitude: params.latitude || '22.5677',
                //埋点信息
                merReserved: '',
                //城市
                cityName: params.gpsCity || '深圳市',
                ACCOUNT_VER: '2.1.0',
                curVer: '9.9.0'
            };
            $.ajax({
                url: C.Api('SEARCH_APPL_INFO'),
                type: 'POST',
                data: searchInfoParam,
                success: success,
                error: error
            });
        },
        increaseQuota: function () {
            if ($('#btn-increase-quota').hasClass('disabled')) return;
            //提高额度
            location.href = 'bind_network_account.html?' + $.param({
                applNo: applInfo.applNo || summaryInfo.acctNo
            });
        }

    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });

    $$.EventListener.onBack = function () {
        location.reload();
    };

});
