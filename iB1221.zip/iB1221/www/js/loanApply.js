/**
 * @author: yerencheng501@pingan.com.cn
 * @date  : 2016-3-15
 * @describe: 申请借款
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    C.FastClick.attach(document.body);
    var Page = View.extend({
        // 事件
        events: {
            'focus #js-input-amount': 'showAmountInput',
            'blur #js-input-amount': 'calculateRepayment',
            'tap #js-arrow-gorepay': 'goRepayment',
            'tap #js-btn-next': 'goLoanInfo', //点击页面下一步
            'tap #js-btn-back': 'goBack',
            'tap #js-late-apply': 'lateApply', //弹层的稍后申请
            'tap #js-huan-kuan': 'toHuankuan', //弹层的去还款
            'tap #js-agree-insurance': 'toInsurance', //同意去投保
            'tap #js-cancle-insurance': 'toCancle', //取消投保
            'tap .know-detail': 'knowDetail', //点击了解更多
            'tap .js-prompt-close': 'closePrompt',
            'change #select-yt': 'chooseUse'

        },
        talkingDate: function(key) {
            var first = {
                '申请提现': {
                    eventId: 'iBT-04-提现',
                    eventLable: 'iBT-0401-申请借款'
                },
                '下一步': {
                    eventId: 'iBT-0401-申请借款',
                    eventLable: 'iBT-040101-下一步'
                },
                '还款计划': {
                    eventId: 'iBT-0401-申请借款',
                    eventLable: 'iBT-040102-还款计划'
                },
                '申请提现试算页': {
                    eventId: '$_03_0_4_31_申请提现试算页'
                },
                '下一步2.0': {
                    eventId: '$_03_1_4_31_02_申请提现试算页'
                },
                '还款计划2.0': {
                    eventId: '$_03_1_4_31_01_申请提现试算页'
                }
            };
            var noFirst = {
                '申请提现': {
                    eventId: 'iBT-0604-提现再贷',
                    eventLable: 'iBT-060401-申请借款'
                },
                '下一步': {
                    eventId: 'iBT-060401-申请借款',
                    eventLable: 'iBT-06040101-下一步'
                },
                '还款计划': {
                    eventId: 'iBT-060401-申请借款',
                    eventLable: 'iBT-06040102-还款计划'
                },
                '申请提现试算页': {
                    eventId: '$_03_0_4_47_提现再贷试算页'
                },
                '下一步2.0': {
                    eventId: '$_03_1_4_47_01_提现再贷试算页'
                },
                '还款计划2.0': {
                    eventId: '$_03_1_4_47_02_提现再贷试算页'
                }
            };
            return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
        },
        // 初始化
        initialize: function() {
            var $this = this,
                idvalidData = C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID) || {},
                migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
            $this.isFirstPay = (idvalidData && idvalidData.isFirstPay) ? idvalidData.isFirstPay : '';
            $this.isMigrate = (migrateData && migrateData.isMigrate) ? migrateData.isMigrate : '';
            //借款用途
            $this.purpose = '';
            // 埋点 申请提现试算页
            if ($this.isMigrate && $this.isMigrate == 'Y') {
                C.Native.TDOnEvent({
                    eventId: '$_03_0_0_58_无欠款迁徙试算页'
                });
            } else {
                C.Native.TDOnEvent($this.talkingDate('申请提现试算页'));
            }
            // 设置APP头部
            C.Native.setHeader({
                title: '申请提现',
                leftCallback: function() {
                    // 首贷回退到出额，再贷回退到账户
                    if (migrateData && migrateData.fromPage) {
                        if (migrateData.fromPage == 'old_home') {
                            C.Native.back({
                                url: 'old_home.html'
                            });
                        } else {
                            C.Native.backModule({
                                moduleName: 'iloan',
                                url: 'shaw_account.html'
                            });
                        }
                    } else {
                        if ($this.isFirstPay == 'Y') {
                            C.Native.back({
                                url: 'loan_select.html'
                            });
                        } else {
                            C.Native.loadPage({
                                url: 'account_iloan.html'
                            });
                        }
                    }

                }
            });
            C.Native.getAppVersion(function(res){
                $this.appVersion = parseInt(res.version);
            });

            //身份信息无效时，需要跳转到账户制的补录信息页
            if(idvalidData && idvalidData.idvalid == 'N') {
                var jsonData = {}, //用于以后native扩展字段，此版本先传空
                    params = {}, //用于更新本地存储的身份证有效期有效性字段
                    iloanVersion = C.Utils.data(C.Constant.DataKey.SDK_VERSION);
                if (App.IS_SDK && !iloanVersion) {
                    $this.getRequestParams();
                    return;
                }
                C.Native.paPresent(C.Constant.DataUrl.TRANSPAGE.IDCARDVALID, jsonData, function(res){
                    console.log(res);
                    if(res.code == '1'){//完成信息补录
                        params.idvalid = 'Y';
                        params.isFirstPay = $this.isFirstPay;
                        C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, params);//完成信息补录后，将身份有效期有效性置为有效
                        // 获取接口入参
                        $this.getRequestParams();
                    }else if(res.code == '2'){//当未完成信息补录，点左上角返回到该页面时
                        // 迁徙失败跳转至原渠道账户页
                        if (migrateData && migrateData.fromPage && migrateData.fromPage === 'old_home') {
                            // SDK1.0账户页
                            C.Native.back({
                                url: 'old_home.html'
                            });
                            return;
                        }
                        if (migrateData && migrateData.fromPage && migrateData.fromPage === 'shaw_account') {
                            // APP1.0账户页
                            C.Native.backModule({
                                moduleName: 'iloan',
                                url: 'shaw_account.html'
                            });
                            return;
                        }
                        if($this.isFirstPay == 'Y'){
                            C.Native.back({
                                url: C.Constant.DataUrl.TRANSPAGE.LOANSELECT
                            });
                        }else{
                            C.Native.back({
                                url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
                            });
                        }
                    }
                });
                return;
            }
            //获取接口入参
            $this.getRequestParams();
        },
        // 初始页面渲染
        render: function(data) {
            var self=this;
            if (data.resultCode == '1') {
                var modifyData = data.infoMap;
                this.isFirstPay = modifyData.isFirstPay = data.isFirstPay;
                this.fundingModel = modifyData.fundingModel;      //资金模式
                this.isLoan = modifyData.isLoan;                  //是否还能继续借款
                this.frequencyLimit = modifyData.frequencyLimit;  //限制贷款配置笔数
                //小贷公司及编码
                modifyData.loanCompanyCode = data.loanCompanyCode;
                modifyData.loanCompanyName = data.loanCompanyName;

                if (modifyData.maxLoanAmt - modifyData.minLoanAmt < 0) {
                    // 显示额度不足的提示框
                    $('#js-block-limit').show();
                } else {
                    modifyData.fundingModel = modifyData.fundingModel || '';//当没有返回fundingModel时，默认值为空
                    modifyData.cgiBankName = modifyData.cgiBankName || '';
                    // 首贷时默认还款日计算
                    modifyData.rpyDay = modifyData.rpyDay || this.repayDay();
                    modifyData.maxLoanAmt = parseInt(Number(modifyData.maxLoanAmt)/(modifyData.loanLimit))*(modifyData.loanLimit); // 最高借款金额

                    // 页面渲染
                    $('#js-wrap-loan').html(_.template($('#js-html-loan').html(), modifyData));
                    modifyData.purpose = self.purpose;
                    // 数据本地存储供后续页面使用
                    self.modifyData = modifyData;
                    C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO, modifyData);
                    // 全局变量供页面内其他方法调用
                    this.minLoanAmt = modifyData.minLoanAmt; // 最低借款金额
                    this.maxLoanAmt = modifyData.maxLoanAmt; // 最高借款金额
                    this.loanLimit = modifyData.loanLimit; // 借款递增单位
                    this.rpyDay = modifyData.rpyDay; // 还款日期
                   // data.formatMaxLoanAmt = C.Utils.formatMoney(parseInt(Number(modifyData.maxLoanAmt)/Number(modifyData.loanLimit))*Number(modifyData.loanLimit));
                    data.formatMaxLoanAmt = parseInt(Number(modifyData.maxLoanAmt)/Number(modifyData.loanLimit))*Number(modifyData.loanLimit);
                    $('#js-input-amount').val(data.formatMaxLoanAmt);
                    $('#js-frequencyLimit').text(this.frequencyLimit);
                    self.calculateRepayment();
                }
                // 埋点
                C.Native.TDOnEvent(this.talkingDate('申请提现'));
            } else {
                C.Native.tip(data.resultMsg);
            }

        },
        // Ajax请求函数
        dataRequest: function(json) {
            this.isLoading = true;
            C.UI.loading();
            var self = this;
            $.ajax({
                url: json.url,
                type: json.type,
                data: {
                    jsonPara: JSON.stringify(json.data)
                },
                success: function(res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        json.callback.call(self, res.data);
                    }
                },
                complete: function() {
                    self.isLoading = false;
                    C.UI.stopLoading();
                }
            });
        },

        // 获取接口请求的入参
        getRequestParams: function() {
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
            this.applyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).applyNo;
            this.loanCode = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).loanCode || C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).ICreditInfo.loanCode;
            this.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
            this.channelType = sourceInfo ? sourceInfo.sourceType : '';
            // 执行Ajax请求并渲染页面
            var data = {
                applyNo: this.applyNo,
                loanCode: this.loanCode,
                payApplyNo: this.payApplyNo,
                channelType: this.channelType
            };
            //新增迁徙入参
            if (this.isMigrate) {
                data.isMigrate = this.isMigrate;
            }
            this.dataRequest({
                url: C.Api('LOAN_INFO_QUERY'),
                callback: this.render,
                type: 'POST',
                data: data
            });
        },

        chooseUse: function(e) {
            var $target = $(e.currentTarget),
                val = $target.val();

            this.modifyData.purpose = val;
            C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO, this.modifyData);    
        },

        // 输入框获取焦点时，显示贷款金额数字
        showAmountInput: function(e) {
            var val = this.loanAmt || '';
            setTimeout(function(){
                $(e.currentTarget).prop('placeholder', '').val(val);
            }, 100);
            this.hideRepayment();
        },

        // 计算默认还款日
        repayDay: function() {
            var today = new Date().getDate();
            if (today > 1 && today < 30) {
                // 当天日期减一
                return today - 1;
            }
            // 30,31,1日减一有可能出现不存在的日期,统一为28日
            return 28;
        },

        /*计算还款计划*/
        showRepayment: function(data) {
            if (data.resultCode == '1') {
                if ($('#js-input-amount').is(':focus')) return;
                var modifyData = data;
                this.term = data.term;
                // 计算还款计划列表中还款金额的宽度百分比,最大100%,最小50%
                this.addListWidth(modifyData.planList, 100, 50);
                //渲染页面
                $('#js-wrap-repay').html(_.template($('#js-html-repay').html(), modifyData));
                $('#js-btn-next').show();
                if(this.fundingModel.toUpperCase() == 'U' || this.fundingModel.toUpperCase() == 'D'){
                    $('.prompt').show(); 
                }
                $('#js-text-charge').text(C.Utils.formatMoney(modifyData.counterFee) + '元');
                // 还款计划数据存储到本地
                C.Utils.data(C.Constant.DataKey.LOAN_REPAY_PLAN, modifyData);
            } else {
                C.Native.tip(data.resultMsg);
            }
        },
        addListWidth: function(lists, max, min) {
            var maxAmt = _.max(lists, function(list) {
                    return parseFloat(list.rpyAmt);
                }).rpyAmt,
                minAmt = _.min(lists, function(list) {
                    return parseFloat(list.rpyAmt);
                }).rpyAmt;
            _.map(lists, function(element) {
                if (maxAmt - minAmt > 0) {
                    element.percent = (min + (element.rpyAmt - minAmt) * (max - min) / (maxAmt - minAmt)).toFixed(2);
                } else {
                    element.percent = max;
                }
            });
        },
        // 输入金额错误提示
        amountTip: function(text) {
            var self = this;
            $('#js-text-tip').html(text);
            $('#js-block-tip').show();
            this.tipTimeout = window.setTimeout(function() {
                $('#js-text-tip').html('');
                $('#js-block-tip').hide();
                window.clearTimeout(self.tipTimeout);
            }, 2000);
        },
        // 验证金额范围
        amountRange: function(val) {
            if (val && C.Utils.RegexMap.moneyTest.test(val)) {
                var min = parseInt(this.minLoanAmt),
                    step = parseInt(this.loanLimit),
                    max = parseInt(this.maxLoanAmt / step) * step,
                    amount = parseFloat(val);
                if (amount > max) {
                    this.amountTip('输入金额不能超过最高可申请金额，请重新输入');
                    return max;
                } else if (amount < min) {
                    this.amountTip('不能低于最低金额' + min + '元，请重新输入');
                    return min;
                } else if (amount % step) {
                    this.amountTip('请输入' + step + '的整数倍');
                    return parseInt(val / step) * step;
                }
                return amount;
            }
            this.amountTip('请输入金额并符合正确格式');
            return '';
        },
        // 显示格式化后的贷款金额
        showAmountText: function(value, element) {
            var amount = C.Utils.formatMoney(value);
            element.prop('placeholder', '0.00').val(amount);
        },
        // 输入框失去焦点时，进行还款试算
        calculateRepayment: function(e) {
            var amt = $('#js-input-amount').val(),
                amount = this.loanAmt = this.amountRange(amt);
            if (amount != '') {
                // 借款金额本地存储
                C.Utils.data(C.Constant.DataKey.LOAN_APPLY_AMOUNT, {
                    loanAmt: String(amount)
                });
                var data = {
                    loanCode: this.loanCode,
                    payApplyNo: this.payApplyNo,
                    loanAmt: String(amount),
                    rpyDay: String(this.rpyDay),
                    channelType: this.channelType
                };
                //新增迁徙入参
                if (this.isMigrate) {
                    data.isMigrate = this.isMigrate;
                }
                this.dataRequest({
                    url: C.Api('REPAYMENT_CALCULATE'),
                    callback: this.showRepayment,
                    type: 'POST',
                    data: data
                });
            }
            // 显示格式化后的提现金额
            this.showAmountText(amount, $('#js-input-amount'));
        },

        // 在输入框获取焦点时，重置还款信息
        hideRepayment: function() {
            $('#js-wrap-repay').html('');
            $('#js-btn-next').hide();
            $('.prompt').hide();
            $('#js-text-charge').text('0.00元');
        },

        // 跳转到还款计划页面
        goRepayment: function(e) {
            // 埋点
            C.Native.TDOnEvent(this.talkingDate('还款计划'));
            // 埋点 申请提现试算页 还款计划
            C.Native.TDOnEvent(this.talkingDate('还款计划2.0'));
            // 跳转到还款试算页面
            C.Native.forward({
                url: 'loan_repay_plan.html'
            });
        },

        // 点击下一步
        goLoanInfo: function(e) {
            var self =this;
            if ($('#select-yt').val() === '') {
                C.Native.tip('请选择借款用途!');
                return;
            }
            // 清除本地缓存的投保单号
            C.Utils.data(C.Constant.DataKey.BT_INSURANCE_NO, null);
            if (self.isMigrate && self.isMigrate == 'Y') {
                //埋点 无欠款迁徙试算页 下一步
                C.Native.TDOnEvent({
                    eventId: '$_03_1_0_58_01_无欠款迁徙试算页'
                });
            } else {
                // 埋点
                C.Native.TDOnEvent(this.talkingDate('下一步'));
                // 埋点 申请提现试算页 下一步
                C.Native.TDOnEvent(this.talkingDate('下一步2.0'));
            }
            if(self.isLoan == 'N'){
                $('#js-frequency-limit').removeClass('dn');                //限制的笔数
            }else{
                if(self.fundingModel == 'U' || self.fundingModel == 'D'){  //资金模式是联合放款
                    if(self.appVersion >= 50400 || App.IS_SDK){
                        //走产险子系统
                        self.getH5Link();
                    }else{
                        //走旧流程
                        if(self.isFirstPay=='N'){
                            C.Native.forward({
                                url: 'icard_policy.html', //再次，直接到投保单
                                //提供给投保当页面的参数
                                data: {
                                    from: 'loan_apply.html',
                                    to: 'loan_info.html'
                                }
                            });
                        }else{
                            $('#js-insurance-tip').removeClass('dn');  //第一次要投保提示
                        }
                    }
                }else{     //担保+小贷L模式
                    C.Native.loadPage({
                        url: 'loan_info.html'
                    });
                }
            }
        },
        getH5Link: function(){
            if (this.isLoading) return;
            //清除核保标示
            C.Utils.data('isPoly', null);
            var self = this,
                postData = {//账户id在init.js中已统一传入，不需要重复传入
                    success_link: C.Constant.DataUrl.TRANSPAGE.LOANINFO,  //页面成功链接函数
                    fail_link: C.Constant.DataUrl.TRANSPAGE.LOANFAIL,  //页面失败链接函数
                    h5_link_addr_expire_date: '1',  //H5链接的有效天数
                    is_rebuild: 'Y',  //是否重新生成链接
                    ln_amt: String(self.loanAmt),  //借款金额
                    ln_term: String(this.term),  //借款期限
                    appl_no: self.payApplyNo,  //申请号的值改为支用申请号
                    funding_model: self.fundingModel,
                    is_send_insured_SMS: 'N',  //是否发送投保短信
                    use_type: (self.isMigrate && self.isMigrate == 'Y') ? 'Y' : self.isFirstPay
                };
            self.dataRequest({
                url: C.Api('GET_INSURANCE_H5_lIANK'),
                type: 'post',
                data: postData,
                callback: function(data){
                    console.log(data);
                    var piUrl = data.h5_link_addr,
                        tipMsg = '您正在进入保险公司网页，保险相关服务由保险公司提供。',
                        backMsg = '投保完成，正返回平安普惠继续申请流程。',
                        needForward = 1; //是否由native来使用forward跳转：是传1，否传0
                    C.Native.processPIBussnise(piUrl, tipMsg, backMsg, needForward, function(res){
                        if(res.code == '1'){
                            //埋点 提现投保页 成功
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_4_33_01_提现投保页'
                            });
                            C.Utils.data(C.Constant.DataKey.BT_INSURANCE_NO, data.cover_no);
                        }else if(res.code == '0'){
                            //埋点 提现投保页 失败
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_4_33_02_提现投保页'
                            });
                        }

                    });
                }
            });
        },
        //同意去投保
        toInsurance: function(){
            // 埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0213-投保单',
                eventLable: 'iBT-021301-投保单确定'
            });
            C.Native.forward({
                url: 'icard_policy.html', //去到投保单
                //提供给投保当页面的参数
                data: {
                    from: 'loan_apply.html',
                    to: 'loan_info.html'
                }
            });
            $('#js-insurance-tip').addClass('dn');
        },
        //取消
        toCancle: function(){
            $('#js-insurance-tip').addClass('dn');
        },
        //稍后申请
        lateApply: function(){
            //埋点 未结清提示弹窗页 稍后申请
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_32_01_未结清提示弹窗页'
            });
            $('#js-frequency-limit').addClass('dn');
        },
        // 去还款 7.3还款页面k
        toHuankuan: function(){
            //埋点 未结清提示弹窗页 去还款
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_32_02_未结清提示弹窗页'
            });
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENT
            });
        },
        // 额度不足时返回
        goBack: function(e) {
            // 跳转到账户页
            C.Native.back();
        },
        knowDetail: function(){
            //埋点 申请提现试算页 产险投保了解详情
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_31_03_申请提现试算页'
            });
            $('#js-insurance-prompt').removeClass('dn');
        },
        closePrompt: function(){
            //埋点  投保须知弹窗页  关闭弹窗
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_24_02_投保须知弹窗页'
            });
            $('#js-insurance-prompt').addClass('dn');
        }

    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});