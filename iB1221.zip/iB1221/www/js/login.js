/*!
 * login登录页
 * 处理登录及登录跳转逻辑
 * @author 周一平 
 * @history 2015-6-23 add
 */
define(['zepto', 'C', 'libs/jsencrypt'], function ($, C, JSEncrypt) {
    'use strict';
    function accountLogin(callback) {
        var RSAENCRYPT = new JSEncrypt();
        RSAENCRYPT.setPublicKey('-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDwHQU77tsMBNbKnzVd+OZeINs7\nrPgGdV8owrau1Ox9a5axrJ2nak3dDQiD9Zt/UfkckZhqFYhDmzxYOgkYDmoP4fTM\neqIwY4e0m4+WDTF6Ef74tEW2SeNwUVqBtcKD+DGEx9QTaWjOLu+wIw4f4gRuuro2\n7oSctyNJfiJ625C32QIDAQAB\n-----END PUBLIC KEY-----');
        C.rsaEncrypt = function (text) {
            return RSAENCRYPT.encrypt(text);
        };
        var paramData = {
            'platform': 'android',
            '_UMLOGINVER': '2.0',
            'os': 'A',
            '_RSAVER': '2.1.0',
            'mobileOsVer': 'android4.4.4',
            'mobile': C.rsaEncrypt($('#mobile').val()), //加密
            'key': C.rsaEncrypt($('#password').val()), //加密
            'machineSN': '3704bbcddf4124e2f698b7485e414c87f',
            'isEmulator': 'N',
            'isYiQianBaoLogin': 'N',
            'curVer': /*C.rsaEncrypt("4.8.20")*/'4.8.20',
            'mobileBrand': '',
            'lng': '114.5',
            'lat': '145.6',
            'city': '深圳',
            'address': '八卦三路',
            'sessionId': 'ap7d2je631izzkqa7swwxg6ho1niusnt',
            'is_valid_devic': '1',
            'deviceMessage': '{"gmtTime":"2016-04-11 10:09:41","osVer":"4.4.2","wifiMac":"C4072F247398","deviceSize":"1776*1080","imei":"865473027203309","isRoot":"Y","deviceModel":"H60-L03","deviceBand":"Huawei","localMac":"c4072f247398","cardType":"B","deviceIp":"81.145.180.10","baseSiteInfo":"","deviceRand":"3535eec0bba4766b4f916a4651cb86ee0","gps":"114.1018,22.5671","imsi":"","deviceLan":"zh"}',
            'channelId': 'ydwz',
            'timestamp': '1460340581217',
            'mac': 'c4072f247398',
            'sim_mobile': '',
            'sdkReturnStr': 'eyJjZWxsTG9jYXRpb24iOiJbOTc4Niw0NTc0MDAzNSwtMV0iLCJjcHVTcGVlZCI6IjM4LjQwIiwibW9kZWwiOiJNSSA0TFRFIiwiaGFyZHdhcmUiOiJxY29tIiwiZ2F0ZXdheSI6LTkzMDA0MDgyMiwidG90YWxTdG9yYWdlIjoiMi4yNSBHQiIsInBob25lVHlwZSI6MSwibXVzaWNIYXNoIjoiZWM0NzU4ZmUxZDJmNzIxMGI3MmQ1NzI0NDAzMTRjIiwic2NyZWVuUmVzIjoiMTA4MHgxOTIwIiwic2RrVmVyc2lvbiI6MTksImJvb3RUaW1lIjoxNDM3NDY1NDkzLCJzZW5zb3JMaXN0IjoiMSwgMiwgMTQsIDQsIDE2LCA4LCA1LCA2LCA3LCA5LCAxMCwgMTEsIDE4LCAxOSwgMTcsIDE1LCAyMCwgMywgMzMxNzEwMDYsIDMzMTcxMDA3LCAzMzE3MTAwMCwgMzMxNzEwMDIsIDMzMTcxMDAzLCAzMzE3MTAwOSwgMzMxNzEwMTAsIDMzMTcxMDExLCAxMyIsImJsdWVNYWMiOiIiLCJzaW1PcGVyYXRvciI6IkNNQ0MiLCJkZXZpY2VOYW1lIjoiY2FuY3JvIiwicGhvbmVOdW1iZXIiOiIiLCJpc0ZpbGVFeGlzdCI6IiIsImluaXRUaW1lIjoxNzYsIndpZmlJcCI6IjEwLjAuMi4xNSwxMC4xODAuMTUyLjQ2IiwiYmF0dGVyeUxldmVsIjozOSwiVk1BcHBzTGlzdCI6IiIsImNhcnJpZXIiOiJDTUNDIiwiY291bnRyeUlzbyI6ImNuIiwiZGV2aWNlQ29uZmlnIjoiQ29uZmlndXJhdGlvbkluZm97NDJkZGRkZTggdG91Y2hzY3JlZW4gPSAzIGlucHV0TWV0aG9kID0gMSBuYXZpZ2F0aW9uID0gMSByZXFJbnB1dEZlYXR1cmVzID0gMCByZXFHbEVzVmVyc2lvbiA9IDE5NjYwOH0iLCJzaW1TZXJpYWwiOiI4OTg2MDA4MDE5MTQwNzA5MTU4NCIsImZpcm1WZXJzaW9uIjoiMDAiLCJkZXZpY2VJZCI6ImZlYzQ2MjQzOWViOGFmZmJlYjM4MjMxMjI2YjkyYmIxIiwidGFncyI6InJlbGVhc2Uta2V5cyIsImNlbGxNYWMiOiIiLCJvcyI6IkFuZHJvaWQiLCJob3N0IjoicWgtbWl1aS1vdGEtYmQ1NyIsImNlbGxJcCI6IiIsIndpZmlNYWMiOiI3YzoxZDpkOTo3MDoxZjo4MCIsImZtVmVyc2lvbiI6InYxLjEuMCIsImltZWkiOiI4NjUzNzIwMjU2NDc5NTYiLCJiYXR0ZXJ5U3RhdHVzIjoiY2hhcmdpbmciLCJjcHVIYXJkd2FyZSI6IlF1YWxjb21tIE1TTTg5NzRQUk8tQUMiLCJkaXNwbGF5IjoiS1RVODRQIiwidWRpZCI6IjZkOWEzOWRmYjE4N2YyODgiLCJyb19uYW1lIjoiY2FuY3JvIiwicHJvZHVjdCI6ImNhbmNyb193Y19sdGUiLCJ1cFRpbWUiOjc4NDA4LCJyb19tb2RlbCI6Ik1JIDNXIiwiaXNCYXR0ZXJ5VXNhZ2UiOmZhbHNlLCJicmFuZCI6IlhpYW9taSIsInN1YnNjcmliZXJJRCI6IjQ2MDAwMjYwNjYzMjQ2NSIsImNwdVNlcmlhbCI6IjAwMDAwMDAwMDAwMDAwMDAiLCJjcHVUeXBlIjoiMyJ9'
        };
        console.log(JSON.stringify(paramData));
        $.ajax({
            url: C.Api('PLUGIN_LOGIN'),
            type: 'post',
            data: paramData,
            success: function (res) {
                if (res && res.flag == '1') {
                    console.log(res);
                    $('#showinfo').html(JSON.stringify(res.data));
                    C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, res.data);
                    callback(res);
                } else {
                    C.UI.error({content: res.msg});
                }
            }
        });
    }

    $(function () {
        C.UI.loading();
        var redirectURL = decodeURIComponent(C.Utils.getParameter('redirectURL') || 'index_e.html');
        var flag = C.Utils.getParameter('flag');
        $('#login').on('click', function () {
            var mobile = $('#mobile').val();
            var password = $('#password').val();
            if (mobile && password) {
                accountLogin(function (data) {
                    if (flag != 'false') {
                        location.href = redirectURL;
                        console.log(data);
                    }
                });
            }
        });

        $('#main').show();
    });
});