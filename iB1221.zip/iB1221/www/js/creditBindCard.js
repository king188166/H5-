/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-绑卡
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #support_list_view': 'viewSupportCards',
            'tap #close_support_list': 'hideSupportCards',
            'tap #btn_card': 'getToken',
            'input #card_input': 'checkBankNum',
            'tap #toKJ': 'linkToAuthoritzion',
            'tap #toYQB': 'linkToAuthoritzion'
        },
        initialize: function () {
            var _this = this;
            C.Native.getAppVersion(function (res) {
                _this.iloanVersion = res.iloanVersion;
                //通过iloanVersion判断是否有getChannelInfo的方法
                if(_this.iloanVersion){
                    C.Native.getChannelInfo(function (res) {
                        _this.cardNo = C.Utils.formatCardNo(res.bankCardNo);
                        //显示默认银行卡
                        if(_this.cardNo){
                            $('#card_input').val(_this.cardNo);
                        }
                    });
                }

            });
            C.Native.setHeader({
                title: '添加银行卡',
                leftCallback: function () {
                    var Page = C.Utils.getParameter('Page');
                    if (Page) {
                        C.Native.back({
                            url: Page
                        });
                        return;
                    }
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
            // 从url中获取前一页面的传参,写入本地缓存
            C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM, {
                route: C.Utils.getParameter('route'),
                url: C.Utils.getParameter('url'),
                moduleName: C.Utils.getParameter('moduleName'),
                failRoute: C.Utils.getParameter('failRoute'),
                failUrl: C.Utils.getParameter('failUrl'),
                failModuleName: C.Utils.getParameter('failModuleName')
            });
            _this.from = C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM);
            if(_this.from.url == 'icard_loading.html'){
                //埋点 重查征信新绑卡页
                C.Native.TDOnEvent({
                    eventId: '$_03_0_4_19_重查征信新绑卡页'
                });
            }else{
                //埋点 添加银行卡页
                C.Native.TDOnEvent({
                    eventId: '$_03_0_2_06_添加银行卡页'
                });
            }
        },
        /**
         * 数字键盘,四位空格
         * */
        checkBankNum: function (e) {
            var $target = $('#card_input');
            //兼容android4.2的input中光标不在最后面问题
            var val = $target.val().replace(/[^0-9]/g, '').replace(C.Utils.RegexMap.bankCardNo, '$1 ');
            $target.val('');
            $target.val(val);
            setTimeout(function () {
                if ($target[0].setSelectionRange) {
                    $target[0].setSelectionRange(val.length, val.length);
                    $target.focus();
                }
            }, 10);
        },

        /**
         * 查看支持银行列表
         * */
        viewSupportCards: function () {
            
            if (C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM).url == 'icard_loading.html') {
                C.Native.TDOnEvent({
                    eventId: 'iBT-03010202-添加银行卡',
                    eventLable: 'iBT-0301020201-查看支持银行'
                });
                //埋点 重查征信新绑卡页 查看支持银行 (还卡)
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_19_01_重查征信新绑卡页'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-020201-添加银行卡',
                    eventLable: 'iBT-02020101-查看支持银行'
                });
                //埋点 添加银行卡页 查看支持银行
                C.Native.TDOnEvent({
                    eventId: '$_03_1_2_06_01_添加银行卡页'
                });
            }

            //输入框失去焦点
            $('#card_input').blur();
            /*
             *监控输入框失去焦点后，恢复键盘对样式的修改
             */
            $(window).resize(function () {
                var height = document.body.scrollHeight;
                console.log(height);
                $('.content').css('height', height + 'px;').css('position', 'relative');
            });
            if ($('#card_support_ul').find('li').length > 0) {
                $('#support_cards_list').show();
                return;
            }
            C.UI.loading();
            C.Native.getDeviceInfo(function (data) {
                var param = {
                    curVer: data.appVersion,
                    machineSN: data.MachineSN || data.machinesn,
                    loanType: C.Constant.PRODUCTION.CODE
                };
                $.ajax({
                    url: C.Api('QUERYBANKCARDLIST'),
                    type: 'post',
                    data: param,
                    success: function (res) {
                        if (res.flag == C.Flag.SUCCESS && res.data) {
                            var bankList = res.data.bankList, lihtml = '';
                            for (var i = 0; i < bankList.length; i++) {
                                var code = bankList[i].bankShortName.toLocaleLowerCase();
                                var classname = 'bank-' + code;
                                lihtml += '<li><span class="icon icon-fix ' + classname + '"></span>' + bankList[i].bankName + '</li>';
                            }
                            $('#card_support_ul').html(lihtml);
                            $('#support_cards_list').show();
                        }
                    },
                    complete: function () {
                        C.UI.stopLoading();
                    }
                });
            });
        },

        /**
         * 隐藏支持银行列表
         * */
        hideSupportCards: function () {
            $('#support_cards_list').hide();
        },

        /**
         * 显示协议
         * */
        linkToAuthoritzion: function (e) {
            var $target = $(e.currentTarget);
            var showid = $target.attr('id');
            if (showid == 'toKJ') {
                
                if (C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM).url == 'icard_loading.html') {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03010202-添加银行卡',
                        eventLable: 'iBT-0301020202-快捷支付协议'
                    });
                    //埋点 重查征信新绑卡页 快捷支付协议
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_19_02_重查征信新绑卡页'
                    });
                } else {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-020201-添加银行卡',
                        eventLable: 'iBT-02020102-快捷支付协议'
                    });
                    //埋点 快捷支付协议
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_06_02_添加银行卡页'
                    });
                }

                C.Native.forward({
                    url: '_authorizion_kj.html'
                });
            } else if (showid == 'toYQB') {
                
                if (C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM).url == 'icard_loading.html') {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03010202-添加银行卡',
                        eventLable: 'iBT-0301020203-壹钱包余额服务协议'
                    });
                    //埋点 重查征信新绑卡页 壹钱包余额服务协议
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_19_03_重查征信新绑卡页'
                    });
                } else {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-020201-添加银行卡',
                        eventLable: 'iBT-02020103-壹钱包余额服务协议'
                    });
                    //埋点 壹钱包余额服务协议
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_06_03_添加银行卡页'
                    });
                }
                C.Native.forward({
                    url: '_authorizion_ys.html'
                });
            }
        },

        /**
         * 获取绑卡token
         * */
        getToken: function () {
            var _this = this,
                userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            var cardNoN = $.trim($('#card_input').val());
            var cardNo = cardNoN.replace(/\s+/g, '');

            if (C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM).url == 'icard_loading.html') {
                C.Native.TDOnEvent({
                    eventId: 'iBT-03010202-添加银行卡',
                    eventLable: 'iBT-0301020204-下一步'
                });
                 //埋点 重查征信新绑卡页 下一步
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_19_04_重查征信新绑卡页'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-020201-添加银行卡',
                    eventLable: 'iBT-02020104-下一步'
                });
                 //埋点 添加银行卡页 下一步
                C.Native.TDOnEvent({
                    eventId: '$_03_1_2_06_04_添加银行卡页'
                });
            }
            
            C.Native.getDeviceInfo(function (data) {
                if (data.code == '1') {
                    _this.deviceInfo = data.result;
                    //卡号校验
                    if (cardNo) {
                        if (cardNo.length > 19) {
                            C.Native.tip('请输入正确的银行卡号');
                            return false;
                        }
                        C.UI.loading();
                        _this.cardNo = cardNo;
                        var param = {
                            name: userdata.custName,
                            certId: userdata.Id,
                            mobileNo: userdata.mobile,
                            cardNo: cardNo
                        };

                        C.Native.rSAEncode(param, function (res) {
                            if (res.code == '1') {
                                param = {
                                    curVer: _this.deviceInfo.appVersion, //app
                                    endDecVer: _this.deviceInfo.appVersion, //sdk
                                    token: userdata.token,
                                    machineSN: _this.deviceInfo.MachineSN || _this.deviceInfo.machinesn,
                                    pafToken: userdata.paPayToken,
                                    loanType: C.Constant.PRODUCTION.CODE,

                                    //加密信息
                                    cardNo: res.result.cardNo,
                                    name: res.result.name,
                                    certId: res.result.certId,
                                    mobileNo: res.result.mobileNo
                                };
                                $.ajax({
                                    url: C.Api('QUERYCARDINFO'),
                                    type: 'post',
                                    data: param,
                                    success: function (res) {
                                        if (res.flag == C.Flag.SUCCESS && res.data) {
                                            console.log(res.data);
                                            res.data.cardNo = _this.cardNo;
                                            C.Utils.data(C.Constant.DataKey.CARD_DATA, res.data);
                                            _this.toBindCard(res.data);
                                        }
                                        C.UI.stopLoading();
                                    },
                                    complete: function (res) {
                                        C.UI.stopLoading();
                                    }
                                });
                            } else {
                                C.Native.tip('安全数据加密失败');
                            }
                        });
                    } else {
                        C.Native.tip('请输入银行卡号');
                    }
                }
            });
        },

        /**
         * 绑卡
         * */
        toBindCard: function (data) {
            C.Native.setHeader({
                title: '添加银行卡',
                isBack: false
            });
            var ChangeUrl = C.Constant.Change_Url;
            var returnhref = ChangeUrl + '?forwardUrl=credit_bindcard_suc.html' + location.search,
                cancelhref = ChangeUrl + '?forwardUrl=credit_bind_card.html' + location.search;

            var paramData = {
                merchantNo: data.merchantNo,
                version: '1.0',
                returnUrl: returnhref,
                cancelUrl: cancelhref,
                requestMsg: data.requestMsg,
                requestNo: data.requestNo
            };
            var _form = document.getElementsByTagName('form');
            _form[0].setAttribute('method', 'post');
            _form[0].setAttribute('action', C.Constant.PAPAY_BIND_CARD);
            document.getElementsByName('merchantNo')[0].setAttribute('value', paramData.merchantNo);
            document.getElementsByName('version')[0].setAttribute('value', paramData.version);
            document.getElementsByName('returnUrl')[0].setAttribute('value', paramData.returnUrl);
            document.getElementsByName('cancelUrl')[0].setAttribute('value', paramData.cancelUrl);
            document.getElementsByName('requestMsg')[0].setAttribute('value', paramData.requestMsg);
            document.getElementsByName('requestNo')[0].setAttribute('value', paramData.requestNo);

            //mock环境不跳转平安付绑卡
            if (C.Env === 'STG20') {
                _form[0].setAttribute('action', 'yqb-addCard.html?cardNo=' + $('#card_input').val().replace(/\s/g, ''));
            }
            _form[0].submit();
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});