/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-11-05
 * @time  : 下午16:10
 *
 * @describe: iLoan定期-手机运营商验证
 */
/*global define:false*/
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        initialize: function () {
            var _this = this;
            //埋点 手机运营商页
            C.Native.TDOnEvent({
                eventId: '$_03_0_2_10_手机运营商页'
            });
            C.Native.setHeader({
                title: '手机运营商'
            });
            _this.init();
        },
        init: function () {
            var _this = this, code = C.Utils.getParameter('code');
            if (code) {
                //手机运营商验证回来
                console.log(code);
                var data = {
                    code: code,
                    type: C.Utils.getParameter('type'),
                    account: C.Utils.getParameter('account'),
                    teleType: C.Utils.getParameter('teletype')
                };
                _this.submitData(data);
            } else {
                //还未做手机运营商验证
                _this.phoneOauth();
            }

        },

        /**
         * 手机运营商认证
         * */
        phoneOauth: function () {
            var userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO),
                xiaoAnUrl = C.Constant.phoneOauth_Url, phoneOauth = 'phoneAppoauth_phonelogin.html';
            var url = xiaoAnUrl + phoneOauth;
            var phoneNum = '', uid = '';
            var loadPageFn = function () {
                var redirectUrl = C.Constant.Change_Url + '?forwardUrl=authentication.html';
                var loadurl = url + '?partner_id=' + C.Constant.partnerId
                    + '&uid=' + uid
                    + '&phoneNum=' + phoneNum
                    + '&redirect_uri=' + redirectUrl;
                if (C.Env != 'PRODUCTION') {
                    loadurl = loadurl + '&debug=true';
                }
                location.assign(loadurl);
            };
            if (userdata) {
                phoneNum = userdata.mobile;
                uid = userdata.accountId;
                loadPageFn();
            } else {
                C.Native.getUserInfo(function (data) {
                    if (data && data.mobile) {
                        C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                        phoneNum = userdata.mobile;
                        uid = userdata.accountId;
                        loadPageFn();
                    } else {
                        //本地没有用户信息情况，重新登录
                        C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, null);
                        C.Native.dealTimeOut('请重新登录');
                    }
                });
            }
        },

        /**
         * 提交手机运营商信息
         * */
        submitData: function (data) {
            var userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            var param = {
                phoneNumber: userdata.mobile,
                account: data.account
            };
            C.Native.rSAEncode(param, function (res) {
                if (res.code == '1') {
                    param = {
                        applyNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO),
                        code: data.code,
                        type: data.type,
                        teleType: data.teleType,
                        phoneNumber: res.result.phoneNumber,
                        account: res.result.account
                    };
                    $.ajax({
                        url: C.Api('PHONEOPERATOR'),
                        type: 'post',
                        data: {
                            jsonPara: JSON.stringify(param)
                        },
                        success: function (res) {
                            if (res.flag == '1' && res.data) {
                                //手机运营商认证成功
                                if (res.data.resultCode == '1') {
                                    // empty
                                } else {
                                    C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
                                }
                                C.Native.back({
                                    url: 'credit_info_list.html'
                                });
                            }
                        },
                        complete: function () {
                            C.UI.stopLoading();
                        }
                    });
                } else {
                    C.Native.tip('安全数据加密失败');
                }
            });
        }

    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});