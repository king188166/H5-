/**
 * @author: yerencheng501@pingan.com.cn
 * @date  : 2016-3-16
 * @describe: 确认提现信息
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        events: {
            'tap #js-arrow-card': 'goSelectCard',
            'tap #js-arrow-rate': 'toggleRateDetail',
            'tap #js-link-contract': 'goLoanContract', //借款协议
            'tap #js-transfer-contract': 'goTransferContract', //资料代传合同
            'tap #js-check-contract': 'isAgreeContract',
            'tap #js-btn-submit': 'loanConfirm',
            'tap #js-btn-reApply': 'goBack'
        },
        talkingDate: function(key) {
            var first = {
                '提现信息': {
                    eventId: 'iBT-040101-下一步',
                    eventLable: 'iBT-04010101-确认提现信息'
                },
                '借款协议': {
                    eventId: 'iBT-04010101-确认提现信息',
                    eventLable: 'iBT-0401010101-借款及担保协议'
                },
                '确认提现': {
                    eventId: 'iBT-04010101-确认提现信息',
                    eventLable: 'iBT-0401010102-同意确认提现'
                },
                '还款警示': {
                    eventId: 'iBT-0401010102-同意确认提现',
                    eventLable: 'iBT-040101010201-还款警示'
                },
                '借款失败': {
                    eventId: 'iBT-0401010102-同意确认提现',
                    eventLable: 'iBT-040101010202-借款失败'
                },
                '确认提现页': {
                    eventId: '$_03_0_4_35_确认提现页'
                },
                '确认提现2.0': {
                    eventId: '$_03_1_4_35_06_确认提现页'
                },
                '事件结果成功': {
                    eventId: '$_03_2_4_35_01_确认提现页'
                },
                '事件结果失败': {
                    eventId: '$_03_2_4_35_02_确认提现页'
                }
            };
            var noFirst = {
                '提现信息': {
                    eventId: 'iBT-06040101-下一步',
                    eventLable: 'iBT-0604010101-确认提现信息'
                },
                '借款协议': {
                    eventId: 'iBT-04010101-确认提现信息',
                    eventLable: 'iBT-0401010101-借款及担保协议'
                },
                '确认提现': {
                    eventId: 'iBT-0604010101-确认提现信息',
                    eventLable: 'iBT-060401010101-确认提现'
                },
                '还款警示': {
                    eventId: 'iBT-060401010101-确认提现',
                    eventLable: 'iBT-06040101010101-还款警示'
                },
                '借款失败': {
                    eventId: 'iBT-060401010101-确认提现',
                    eventLable: 'iBT-06040101010102-失败'
                },
                '确认提现页': {
                    eventId: '$_03_0_4_48_再贷确认提现页'
                },
                '确认提现2.0': {
                    eventId: '$_03_1_4_48_01_再贷确认提现页'
                },
                '事件结果成功': {
                    eventId: '$_03_2_4_48_01_再贷确认提现页'
                },
                '事件结果失败': {
                    eventId: '$_03_2_4_48_02_再贷确认提现页'
                }
            };
            return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
        },
        initialize: function() {
            this.from = C.Utils.getQueryMap().from;
            // 获取迁徙存储数据
            this.migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
            if(this.from && this.from == 'icard_policy.html'){
                C.Native.setHeader({
                    title: '确认提现信息',
                    isBack: 1
                });
            }else{
                C.Native.setHeader({
                    title: '确认提现信息',
                    leftCallback: function() {
                        C.Native.back({
                            url: 'loan_apply.html'
                        });
                    }
                });
            }
            // 获取接口入参
            this.getRequestParams();
            // 获取返回参数来渲染页面
            // this.getOnbackDate();
            // 首贷需要获取同盾参数
            if (this.isFirstPay == 'Y') {
                // 获取同盾参数
                this.getDeviceParams();
                //929版本新增两个参数:获取恶意app数量maliciousAppCnt 和 网络连接类型connectionType
                this.getIriskParams();
            }else{
                // 获取GPS参数方法与获取同盾参数都是调用getDeviceInfo方法,如果不是首贷,则单独获取
                this.getGpsParams();
                $('#js-again-hidden').addClass('dn');    //再贷时隐藏提示语k
            }
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                //埋点 无欠款迁徙提现确认页
                C.Native.TDOnEvent({
                    eventId: '$_03_0_0_59_无欠款迁徙确认页'
                });
            } else {
                //埋点 （再贷）确认提现页 
                C.Native.TDOnEvent(this.talkingDate('确认提现页'));
            }
        },
        // 获取接口请求的入参
        getRequestParams: function() {
            var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO),
                queryApplyInfo = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO);
            this.channelType = sourceInfo ? sourceInfo.sourceType : '';
            this.isUpdateAgreement = queryApplyInfo.isUpdateAgreement;
            this.productType = queryApplyInfo.productType;
            this.loanCompanyCode = queryApplyInfo.loanCompanyCode || 'L';
            // 投保单号
            this.insuranceNo = C.Utils.data(C.Constant.DataKey.BT_INSURANCE_NO) || '';
            this.isFirstPay = queryApplyInfo.isFirstPay;
            this.fundingModel = queryApplyInfo.fundingModel || '';
            this.cgiBankName = queryApplyInfo.cgiBankName || '';
            this.applyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).applyNo;
            this.loanCode = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).loanCode || C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).ICreditInfo.loanCode;
            this.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
            this.loanBindNo = queryApplyInfo.loanBindNo;
            // 新增借款用途字段
            this.purpose = queryApplyInfo.purpose;
            // 借款金额
            this.loanAmt = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_AMOUNT).loanAmt;
            // 日保费费率
            this.premium = queryApplyInfo.premium;
            // 保费率码值 525产险剥离二期添加
            this.insuranceRateCode = queryApplyInfo.insuranceRateCode || '';
            // 贷款期数
            this.term = C.Utils.data(C.Constant.DataKey.LOAN_REPAY_PLAN).term;
            this.version = C.Constant.PRODUCTION.cgiVersionNo[this.loanCompanyCode || 'L']; //协议书版本
            // 账户是否有效
            this.isAccountValid = queryApplyInfo.isAccountValid;
            this.getUnderwritingRes();
        },
        //核保结果
        getUnderwritingRes: function(){
            var self = this,
                isPoly = C.Utils.data('isPoly') || false,
                params = {
                    insuranceRate: self.premium,  // 日保费费率
                    insuranceRateCode: self.insuranceRateCode, // 保费率码值 525产险剥离二期添加
                    term: self.term,  // 贷款期数
                    applyNo: self.applyNo,  // 申请号
                    insuranceNo: self.insuranceNo,  // 投保单号
                    ln_amt: self.loanAmt  // 借款金额
                };
            // 新增迁徙入参
            if(this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                params.isMigrate = this.migrateData.isMigrate;
            }
            if((this.fundingModel.toUpperCase() === 'U' || this.fundingModel.toUpperCase() === 'D') && !isPoly){
                C.UI.loading();
                $.ajax({
                    url: C.Api('ADVISE_UNDERWRITING'),
                    type: 'post',
                    data: params,
                    success: function(res){
                        if(res.flag && res.flag == C.Flag.SUCCESS){
                            var data = res.data;
                            if(data.resultCode == '1'){
                                //埋点 提现核保页 成功
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_4_34_01_提现核保页'
                                });
                                C.Utils.data('isPoly', true);
                                self.getOnbackDate(); 
                            }else{//核保失败跳转到系统开小差页
                                //埋点 提现核保页 失败
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_4_34_02_提现核保页'
                                });
                                C.Utils.data('isPoly', null);
                                C.Native.loadPage({
                                    url: C.Constant.DataUrl.TRANSPAGE.LOANFAIL
                                });
                            }
                        }else{
                            C.Native.tip(res.msg || res.data.resultMsg);
                        }
                    },
                    complete: function(res){
                        C.UI.stopLoading();
                    }
                });
            }else{
                this.getOnbackDate(); 
            }
        },
        // 根据onBack的返回参数请求不同页面
        getOnbackDate: function() {
            this.backData = C.Utils.data(C.Constant.DataKey.ONBACK_DATA);
            //获取返回到该页面的值，其他页面通过C.Native.back方法返回字段值同时native中也调用了onback方法，
            this.applyInfo = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO);
            if (this.backData && this.backData.bindNo) {
                // 有卡名称，直接更新本地缓存渲染页面
                if (this.backData.cardName) {
                    this.loanBindNo = this.applyInfo.loanBindNo = this.backData.bindNo; // 卡绑定号
                    this.applyInfo.creditCardName = this.backData.cardName; // 卡名称

                    C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO, this.applyInfo);   //存储
                    this.renderView();
                    // 清空onBack缓存，方便下次或者其他返回到该页面时进行存储值
                    C.Utils.data(C.Constant.DataKey.ONBACK_DATA, null);
                } else {
                    // 无卡名称，请求借款查询接口
                    this.requestLoanInfo();
                }
            } else {
                this.renderView();
                // 埋点
                C.Native.TDOnEvent(this.talkingDate('提现信息'));
            }
        },
        // 拼接本地数据并渲染页面
        renderView: function() {
            var arr = [
                C.Constant.DataKey.USER_LOGIN_INFO, // 用户登录信息
                C.Constant.DataKey.LOAN_APPLY_INFO, // 借款查询接口返回信息
                C.Constant.DataKey.LOAN_REPAY_PLAN, // 还款试算接口返回信息
                C.Constant.DataKey.LOAN_APPLY_AMOUNT // 借款金额
            ];
            this.render(this.concatLocalData(arr));
        },
        // 初始页面渲染
        render: function(data) {
            var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            data.Id = userInfo.Id.replace(/^(\d{4})\d{10}(.{4})$/, '$1**********$2');
            // 增加迁徙逻辑
            data.isMigrate = 'N';
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                data.isMigrate = this.migrateData.isMigrate;
            }
            $('#js-wrap-info').html(_.template($('#js-html-info').html(), data));
            $('#js-wrap-submit').html(_.template($('#js-html-submit').html(), data));
            if(App.IS_SDK){
                //按钮的颜色
                var btnTitleColor='#fff',
                    btnBgColor='#eb6100',
                    border = '1px solid #eb6100';
                C.Native.getUIParams(function (data) {
                    btnBgColor = data.btnBgColor || data.buttonColor || btnBgColor;
                    btnTitleColor = data.btnTitleColor || btnTitleColor;
                    border = '1px solid' + btnBgColor;
                    $('#js-btn-submit').css({
                        'color': btnTitleColor,
                        'border': border,
                        'background': btnBgColor
                    });
                });
            }
        },
        // 多对象合并
        concatObject: function(arr) {
            var obj = {};
            for (var i = 0; i < arr.length; i++) {
                if (_.isObject(arr[i])) {
                    obj = _.extend(obj, arr[i]);
                }
            }
            return obj;
        },
        // 拼接本地缓存数据
        concatLocalData: function(arrdata) {
            var arr = _.map(arrdata, function(num) {
                return C.Utils.data(num);
            });
            return this.concatObject(arr);
        },
        // 更新提现信息
        updateLocalDate: function(data) {

            if (data.resultCode == '1') {
                this.applyInfo.debitCarList = data.infoMap.debitCarList; // 更新储蓄卡列表
                var cardInfo = this.matchCardList(this.applyInfo.debitCarList, {
                    loanBindNo: this.backData ? this.backData.bindNo : this.callBackBindNo
                });
                if (cardInfo) {
                    this.loanBindNo = this.applyInfo.loanBindNo = cardInfo.loanBindNo; // 卡绑定号
                    this.applyInfo.creditCardName = cardInfo.cardName; // 卡名称
                }
                C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO, this.applyInfo);
                this.renderView();
            } else {
                C.Native.tip(data.resultMsg);
            }
            // 清空onBack缓存
            C.Utils.data(C.Constant.DataKey.ONBACK_DATA, null);
        },
        matchCardList: function(list, prop) {
            return _.findWhere(list, prop);
        },
        requestLoanInfo: function() {
            var data = {
                applyNo: this.applyNo,
                loanCode: this.loanCode,
                payApplyNo: this.payApplyNo,
                channelType: this.channelType
            };
            // 新增迁徙入参
            if(this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                data.isMigrate = this.migrateData.isMigrate;
            }
            this.dataRequest({
                url: C.Api('LOAN_INFO_QUERY'),
                callback: this.updateLocalDate,
                type: 'POST',
                data: data
            });
        },

        // Ajax请求数据
        dataRequest: function(json) {
            C.UI.loading();
            var self = this;
            $.ajax({
                url: json.url,
                type: json.type,
                data: {
                    jsonPara: JSON.stringify(json.data)
                },
                success: function(res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        json.callback.call(self, res.data);
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        //1025新增,获取GPS入参参数
        getGpsParams: function(){
            var self = this;
            C.Native.getDeviceInfo(function(res){
                if(res.code == '1' && res.result){
                    self.GpsParams = {
                        address: res.result.address,
                        longitude: res.result.longitude,
                        latitude: res.result.latitude 
                    };
                }
            });
        },
        // 获取同盾参数
        getDeviceParams: function() {
            var self = this;
            C.Native.getDeviceInfo(function(json) {
                console.log(json);
                if (json.code == '1' && json.result) {
                    self.DeviceParams = {
                        //增加imei和Sparta_deviceid这2个参数（SDK是从这个方法获取这两个参数）
                        imei: json.result.imei || '',
                        sparta_deviceid: json.result.sparta_deviceid || '',

                        mac: json.result.mac || '',
                        city: json.result.gpsCity || '',
                        isRoot: json.result.isRoot || '',
                        address: json.result.address || '',
                        machineSN: json.result.MachineSN || '',
                        appVersion: json.result.appVersion || '',
                        mobileBrand: json.result.mobileBrand || '',
                        mobileOsVer: json.result.mobileOsVer || '',
                        sdkReturnStr: json.result.sdkReturnStr || ''
                    };
                    //GPS参数一起获取了
                    self.GpsParams = {
                        address: json.result.address,
                        longitude: json.result.longitude,
                        latitude: json.result.latitude 
                    };
                    // 敏感信息加密
                    C.Native.rSAEncode({
                        idNumber: C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).Id,
                        registNo: C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).mobile,
                        mobile: json.result.simMobile || '',
                        cardNumber: ''
                    }, function(res) {
                        if (res.code == '1' && res.result) {
                            console.log(res);
                            self.DeviceParams = _.extend(self.DeviceParams, res.result);
                        } else {
                            C.Native.tip('加密信息失败');
                        }
                    });
                } else {
                    C.Native.tip('获取同盾参数失败');
                }
            });
        },
        //首贷需要获取获取恶意app数量maliciousAppCnt 和 网络连接类型connectionType
        getIriskParams: function(){
            var self = this;
            C.Native.getTDParams(function(res){
                self.IriskParams = {
                    maliciousAppCnt: res.maliciousAppCnt || '',
                    connectionType: res.connectionType || '',
                    sparta_deviceid: res.sparta_deviceid || '', //sparta设备号 (联合放款)
                    imei: res.imei || '',  //imei号(联合放款)
                    totalstorage_n: res.totalstorage_n || '',
                    screenres_length1: res.screenres_length1 || '',
                    screenres_length2: res.screenres_length2 || '',
                    black_box: res.black_box || ''              // 设备加密串
                };
            });
        },
        // 选择银行卡
        goSelectCard: function() {
            var self = this;
            // 埋点 收还卡账户
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_35_01_确认提现页'
            });
            if(App.IS_SDK){
                C.Native.forward({
                    url: 'loan_select_card.html',
                    data: {
                        loanBindNo: self.loanBindNo
                    }, 
                    //重新渲染银行卡
                    callBack: function(data) {
                        if(data.cardName){
                            $('#js-repay-card').text(data.cardName);
                            self.loanBindNo = self.applyInfo.loanBindNo = data.bindNo;//回传的绑定号
                            self.applyInfo.creditCardName = data.cardName; //回传的卡名称
                            C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO, self.applyInfo); //重新保存默认的申请信息
                        } else if (data && !!data.reload && data.bindNo) {
                            self.callBackBindNo = data.bindNo;
                            self.requestLoanInfo();
                        }
                    }
                });
            }else{
                C.Native.forward({
                    url: 'loan_select_card.html'
                }); 
            }
        },
        // 显示费率详情
        toggleRateDetail: function(e) {
            var arrow = $(e.currentTarget).children('.icon-sm');
            if (arrow.hasClass('icon-down')) {
                arrow.removeClass('icon-down').addClass('icon-up');
            } else if (arrow.hasClass('icon-up')) {
                arrow.removeClass('icon-up').addClass('icon-down');
            }
            $('#js-block-rate').toggleClass('dn');
        },
        // 借款合同页面
        goLoanContract: function(e) {
            var self = this;

            // 埋点
            C.Native.TDOnEvent(self.talkingDate('借款协议'));

            // 跳转到借款协议页面
            if(self.fundingModel=='U'||self.fundingModel=='D'){
                C.Native.forward({
                    url: C.Constant.CONTRACTCGI[self.version]//loan_contract_cgi.html
                }); 
                //埋点 确认提现页 借款协议
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_35_04_确认提现页'
                });
            }else{
                //埋点 确认提现页 借款及担保协议
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_35_03_确认提现页'
                });
                C.Native.forward({
                    url: C.Constant.CONTRACT[C.Constant.PRODUCTION.lastVersionNo]//loan_contract.html
                });
            }
        },
        //资料代传合同页面
        goTransferContract: function(){
            //埋点 确认提现页 资料代传协议
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_35_05_确认提现页'
            });
            // 跳转到借款协议页面,
            C.Native.forward({
                url: C.Constant.DATAVERSION[C.Constant.PRODUCTION.dataVersionNo]//loan_data_transfer_contract.html
            });

        },
        // 是否同意借款合同
        isAgreeContract: function(e) {
            //埋点 确认提现页 同意单选框
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_35_02_确认提现页'
            });
            $(e.currentTarget).toggleClass('checked');
            $('#js-btn-submit').toggleClass('btn-dis');
        },
        // 提现确认
        loanConfirm: function(e) {
            if (!$(e.currentTarget).hasClass('btn-dis')) {
                // if ((this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') || this.isFirstPay == 'N') {
                //     // 再贷或者迁徙用户 调用再贷确认借款接口
                //     this.loanConfirmRequest(C.Api('RESUBMIT_LOAN_APPLY'));
                // } else {
                //     // 首次合同签约接口
                //     this.loanConfirmRequest(C.Api('SUBMIT_LOAN_APPLY'));
                // }
                if (this.isFirstPay == 'Y') {
                    this.loanConfirmRequest(C.Api('SUBMIT_LOAN_APPLY'));//首次合同签约接口
                } else {
                    this.loanConfirmRequest(C.Api('RESUBMIT_LOAN_APPLY'));
                }
                if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                    //埋点 无欠款迁徙提现确认页 同意
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_0_59_01_无欠款迁徙确认页'
                    });
                } else {
                    // 埋点
                    C.Native.TDOnEvent(this.talkingDate('确认提现'));
                    // 埋点 确认提现页 确认提现
                    C.Native.TDOnEvent(this.talkingDate('确认提现2.0'));
                }
            }
        },
        // 提现签约请求
        loanConfirmRequest: function(url) {
            var parms = {
                    applyNo: this.applyNo,
                    loanCode: this.loanCode,
                    payApplyNo: this.payApplyNo,
                    loanBindNo: this.loanBindNo,
                    loanAmt: this.loanAmt,
                    insuranceNo: this.insuranceNo, // 511版本,首贷/再贷提现确认增加投保单号入参
                    versionNo: (this.fundingModel == 'U' ||this.fundingModel=='D') ? this.version : C.Constant.PRODUCTION.lastVersionNo,
                    dataVersionNo: (this.fundingModel == 'U' ||this.fundingModel=='D') ? C.Constant.PRODUCTION.dataVersionNo : '', //资料代传 版本
                    channelType: this.channelType,
                    isUpdateAgreement: this.isUpdateAgreement,
                    purpose: this.purpose
                },
                data = this.concatObject([parms, this.DeviceParams, this.IriskParams, this.GpsParams]);
            // 新增迁徙入参
            if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isDebt) {
                data.isMigrate = this.migrateData.isMigrate;
                data.isDebt = this.migrateData.isDebt;
            }
            if (this.isAccountValid && this.isAccountValid == '0') {
                //新增是否变更借款合同有效期
                data.isAccountValid = '1';
                data.isUpdateAgreement = 'Y';
            }
            this.dataRequest({
                url: url,
                callback: this.goLoanResult,
                type: 'POST',
                data: data
            });
        },
        // 提现申请结果
        goLoanResult: function(data) {
            // 签约被拒绝情况
            if (data.subProcessCode == 'RJ') {
                C.Native.forward({
                    url: 'credit_fail_result.html'
                });
                return;
            }
            // 签约重新评级情况
            if (data.levelChange == '1') {
                this.showReApply();
                return;
            }
            // 签约开关
            if (data.signSwitch == '1') {
                //迁徙开关关闭，提示额度已抢光
                if (data.migrateSwitch && data.migrateSwitch == '0') {
                    C.Native.tip(data.migrateMsg);
                    return;
                }
                if (data.resultCode == '1') {
                    if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                        //埋点 迁徙提交成功
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_0_59_01_无欠款迁徙确认页'
                        });
                    } else {
                        //老埋点
                        C.Native.TDOnEvent(this.talkingDate('还款警示'));
                        //新埋点 事件结果 成功
                        C.Native.TDOnEvent(this.talkingDate('事件结果成功'));
                    }
                    // 跳转到成功页面
                    C.Native.loadPage({
                        url: 'loan_suc.html'
                    });
                } else {
                    if (this.migrateData && this.migrateData.isMigrate && this.migrateData.isMigrate == 'Y') {
                        //埋点 迁徙提交失败
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_0_59_02_无欠款迁徙确认页'
                        });
                    } else {
                        // 埋点
                        C.Native.TDOnEvent(this.talkingDate('借款失败'));
                        //埋点 事件结果 失败
                        C.Native.TDOnEvent(this.talkingDate('事件结果失败'));
                    }
                    // 跳转到失败页面
                    C.Native.loadPage({
                        url: 'loan_fail.html',
                        data: {
                            isSignSuccess: data.isSignSuccess,
                            isDrawSuccess: data.isDrawSuccess
                        }
                    });
                }
            } else {
                C.Native.tip(data.switchMsg || data.resultMsg);
            }
        },
        // 签约重新评级情况
        showReApply: function() {
            $('#js-block-reApply').show();
        },
        goBack: function() {
            if (this.isFirstPay == 'Y') {
                C.Native.back({
                    url: 'loan_select.html'
                });
            } else {
                C.Native.back({
                    url: 'account_iloan.html'
                });
            }
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});