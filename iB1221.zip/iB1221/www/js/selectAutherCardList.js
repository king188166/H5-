/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2016-03-17
 * @time  : pm 19:53
 *
 * @describe: 可以鉴权的卡列表
 */

define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .js_tap': 'choose',
            'tap .btn': 'makeSure'
        },
        initialize: function () {
            var self = this;
            self.paPayAccount = '';
            self.idx = '';
            self.cardNo = '';
            self.bindAccountList = [];
            self.loginInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            // 从url中获取前一页面的传参,写入本地缓存
            C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM, {
                route: C.Utils.getParameter('route'),
                url: C.Utils.getParameter('url'),
                moduleName: C.Utils.getParameter('moduleName'),
                failRoute: C.Utils.getParameter('failRoute'),
                failUrl: C.Utils.getParameter('failUrl'),
                failModuleName: C.Utils.getParameter('failModuleName')
            });
            self.from = C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM);
            //埋点
            if(self.from.url == 'icard_loading.html'){
                //埋点 重查征信绑卡页
                C.Native.TDOnEvent({
                    eventId: '$_03_0_4_18_重查征信绑卡页'
                });
            }else{
               //埋点 选择银行卡页
                C.Native.TDOnEvent({
                    eventId: '$_03_0_2_05_选择银行卡页'
                }); 
            }
            if (!self.loginInfo) {
                C.Native.getUserInfo(function (data) {
                    self.loginInfo = data;
                });
            }
            C.UI.stopLoading();
            var data = {};
            data.bindAccountList = C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST) ? C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST).bankCards : [];
            if (!data.bindAccountList.length) {
                self.getBankList();
                return;
            }
            self.bindAccountList = data.bindAccountList;
            $.each(data.bindAccountList, function (index, value) {
                self.paPayAccount = self.paPayAccount || value.paPayAccount;
                value.paPayAccount = self.paPayAccount;
                value.accountTypeName = value.bankName;
                value.accountNo = self.formatId(value.bankNo);
                value.bankCode = value.bankShortName.toLowerCase();
            });
            self.bindno = '';
            self.render(data);
            self.isPosting = false;
            self.yqb = false;
        },

        getBankList: function () {
            var self = this;
            C.Native.getDeviceInfo(function (data) {
                var param = {
                    curVer: data.appVersion,
                    machineSN: data.MachineSN || data.machinesn,
                    loanType: '2'
                };
                $.ajax({
                    url: C.Api('BINDBANKCARDS'),
                    data: param,
                    type: 'post',
                    success: function (res) {
                        C.UI.stopLoading();
                        if (res.flag == C.Flag.SUCCESS && res.data) {
                            if (res.data.bankCards && res.data.bankCards.length > 0) {
                                C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST, res.data);
                                var data = {};
                                data.bindAccountList = C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST) ? C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST).bankCards : [];
                                self.bindAccountList = data.bindAccountList;
                                $.each(data.bindAccountList, function (index, value) {
                                    self.paPayAccount = self.paPayAccount || value.paPayAccount;
                                    value.paPayAccount = self.paPayAccount;
                                    value.accountTypeName = value.bankName;
                                    value.accountNo = self.formatId(value.bankNo);
                                    value.bankCode = value.bankShortName.toLowerCase();
                                });
                                self.bindno = '';
                                self.render(data);
                                self.isPosting = false;
                            }
                        }
                    }
                });
            });
        },

        render: function (data) {
            var self = this;
            $.each(data.bindAccountList, function (index, value) {
                value.accountNo = self.formatId(value.accountNo);
                value.bankCode = value.bankCode.toLowerCase();
                value.isChoosed = false;
                if (self.bindno != '') {
                    if (value.bindNo == self.bindno) {
                        self.idx = index;
                        value.isChoosed = true;
                    }
                } else if (self.bindno == '') {
                    if (index == 0) {
                        self.idx = index;//从完善信息页面过来的话，没有默认的卡，默认选择第一张
                        value.isChoosed = true;
                    }
                }
            });
            var html = _.template($('#bind_account_list').html(), {data: data.bindAccountList});
            $('ul.content').prepend(html);
            C.Native.setHeader({
                title: '选择银行卡',
                leftCallback: function () {
                    C.Utils.data(C.Constant.DataKey.CHOOSE_CARD_FROM, null);
                    var Page = C.Utils.getParameter('Page');
                    if (Page) {
                        C.Native.back({
                            url: Page
                        });
                        return;
                    }
                    C.Native.back();
                },
                rightIcon: 'add',
                rightCallback: function () {
                    if (self.from.url == 'icard_loading.html') {
                        C.Utils.data(C.Constant.DataKey.BT_BINDCARD_FLAG, '2');
                        C.Native.TDOnEvent({
                            eventId: 'iBT-030102-绑银行卡',
                            eventLable: 'iBT-03010202-添加银行卡'
                        });
                        //埋点 重查征信绑卡页 绑银行卡（还卡流程）
                        C.Native.TDOnEvent({
                            eventId: '$_03_1_4_18_02_重查征信绑卡页'
                        });
                    } else {
                        C.Native.TDOnEvent({
                            eventId: 'iBT-0202-绑定银行卡',
                            eventLable: 'iBT-020201-添加银行卡'
                        });
                        //埋点 添加银行卡
                        C.Native.TDOnEvent({
                            eventId: '$_03_1_2_05_01_选择银行卡页'
                        });
                    }
                    C.Native.forward({
                        url: 'credit_bind_card.html',
                        data: {
                            route: C.Utils.getParameter('route'),
                            url: C.Utils.getParameter('url'),
                            moduleName: C.Utils.getParameter('moduleName'),
                            failRoute: C.Utils.getParameter('failRoute'),
                            failUrl: C.Utils.getParameter('failUrl'),
                            failModuleName: C.Utils.getParameter('failModuleName')
                        }
                    });
                }
            });

        },
        formatId: function (str) {
            if (str) {
                return '**** **** ****' + str.substr(str.length - 4);
            }
        },

        choose: function (e) {
            var self = this;
            var node = $(e.currentTarget);
            if (node.hasClass('active')) {
                return;
            }
            self.yqb = node.hasClass('yqb') ? true : false;
            node.addClass('active').siblings().removeClass('active');
            self.idx = node.attr('idx');
        },
        makeSure: function () {
            var self = this,
                bindData = self.bindAccountList[self.idx];
            var iloanH5Result = C.Utils.data(C.Constant.DataKey.QUERY_ILOAN_H5_RESULT);
            if (self.paPayAccount) {
                //点击确定，如果是来自loanselect，BT30天，则换取token，跳转平安付
                if (self.from.url == 'icard_loading.html') {
                    self.queryCardInfo(bindData);
                    C.Native.TDOnEvent({
                        eventId: 'iBT-03010201-选择银行卡',
                        eventLable: 'iBT-0301020101-确定'
                    });
                    //埋点 重查征信绑卡页  选择银行卡 （还卡流程）
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_18_01_重查征信绑卡页'
                    });
                } else {
                    if(self.yqb){ // 绑卡失败后，重新进入该页面，默认显示的是外置H5接口返回的数据
                        //埋点 选择银行卡页 选定壹钱包卡
                        C.Native.TDOnEvent({
                            eventId: '$_03_1_2_05_02_选择银行卡页'
                        });
                    }else{
                        //埋点 选定银行卡
                        C.Native.TDOnEvent({
                            eventId: '$_03_1_2_05_03_选择银行卡页'
                        });
                    }
                    self.submitCardInfo(bindData);
                }
            } else {
                //手动获取壹钱包会员号
                //H5外置用户跳转平安付
                if(!!iloanH5Result) {
                    if ((iloanH5Result.isAppoint == 1 && iloanH5Result.isAppl == 1 && iloanH5Result.isCredit == 0) || (iloanH5Result.isAppoint == 1 && iloanH5Result.isAppl == 0 )) {
                        self.queryCardInfo(bindData);
                    }
                }
            }
            return;
        },
        queryCardInfo: function (bindData) {
            var self = this;
            if (self.isPosting) {
                return;
            }
            self.isPosting = true;
            C.UI.loading();
            C.Native.getDeviceInfo(function (data) {
                if (data.code == '1') {
                    self.deviceInfo = data.result;
                    self.cardNo = bindData.bankNo;
                    var param = {
                        name: self.loginInfo.custName,
                        certId: self.loginInfo.Id,
                        mobileNo: self.loginInfo.mobile,
                        cardNo: self.cardNo
                    };
                    // 425版本,绑卡参数加密
                    C.Native.rSAEncode(param, function (res) {
                        if (res.code == '1') {
                            var param = {
                                curVer: self.deviceInfo.appVersion,
                                endDecVer: self.deviceInfo.appVersion,
                                token: self.loginInfo.token,
                                machineSN: self.deviceInfo.MachineSN || self.deviceInfo.machinesn,
                                pafToken: self.loginInfo.paPayToken,
                                loanType: C.Constant.PRODUCTION.CODE,
                                // 加密信息
                                cardNo: res.result.cardNo,
                                name: res.result.name,
                                certId: res.result.certId,
                                mobileNo: res.result.mobileNo
                            };
                            $.ajax({
                                url: C.Api('QUERYCARDINFO'),
                                type: 'post',
                                data: param,
                                success: function (res) {
                                    if (res.flag == C.Flag.SUCCESS && res.data) {
                                        res.data.cardNo = self.cardNo;
                                        C.Utils.data(C.Constant.DataKey.CARD_DATA, res.data);
                                        self.toBindCard(res.data);
                                    }
                                },
                                complete: function (res) {
                                    C.UI.stopLoading();
                                    self.isPosting = false;
                                }
                            });
                        } else {
                            C.Native.tip('安全数据加密失败');
                        }
                    });
                }
            });
        },
        /**
         * 绑卡
         * */
        toBindCard: function (data) {
            var self = this;
            C.Native.TDOnEvent({
                eventId: 'iBT-0301020101-确定',
                eventLable: 'iBT-030102010101-下一步'
            });
            if(self.from.url == 'icard_loading.html'){
                //埋点 重查征信绑卡页  确定 （还卡流程）
                C.Native.TDOnEvent({
                    eventId: '$_03_1_4_18_03_重查征信绑卡页'
                });
            }else{
                //埋点 确定（从外置H5过来的绑卡确定的埋点）
                C.Native.TDOnEvent({
                    eventId: '$_03_1_2_05_04_选择银行卡页'
                });
            }
            //重查PBOC走签名绑卡,去掉绑卡成功页面右上角"+",和左上角回退图标
            C.Native.setHeader({
                title: '添加银行卡',
                isBack: false,
                rightIcon: ''
            });
            var ChangeUrl = C.Constant.Change_Url;
            var returnhref = ChangeUrl + '?forwardUrl=credit_bindcard_suc.html' + location.search,
                cancelhref = ChangeUrl + '?forwardUrl=select_auther_card_list.html' + location.search;

            var paramData = {
                merchantNo: data.merchantNo,
                version: '1.0',
                returnUrl: returnhref,
                cancelUrl: cancelhref,
                requestMsg: data.requestMsg,
                requestNo: data.requestNo
            };
            var _form = document.getElementsByTagName('form');
            _form[0].setAttribute('method', 'post');
            _form[0].setAttribute('action', C.Constant.PAPAY_BIND_CARD);
            document.getElementsByName('merchantNo')[0].setAttribute('value', paramData.merchantNo);
            document.getElementsByName('version')[0].setAttribute('value', paramData.version);
            document.getElementsByName('returnUrl')[0].setAttribute('value', paramData.returnUrl);
            document.getElementsByName('cancelUrl')[0].setAttribute('value', paramData.cancelUrl);
            document.getElementsByName('requestMsg')[0].setAttribute('value', paramData.requestMsg);
            document.getElementsByName('requestNo')[0].setAttribute('value', paramData.requestNo);
            _form[0].submit();
        },
        /**
         * 提交绑卡信息接口
         * */
        submitCardInfo: function (data) {
            var self = this;
            if (self.isPosting) {
                return;
            }
            //埋点 确定 不绑卡直接选择确定时埋点
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_05_04_选择银行卡页'
            });
            C.Native.getDeviceInfo(function (res) {
                if (res.code == '1') {
                    self.deviceInfo = res.result;
                    var param = {
                        name: self.loginInfo.custName,
                        paPayAccount: data.paPayAccount,
                        id: self.loginInfo.Id,
                        tel: self.loginInfo.mobile,
                        bankCardNo: data.bankNo,
                        bankCardTel: data.reservePhone,
                        simMobile: self.deviceInfo.simMobile,
                        bankName: data.bankName
                    };
                    var sourData = {};
                    C.Native.rSAEncode(param, function (res) {
                        if (res.code == '1') {
                            var param = {
                                name: res.result.name,
                                paPayAccount: res.result.paPayAccount,
                                id: res.result.id,
                                tel: res.result.tel,
                                bankCardNo: res.result.bankCardNo,
                                bankCardTel: res.result.bankCardTel,
                                simMobile: res.result.simMobile || '',
                                bankName: res.result.bankName,
                                cardType: data.cardType,
                                bankNo: data.bankShortName,
                                bindingSource: 'ILOANBT',
                                platform: App.IS_IOS ? 'IOS' : 'A',
                                machineSN: self.deviceInfo.MachineSN || self.deviceInfo.machinesn,
                                address: self.deviceInfo.address,
                                longitude: self.deviceInfo.longitude,
                                latitude: self.deviceInfo.latitude,
                                cityName: self.deviceInfo.gpsCity,
                                provinceName: self.deviceInfo.gpsProvince,
                                registNo: self.loginInfo.mobile,
                                callType: '鉴权绑卡',
                                callChannel: '平安易贷',
                                appVersion: self.deviceInfo.appVersion,
                                mobileBrand: self.deviceInfo.mobileBrand,
                                mobileOsVer: self.deviceInfo.mobileOsVer,
                                sdkReturnStr: self.deviceInfo.sdkReturnStr,
                                ip: self.deviceInfo.ip,
                                bankCardId: data.bankCardId
                            };
                            if (App.IS_SDK) {
                                sourData = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
                                param.thirdChannel = sourData.source;
                                param.channelType = sourData.sourceType;
                            }
                            if (!param.longitude || !param.cityName) {
                                //未获取到定位信息提示
                                C.Native.tip('无法获取当前城市，请允许定位重新尝试');
                            } else {
                                self.isPosting = true;
                                C.UI.loading();
                                $.ajax({
                                    url: C.Api('REGULARBINDBINKCARD'),
                                    data: {
                                        jsonPara: JSON.stringify(param)
                                    },
                                    type: 'POST',
                                    success: function (result) {
                                        if (result.flag == C.Flag.SUCCESS && result.data) {
                                            if (result.data.resultCode == '1') {
                                                // 根据缓存中的参数，跳转到不同页面并刷新
                                                C.Native[self.from.route]({
                                                    url: self.from.url,
                                                    moduleName: self.from.moduleName,
                                                    data: {isSuccess: true}
                                                });
                                            } else {
                                                C.Native.tip('提交信息失败，请稍后重试');
                                            }
                                        } else {
                                            C.Native.tip('提交信息失败，请稍后重试');
                                        }
                                    },
                                    complete: function (res) {
                                        self.isPosting = false;
                                        C.UI.stopLoading();
                                    }
                                });
                            }
                        } else {
                            C.Native.tip('安全数据加密失败');
                        }
                    });
                } else {
                    C.Native.tip('获取提交信息失败');
                }
            });
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
