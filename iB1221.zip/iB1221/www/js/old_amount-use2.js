/**
 * @author: qiuxiaoqiang292@pingan.com.cn
 * @date  : 2015-10-12
 * @time  : 上午09:25
 *
 * @describe: 动用额度
 */
/*global define:false*/
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .js_tap': 'choose',
            'tap .icon-add': 'addCard',
            'tap #next-btn': 'nextStep'
        },
        initialize: function () {
            var self = this;
            // 设置标题
            C.Native.setHeader({
                title: '动用额度',
                leftCallback: function () {
                    C.Native.back({
                        data: {
                            'checkReload': '1'
                        }
                    });
                    C.Utils.data('SSION_MONEY', '', 1);
                }
            });
            self.pageInit();
        },
        requestData: function (json) {
            C.UI.loading();
            $.ajax({
                type: json.type,
                url: json.url,
                data: json.data,
                success: function (data) {
                    if (data.flag && data.data) {
                        json.successCall(data);
                    }
                    C.UI.stopLoading();
                },
                complete: function (data) {
                    json.completeCall(data);
                    C.UI.stopLoading();
                }
            });
        },
        /*
         * 进入后加载
         */
        pageInit: function () {
            var self = this;
            self.drawOrder = C.Utils.data('OLD_SUMMARY_INFO');
            var json = {
                url: C.Api('drawQueryInfo'),
                type: 'post',
                data: {
                    custNo: self.drawOrder.custNo,
                    acctNo: self.drawOrder.acctNo
                }
            };
            var successCall = function (data) {
                self.render(data.data);
                self.cardsList = [];
                self.cardsList = data.data.disbAcountList;
                self.List = data.data;
                self.abledAmt = data.data.abledAmt;
                //获取相差天数
                self.gap = self.DateDiff(self.dateFormat(data.data.curDate), self.dateFormat(data.data.rpDate)) + 1;
                //渲染卡列表
                var activeClass = 'js_tap';
                var html = '';
                var flag = 0;
                for (var item in self.cardsList) {
                    var itemCard = self.cardsList[item];
                    itemCard.lastFour = itemCard.accountNo.substr(itemCard.accountNo.length - 4, itemCard.accountNo.length);
                    var accountTypeName = self.cardsList[item].accountTypeName;
                    var bindType = self.cardsList[item].bindType;
                    if (bindType != 'YQB' && flag === 0) {
                        flag++;
                        html += '<li class="js_tap focus" data-bind-no="' + itemCard.bindNo + '" data-bind-name="' + accountTypeName + '" class="' + activeClass + '"><div>' + accountTypeName + '</div><div class="tail">尾号' + itemCard.lastFour + '</div></li>';
                    } else if (bindType != 'YQB') {
                        html += '<li   data-bind-no="' + itemCard.bindNo + '" data-bind-name="' + accountTypeName + '" class="' + activeClass + '"><div>' + accountTypeName + '</div><div class="tail">尾号' + itemCard.lastFour + '</div></li>';
                    }
                }
                $('#choose_bank').html(html);
                self.init(data.data);
                self.bind();
            };
            var completeCall = function () {
                // console.log()
            };

            json.successCall = successCall;
            json.completeCall = completeCall;
            this.requestData(json);
        },
        render: function (data) {
            var self = this;
            console.log(data);
            for (var key in data) {
                $('.js_' + key).html(data[key]);
            }
            var rpDate = data.rpDate;
            var yyyyMMdd = rpDate;
            var yyyy = yyyyMMdd.substring(0, 4);
            var MM = yyyyMMdd.substring(4, 6);
            var dd = yyyyMMdd.substring(6, 8);
            self.rpMouth = MM;
            self.rpDate = yyyy + '-' + MM + '-' + dd;
            $('.js_rpDate').html(self.rpDate);
            $('.js_interestRate').html(0);
            $('.js_guaranteeRate').html(0);
            self.rpDay = dd;
            $('.js_abledAmt').val(data.abledAmt);
        },
        /*
         * 还款说明
         */
        init: function (data) {
            var self = this;
            var cardsList = [];
            self.rpDate = data.rpDate;
            //			var dayList = self.getDay();
            cardsList = self.getDay();
            var rpDate = data.rpDate;
            cardsList.rpMouth = rpDate.substring(4, 6);
            cardsList.rpDay = rpDate.substring(6, 8);
            cardsList.guaranteOP = '0.00';
            cardsList.getMoney = '0.00';
            cardsList.sumTotal = '0.00';
            cardsList.interestOP = '0.00';
            cardsList.sumMoney = '0.00';
            cardsList.nextMouth = data.billDate.substring(4, 6);
            cardsList.sumDay = data.billDate.substring(6, 8);

            var html = _.template($('#content_body').html(), {
                dayList: cardsList
            });
            $('.remind').html(html);
        },
        /*
         * 选择卡列表
         */
        choose: function (e) {
            var node = $(e.currentTarget);
            if (node.hasClass('focus')) {
                return;
            }
            C.Native.TDOnEvent({
                eventId: '020402-下一步',
                eventLable: '02050103-选择银行卡',
                jsonData: {}
            });
            node.addClass('focus').siblings().removeClass('focus');
            console.log(node.attr('data-bind-name'));
        },
        bind: function () {
            var self = this;
            $('#input_money').on('focus', function () {
                $('#input_money').attr('type', 'number');
                $('#input_money').val(self.getMoney);
            });
            $('#input_money').on('blur', function () {
                $('#input_money').attr('type', 'text');
                self.money = $('#input_money').val();
                var money = Number(self.money);
                if (!money) {
                    C.Native.tip('请您正确输入数值.');
                    self.getMoney = '';
                    return false;
                }
                self.getMoney = money;
                $('#input_money').val(money + '元');
                self.infomationRender();
            });
            $('#input_money').on('keyup', function () {
                var getMoney = $('#input_money').val();
                self.getMoney = $('#input_money').val();
                C.Utils.data('GET_MONEY', getMoney);
                C.Utils.data('SSION_MONEY', getMoney, 1);
            });
        },
        /*
         * 还款信息提示
         */
        infomationRender: function () {
            var self = this;
            var getDay = self.getDay();
            console.log(getDay);
            var List = self.List,
                dayList = self.getDay();
            dayList.getMoney = self.money;
            dayList.sumDay = self.List.billDate.substring(6, 8);
            var money = Number(dayList.getMoney),
                interestRate = Number(List.interestRate),
                guaranteeRate = Number(List.guaranteeRate);
            /*
             * 借款信息展示计算区域
             */
            var days = Number(self.gap);
            dayList.guarante = self.accMul(Number(List.guaranteeRate), Number(dayList.getMoney)) * dayList.day;
            dayList.interest = self.accMul(Number(List.interestRate), Number(dayList.getMoney)) * dayList.day;
            dayList.sumTotal = dayList.interest + dayList.guarante;
            console.log(dayList.sumTotal);

            /*
             * 还款总时间费用计算
             */
            dayList.guaranteOP = self.accMul(Number(List.guaranteeRate), Number(dayList.getMoney)) * days;
            dayList.interestOP = self.accMul(Number(List.interestRate), Number(dayList.getMoney)) * days;
            dayList.sumMoney = dayList.interestOP + dayList.guaranteOP + Number(dayList.getMoney);
            dayList.guarante = C.Utils.formatMoney(dayList.guarante, 2);
            dayList.interest = C.Utils.formatMoney(dayList.interest, 2);
            dayList.guaranteOP = C.Utils.formatMoney(dayList.guaranteOP, 2);
            dayList.interestOP = C.Utils.formatMoney(dayList.interestOP, 2);
            dayList.sumTotal = C.Utils.formatMoney(dayList.sumTotal, 2);
            dayList.getMoney = C.Utils.formatMoney(dayList.getMoney, 2);
            dayList.sumMoney = C.Utils.formatMoney(dayList.sumMoney, 2);
            dayList.rpMouth = self.rpMouth;
            dayList.rpDay = Number(self.rpDay);
            var html = _.template($('#content_body').html(), {
                dayList: dayList
            });
            guaranteeRate = self.accMul(guaranteeRate, money);
            interestRate = self.accMul(interestRate, money);
            $('.remind').html(html);
            $('.js_interestRate').html(interestRate);
            $('.js_guaranteeRate').html(guaranteeRate);
        },
        addCard: function () {
            require(['js/old_bindcard'], function (bindcard) {
                bindcard('add').done(function (data) {
                    console.log('bindcard().done', data);
                    //当bindcard('add'),返回：
                    data = data || {
                        flag: '',
                        msg: '',
                        bindCode: '',
                        bindNo: '',
                        accountTypeName: '',
                        accountNo: '',
                        bankCode: '',
                        bindType: ''
                    };

                    $('#choose_bank li').remove();
                    var activeClass = 'js_tap';
                    var html = '',
                        flag = 0,
                        cardsList = data.disbAcountList;

                    for (var item in cardsList) {
                        var itemCard = cardsList[item];
                        itemCard.lastFour = itemCard.bindNo.substr(itemCard.bindNo.length - 4, itemCard.bindNo.length);
                        var accountTypeName = cardsList[item].accountTypeName;
                        var bindType = cardsList[item].bindType;
                        if (bindType != 'YQB' && flag === 0) {
                            flag++;
                            html += '<li class="js_tap focus" data-bind-no="' + itemCard.bindNo + '" data-bind-name="' + accountTypeName + '"                                 class="' + activeClass + '"><div>' + accountTypeName + '</div><div class="tail">尾号' + itemCard.lastFour + '</div></li>';
                        } else if (bindType != 'YQB') {
                            html += '<li   data-bind-no="' + itemCard.bindNo + '" data-bind-name="' + accountTypeName + '" class="' + activeClass + '"><div>' + accountTypeName + '</div><div class="tail">尾号' + itemCard.lastFour + '</div></li>';
                        }
                    }
                    $('#choose_bank').html(html);

                }).fail(function (error) {
                    console.log(error);
                });
            });
        },
        /*
         * Js计算精度解决方法
         */
        formatFloat: function (f, digit) {
            var m = Math.pow(10, digit);
            return parseInt(f * m, 10) / m;
        },
        //下一步
        nextStep: function () {
            C.Native.TDOnEvent({
                eventId: '02050101-下一步',
                eventLable: '02050104-确认动用',
                jsonData: {}
            });
            var self = this,
                bindNo = $('.focus').attr('data-bind-no');
            /*
             * 判断输入动用额度是否为100的整数倍
             */
            self.inputValue = Number(self.money);
            console.log(self.inputValue);
            if (!self.inputValue) {
                C.Native.tip('输入格式不正确!');
                console.log('输入格式不正确!');
                return false;
            } else if (self.inputValue % 100 != 0) {
                C.Native.tip('请输入动用额度为100的整数倍.');
                console.log('请输入动用额度为100的整数倍.');
                return false;
            } else if (!bindNo) {
                C.Native.tip('请选择默认收(还)账户');
                return false;
            } else if (self.abledAmt < self.inputValue) {
                console.log('动用金额请低于可用金额.');
                C.Native.tip('动用金额请低于可用金额.');
                return false;
            }

            var json = {
                url: C.Api('drawCash'),
                type: 'get',
                data: {
                    custNo: self.drawOrder.custNo,
                    acctNo: self.drawOrder.acctNo,
                    trxAmt: self.inputValue,
                    bindBankNo: bindNo
                }
            };
            var successCall = function (data) {
                var flag = data.flag;
                //alert(typeof(flag));
                if (flag == C.Flag.SUCCESS) {
                    // C.Native.TDOnEvent({
                    //     eventId: '02050104-确认动用',
                    //     eventLable: '0205010401-确认动用成功',
                    //     jsonData: {}
                    // });

                    self.tip();
                } else {
                    //C.UI.error(data.msg);
                    C.Native.tip(data.msg);
                }
            };
            var completeCall = function () {
                // console.log()
            };
            json.successCall = successCall;
            json.completeCall = completeCall;
            this.requestData(json);
        },
        tip: function () {
            C.Utils.data('SSION_MONEY', '', 1);
            C.UI.dialog({
                'btnnum': '1',
                'position': 'bottom',
                'content': '恭喜<br />成功转入银行账户，请查询',
                'okText': '确定',
                'ok': function () {
                    C.Native.back({
                        data: {
                            'checkReload': '1'
                        }
                    });
                }
            });
        },
        back: function () {
            C.Native.back();
        },
        /*
         * 将时间格式化
         */
        dateFormat: function (date) {
            var yyyyMMdd = date,
                yyyy = yyyyMMdd.substring(0, 4),
                MM = yyyyMMdd.substring(4, 6),
                dd = yyyyMMdd.substring(6, 8),
                Date = yyyy + '-' + MM + '-' + dd;
            return Date;
        },
        /*
         * JS乘法精度优化
         */
        accMul: function (arg1, arg2) {
            var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
            try {
                m += s1.split('.')[1].length;
            } catch (e) {
                //console.error(e);
            }
            try {
                m += s2.split('.')[1].length;
            } catch (e) {
                //console.error(e);
            }
            return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / Math.pow(10, m);
        },
        getDay: function () {
            var self = this;
            var date = new Date();
            //获取年份
            var year = date.getFullYear();
            //获取当前月份
            var mouth = date.getMonth() + 1;
            //定义当月的天数；
            var days;
            //当前日期
            var now = date.getDate();
            //当月份为二月时，根据闰年还是非闰年判断天数
            if (mouth == 2) {
                days = year % 4 == 0 ? 29 : 28;
            } else if (mouth == 1 || mouth == 3 || mouth == 5 || mouth == 7 || mouth == 8 || mouth == 10 || mouth == 12) {
                //月份为：1,3,5,7,8,10,12 时，为大月.则天数为31；
                days = 31;
            } else {
                //其他月份，天数为：30.
                days = 30;
            }
            //本月剩余天数(算上当天)
            var surplusDay = days - now + 1;
            var param = {};
            param.mouth = mouth;
            param.day = days;
            param.nextMouth = self.List.billDate.substring(4, 6);
            param.now = now;
            param.surplusDay = surplusDay;
            //输出天数
            return param;
        },
        DateDiff: function (startDate, endDate) {
            var s1 = new Date(startDate);
            var s2 = new Date(endDate);
            var days = s2.getTime() - s1.getTime();
            var time = parseInt(days / (1000 * 60 * 60 * 24));
            return time;
        },
        /*
         * 时间差计算
         */
        addDay: function (data) {
            var DaysToAdd = data,
                newDate = new Date(),
                newTimeMs = newDate.getTime() + (DaysToAdd * 24 * 60 * 60 * 1000);
            newDate.setTime(newTimeMs);
            var nextMouthDate = newDate.getDate();
            console.log(nextMouthDate);
            return nextMouthDate;
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});