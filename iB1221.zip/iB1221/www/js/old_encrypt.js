define(['libs/jsencrypt'], function (JSEncrypt) {
    'use strict';
    var RSAENCRYPT = new JSEncrypt();
    RSAENCRYPT.setPublicKey('-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDwHQU77tsMBNbKnzVd+OZeINs7\nrPgGdV8owrau1Ox9a5axrJ2nak3dDQiD9Zt/UfkckZhqFYhDmzxYOgkYDmoP4fTM\neqIwY4e0m4+WDTF6Ef74tEW2SeNwUVqBtcKD+DGEx9QTaWjOLu+wIw4f4gRuuro2\n7oSctyNJfiJ625C32QIDAQAB\n-----END PUBLIC KEY-----');
    var Encrypt = {
        rsaEncrypt: function (text) {
            return RSAENCRYPT.encrypt(text);
        }
    };
    return Encrypt;
});