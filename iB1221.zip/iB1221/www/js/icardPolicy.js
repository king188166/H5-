/**
 * by xuke163@pingan.com.cn
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        events: {
            'tap #js-check': 'agreeContract',
            'tap .qianming': 'esign',
            'tap #js-btn-submit': 'doSubmit',
            'tap #js-insurance-borrow': 'checkBorrow',
            'tap #js-insurance-item': 'checkItem',
            'tap #js-insurance-credit': 'checkCredit'
        },
        initialize: function() {
            var self = this;
            self.lock = 1;
            self.online_domesticAlgorithm = 'Y';
            self.online_OcrNeed = 'N';
            self.online_OcrKey = 'N';
            self.from = C.Utils.getQueryMap().from;
            
            var queryApplyInfo = C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA);
            this.isFirstPay = self.from == 'loan_apply.html' ? C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO).isFirstPay : queryApplyInfo.isFirstPay; 
            this.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
            
            this.applyNo = self.from == 'loan_apply.html' ? C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).applyNo : queryApplyInfo.applyNo;
            
            C.Native.setHeader({
                title: '投保单',
                isBack: 1
            });            

            var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO),
                repayment = self.from == 'loan_apply.html' ? C.Utils.data(C.Constant.DataKey.LOAN_APPLY_AMOUNT) :C.Utils.data(C.Constant.DataKey.BT_REPAYMENT);

            this.accountId = userInfo.accountId;

            this.data = {
                custName: userInfo.custName,
                loanAmt: repayment.loanAmt,
                term: repayment.term || C.Utils.data(C.Constant.DataKey.LOAN_REPAY_PLAN).term
            };   

            this.data.mobile = userInfo.mobile.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2');
            this.data.Id = userInfo.Id.replace(/^(\d{4})\d{10}(.{4})$/, '$1**********$2');
            C.UI.stopLoading();
            this.getSwitch();
            C.Native.getUserInfo(function(data) {
                C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                self.isSigned();
            });
            this.render(this.data);
        },
        render: function(data){
            $('#privacy').prepend(_.template($('#content-privacy').html(), data));
            $('#date').append(C.Utils.parseDateFormat(new Date()));
        },
        agreeContract: function(e){
            $(e.currentTarget).toggleClass('checked');
            if(this.lock == 0){
                if($(e.currentTarget).is('.checked')){
                    $('#js-btn-submit').removeClass('dn');
                }else{
                    $('#js-btn-submit').addClass('dn');
                }
                
            }            
        },
        esign: function(e){
            var self = this;
            var $target = $(e.currentTarget);
            var barCode = 'iloanbt' + Math.round(Math.random() * 1000) + new Date().getTime();
            if ($target.hasClass('justClick')) {
                return;
            }
            $target.addClass('justClick');
            setTimeout(function() {
                $target.removeClass('justClick');
            }, 2000);
            //var esignParam = {};
            C.Native.getAppVersion(function(res) {
                self.appVersion = parseInt(res.version);
                //499之后的app，android和ios均调用5个参数的方法
                if (res.version && parseInt(res.version) >= 499) {
                    C.Native.esign3({
                        domesticAlgorithm: self.online_domesticAlgorithm,
                        barCode: barCode,
                        enText: self.authText,
                        keyWord: '客户签名：'
                    }, function(res) {
                        console.log(res);
                        if (typeof res == 'string') {
                            res = JSON.parse(res);
                        }
                        if (typeof res.signData == 'string') {
                            res.signData = JSON.parse(res.signData);
                        }
                        if (res.code == '1') {
                            if (res.result && res.result.imageData) {
                                self.barCode = barCode;
                                self.imgBytes = res.result.imageData;
                                self.imgDenseStr = res.result.signData;
                                $('#qian-input').hide();
                                var srcStr = 'data:image/jpg;base64,' + self.imgBytes;
                                $('#img').attr('src', srcStr).show();
                                $('#result').attr('value', self.imgDenseStr);
                                if($('#js-check').is('.checked')){
                                    $('#js-btn-submit').removeClass('dn');
                                }                               
                                self.lock = 0;
                            }
                        } else {
                            C.Native.tip('电子签名出错' + res.msg);
                        }
                    });
                }
            });
        },
        //获取电子签名在线开关文件

        getSwitch: function() {
            var self = this;
            $.ajax({
                url: C.Api('ALL_ILOAN_SWITCH', 'SWITCH'),
                cache: false,
                type: 'GET',
                success: function(res) {
                    if (res.code == '1' && 　res.data) {
                        self.online_domesticAlgorithm = res.data.esignOCR.domesticAlgorithm;
                        self.online_OcrNeed = res.data.esignOCR.OcrNeed;
                        self.online_OcrKey = res.data.esignOCR.OcrKey;
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });

        },
        /**
         * 判断是否可以电子签名
         * */
        isSigned: function() {
            var self = this,
                userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
                //productType = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).productType;
            if (!userdata) { //本地没有用户登录态
                return;
            }
            if (this.isSign) {
                //已电子签名
                
            } else {
                self.authText = $('#privacy').html();
            }
        },
        doSubmit: function(){
            C.UI.loading();
            var self = this;
            $.ajax({
                url: C.Api('INSURE_VERIFY'),
                type: 'POST',
                data: {
                    applyNo: this.applyNo,
                    payAppyNo: this.payApplyNo,
                    periodInsurance: this.data.term,
                    insuredAmount: this.data.loanAmt,
                    businessNo: this.barCode,
                    imgBytes: this.imgBytes,
                    imgDenseStr: this.imgDenseStr,
                    accountId: this.accountId,
                    productType: 'I',
                    platform: App.IS_IOS ? 'IOS' : 'A',
                    productId: 'ILOANBT',
                    isDomesticAlgorithm: self.online_domesticAlgorithm,
                    ocrKey: self.online_OcrNeed,
                    ocrNeed: self.online_OcrKey
                },
                success: function(res) {
                    C.UI.stopLoading();
                    if (res && res.flag == C.Flag.SUCCESS) {
                        if(res.data.resultCode == '1'){
                            if(self.from == 'loan_apply.html'){
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-0402-投保单',
                                    eventLable: 'iBT-040201-确认投保单'
                                });
                                C.Native.forward({ 
                                    url: 'loan_info.html',
                                    data: {
                                        from: C.Constant.DataUrl.TRANSPAGE.POLICY
                                    }
                                });
                            }else{
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-030302-投保单',
                                    eventLable: 'iBT-03030201-确认投保单'
                                });
                                C.Native.forward({ 
                                    title: C.Constant.Enum.TITLE.BORROW,
                                    url: C.Constant.DataUrl.TRANSPAGE.BORROW
                                }); 
                            }
                        }else{
                            C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
                        }
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                }
            });
        },
        checkBorrow: function(){
            C.Native.forward({ 
                url: 'insurance_loan_item.html'
            });
        },
        checkItem: function(){
            C.Native.forward({ 
                url: 'insurance_item.html'
            });
        },
        checkCredit: function(){
            C.Native.forward({ 
                url: 'insurance_credit_item.html'
            });
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});