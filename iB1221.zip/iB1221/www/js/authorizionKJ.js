/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-12-04
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-快捷支付协议
 */
/*global define:false*/
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .btn': 'makeSure'
        },
        initialize: function () {
            C.Native.setHeader({
                title: '快捷支付协议',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});