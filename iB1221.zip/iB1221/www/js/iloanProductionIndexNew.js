/**
 * @author: ex-zhangkeming001@pingan.com.cn
 * @date  : 2017-11-15
 * @time  : 上午09:50
 *
 * @describe: iLoanBT-新产品展示页 A/Btest
 */
define(['zepto', 'C', 'view', 'js/refresh', 'js/callback'], function ($, C, View, RE, CB) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #experience_btn': 'experienceLoan', // 马上体验
            'tap #btn_more': 'toProductPage'
        },
        nodeObj: {
            'AU': 'credit_info_list.html',
            'AM': 'credit_info_list.html',
            'AF': 'credit_info_list.html',
            'AC': 'credit_info_list.html',
            'AY': 'credit_info_list.html',
            'AP': 'loan_select.html',
            'RP': 'account_iloan.html',
            'RJ': 'credit_fail_result.html',
            'XX': ''
        },
        initialize: function () {
            var self = this;
            var frompage = C.Utils.getParameter('frompage');
            self.isPosting = false;
            self.ageSign = false;
            // var iloanH5Result = C.Utils.data("QUERY_ILOAN_H5_RESULT");
            //初始化，新产品介绍页 页面埋点
            C.Native.TDOnEvent({
                eventId: '$_03_0_0_65_新产品介绍页' 
            });

            if (App.IS_SDK) {
                C.Native.getUIParams(function (data) {
                    var productName = data.productName || data.proName;
                    C.Native.setHeader({
                        title: productName ? productName : 'i贷',
                        leftCallback: function () {
                            CB.init();
                        },
                        rightIcon: 'iloan_lmpp',
                        rightCallback: function () {
                            //新埋点‘关于i贷’
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_1_01_03_产品介绍页' 
                            });
                            C.Native.forward({
                                url: 'iloan_lmpp.html'
                            });
                        }
                    });
                });

                C.Native.getAppVersion(function (res) {
                    self.iloanVersion = res.iloanVersion;
                });
                return;
            }

            $('#content').show();

            if (frompage == 'home') {
                C.Native.setHeader({
                    title: 'i贷',
                    leftCallback: function () {
                        C.Native.back();
                    },
                    rightIcon: 'iloan_lmpp',
                    rightCallback: function () {
                        //新埋点‘关于i贷’
                        C.Native.TDOnEvent({
                            eventId: '$_03_1_1_01_03_产品介绍页'
                        });
                        C.Native.forward({
                            url: 'iloan_lmpp.html'
                        });
                    }
                });
            } else {
                C.Native.setHeader({
                    title: 'i贷',
                    leftCallback: function () {
                        C.Native.backModule({
                            moduleName: C.Constant.MODULE_NAME.home,
                            url: C.Constant.index_page
                        });
                    },
                    rightIcon: 'iloan_lmpp',
                    rightCallback: function () {
                        //新埋点‘关于i贷’
                        C.Native.TDOnEvent({
                            eventId: '$_03_1_1_01_03_产品介绍页'
                        });
                        C.Native.forward({
                            url: 'iloan_lmpp.html'
                        });
                    }
                });
            }
            C.UI.stopLoading();

            //请求判断是否H5外置用户接口,如果是,就弹出3s窗口
            C.Native.getUserInfo(function (data) {
                var param = {tel: data.mobile};

                self.userInfo = data;
                C.Native.getAppVersion(function (res) {
                    if (App.IS_ANDROID && res.version >= 430) {
                        C.Native.loadingBeginNew('', false);
                    } else {
                        C.UI.loading();
                    }
                });
                C.Native.rSAEncode(param, function (data) {
                    $.ajax({
                        type: 'post',
                        url: C.Api('QUERY_APPH5_ILOAN'),
                        data: {
                            jsonPara: JSON.stringify({
                                accountId: self.userInfo.accountId,
                                tel: data.result.tel
                            })
                        },
                        success: function (res) {
                            if (C.Flag.SUCCESS == res.flag) {  // 存在成功预约授信 && 已生成I贷申请
                                if ((res.data.isAppoint == 1 && res.data.isAppl == 1 && res.data.isCredit == 0) || (res.data.isAppoint == 1 && res.data.isAppl == 0 )) {
                                    C.Utils.data(C.Constant.DataKey.QUERY_ILOAN_H5_RESULT, res.data);
                                    C.UI.stopLoading();
                                    $('.js-layear-3s').removeClass('dn');
                                    var count = 3;
                                    var setIn = setInterval(function () {
                                        count = --count;
                                        if (count != 0) {
                                            $('.n-time').html(count);
                                        } else {
                                            clearInterval(setIn);
                                            self.experienceLoan();
                                        }
                                    }, 1000);
                                } else {
                                    C.UI.stopLoading();
                                }
                            }
                        },
                        error: function () {
                            C.UI.stopLoading();
                        }
                    });
                    
                });
            });
        },
        toProductPage: function () {
            //埋点： 8.29新增
            C.Native.TDOnEvent({
                eventId: 'iBT-01-产品介绍页',
                eventLable: 'iBT-0101-产品详细介绍页'
            });
            //埋点 信用卡了解更多
            C.Native.TDOnEvent({
                eventId: '$_03_1_1_01_02_产品介绍页'
            });
            C.Native.forward({
                url: 'product-detail.html'//i贷 产品详情页
            });
        },
        // 马上体验
        experienceLoan: function (e) {
            var self = this,
                xydSign = C.Utils.data('XIAO_YUAN_DAI') || [],
                userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            if (self.isPosting || self.ageSign) {
                return false;
            }
            C.Native.TDOnEvent({
                eventId: 'iBT-01-产品介绍页',
                eventLable: 'iBT-02-完善信息'
            });
            //埋点 马上体验 按钮 
            C.Native.TDOnEvent({
                eventId: '$_03_1_0_65_01_新产品介绍页'
            });
            self.isPosting = true;
            RE.init(function (res) {   //申请状态查询接口
                //封堵SDK未升级包的用户
                if (res.data.fundingModel == 'D' || res.data.fundingModel == 'U') {
                    if (App.IS_SDK && !self.iloanVersion) {
                        C.Native.tip('尊敬的客户，为了让您更快更好的使用产品，请您将APP更新至最新版本！');
                        return;
                    }
                }
                C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, res.data);
                C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, res.data.applyNo || null);
                if (res.data.applySwitch && res.data.applySwitch == '0') {//关闭
                    C.Native.tip(res.data.switchMsg);
                } else {                                                 //申请开关打开
                    if (self.nodeObj[res.data.subProcessCode] == '') {
                        C.Native.tip(res.data.resultMsg);
                    } else {
                        if (res.data.subProcessCode == 'RJ') {
                            //埋点 授信结果页 审核拒绝 （事件结果）
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_2_11_02_授信结果页'
                            });
                            C.Native.TDOnEvent({
                                eventId: 'iBT-02-完善信息',
                                eventLable: 'iBT-07-拒绝'
                            });
                        }
                        //新增禁止校园贷优化需求
                        if (xydSign && xydSign.indexOf(userInfo.accountId) == -1 && userInfo.Id && C.Utils.ageCheck(userInfo.Id, 18, 23) == 1) {
                            xydSign.push(userInfo.accountId);
                            C.Utils.data('XIAO_YUAN_DAI', xydSign);
                            self.ageSign = true;
                            C.Native.tip('在校学生禁止申请，如发现借款人身份为学生，我公司可采取停止发放借款、要求提前还款等措施');
                            setTimeout(function () {
                                self.ageSign = false;
                                C.Native.forward({
                                    url: self.nodeObj[res.data.subProcessCode],
                                    data: {
                                        rule: 'A'      // 从新广告页面跳转
                                    }
                                });
                            }, 2000);
                            return;
                        }
                        C.Native.forward({
                            url: self.nodeObj[res.data.subProcessCode],
                            data: {
                                rule: 'A'      // 从新广告页面跳转
                            }
                        });
                    }
                }
                self.isPosting = false;
            }, function (res) {
                $('.js-layear-3s').addClass('dn');
                self.isPosting = false;
            });
        }
        //年龄校验
        //ageCheck: function (id) {
        //    var birthday,
        //        min = 567648000000, //18*365*24*60*60*1000
        //        max = 725328000000, //23*365*24*60*60*1000
        //        curYear = new Date().getTime();//获取当前年份
        //    if (id.length == 15 || id.length == 18) {
        //        //截取出生年月
        //        birthday = id.length == 15 ? '19' + id.substr(6, 6): id.substr(6, 8);
        //        //将出生年月转为时间戳
        //        birthday = new Date(birthday.substr(0, 4), (parseInt(birthday.substr(4, 2)) - 1), birthday.substr(6, 2)).getTime();
        //        if (min <= curYear - birthday && curYear - birthday < max) {
        //            //在限定的年龄范围内
        //            return 1;
        //        }
        //        //不在年龄限制范围内
        //        return -1;
        //    }
        //    //身份证长度不符合
        //    return -1;
        //}
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
