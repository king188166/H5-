/**
 * @Author : liujinhuan647@pingan.com.cn
 * @Date   : 2016-3-18
 * @Time   : am 10:37
 *
 * @Description: 定位失败页面
 */
/*global define:false*/
define(['zepto', 'C', 'view', 'js/common/iloanInside', 'js/refresh'], function ($, C, View, L, RE) {

    'use strict';

    var Page = View.extend(_.extend({

        events: {
            'tap .to-getCityname': 'toGetCityname'
        },

        nodeObj: {
            'AU': 'credit_info_list.html',
            'AM': 'credit_info_list.html',
            'AF': 'credit_info_list.html',
            'AC': 'credit_info_list.html',
            'AY': 'credit_info_list.html',
            'AP': 'loan_select.html',
            'RP': 'account_iloan.html',
            'RJ': 'credit_fail_result.html',
            'XX': ''
        },

        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '定位失败',
                isBack: false
            });
            self.isPosting = false;
            self.userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {};
            self.frompage = C.Utils.getParameter('frompage');
            self.render();
        },
        // 渲染整个view
        render: function () {
            var html = _.template($('#fail-tpl').html())({});
            this.$el.find('.to-result-content').html(html);
            C.UI.stopLoading();
        },

        toGetCityname: function () {
            var self = this;
            if (self.isPosting) {
                return;
            }
            self.isPosting = true;
            C.UI.loading();
            C.Native.getUserInfo(function (data) {
                C.Utils.data('BT_ILOAN_USER_LOGIN_INFO', data);
                C.Native.getCityName(function (result) {
                    C.UI.stopLoading();
                    self.isPosting = false;
                    var cityName = result.cityName;
                    if (!!cityName) {
                        C.Utils.data(C.Constant.DataKey.BT_ILOAN_CITYNAME, cityName);
                        //如果获取得到，给iloan也保存一份
                        C.Utils.data('ILOAN_CITYNAME', cityName);
                        //如果点击首页i贷，未获取到地理位置，跳转到iloanbt模块里面，点击确定，进行判断跳转
                        if (self.frompage && self.frompage == 'home') {
                            C.Native.backModule({
                                moduleName: C.Constant.MODULE_NAME.home,
                                url: C.Constant.index_page
                            });
                        } else {//内部模块进来的话，点击就判断进入iloanbt里面的哪一个页面
                            self.iLoanBTClick(cityName);
                        }
                    } else {
                        C.Utils.data(C.Constant.DataKey.BT_ILOAN_CITYNAME, null);
                    }
                });
            });
            setTimeout(function () {
                self.isPosting = false;
                C.UI.stopLoading();
            }, 2000);
        },

        iLoanBTClick: function (cityname) {
            var self = this;
            if (self.isPosting) {
                return false;
            }
            self.isPosting = true;
            C.UI.loading();
            RE.init(function (res) {
                self.isPosting = false;
                C.UI.stopLoading();
                C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, res.data);
                C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, res.data.applyNo || null);
                if (self.nodeObj[res.data.subProcessCode] == '') {
                    C.Native.tip(res.data.resultMsg || res.msg);
                } else {
                    C.Native.forward({
                        url: self.nodeObj[res.data.subProcessCode]
                    });
                }
            }, function (res) {
                self.isPosting = false;
            });
        }

    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});

