/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 * @describe: iLoan定期-完善信息
 */
define(['zepto', 'C', 'view', 'js/refresh', 'js/callback'], function ($, C, View, RE, CB) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .info_list_tap': 'liTapEvent',
            'tap #disagree_btn': 'hideEsignTpl',
            'tap #agree_btn': 'submitEsign',
            'tap .qianming': 'esign',          //综合授权书中的签名
            'tap #continueWait': 'closeTip',
            'tap .js-ihaveknow': 'phoneOauth',
            'tap .phone_layer': 'toHidePhoneLayer'
        },

        suctiphtml: '<p>恭喜您审核成功，最高额度<span id="money-limit" class="red"></span></p><p>您可继续提升额度，或直接选择产品！</p>',
        waittiphtml: '<p class="icon-wait"></p><p>额度审核中，请耐心等待！</p>',
        undonetiphtml: '<p>差一点您就获取额度啦</p><p>赶快进行手机运营商校验吧</p>',
        promotelimithtml: '<p>额度太低？没关系，立即提升额度吧！</p>',
        failtip: '<p>对不起运营商开小差啦，您要再校验一次哦</p>',
        initialize: function () {
            //埋点 完善信息页
            C.Native.TDOnEvent({
                eventId: '$_03_0_2_03_完善信息页'
            });
            var _this = this;
            _this.isPosting = false;
            _this.isAuth = true;
            _this.isSign = true;
            _this.barCode = '';
            _this.online_domesticAlgorithm = 'Y';
            _this.online_OcrKey = 'N';
            _this.online_OcrNeed = 'N';
            //当前状态展示: 0-未实名认证，1-未签名，2-AU，3-AM，4-AF，5-AC，6-AY，7-AYAC，8-AP
            _this.rendFlag = 0;
            _this.signElectSw = '';
            _this.isCreditAuthenticating = '';
            _this.formatCredit = '';
            _this.percentShow = $('#info_percent');
            _this.resetHeader();
            C.UI.stopLoading();

            _this.getSwitch();
            if (!C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO)) {
                C.Native.getUserInfo(function (data) {
                    C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                    _this.refresh();
                });
            } else {
                _this.refresh();
            }
        },

        /**
         * 回设置完善信息头部
         * */
        resetHeader: function () {
            C.Native.setHeader({
                title: '完善信息',
                leftCallback: function () {
                    if (App.IS_SDK) {
                        //从哪个页面而来
                        var adflag = C.Utils.data(C.Constant.DataKey.AD_FLAG);
                        var rule = C.Utils.getQueryMap().rule; // SDK 从新广告页过来的
                        if (adflag && adflag == '0') {
                            CB.init();
                            return;
                        }
                        if(!!rule){    //返回新广告页
                            C.Native.back({
                                url: 'iloan_production_index_new.html'
                            });
                        }else{
                            C.Native.back({
                                url: 'iloan_production_index.html'
                            });
                        }
                        return;
                        
                    }
                    C.Native.backModule({
                        moduleName: C.Constant.MODULE_NAME.home,
                        url: C.Constant.index_page
                    });
                },
                rightIcon: App.IS_SDK ? '' : 'robot_entrance',
                rightCallback: function () {
                    C.Native.gotoNative('onlineCustomerCare');
                }
            });
        },

        /**
         * 状态刷新
         * */
        refresh: function () {
            var _this = this;
            RE.init(function (res) {
                //申请开关关闭
                if (res.data.applySwitch && res.data.applySwitch == '0') {
                    C.Native.tip(res.data.switchMsg);
                    C.Native.forward({
                        url: 'sign_friend.html'
                    });
                } else {
                    //保存申请状态查询接口返回数据
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, res.data);
                    C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, res.data.applyNo || null);
                    //处理不同流程节点
                    if (res.data.realNameAuth == '0') {
                        //没有实名认证
                        _this.percentShow.html('0%');
                        _this.isAuth = false;
                        _this.isSign = false;
                        _this.rendFlag = 0;
                        _this.rendTemplate(res.data);
                    } else if (res.data.electronicSignature == '0' && res.data.realNameAuth == '1' && res.data.subProcessCode == 'AU') {
                        //没有电子签名
                        _this.percentShow.html('25%');
                        _this.isAuth = true;
                        _this.isSign = false;
                        _this.signElectSw = res.data.signElectSw;
                        _this.rendFlag = 1;
                        _this.rendTemplate(res.data);
                    } else if (res.data.subProcessCode == 'RJ') {
                        C.UI.stopLoading();
                        //埋点 授信结果页 审核拒绝 （事件结果）
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_2_11_02_授信结果页'
                        });
                        C.Native.TDOnEvent({
                            eventId: 'iBT-02-完善信息',
                            eventLable: 'iBT-07-拒绝'
                        });
                        C.Native.forward({
                            url: 'credit_fail_result.html'
                        });
                    } else {
                        //根据状态处理
                        _this.isAuth = true;
                        _this.isSign = true;
                        _this.render(res.data);
                    }
                }
            });
        },

        /**
         * 页面渲染
         * */
        render: function (data) {
            var _this = this;
            C.Utils.data(C.Constant.DataKey.EDIT_CONTACT, null);
            C.UI.stopLoading();
            switch (data.subProcessCode) {
                case 'AU':
                    _this.signElectSw = data.signElectSw;
                    _this.percentShow.html('25%');
                    _this.rendFlag = 2;
                    _this.rendTemplate(data);
                    break;
                case 'AM':
                    //缓存是否需要上传通讯录和通话记录和是否可以手动修改联系人
                    C.Utils.data(C.Constant.DataKey.NEED_CONTACT, data.uploadTelBookFlag);
                    C.Utils.data(C.Constant.DataKey.EDIT_CONTACT, data.isContactEdit);
                    C.Utils.data(C.Constant.DataKey.UPLOAD_CONTACT_NUM, data.transferContactNum);
                    _this.percentShow.html('50%');
                    _this.rendFlag = 3;
                    _this.rendTemplate(data);
                    break;
                case 'AF':
                    //保存人脸识别参数
                    C.Utils.data(C.Constant.DataKey.FACE_PARAM, data.faceParam);
                    C.Utils.data(C.Constant.DataKey.FACE_STARTTIME, data.faceStartTime);
                    _this.percentShow.html('75%');
                    _this.rendFlag = 4;
                    _this.rendTemplate(data);
                    break;
                case 'AC':
                    _this.percentShow.html('99%');
                    //轮询时，如果上一个节点的是AY，已经手机运营商了，就把这行展示出来，
                    //如果上一及诶但是人脸识别，就展示到人脸识别就好了、、、
                    _this.rendFlag = data.processCode == 'AY' ? 7 : 5;
                    _this.rendTemplate(data);
                    //AC状态调用轮询接口,显示透明层页面不可点
                    $('.js-updating-win').removeClass('dn');
                    $('#lucenry_leayer').show();

                    setTimeout(function () {
                        _this.loop();
                    }, 5000);
                    break;
                case 'AY':
                    _this.percentShow.html('99%');
                    _this.rendFlag = 6;
                    _this.rendTemplate(data);
                    $('.js-updating-win').addClass('dn');
                    $('#tip-show').removeClass('wait').html(_this.undonetiphtml).removeClass('dn');
                    break;
                case 'AP':
                    _this.isCreditAuthenticating = data.isCreditAuthenticating;
                    _this.formatCredit = C.Utils.formatMoney(data.credit);
                    _this.percentShow.html('100%');
                    _this.rendFlag = data.isFinishMpo == '1' ? 9 : 8;
                    _this.rendTemplate(data);
                    //设置按钮状态
                    $('.js-updating-win').addClass('dn');
                    //1025版本取消强制出现'i贷代还信用卡'的页面介绍
                    //埋点 授信结果页 审核出额 （事件结果）
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_2_11_01_授信结果页'
                    });
                    C.Native.forward({
                        url: 'loan_select.html'
                    });
                    break;
                case 'RP':
                    C.Native.forward({
                        url: 'account_iloan.html'
                    });
                    break;
                case 'XX':
                    C.Native.tip(data.resultMsg);
                    C.Native.forward({
                        url: 'credit_fail_result.html'
                    });
                    break;
            }

        },

        /**
         * rend template
         * */
        rendTemplate: function (data) {
            var _this = this;
            data.id = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).Id;
            data.name = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).custName;
            data.showid = data.id ? _this.formatId(data.id) : '';
            var html = _.template($('#info_list_template').html(), {
                data: data,
                flag: _this.rendFlag
            });
            $('#info-state-list').html(html);
            //在添加银行卡节点,根据不同的放款模式渲染电子签名授权书内容
            if (data.subProcessCode == 'AU' && !App.IS_SDK) {
                _this.rendEsignContract(data);
            }
            C.UI.stopLoading();
        },

        /**
         * 电子签名授权书渲染(1.小贷+担保(老流程)  2.联合放款银行配比大于0  3.联合放款银行配比等于0)
         * */
        rendEsignContract: function (data) {
            if (!data.fundingModel) {
                data.fundingModel = '';
            }
            $('#esign_section').html(_.template($('#js-html-esign').html(), data));
            //显示"银行征信授权书";只有授信才需要显示"银行征信授权书",首次还卡和重查征信不用
            if (data.fundingModel && data.isCredit && data.fundingModel == 'U' && data.isCredit == '1') {
                var bankClass = C.Constant.BANKCONTRACT[data.cgiBankName];
                $('.'+bankClass).removeClass('dn');
            }
        },

        /**
         * 初始化TAB
         * */
        initTabState: function (id) {
            $('#' + id).removeClass('focus').removeClass('active').removeClass('icon-red');
            $('#' + id).find('.txt-one').addClass('dn');
            //隐藏手机运营商tab
            $('#info_phone').addClass('dn');
        },

        /**
         * 吸顶提示信息
         * */
        topTip: function (id) {
            var msg = '请按顺序完成';
            switch (id) {
                case 'info_indentify':
                    msg = '请先实名认证';
                    break;
                case 'info_card':
                    msg = '请先添加银行卡';
                    break;
                case 'info_contact':
                    msg = '请先添加联系人';
                    break;
                case 'info_face':
                    msg = '请先人脸识别';
                    break;
                default:
                    break;
            }
            C.UI.tip({
                tip: msg,
                time: 3000
            });
        },

        /**
         * 列表点击事件
         * */
        liTapEvent: function (e) {
            var _this = this,
                $target = $(e.currentTarget),
                nowid = $('.icon-red').attr('id');
            if (!$target.hasClass('icon-red')) {
                if (!$target.hasClass('active')) {
                    if (nowid) {
                        _this.topTip(nowid);
                    } else {
                        if (_this.faceTimeOver) {
                            C.UI.tip({
                                tip: '您今天人脸识别次数已用光，请明天再来',
                                time: 3000
                            });
                        }
                    }
                }
                return false;
            }
            var id = $target.attr('id');
            switch (id) {
                case 'info_indentify':
                    if (!_this.isAuth) { //未实名认证
                        C.Native.realnameVerification('N', function (res) {
                            if (res.flag == '1') {
                                _this.refresh();
                                C.Native.getUserInfo(function (data) {
                                    C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                                });
                            }
                        });
                    }
                    break;
                case 'info_card':
                     //埋点 添加银行卡
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_03_01_完善信息页'
                    });
                    C.Native.getUserInfo(function (data) {
                        C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                        _this.isSigned();
                    });
                    break;
                case 'info_contact':
                    _this.addContact();
                    C.Native.TDOnEvent({
                        eventId: 'iBT-02-完善信息',
                        eventLable: 'iBT-0203-添加联系人'
                    });
                    //埋点 添加联系人
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_03_02_完善信息页'
                    });
                    break;
                case 'info_face':
                    C.Native.TDOnEvent({
                        eventId: 'iBT-02-完善信息',
                        eventLable: 'iBT-0204-人脸识别'
                    });
                    //埋点 人脸识别
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_03_03_完善信息页'
                    });
                    _this.faceInterView();
                    break;
                case 'info_phone':
                    C.Native.TDOnEvent({
                        eventId: 'iBT-02-完善信息',
                        eventLable: 'iBT-0205-MPO'
                    });
                    //埋点 手机运营商
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_03_04_完善信息页'
                    });
                    var $t = $(e.target);
                    if ($t.hasClass('qa')) { //点击的是小问号，就弹框
                        _this.toShowPhoneLayer();
                    } else {
                        _this.phoneOauth();
                    }

                    break;
                default:
                    break;
            }
        },

        /**
         * 判断是否可以电子签名
         * */
        isSigned: function () {
            var _this = this,
                userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO),
            //联合放款资金模式判断
                fundingModel = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).fundingModel,
                isCredit = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).isCredit,
                loanCompanyCode = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).loanCompanyCode || 'L';
            if (!userdata) { //本地没有用户登录态
                return;
            }
            if (_this.isSign) {
                //已电子签名
                if (userdata.paPayToken) {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-02-完善信息',
                        eventLable: 'iBT-0202-绑定银行卡'
                    });
                    var iloanH5Result = C.Utils.data(C.Constant.DataKey.QUERY_ILOAN_H5_RESULT);
                    //如果是ilaonh5的外置需求，就保存数据，跳转到卡列表页面
                    if (iloanH5Result) {
                        if ((iloanH5Result.isAppoint == 1 && iloanH5Result.isAppl == 1 && iloanH5Result.isCredit == 0) || (iloanH5Result.isAppoint == 1 && iloanH5Result.isAppl == 0)) {
                            var data = {
                                bankCards: [{
                                    bankShortName: iloanH5Result.bankNo,
                                    paPayAccount: iloanH5Result.paPayAccount || '',
                                    bankName: iloanH5Result.bankName,
                                    bankNo: iloanH5Result.bankCardNo
                                }]
                            };
                            $('#esign_section').hide(); // 隐藏综合授权书
                            C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST, data);
                            C.Native.forward({
                                url: 'select_auther_card_list.html',
                                data: {
                                    route: 'back',
                                    url: 'credit_info_list.html',
                                    moduleName: '',
                                    failRoute: 'back',
                                    failUrl: 'credit_info_list.html',
                                    failModuleName: ''
                                }
                            });
                        } else {
                            _this.queryCardList();
                        }
                    } else {
                        _this.queryCardList();
                    }
                } else {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0202-绑定银行卡',
                        eventLable: 'iBT-020203-壹钱包'
                    });
                    //没有静默注册成功
                    C.Native.loginOrRegistPaOne(function () {
                        C.Native.getUserInfo(function (data) {
                            C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                        });
                    });
                }
            } else {
                //埋点 综合授权书
                C.Native.TDOnEvent({
                    eventId: '$_03_0_2_04_综合授权书页'
                });
                C.Native.TDOnEvent({
                    eventId: 'iBT-02-完善信息',
                    eventLable: 'iBT-0201-综合授权书'
                });
                if (App.IS_SDK) {
                    C.Native.forward({
                        url: 'old_personal-credit.html',
                        data: {
                            fromPage: 'credit_info_list',
                            fundingModel: fundingModel,
                            isCredit: isCredit,
                            loanCompanyCode: loanCompanyCode
                        }
                    });
                    return;
                }
                //未电子签名弹出综合授权书,分老流程和联合放款;L 担保+小贷（默认值）, D CGI+小贷,U CGI+联合放款
                if (fundingModel && (fundingModel == 'U' || fundingModel == 'D')) {
                    $('#zxsq_cgi').show();
                    _this.authText = $('#zxsq_cgi').html();
                    switch (loanCompanyCode) {
                        case 'C':
                            $('.zxsq_cgi_c').show();
                            break;
                        case 'H':
                            $('.zxsq_cgi_h').show();
                            break;
                        default:
                            $('.zxsq_cgi_l').show();
                            break;
                    }
                } else {
                    if (loanCompanyCode == 'C') {
                        $('#zxsq_l').hide();
                        $('#zxsq_c').show();
                        _this.authText = $('#zxsq_c').html();
                    } else {
                        $('#zxsq_c').hide();
                        $('#zxsq_l').show();
                        _this.authText = $('#zxsq_l').html();
                    }
                }
                if (_this.signElectSw != 'Y') {
                    $('#esign_section').find('.signature').hide();
                } else {
                    $('#esign_section').find('.signature').show();
                }
                $('#esign_section').show();
            }
        },

        /**
         * 调用Native电子签名接口
         * */
        esign: function (e) {
            var fundingModel = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).fundingModel;
            //埋点 电子签名 综合授权书
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_04_01_综合授权书页'
            });

            if (fundingModel && (fundingModel == 'U' || fundingModel == 'D')) {
                //联合放款电子签名埋点
                C.Native.TDOnEvent({
                    eventId: 'iBT-0211-综合授权书',
                    eventLable: 'iBT-021101-电子签名'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0201-综合授权书',
                    eventLable: 'iBT-020101-电子签名'
                });
            }
            var _this = this;
            var $target = $(e.currentTarget);
            var barCode = 'iloanbt' + Math.round(Math.random() * 1000) + new Date().getTime();
            
            if ($target.hasClass('justClick')) {
                return;
            }
            $target.addClass('justClick');
            setTimeout(function () {
                $target.removeClass('justClick');
            }, 2000);

            C.Native.esign3({
                domesticAlgorithm: _this.online_domesticAlgorithm,
                barCode: barCode,
                enText: _this.authText,
                keyWord: ''
            }, function (res) {
                console.log(res);
                if (typeof res == 'string') {
                    res = JSON.parse(res);
                }
                if (typeof res.signData == 'string') {
                    res.signData = JSON.parse(res.signData);
                }
                if (res.code == '1') {
                    if (res.result && res.result.imageData) {
                        _this.barCode = barCode;
                        _this.imgBytes = res.result.imageData;
                        _this.imgDenseStr = res.result.signData;
                        $('#qian-input').hide();
                        var srcStr = 'data:image/jpg;base64,' + _this.imgBytes;
                        $('#img').attr('src', srcStr).show();
                        $('#result').attr('value', _this.imgDenseStr);
                    }
                } else {
                    C.Native.tip('电子签名出错' + res.msg);
                }
            });
        },
        /**
         * 查询该账号是否有已绑定卡列表
         * */
        queryCardList: function (callback) {
            var userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            if (!userdata) return;
            C.UI.loading();
            C.Native.getDeviceInfo(function (data) {
                var param = {
                    curVer: data.appVersion,
                    machineSN: data.MachineSN || data.machinesn,
                    mobileNo: userdata.mobile,
                    loanType: '2'
                };
                $.ajax({
                    url: C.Api('BINDBANKCARDS'),
                    data: param,
                    type: 'post',
                    success: function (res) {
                        if (res.flag == C.Flag.SUCCESS && res.data) {
                            if (res.data.bankCards && res.data.bankCards.length > 0) {
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-0202-绑定银行卡',
                                    eventLable: 'iBT-020202-选择银行卡'
                                });
                                $('#esign_section').hide();
                                C.Utils.data(C.Constant.DataKey.BIND_CARDS_LIST, res.data);
                                C.Native.forward({
                                    url: 'select_auther_card_list.html',
                                    data: {
                                        route: 'back',
                                        url: 'credit_info_list.html',
                                        moduleName: '',
                                        failRoute: 'back',
                                        failUrl: 'credit_info_list.html',
                                        failModuleName: ''
                                    }
                                });
                            } else {
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-0202-绑定银行卡',
                                    eventLable: 'iBT-020201-添加银行卡'
                                });
                                $('#esign_section').hide();
                                C.Native.forward({
                                    url: 'credit_bind_card.html',
                                    data: {
                                        route: 'back',
                                        url: 'credit_info_list.html',
                                        moduleName: '',
                                        failRoute: 'back',
                                        failUrl: 'credit_info_list.html',
                                        failModuleName: ''
                                    }
                                });
                            }
                        }
                        C.UI.stopLoading();
                    },

                    complete: function () {
                        C.UI.stopLoading();
                    }
                });
            });
        },

        /**
         * 手机运营商认证
         * */
        phoneOauth: function () {
            //跳转至手机运营商
            $('.phone_layer').addClass('dn');
            C.Native.TDOnEvent({
                eventId: 'iBT-0205-MPO',
                eventLable: 'iBT-020501-我已了解'
            });
            //埋点 手机运营商页 我已了解
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_10_01_手机运营商页'
            });
            C.Native.forward({
                url: 'authentication.html'
            });
        },
        /**
         * 隐藏弹出的运营商提示框
         * */
        toHidePhoneLayer: function () {
            $('.phone_layer').addClass('dn');
        },
        /**
         * 显示弹出的运营商提示框
         * */
        toShowPhoneLayer: function () {
            $('.phone_layer').removeClass('dn');
        },


        /**
         * 关闭提示
         * */
        closeTip: function () {
            $('#onNetCheckTip').hide();
        },


        /**
         * 隐藏授权书电子签名
         * */
        hideEsignTpl: function () {
            var fundingModel = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).fundingModel;

            //埋点 不同意 综合授权书
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_04_03_综合授权书页'
            });
            if (fundingModel && (fundingModel == 'U' || fundingModel == 'D')) {
                //联合放款电子签名埋点
                C.Native.TDOnEvent({
                    eventId: 'iBT-0211-综合授权书',
                    eventLable: 'iBT-021103-不同意'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0201-综合授权书',
                    eventLable: 'iBT-020103-不同意'
                });
            }
            $('#esign_section').hide();
            $('#img').hide().attr('src', '');
            $('#result').val('');
            $('#qian-input').show();
        },

        /**
         * 提交电子签名信息
         * */
        submitEsign: function () {
            var fundingModel = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).fundingModel;

            //埋点 同意 综合授权书
            C.Native.TDOnEvent({
                eventId: '$_03_1_2_04_02_综合授权书页'
            });
            if (fundingModel && (fundingModel == 'U' || fundingModel == 'D')) {
                //联合放款电子签名埋点
                C.Native.TDOnEvent({
                    eventId: 'iBT-0211-综合授权书',
                    eventLable: 'iBT-021102-同意'
                });
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0201-综合授权书',
                    eventLable: 'iBT-020102-同意'
                });
            }
            var _this = this;
            //联合放款新增入参
            var cgiBankName = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).cgiBankName;
            var ratio = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).ratio;
            if (_this.isPosting) return false;
            var isSigned = !$('#result')[0].value ? false : true;
            //===测试数据直接提交电子签名
            if (!isSigned && _this.signElectSw == 'Y') {
                //提示需要先签名
                C.Native.tip('请先签名');
                return;
            }
            var params = {};
            _this.isPosting = true;
            C.UI.loading();
            if (_this.signElectSw == 'Y') {
                params.imgDenseStr = _this.imgDenseStr;
                params.imgBytes = _this.imgBytes;
            }
            params.productType = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).productType;
            params.loanCompanyCode = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).loanCompanyCode || 'L';
            params.platform = App.IS_IOS ? 'IOS' : 'A';
            params.businessNo = _this.barCode;
            if (!!fundingModel) {
                params.fundingModel = fundingModel;
            }
            if (!!cgiBankName) {
                params.cgiBankName = cgiBankName;
            }
            if (!!ratio) {
                params.ratio = ratio;
            }
                
            params.ocrKey = _this.online_OcrKey;
            params.ocrNeed = _this.online_OcrNeed;
            params.productId = 'ILOANBT';
            params.isDomesticAlgorithm = _this.online_domesticAlgorithm;
            
            $.ajax({
                url: C.Api('UPLOADPOSELECTRONICSIGNATURE'),
                type: 'post',
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function (res) {
                    if (res.flag == '1') {
                        //埋点  签名成功 综合授权书
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_2_04_01_综合授权书页'
                        });
                        _this.isSign = true;
                        _this.isSigned();
                    } else { //OCR识别的结果校验，=3代表校验不通过需要重新签名;=2代表接口有问题
                        //埋点  签名失败 综合授权书
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_2_04_02_综合授权书页'
                        });
                        $('#img').hide().attr('src', '');
                        $('#result').val('');
                        $('#qian-input').show();
                    }
                },
                complete: function (res) {
                    C.UI.stopLoading();
                    _this.isPosting = false;
                }
            });
        },

        /**
         * 上传联系人
         * */
        addContact: function () {
            //跳转至联系人添加页面
            C.Native.forward({
                url: 'credit_info_contact.html'
            });
        },

        /**
         * 人脸识别
         * */
        faceInterView: function () {
            var _this = this;
            if (_this.isDoing) {
                return false;
            }
            _this.isDoing = true;
            var param = {
                faceParam: C.Utils.data(C.Constant.DataKey.FACE_PARAM),
                applNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO),
                firstStartTime: C.Utils.data(C.Constant.DataKey.FACE_STARTTIME),
                cardNumber: C.Utils.data(C.Constant.DataKey.CARD_NO)
            };

            C.Native.TDOnEvent({
                eventId: 'iBT-0204-人脸识别',
                eventLable: 'iBT-020401-准备提示页'
            });
            C.Native.faceRecognise(param, function (data) {
                console.log(JSON.stringify(data));
                //人脸识别返回判断
                _this.isDoing = false;
                if (data.code == '1') {
                    C.Native.forward({
                        url: 'credit_identification_suc.html'
                    });
                } else if (data.code == '2') { //放弃人脸识别操作,回到完善信息页面是要重新load的
                    location.reload();
                } else if (data.code == '4') {
                    //人脸识别次数超限提示
                    _this.faceTimeOver = true;
                    _this.initTabState('info_face');
                }
            });
        },

        /**
         * 格式化身份证
         * */
        formatId: function (str) {
            if (typeof str == 'string') {
                return '**** **** ****' + str.substr(str.length - 4);
            }
        },

        /**
         * 轮询接口
         * */
        loop: function () {
            var _this = this;
            var fn = function () {
                var param = {
                    applyNo: C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO),
                    queryType: 'ibtCredit'
                };
                $.ajax({
                    url: C.Api('AUDITPOLLING'),
                    type: 'post',
                    data: {
                        jsonPara: JSON.stringify(param)
                    },
                    success: function (res) {
                        if (res.flag == '1' && res.data) {
                            if (res.data.polling == '0') {
                                //不需要在轮询,隐藏透明层
                                $('#lucenry_leayer').hide();
                                _this.refresh();
                            } else {
                                //继续轮询
                                setTimeout(function () {
                                    fn();
                                }, 5000);
                            }
                        }
                    },
                    complete: function () {
                        // empty
                    }
                });
            };
            fn();
        },
        //获取电子签名在线开关文件

        getSwitch: function () {
            var _this = this;
            $.ajax({
                url: C.Api('ALL_ILOAN_SWITCH', 'SWITCH'),
                cache: false,
                type: 'GET',
                success: function (res) {
                    if (res.code == '1' && res.data) {
                        _this.online_domesticAlgorithm = res.data.esignOCR.domesticAlgorithm;
                        _this.online_OcrNeed = res.data.esignOCR.OcrNeed;
                        _this.online_OcrKey = res.data.esignOCR.OcrKey;
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });

        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function () {
            location.reload();
        };
    });
});