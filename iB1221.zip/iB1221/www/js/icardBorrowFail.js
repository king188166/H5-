/**
 * @author: xuke163@pingan.com.cn
 * @date  : 2016-10-19
 * @describe: 申请失败
 */
 define(['zepto', 'C', 'view'], function ($, C, View) {
    // body...
     'use strict';
     var Page = View.extend({
         events: {
             'tap #js-btn': 'confirmFail'
         },
         talkingDate: function(key) {
             var first = {
                 '确认借款': {
                     eventId: 'iBT-0303010102-确认借款',
                     eventLable: 'iBT-030301010202-借款失败'
                 }
             };
             var noFirst = {
                 '确认借款': {
                     eventId: 'iBT-0605020101-确认借款',
                     eventLable: 'iBT-060502010102-失败'
                 }
             };
             return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
         },
        //初始化
         initialize: function(){
             C.Native.setHeader({
                 title: C.Constant.Enum.TITLE.BORROWFAIL,
                 isBack: false,
                 leftCallback: function(){return this;}
             });
             this.isFirstPay = C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA).isFirstPay;
             C.Native.TDOnEvent(this.talkingDate['确认借款']);
             //埋点 借款失败页 
             C.Native.TDOnEvent({
                 eventId: '$_03_0_4_30_借款失败页'
             });
             C.UI.stopLoading(); 
         },
         confirmFail: function(e){
             C.Native.TDOnEvent({
                 eventId: 'iBT-07-拒绝',
                 eventLable: 'iBT-0701-返回首页'
             });
             //埋点 借款失败页 确定按钮
             C.Native.TDOnEvent({
                 eventId: '$_03_1_4_30_01_借款失败页'
             });
             if (this.isFirstPay == 'Y'){
                 //SDK 中对字段是否为非数字值的判断
                 if (C.Utils.getParameter('isSignSuccess') == '1') {
                     C.Native.loadPage({
                         url: [C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN].join('/')
                     });
                 }else{
                     C.Native.back({
                         url: [C.Constant.DataUrl.TRANSPAGE.LOANSELECT].join('/')
                     });
                 }                                   
             }else{
                 C.Native.loadPage({
                     url: [C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN].join('/')
                 });
             }
         }          
     });
     $(function() {
         new Page({
             el: $('body')[0]
         });
     });
 });
           