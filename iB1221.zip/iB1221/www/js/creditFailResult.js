/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2016-3-21
 * @time  : pm 16:54
 *
 * @describe: iLoan定期-授信失败
 */
define(['zepto', 'C', 'view', 'js/callback'], function ($, C, View, CB) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #back_to_home': 'backToHome'
        },
        initialize: function () {
            C.Native.setHeader({
                title: '申请失败',
                isBack: false
            });
            C.UI.stopLoading();
            self.isPosting = false;
        },
        /**
         * 点击回到首页
         * */
        backToHome: function () {
            var self = this;
            if (self.isPosting) {
                return;
            }
            self.isPosting = true;
            C.UI.loading();
            var RJFROM = C.Utils.data(C.Constant.DataKey.BT_RJ_FROM);
            if (RJFROM && RJFROM == 'RP') {
                C.Utils.data(C.Constant.DataKey.BT_RJ_FROM, '');
                C.Native.back({
                    url: 'account_iloan.html'
                });
            } else {
                if(App.IS_SDK){
                    //不展示广告页，点击返回首页，退出SDK
                    var form = C.Utils.getParameter('route');
                    var rule = C.Utils.getParameter('rule');
                    if ('entrance' == form) {
                        C.UI.stopLoading();
                        CB.init();
                    }else{
                        if(!!rule){    //返回新广告页
                            C.Native.back({
                                url: 'iloan_production_index_new.html'
                            });
                        }else{
                            C.Native.back({
                                url: 'iloan_production_index.html'
                            });
                        }
                    }

                }else{
                    C.Native.backModule({
                        moduleName: C.Constant.MODULE_NAME.home,
                        url: C.Constant.index_page
                    });
                }
            }
            setTimeout(function () {
                self.isPosting = false;
                C.UI.stopLoading();
            }, 5000);
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});