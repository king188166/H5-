define(["zepto", "js/common/constant","js/common/native"], function($, Constant,Native) {
    var DEBUG_MODE = Constant.DEBUG_MODE,
    	debug;
    var _init = function() {
        if (!$("#_result")[0]) {
            $(document.body).append("<div id='_result' style='display:none;'><button class='btn' onclick='location.href=location.href;'>refresh</button> <a class='btn' href='debug.html'>debug</a><p class='v'>version:"+_ipos.version+"_build_"+_ipos.ts+"</p><p class='v'>version:"+location.href+"</p></div>");
            Native.titleClick(function() {
                $("#_result").toggle();
            })
            $("#_result").css({
                "font-size": "8px",
                "padding": "5px",
                "line-height": "14px"
            });
            $(document.head).append("<style type='text/css'>#_result{position:absolute;top:40px;height:400px;overflow-y:auto;background-color:rgba(0,0,0,0.8);width:100%;}#_result>div{border-bottom:dotted 1px #666;}#_result .v{color:#fff;font-size:14px;padding:5px;}</style>")
        }
    }
    if (DEBUG_MODE) {
    	$(function(){
    		_init();
    	});
        debug = {
            test: function(text) {
                $.ajax({
                    url: "http://10.180.153.208:8899/t.js",
                    type: "post",
                    data: text,
                    xhr: function() {
                        return new window.XMLHttpRequest();
                    },
                    error:function(){}
                })
            },
            log: function(text) {
                _init();
                var text = Array.prototype.join.apply(arguments, [","]);
                // debug.test("[DEBUG]"+text);
                $("#_result").append("<div style='color:#8FDAFF;'><div style='display:inline-block;width:40px;'>[DEBUG]</div>" + text + "</div>");
                $("#_result")[0].scrollTop = $("#_result")[0].scrollHeight;
            },
            error: function(text) {
                _init();
                var text = Array.prototype.join.apply(arguments, [","]);
                debug.test("[ERROR]" + text);
                $("#_result").append("<div style='color:#FF8F8F;'><div style='display:inline-block;width:40px;'>[ERROR]</div>" + text + "</div>");
                $("#_result")[0].scrollTop = $("#_result")[0].scrollHeight;
            }
        }
    } else {
        debug = {
            test: function() {},
            log: function() {},
            error: function() {}
        }
    }
    return debug;
})
