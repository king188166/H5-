/*!
 * common模块提供zed_H5的所有基础功能以及环境初始化
 * @module common
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
    'zepto',
    'fastclick',
    // 基础库 不依赖其他模块
    'js/common/env',
    'js/common/utils',
    'js/common/api',
    'js/common/flag',
    'js/common/constant',
    'js/common/native',
    'js/common/talkingdata',
    'js/common/ui',
    // 业务库，组装业务功能
    'js/common/account',
    'js/common/init',
    'js/common/debug',
    'libs/aes'
], function($, FastClick, EnvJson, Utils, Api, Flag, Constant, Native, TD, UI, Account, Init, Debug, CryptoJS) {
    /**
     * 定义与Native相关的事件监听
     */
    $$.EventListener = {
        /**
         * 页面回退刷新
         * */
        onRefresh: function() {
            Native.getUserInfo(function(data) {
                Utils.data(Constant.DataKey.USER_LOGIN_INFO, data);
                //back to home
                Native.backModule({
                    moduleName: Constant.MODULE_NAME.home,
                    url: Constant.index_page
                });

            });
        },
        pageDidAppear: function() {
            //
        },
        pageDidDisappear: function() {
            //
        },
        /**
         * 返回（点击返回按钮或Android物理返回键）
         * @param url
         */
        onBack: function(url, data) {
            if (data && typeof data != 'object') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    return;
                }
            }
            Utils.data(Constant.DataKey.ONBACK_DATA, data);
            if (data && data.reload) {
                location.reload();
            }
        }
    };

    /**
     * 事件监听插件配置初始化
     * */
    (function () {
        function initListener(config, userInfo, deviceInfo) {
            config.extraData = $.extend(userInfo, deviceInfo);
            config.env = EnvJson.ssEnv;
            var _lisenerJsUrl = (!!EnvJson.ssEnv && EnvJson.ssEnv != 'PRODUCTION') ? 'https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/public/listener.js' : 'https://puhui-web.pingan.com.cn/manager/prd/paem/public/listener.js';
            require([_lisenerJsUrl], function (listener) {
                listener.init(config);
            });
        }

        function start(config) {
            var userInfo = Utils.data(Constant.DataKey.USER_LOGIN_INFO);
            var deviceInfo = Utils.data(Constant.DataKey.USER_DEVICE_INFO);

            if (!userInfo) {
                Native.getUserInfo(function (data) {
                    Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                    userInfo = data;
                    Native.getDeviceInfo(function (res) {
                        Utils.data(C.Constant.DataKey.USER_DEVICE_INFO, res.result);
                        deviceInfo = res.result;
                        initListener(config, userInfo, deviceInfo);
                    });
                });
            } else {
                initListener(config, userInfo, deviceInfo);
            }
        }
        function getSwitch(callback) {
            var config = Utils.data(Constant.DataKey.H5_LOG_CONFIG) || '';
            var url = '';
            if (Utils.data(Constant.DataKey.LISTENER_URL)) {
                url = Utils.data(Constant.DataKey.LISTENER_URL);
            } else {
                url = App.IS_SDK ? Api('LISTENER_CONFIG_KEPLER', 'SWITCH') : Api('LISTENER_CONFIG_JSON', 'SWITCH');
                Utils.data(Constant.DataKey.LISTENER_URL, url);
            }
            
            if(!config) {
                $.ajax({
                    url: url,
                    dataType: 'json',
                    cache: false,
                    type: 'get',
                    success: function (res) {
                        if (res.flag == '1') {
                            Utils.data(Constant.DataKey.H5_LOG_CONFIG, res.data.config);
                            callback(res.data.config);
                        }
                    }
                });
            }else{
                callback(config);
            }
        }
        getSwitch(start);

    })();

    //SDK按钮颜色自定义配置
    (function () {
        if (!App.IS_SDK) return;
        var border = '1px solid #eb6100',
            btnBgColor = '#eb6100',
            btnTitleColor ='#FFF',
            cancelBtnBgColor = '#eb6100',
            cancelBtnTitleColor = '#FFF';
        var setStyle = function () {

            Native.getUIParams(function (data) {
                console.log(data);
                btnBgColor = data.btnBgColor || data.buttonColor || btnBgColor;
                btnTitleColor = data.btnTitleColor || btnTitleColor;
                cancelBtnBgColor = data.cancelBtnBgColor || btnBgColor;
                cancelBtnTitleColor = data.cancelBtnTitleColor || btnTitleColor;
                border = '1px solid ' + btnBgColor;
                $('.btn-other').css({
                    'color': btnTitleColor,
                    'border': border,
                    'background': btnBgColor
                });

                $('.cancel-btn-bg-color').css({
                    'color': cancelBtnTitleColor,
                    'border': '1px solid' + cancelBtnBgColor,
                    'background': cancelBtnBgColor
                });

            });
        };
        setStyle();
    })();

    // 判断是否已经登录
    var C = {
        FastClick: FastClick,
        // 环境变量
        Env: EnvJson.ssEnv,
        // API
        Api: Api,
        // API
        Flag: Flag,
        // 常量
        Constant: Constant,
        // 工具类
        Utils: Utils,
        // Native接口
        Native: Native,
        // Talking埋点
        TD: TD,
        // UI控件
        UI: UI,
        // 帐户
        Account: Account,
        // 调试
        Debug: Debug,
        // 校验
        Validator: {
            // 验证手机号
            mobileNo: function(mobileNo) {
                // 判断非空
                if (!mobileNo) {
                    return {
                        result: false,
                        error: '手机号码不能为空'
                    };
                }
                // 判断是否符合规则
                else if (!Utils.RegexMap.MobileNo.test(mobileNo)) {
                    return {
                        result: false,
                        error: '手机号码格式错误'
                    };
                }
                return {
                    result: true
                };
            },
            /*
             验证证件号码
             01: 居民身份证
             02/03/04: 军官证/士兵证/护照
             05/06: 港澳通行证或台胞证
             07: 其他
             */
            idNo: function(idType, idNo) {
                var checkResult = {
                    result: true
                };
                var formatErrorResult = {
                    result: false,
                    error: '证件号码格式错误'
                };

                if (idNo == '') {
                    checkResult = {
                        result: false,
                        error: '证件号码不能为空'
                    };
                } else {
                    switch (idType) {
                        // 身份证：15或18位字符
                        case '01':
                            if (idNo.length == 15) {
                                checkResult = {
                                    result: false,
                                    error: '请输入18位身份证号'
                                };
                            } else if (!(Utils.RegexMap.idCard.test(idNo) && Utils.strDateTime(idNo.substr(6, 8)))) {
                                checkResult = formatErrorResult;
                            }
                            break;
                            // 护照 2
                            // 士兵证
                            // 军官证：6-50位字符(可输中文)
                        case '02':
                        case '03':
                        case '04':
                            if (!/^[\u4e00-\u9fa5a-zA-Z\d]{6,50}$/.test(idNo)) {
                                checkResult = formatErrorResult;
                            }
                            break;
                            // 港澳台回乡证或台胞证: 5-50位字符，只允许大写字母和数字，最多输入50位
                        case '05':
                        case '06':
                            if (!/^[A-Z\d]{5,50}$/.test(idNo)) {
                                checkResult = formatErrorResult;
                            }
                            break;
                        default:
                            // 其他：3-50位字符，最多输入50位
                            if (!/^[a-zA-Z\d]{3,50}$/.test(idNo)) {
                                checkResult = formatErrorResult;
                            }
                            break;
                    }
                }
                return checkResult;
            },
            // 验证房产证号码
            propertyNo: function(propertyNo) {
                // 判断非空
                if (!propertyNo) {
                    return {
                        result: false,
                        error: '房产证号不能为空'
                    };
                }
                // 判断是否符合规则
                else if (!/^[A-Za-z0-9]{9}$/.test(propertyNo)) {
                    return {
                        result: false,
                        error: '房产证号格式错误'
                    };
                }
                return {
                    result: true
                };
            }
        },
        // 信息公用
        InfoCommon: {
            // 代号转为名称
            codeOfName: function(code, map) {
                return map[code];
            },
            bind: function() {
                // 下拉框事件
                $(document.body).on('tap', 'li', function() {
                    // 是否是下拉框
                    var oDiv = $(this).find('div').eq(0);
                    var isSelect = oDiv.hasClass('select_info');
                    $(this).find('.xiabiao').addClass('xiabiao2');
                    if (isSelect) {
                        oDiv.show();
                    }
                });

                // 选择下拉框中的内容
                $(document.body).on('tap', '.select_info div', function() {
                    var code = $(this).attr('data-code'),
                        codeName = $(this).html(),
                        selectInfoEl = $(this).parent('.select_info'),
                        oSpan = selectInfoEl.prev(),
                        cardIdUlEl = selectInfoEl.parent('li').next(),
                        certIdEl = cardIdUlEl.find('.certId'),
                        certIdValEl = cardIdUlEl.find('.certIdVal'),
                        // 是否是证件类型下拉框
                        isCertType = selectInfoEl.hasClass('certType');
                    selectInfoEl.next().removeClass('xiabiao2');
                    oSpan.attr('data-code', code);
                    oSpan.html(codeName);
                    $(this).parent('div').hide();
                    if (isCertType) {
                        certIdValEl.val('');
                        if (code == Constant.CODE.idNo) {
                            certIdEl.addClass('saoyisao');
                        } else {
                            certIdEl.removeClass('saoyisao');
                        }
                    }
                });

                // checkbox 按钮事件
                $(document.body).on('tap', '.select_icon', function() {
                    var oDiv = $(this).find('div'),
                        isSelected = oDiv.hasClass('other_green'),
                        parentDiv = $(this).parent();
                    if (!isSelected) {
                        parentDiv.attr('data-code', $(this).attr('data-code'));
                        oDiv.addClass('other_green').parent('div').siblings('div').find('div').removeClass('other_green');
                    }
                });

                // 扫描身份证号码
                $(document.body).on('tap', '.saoyisao', function() {
                    var $self = $(this),
                        fullNameEl = $self.parent('li').next().find('input');
                    Native.idCardScanning(function(data) {
                        if (idCard && idCard.idCardNuber && idCard.userName) {
                            $self.prev().val(data.idCardNuber);
                            fullNameEl.val(data.userName);
                            $self.parent('li').siblings('.dateInfo').find('.dateControls').html(Units.strDateTime(data.idCardNuber), true);
                        } else {
                            Native.tip('身份证扫描失败，请重新扫描正面');
                        }
                    });
                });

                // 户口所在地 坐落地址
                $(document.body).on('tap', '.addressInfo', function() {
                    var $self = $(this);
                    Native.selectAddressInfo(function(data) {
                        var area = data.province + '/' + data.city + '/' + data.zone;
                        $self.find('.areaControls').html(area);
                        $self.find('.areaControls').attr('data-code', data.zoneCode || '110000/110100/110101');
                    });
                });

                // 出生日期
                $(document.body).on('tap', '.dateInfo', function() {
                    var $self = $(this);
                    var addZero = function(val) {
                        return /^\d{1}$/.test(val) ? '0' + val : val;
                    };
                    Native.showDatePikerDialog({
                        callBack: function(data) {
                            var area = data.year + addZero(data.month) + addZero(data.day);
                            $self.find('.dateControls').html(Utils.parseDateFormat(area, 'yyyy年MM月dd日'));
                        }
                    });
                });
            }
        },

        rsaEncrypt: function(text) {
            return RSAENCRYPT.encrypt(text);
        },

        /**
         * 转化金额为中文大写
         * */
        formatMoneyData: function(n) {
            if (!/^(0|[1-9]\d*)(\.\d+)?$/.test(n))
                {return '数据非法';}
            var unit = '千百拾亿千百拾万千百拾元角分',
                str = '';
            n += '00';
            var p = n.indexOf('.');
            if (p >= 0)
                {n = n.substring(0, p) + n.substr(p + 1, 2);}
            unit = unit.substr(unit.length - n.length);
            for (var i = 0; i < n.length; i++)
                {str += '零壹贰叁肆伍陆柒捌玖'.charAt(n.charAt(i)) + unit.charAt(i);}
            return str.replace(/零(千|百|拾|角)/g, '零').replace(/(零)+/g, '零').replace(/零(万|亿|元)/g, '$1').replace(/(亿)万|壹(拾)/g, '$1$2').replace(/^元零?|零分/g, '').replace(/元$/g, '元');
        }

    };
    Init.apply(this);
    return C;
});