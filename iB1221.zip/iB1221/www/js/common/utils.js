/*!
 * Utils utils子模块
 * @module utils
 * @author 周一平
 * @history 2015-6-10 add
 */
define(["underscore"], function(_) {
    var Utils = {
        RegexMap : {
            //制表符
            table: /\t/g,
            //换行符
            line: /\n/g,
            //正负整数或浮点数
            intOrFloat: /^(-)?\d+(\.\d+)?$/,
            //组织机构代码
            enterpriseCode:  /^[a-zA-Z0-9]{8}\-[a-zA-Z0-9]$/,
            //工商执照注册号
            enterpriseRegCode:  /^\d{13}$|^\d{15}$/,  //   以前是13位,08年以后变15位
            //身份证
            idCard:  /^\d{15}$|^\d{18}$|^\d{17}(\d|X|x)$/,
            // 手机号码
            MobileNo: /^1[34587]\d{9}$/,
            // 银行卡号（大于或等于16位的数字）
            CardNo: /^\d{16,}$/,
            // 短验证码（6位数字以上）
            MobileCode: /^\d{6,}$/,
            // 交易密码(6-16位数字或字母)
            OrderPassword: /^\S{6,16}$/,
            //千分位正则
            parseThousands: /(\d{1,3})(?=(\d{3})+(?:$|\.))/g,
            //每4位字符用空格隔开
            bankCardNo: /(\d{4})(?=\d)/g,
            //金额检测
            moneyTest: /^(0|[1-9]\d*)(\.\d{1,2})?$/,
            //卡号屏蔽
            parseToStarNumber: /^(\d{4})(\d+)(\d{4})$/,
            // 后四位屏蔽
            parseRightFourStar: /^(\w+)(\w{4})$/,
            //日期格式检测
            parseDateFormat: /\b(\d{4})\b[^\d]+(\d{1,2})\b[^\d]+(\d{1,2})\b(\s(\d{1,2})\:(\d{1,2})\:(\d{1,2}))?[^\d]?/,
            // 出生日期掩码，显示格式（"19**年**月*2日")
            userBirthdayStarRegex: /(\d{2})\d{2}([^\d]+)\d+([^\d]+)\d?(\d)([^\d]+)?/,
            //金额转换
            moneyReplace: /[^0-9\.]/g,
            //POS机编号
            posNumberREG:/^[0123456789]\d{14}$/,
            //lufax's name
            lufaxName:/^[a-zA-Z0-9-_]{4,30}$/g
        },
        RegexReplacement : {
            parseThousands: '$1,',
            parseToStarNumber: function ($0, $1, $2, $3) {
                return $1 + $2.replace(/\d/g, "*") + $3;
            },
            parseRightFourStar: function ($0, $1, $2) {
                return $1.replace(/\w/g, "*") + $2;
            }
        },
        /**
         * 日志打印方法
         * @param text 需要打印的日志内容
         */
        logs: function(text) {
            window.console && console.log && console.log(text);
        },
        parseThousands : function (priceVal) {
            return ((priceVal || '0') + '').replace(Utils.RegexMap.parseThousands, Utils.RegexReplacement.parseThousands);
        },
        /**
         * 本地数据操作
         * @param key
         * @param value
         * @param type{0-localStorage, 1-sessionStorage}
         */
        data: function(key, value, type) {
        	var storage = localStorage;
        	if(type && type=="1"){
        		storage = sessionStorage
        	}
            var getItemValue = function() {
                var data = storage.getItem(key);
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    Utils.logs(e.message);
                }
                return data;
            };
            if (key && value === undefined) {
                return getItemValue();
            }else if(key && value === null){
            	storage.removeItem(key);
            }else{
            	storage.setItem(key, JSON.stringify(value));
            }
        },
        /**
         * 公共方法定义
         * @example: http://xxx.com/a.do?productCode=P001
         *     Result:  C.getParameter('productCode')  // 'P001'
         */
        getParameter : function (param) {
        	var reg = new RegExp('[&,?,&amp;]' + param + '=([^\\&]*)', 'i');
            var hrefStr = location.search;
            hrefStr = decodeURIComponent(decodeURIComponent(hrefStr));
            var value = reg.exec(hrefStr);
            return value ? value[1] : '';
        },
        /**
         * 获取URL参数对象
         * @param queryString
         * @returns {{}}
         */
        getQueryMap: function (queryString) {
            var paramObj = {},
                paramList,
                oneQueryMatch,
                regGlobal = /[\?\&][^\?\&]+=[^\?\&#]+/g,
                regOne = /[\?\&]([^=\?]+)=([^\?\&#]+)/;

            queryString = queryString || location.href;
            paramList = queryString.match(regGlobal);

            if (!paramList) {
                return paramObj;
            }

            for (var i = 0, len = paramList.length; i < len; i++) {
                oneQueryMatch = paramList[i].match(regOne);
                if (null === oneQueryMatch) {
                    continue;
                }
                paramObj[oneQueryMatch[1]] = oneQueryMatch[2];
            }

            return paramObj;
        },
        /**
         * 获取填写身份证相关的信息
         * @ param str 截取的出生日期字符串 或 身份证号
         * @ param type 传入第二个值是证明需返回的是string，否则是boolean
         * 检测身份证中的日期是否有效
         *
         */
        strDateTime: function (str,type){
            var type = type || true;
            // 如果传入的是身份证号时，从第6位开始截取8个字符
            if(str.length == 18){
                str = str.substr(6,8);
            }
            var r = str.match(/^(\d{1,4})(-|\/)?(\d{1,2})\2(\d{1,2})$/);
            if(r==null)return false;
            var d= new Date(r[1], r[3]-1, r[4]);
            var now = new Date();
            var minDate = new Date("1900-01-01"), maxDate = new Date(now.getFullYear(),now.getMonth(),now.getDate());
            // 如果不符合最大当前日期，最小1900年1月1日，则不通过日期校验
            if(d < minDate || d > maxDate){
                return false;
            }
            if(type){
                return d.getFullYear()+'年'+(d.getMonth()+1)+'月'+d.getDate()+'月';
            }

            return (d.getFullYear()==r[1]&&(d.getMonth()+1)==r[3]&&d.getDate()==r[4]);
        },
        // 判断对象中属性的值为空的个数
        isEmptyAttrValObject:function(obj){
            var count = 0;
            if(_.isArray(obj)){
                for(var i=0,len = obj.length;i<len;i++){
                    count = _.filter(obj[i], function(val){ return !!val == false;}).length;
                }
            }else{
                count = _.filter(obj, function(val){ return !!val == false;}).length;
            }
            return !!count;
        },
        //金额格式化
        formatMoney: function(s, n){
        	if(Number(s) == NaN || String(s) == "" ? true : false) return s;
        	n = n > 0 && n <= 20 ? n : 2;
        	s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
        	var l = s.split(".")[0].split("").reverse(),
        	r = s.split(".")[1];
        	t = "";
        	for(i = 0; i < l.length; i ++ )
        	{
        		t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
        	}
        	return t.split("").reverse().join("") + "." + r;
        },
        /** 转换日期格式
         * @param date : 日期格式|String类型 (如：'2012-12-12' | '2012年12月12日' | new Date())
         * @param format : String类型 （如: 'yyyy年MM月dd日'或'yyyy年MM月dd日 hh时mm分ss秒',默认'yyyy-MM-dd'）
         * @example C.parseDateFormat(new Date(), 'yyyy年MM月dd日') 输出："2014年04月29日"
         * @example C.parseDateFormat(new Date()) 输出："2014-04-29"
         * @exmaple C.parseDateFormat("2014-05-07 16:09:47","yyyy年MM月dd日 hh时mm分ss秒")
         *          输出："2014年05月07日 16时09分47秒"
         **/
        parseDateFormat:function (date, format) {
            if(!date){
                return date;
            }
            if(!isNaN(date) && String(date).length == 8){
                date = (date+'').replace(/^(\d{4})(\d{2})(\d{2})$/,"$1/$2/$3");
            }
            var addZero = function (val) {
                return /^\d{1}$/.test(val) ? '0' + val : val;
            };
            format = format || 'yyyy-MM-dd';
            var year = '', month = '', day = '', hours = "", minutes = "", seconds = "";
            if (typeof date == 'string') {
                var dateReg = Utils.RegexMap.parseDateFormat;
                var dateMatch = date.match(dateReg);
                if (dateMatch) {
                    year = dateMatch[1];
                    month = dateMatch[2];
                    day = dateMatch[3];
                    hours = dateMatch[5];
                    minutes = dateMatch[6];
                    seconds = dateMatch[7];
                }
            } else {
                year = date.getFullYear();
                month = date.getMonth() + 1;
                day = date.getDate();
                hours = date.getHours();
                minutes = date.getMinutes();
                seconds = date.getSeconds();
            }
            month = addZero(month);
            day = addZero(day);
            hours = addZero(hours);
            minutes = addZero(minutes);
            seconds = addZero(seconds);
            return format.replace('yyyy', year).replace('MM', month).replace('dd', day).replace("hh", hours).replace("mm", minutes).replace("ss", seconds);
        },
        //为界面金额添加分隔逗号
		regMoneyAndDou:function(money){
			if(money =='0'){
				return '0';
			}
			money = money.toString();
			var source= money.replace(/,/g,'').split('.');
			source[0]=source[0].replace(/(\d)(?=(\d{3})+$)/ig,'$1,');
			if(source[1]){
				money = source[0]+"."+source[1];
			}else{
				money = source[0];
			}
			return money;
		},
        regMoneyAndDous: function(money,n) {
            if (isNaN(money) || money == '0') {
                return '0.00';
            }
            isNaN(n) && (n = 2);
            money = (parseFloat(money).toFixed(n)).toString();
            var source = money.replace(/,/g, '').split('.');
            source[0] = source[0].replace(/(\d)(?=(\d{3})+$)/ig, '$1,');
            if (source[1]) {
                money = source[0] + "." + source[1];
            } else {
                money = source[0];
            }
            return money;
        },
        // 每4个字符用空格隔开
        formatCardNo: function(num) {
            num = num.toString();
            return num.replace(Utils.RegexMap.bankCardNo,'$1 ').replace(/\s*$/,'');
        },
        // 保留卡号后4位,其余的用＊代替
        tailCardNo: function(num) {
            num = num.toString();
            return '**** **** **** ' + num.substr(-4);
        },
        /**
         * 费率小数换算
         * 如：后台返回费率均是%之前的返回数据，即：如果费率为0.78%，后台实际返回0.0078.前端要做%处理。
         * 0.07--->0.0070--->00.70--->0.70
         * 0.0078--->0.0070--->00.70--->0.70
         * 0.00792--->0.0079--->00.79--->0.79
         * 0.1278--->0.1270--->12.70--->12.70
         */
        toChangeXS:function(num){
			var temp = num.toString();
			if(temp.length<=5){
				var cha = 6-temp.length;
				for(var i=0;i<cha;i++){
					temp = temp+"0";
				}
			}else if(temp.length<=6){
				temp = temp.substring(0,5)+"0";
			}else{
				temp = temp.substring(0,6);
			}
			var index = temp.indexOf(".");
			var start = temp.substring(2,4);
			var end = temp.substring(4,6);
			if(start.indexOf(0)=="0"){
				start = start.substring(1);
			}
			return start+"."+end;
		},
		/**
		 * 小数加法运算，并保证小数点保留两位小数
		 */
        accAdd: function(arg1, arg2) {
            var decimals = [], m, sum = 0,value;
            for (i = 0;i < arguments.length; i++){
                if(arguments[i].toString().indexOf(".") != -1){
                    decimals.push(arguments[i].toString().split(".")[1].length);
                }
            }
            m = Math.pow(10 ,decimals.sort(function(a,b){return b - a;})[0]);
            for (i = 0;i < arguments.length; i++){
                sum += Math.round(arguments[i]*m);
            }
            value = sum/m;
            if (value.toString().indexOf(".") == -1) {
                value = value + ".00";
            } else {
                var afterDoitLen = value.toString().substring(value.toString().indexOf("."), value.toString().length).length;
                if (afterDoitLen < 3) {
                    var cha = 3 - afterDoitLen;
                    for (var i = 0; i < cha; i++) {
                        value = value + "0";
                    }
                }
            }
            return value;
        },
        /**
         * 补足小数点后至少几位小数
         */
        formatFloat: function(value, number) {
            // 入参验证
            if(Number(value) == NaN || String(value) == "" ? true : false) return value;
            number = number ? number : 2;
            // 操作字符串
            var s = String(value);
            var arr = s.split(".");
            var integer = arr[0];
            var decimal = arr[1] ? arr[1] : "";
            if(decimal.length<number){
                for(var i=decimal.length; i<number; i++) {
                    decimal += "0";
                }
            }
            return integer + "." + decimal;
        },
		/**
		 * 计算month月day日的日期+monthDays间隔天数（其实就是这个月month的天数）之后的日期
		 * 如果当前day>这个月的天数，就说明是下一个月的了，求取多出的天数nextDay
		 * 返回{month：加后的月份，day：加后的日}
		 */
		calcDay:function(month,day,monthDays){
			var self = this,nextDay = 0;
			if(day>monthDays){
				nextDay = day % monthDays;
			}
			if(nextDay!=0){
				month = month+1;
				if(month == 13){//加到下一年
					month = 1;
				}
				day = nextDay;
			}
			return {month:month,day:day};
		},
		/**
		 * 计算每月固定还款日：月份+1，日期-1，日期范围：日期-1+M~日期-1+N
		 * startM:计算的每月固定还款日开始日期
		 * endN:计算的每月固定话款日结束日期
		 * monthDays:月份天数（2月添加闰年判断，28/29天；4，6，8，10，12月30天；1，3，5，7，9，11月31天）
		 * curMonth:当前时间的月份（去掉前导0）
		 * curDay:当前时间的日期（去掉前导0）
		 */
		calcGDHKDay:function(paramM,paramN,curDate){
			var self = this,startM = 0,endN = 0,monthDays = 0;
			var oushuTwo = {2:true},oushuNotTwo = {4:true,6:true,8:true,10:true,12:true},jishu = {1:true,3:true,5:true,7:true,9:true,11:true};
			var M = parseInt(paramM)+1,N = parseInt(paramN)+1;
			var curYear = curDate.substring(0,4),
				curMonth = curDate.substring(4,6),
				curDay = curDate.substring(6,8);
			curMonth = parseInt(curMonth.indexOf(0)=="0"?curMonth.substring(1):curMonth);
			curDay = parseInt(curDay.indexOf(0)=="0"?curDay.substring(1):curDay);
			curMonth  = curMonth + 1;
			if(curMonth == 13){//加到下一年
				curMonth = 1;
			}
			curDay = curDay-1;
			if(curDay==0){//减到上一个月
				curMonth = curMonth-1;
				if(curMonth==0){
					curMonth = 12;
				}
				if(oushuTwo[curMonth]){
					var isLeap = self.leapYear(curYear) ;
					if(isLeap){
						curDay = 29;
					}else{
						curDay = 28;
					}
				}else if(oushuNotTwo[curMonth]){
					curDay = 30;
				}else if(jishu[curMonth]){
					curDay = 31;
				}
			}
			if(oushuTwo[curMonth]){
				var isLeap = self.leapYear(curYear) ;
				if(isLeap){
					monthDays = 29;
				}else{
					monthDays = 28;
				}
			}else if(oushuNotTwo[curMonth]){
				monthDays = 30;
			}else if(jishu[curMonth]){
				monthDays = 31;
			}
			startM = curDay + M;
			endN = curDay + N;
			var startMInMonth = self.calcDay(curMonth,startM,monthDays);
			startM = startMInMonth.day;
			var endNInMonth = self.calcDay(curMonth,endN,monthDays);
			endN = endNInMonth.day;
			console.log("固定还款日---"+curMonth+"月"+curDay+"日");
			var res = {
				"curDay":curDay,
				"curMonth":curMonth,
				"monthDays":monthDays,
				"startMInMonth":startMInMonth.month,
				"startM":startM,
				"endNInMonth":endNInMonth.month,
				"endN":endN
			};
			return res;
		},
		leapYear:function(year) {
			year = parseInt(year);
		    return !(year % (year % 100 ? 4 : 400));
		},
        /**
         * base64编码码
         * @param str 需base64编码字符
         * @returns {*} base64解码后的字符
         */
        base64encode: function (str) {
            var base64EncodeChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
            var out, i, len;
            var c1, c2, c3;
            str = this.utf16to8(str);
            len = str.length;
            i = 0;
            out = '';
            while (i < len) {
                c1 = str.charCodeAt(i++) & 0xff;
                if (i == len) {
                    out += base64EncodeChars.charAt(c1 >> 2);
                    out += base64EncodeChars.charAt((c1 & 0x3) << 4);
                    out += '==';
                    break;
                }
                c2 = str.charCodeAt(i++);
                if (i == len) {
                    out += base64EncodeChars.charAt(c1 >> 2);
                    out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
                    out += base64EncodeChars.charAt((c2 & 0xF) << 2);
                    out += '=';
                    break;
                }
                c3 = str.charCodeAt(i++);
                out += base64EncodeChars.charAt(c1 >> 2);
                out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
                out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
                out += base64EncodeChars.charAt(c3 & 0x3F);
            }
            return out;
        },
        utf16to8: function (str) {
            var out, i, len, c;

            out = '';
            len = str.length;
            for (i = 0; i < len; i++) {
                c = str.charCodeAt(i);
                if ((c >= 0x0001) && (c <= 0x007F)) {
                    out += str.charAt(i);
                } else if (c > 0x07FF) {
                    out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
                    out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
                    out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
                } else {
                    out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
                    out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
                }
            }
            return out;
        },
        /*
        * 年龄校验
        * @birthday 根据身份证截取的出生年月
        * @curYear 当前系统时间戳
        * @identity 身份证号
        * @minAge 最小限定年龄
        * @maxAge 最大限定年龄
        * */
        ageCheck: function () {
            var birthday, minAge, maxAge, identity,
                curYear = new Date().getTime();//获取当前年份
            if (arguments.length > 0 && (arguments[0].length == 15 || arguments[0].length == 18)) {
                identity = arguments[0];// 第一个参数必须为身份证号
                //截取出生年月
                birthday = identity.length == 15 ? '19' + identity.substr(6, 6): identity.substr(6, 8);
                //将出生年月转为时间戳
                birthday = new Date(birthday.substr(0, 4), (parseInt(birthday.substr(4, 2)) - 1), birthday.substr(6, 2)).getTime();
                switch (arguments.length) {
                    case 1:
                        //根据身份证号计算返回客户年龄
                        return parseInt((curYear - birthday)/31536000000);
                        break;
                    case 3:
                        //根据身份证号判定客户年龄是否在指定的范围内
                        minAge = parseInt(arguments[1]);
                        maxAge = parseInt(arguments[2]);
                        if (minAge > maxAge) {
                            minAge = arguments[2];
                            maxAge = arguments[1];
                        }
                        if (minAge * 31536000000 <= curYear - birthday && curYear - birthday < maxAge * 31536000000) {
                            return 1;
                        }
                        return -1;
                        break;
                    default :
                        return -1;
                }
            }
        }
    };
    return Utils;
});

