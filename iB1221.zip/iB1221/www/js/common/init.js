/*!
 * 初始化 common子模块
 * @module init
 * @author 周一平
 * @history 2016-4-18 modify by yerencheng
 */
define([
    'zepto',
    'js/common/env',
    'js/common/flag',
    'js/common/constant',
    'js/common/utils',
    'js/common/ui',
    'js/common/native',
    'js/common/account',
    'js/common/api'
], function($, EnvJson, Flag, Constant, Utils, UI, Native, Account, Api) {
    'use strict';
    return function() {
        var Env = EnvJson.ssEnv;

        //备份ajax方法
        var _ajax = $.ajax;
        // Ajax共用回调函数
        var _ajaxExt = {
            success: function(res, url) {
                // flag值不在whiteCode列表内，则显示提示框
                var whiteCode = [Flag.SUCCESS];
                // 登录超时，跳转到登录页
                if (res.flag == Flag.LOGIN_TIMEOUT || res.flag == Flag.ERROR) {
                    Account.logout();
                    toLogin(res.msg);
                } else if ($.inArray(res.flag, whiteCode) == -1) {
                    messageTip(res.msg);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                messageTip('网络异常，请稍后再试！');
            },
            complete: function() {
                // empty
            }
        };

        function messageTip(txt) {
            if (Env == 'DEVELOPMENT') {
                window.alert(txt);
            } else {
                Native.tip(txt);
            }
        }
        function toLogin(txt) {
            if (Env == 'DEVELOPMENT') {
                var url = 'login.html?redirectURL=' + encodeURIComponent(location.href);
                if (window.confirm(txt)) {
                    window.location.href = url;
                }
            } else {
                Native.dealTimeOut(txt);
            }
        }
        function httpRequest(option) {
            if (Env == 'DEVELOPMENT') {
                _ajax(option);
            } else {
                Native.request(option);
            }
        }
        function ajaxPostError (data, url, startTimeStamp) {
            var errorCode;
            if (!!data) {
                // native 请求60s超时,data返回'null',把errorCode定义为003;
                if (data === 'null') {
                    errorCode = '003';
                } else {
                    errorCode = data.flag;
                }
            }
            var args = {
                errorCode: errorCode || '',
                url: url || '',
                startTimeStamp: startTimeStamp || ''
            };
            var _lisenerJsUrl = (!!Env && Env != 'PRODUCTION') ? 'https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/public/listener.js' : 'https://puhui-web.pingan.com.cn/manager/prd/paem/public/listener.js';
            require([_lisenerJsUrl], function (listener) {
                listener.ajaxPostError(args);
            });
        }
        //扩展ajax的参数
        $.ajax = function(opt) {
            if (Env == 'DEVELOPMENT') {
                opt.type = 'GET';
            }
            // 记录请求开始的时间
            var startTimeStamp = new Date();
            // 页面中自定义的回调函数
            var fn = {
                success: opt.success || function(data) {},
                error: opt.error || function(XMLHttpRequest, textStatus, errorThrown) {},
                complete: opt.complete || function(XHR, TS) {}
            };
            // 合并共用回调函数和页面回调函数
            var _opt = $.extend(opt, {
                // 设置默认参数
                type: opt.type || 'GET',
                data: opt.data || {},
                dataType: opt.dataType || 'json',
                timeout: opt.timeout || 60000,
                cache: opt.cache || false,
                //增加ajax开始的时间
                _startTime: +new Date(),
                success: function(data) {
                    console.log('success callback data:' + JSON.stringify(data));
                    //执行页面回调函数之后再执行共用回调函数
                    fn.success(data);
                    _ajaxExt.success(data);
                    //ajax插入dom
                    _opt['_end'] = +new Date();
                    window.watchTime && window.watchTime.setAjaxResouce(_opt);


                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    fn.error(XMLHttpRequest, textStatus, errorThrown);
                    _ajaxExt.error(XMLHttpRequest, textStatus, errorThrown);
                    //增加ajax错误的标志
                    _opt["Err"] = {content:fn.error};
                    //触发ajax完成的函数
                    window.watchTime && window.watchTime.setAjaxResouce(_opt);
                    
                },
                complete: function(XHR, TS) {
                    fn.complete(XHR, TS);
                    _ajaxExt.complete(XHR, TS);
                    // 请求完成后记录请求时间和提交错误函数
                    ajaxPostError(XHR, opt.url, startTimeStamp);
                }
            });
            // 合并共用入参和页面入参
            var loginInfo = Utils.data(Constant.DataKey.USER_LOGIN_INFO);
            if (loginInfo) {
                $.extend(_opt.data, {
                    accountId: loginInfo.accountId,
                    token: loginInfo.token,
                    os: App.IS_IOS ? 'IOS' : 'A'
                });
            }
            console.log(_opt);
            // 执行ajax请求
            httpRequest(_opt);
        };
    };
});