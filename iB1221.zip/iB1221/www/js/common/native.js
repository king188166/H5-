define(['js/common/utils'], function(Utils) {
    var App = window.App || {};
    var defaultCallback = function() {};

    return {
        /**
         * 发送HTTP请求
         * @import jQuery|Zepto
         * @param options 对象{type:"get",data:{},successCallBack:function(res){},failCallBack:function(res){}}
         * @param .data JSON对象 请求入参
         * @param .type 字符串 请求方式，默认get
         * @param .success 函数 function(){} 请求成功处理
         * @param .error  函数 function(){} 请求失败处理
         */
        request: function(options) {
            var data = options.data || {},
                param = [],
                type = options.type || 'get';

            if (/^POST|post$/.test(type)) {
                type = App.IS_IOS ? 'post' : 'POST';
            }

            if (/^GET|get$/.test(type)) {
                type = App.IS_IOS ? 'get' : 'GET';
            }

            if (data && typeof data == 'object') {
                for (var key in data) {
                    try {
                        param.push(key + '=' + encodeURIComponent(decodeURIComponent(data[key])));
                    } catch (e) {
                        param.push(key + '=' + encodeURIComponent(data[key]));
                    }
                }

                data = param.join('&');
            }
            App.call('request', options.url, type, options.headers || '', data, function() {
                options.success.apply(this, arguments);
            	options.complete.apply(this, arguments);
            }, function() {
            	options.complete.apply(this, arguments);
                options.error.apply(this, arguments);
            });
        },
        /**
         * 发送电子签名请求
         * @param options 对象
         */
        uploadSign: function(options) {
            App.call('uploadSign', options.url, options.params, options.callback);
        },
        /**
         * 发送HTTP GET请求（调用C.Native.request）
         * @param options 对象
         * 默认get方式 方法参照request
         */
        get: function(options) {
            options.type = 'get';
            this.request(options);
        },
        /**
         * 发送HTTP POST请求（调用C.Native.request）
         * @param options 对象
         * 默认post方式 方法参照request
         */
        post: function(options) {
            options.type = 'post';
            this.request(options);
        },
        /**
         * WebView跳转（本地页面、服务端页面、及模块）
         * @param options 对象 {title:"",url:""}
         * .url 字符串 跳转的链接
         * .defaultCallback 函数 function(){} 请求处理
         * 跳转参数
         */
        forward: function(options) {
            var data = options.data,
                url = options.url;

            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }

            // PC的跳转方式
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            /*
             *过滤param
             */
            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split("?")[0],
                    urlData = Utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + "?" + param.join("&");
            }

            url = url.replace(/(%2F)/ig, "/");
            if(App.IS_IOS && options.callBack){
                $$.EventListener.onBack = function (url,data){
                    try{
                        data = typeof data === "string" ? JSON.parse(data) : data;
                    }catch(e){

                    }
                    if(options.callBack && typeof options.callBack === "function"){
                        options.callBack(data);
                    }
                };
            }
            if (App.IS_SDK) {
                App.call('forwardToNewPage', url, options.callBack || '');
                return;
            }
            App.call('forward', url, options.callBack || '');
        },
        /**
         * WebView带模块名跳转
         */
        forwardModule: function(options) {
            var data = options.data,
                url = options.url,
                moduleName = options.moduleName;

            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }

            // PC的跳转方式
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            /*
             *过滤param
             */
            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split("?")[0],
                    urlData = Utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + "?" + param.join("&");
            }

            url = url.replace(/(%2F)/ig, "/");
            App.call('forwardModule', moduleName, url, options.callBack || '');
        },

        /**
         * 在当前webview开启新页面
         * @param options 对象 {title:'',url:''}
         * .url 字符串 跳转的链接
         * .defaultCallback 函数 function(){} 请求处理
         * 跳转参数
         */
        forwardInCurPage: function (options) {
            var data = options.data,
                url = options.url;
            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }
            // 本地开发浏览器环境
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split('?')[0],
                    urlData = Utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + '?' + param.join('&');
            }
            url = url.replace(/(%2F)/ig, '/');
            App.call('forwardInCurPage', url, options.callback || '');
        },

        /**
         * 在当前activity加载页面
         * */
        loadPage: function(options) {
            var data = options.data,
                url = options.url;

            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }

            // PC的跳转方式
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }

            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split("?")[0],
                    urlData = Utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + "?" + param.join("&");
            }

            url = url.replace(/(%2F)/ig, "/");
            App.call('loadPage', url, options.callBack || '');
        },

        /**
         * WebView返回
         * @param options {url:""}
         * .url back返回的url,为空默认返回上一个页面,
         * .data 返回后Native调用C.Service.onback()事件, 并将参数data传递给onback方法
         *                如果返回到流程开始的的页面,需要传页面名字,如"info_loan.html"
         * .defaultCallback 函数 function(){} 请求处理
         */
        back: function(options) {
            var options = options || {},
                url = "",
                data = "";

            if (options && options.url) {
                url = options.url;

                if (/^https*:\/\//.test(url)) {
                    //
                } else {
                    url = url;
                }
            }
            if (options && options.data) {
                data = options.data;
            }
            // PC的跳转方式
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            App.call('back', url || "", data || "", options.callBack || '');
        },
        /**
         * WebView跨模块返回首页
         * @param options {url:"",moduleName:""}
         * .url back返回的url,为空默认返回上一个页面,
         * .data 返回后Native调用C.Service.onback()事件, 并将参数data传递给onback方法
         *                如果返回到流程开始的的页面,需要传页面名字,如"info_loan.html"
         * .defaultCallback 函数 function(){} 请求处理
         */
        backModule: function(options) {
            var options = options || {},
                moduleName = "",
                url = "",
                data = "";

            if (options && options.moduleName) {
                moduleName = options.moduleName;
            }
            if (options && options.url) {
                url = options.url;

                if (/^https*:\/\//.test(url)) {
                    //
                } else {
                    url = url;
                }
            }
            if (options && options.data) {
                data = options.data;
            }

            App.call('backModule', moduleName || "", url || "", data || "", options.callBack || '');
        },
        /**
         * 设置头部信息
         * @param options {title:"标题",isBack:true,leftCallback:function(){},isClose:true,closeCallback:function(){}}
         * .title 字符串 设置头部标题
         * .isBack 布尔值 是否有返回图标
         * .leftCallback function(){} 函数 设置左边回调
         * .rightText 布尔值 是否有关闭图标
         * .rightIcon  function(){} 函数 设置右边回调
         * .rightCallback function(){} 函数 设置右边回调
         * .data 扩展数据 Json格式  如：isFullScreen(是否全屏)
         */
        setHeader: function(options) {
            var leftCallback = options.leftCallback || '',
                rightCallback = options.rightCallback || '';
            if (typeof options.isBack == "undefined") {
                options.isBack = true;
            }
            //options.noSave 是否保存当前header设置
            !options.noSave && (App.curHeaderOpts = options);
            App.call('setHeader', options.title || '', !!options.isBack, leftCallback, options.rightText, options.rightIcon || '', rightCallback, options.data || '');
        },
        header: function (options) {
            switch (typeof options) {
                case 'object':
                    return this.setHeader(options);
                    break;
                case 'undefined':
                    return App.curHeaderOpts;
                    break;
            }
        },
        /**
         * 显示加载动画 C.UI.loading();
         * options.msg 当不允许取消加载动画时 提示信息
         */
        loadingBegin: function(options) {
            var msg = '';

            if (options) {
                msg = options.msg;
            }

            App.call('loadingBegin', msg);
        },
        /**
         * 关闭加载动画 C.UI.stopLoading();
         */
        loadingFinish: function() {
            App.call('loadingFinish');
        },
        /**
         * 提示
         * .text 字符串 C.Native.tip('提示内容');
         */
        tip: function(text) {
            var text = text || '';
            App.call('tip', text);
        },
        /**
         * 监听用户操作数据
         * @param eventId 事件分类
         * @param eventLable事件 事件类型细分
         * @param jsonData 数据
         */
        TDOnEvent: function(options) {
            var options = options || {};
            App.call("TDOnEvent", options.eventId || '', options.eventLable || '', options.jsonData || '');
        },

        /**
         * 选择地区
         * @param callback 对过callback的data将地区信息通过data传递给H5，
         * data格式{"province":"广东省","city":"深圳市","zone":"八卦岭"}
         */
        selectAddressInfo: function(callBack) {
            App.call("selectAddressInfo", callBack || defaultCallback);
        },
        /**
         * 显示日期选择控件
         * @param title 选泽日期的标题，默认为“选择日期”
         * @param showYear 是否显示年份  Y|N
         * @param showMonth 是否显示月  Y|N
         * @param showDay 是否显示日期  Y|N
         * @param pos 弹框的显示位置，bottom｜center｜top
         * @param callback js回调
         * {
         *    "year":"2015",//根据Y｜N来判断是否返回该值
         *    "month":"2",
         *    "day":"28"
         * }
         */
        showDatePikerDialog: function(options) {
            App.call("showDatePikerDialog", options.title || '选择日期', options.showYear || 'Y', options.showMonth || 'Y', options.showDay || 'Y', options.pos || 'bottom', options.callBack || defaultCallback);
        },
        /**
         * 获取当前用户的登录信息
         * 返回当前用户的登录信息，以json形式返回
         *
         {
         "custName": "dapeng",
         "account": "abcd",
         "msgCnt": "12",
         "token": "ad3bjlaoe00jbmbm",
         "custId": "399444",
         "mobile": "1312929400",
         "city": "",
         "cityName": "深圳",
         "sysDate": "",
         "ad": user.getAd,
         "paPayToken":"ad3bjlaoe00jbmbm",
         "platform": "android",
         "accountId":"",
         "mark": "BN"
         "Id": "",
         "pointsSwitch": "",
         "isOrangebankCust": "",
         "InvitationCode": "",
         "isNew": "",
         "machineId": ""
         }
         */
        getUserInfo: function(callback) {
            App.call("getUserInfo", callback || defaultCallback);
        },

        /**
         * 设置用户的当前信息，注意，会将传递的值覆盖现有值。
         * @param userInfo 需要设置的用户信息（可以只提供需要设置的信息如｛"acountId","abcd"｝）
         * @param callback 设置成功返回1，失败返回0
         */
        setUserInfo: function(userInfo) {
            var userInfo = userInfo || {};
            App.call("setUserInfo", userInfo);
        },
        /**
         * 登录超时接口。在弹出的dialog中点击确定后，跳转到登录页面登录
         * @param msg 弹出登录超时提示框中显示的信息。默认显示“登录超时，请重新登录”
         */
        dealTimeOut: function(msg) {
            var msg = msg || '';
            App.call("dealTimeOut", msg);
        },
        /**
         * 客户端判断用户是否登录接口
         * @param callback
         * @return Object {flag:1}--已登录，{flag:0}--未登录
         */
        isLogined: function(callback) {
            App.call("isLogined", callback || defaultCallback);
        },
        login: function(data, callback) {
            App.call('login', data, callback || defaultCallback);
        },
        /**
         * 跳转到某个Native界面
         * page: 界面名称
         * data: 传递数据
         */
        gotoNative: function(page, data, callback) {
            App.call('gotoNative', page, data || '', callback || defaultCallback);
        },
        /**
         * Native测试事件
         */
        titleClick: function(callback) {
            App.call("titleClick", callback || defaultCallback);
        },
        /**
         * 补充身份信息
         * */
        addUserInfo: function(callback) {
            App.call("addUserInfo", callback || defaultCallback)
        },
        /*
         *调平安付实名升级页面
         */
        realnameVerification:function(realname, callback, isYZTUser){
            var self = this;
            if(isYZTUser && isYZTUser != '') {
                if(isYZTUser == 'Y') {
                    self.addUserInfo(callback);
                } else {
                    App.call("realnameVerification", realname || '', callback || defaultCallback);
                }
            } else {
                self.getUserInfo(function(data) {
                    if(data.isYZTUser && data.isYZTUser == 'Y'){
                        self.addUserInfo(callback);
                    } else {
                        App.call("realnameVerification", realname || '', callback || defaultCallback);
                    }
                });
            }
        },
        /**
         * 获取设备信息
         * */
        getDeviceInfo: function(callback) {
            if (App.IS_SDK) {
                App.call("getDeviceInfo", callback || defaultCallback);
                return;
            }
            App.call("getBindCardParams", callback || defaultCallback)
        },
        /**获取当前所在的城市名{"cityName":"深圳市"}*/
        getCityName: function(callback) {
            App.call("getCityName", callback || defaultCallback);
        },
        /**
         * 手动鉴权壹钱包
         * */
        loginOrRegistPaOne: function(callback) {
            App.call("loginOrRegistPaOne", callback || defaultCallback);
        },
        /**
         * 查询绑定网络帐户信息
         */
        searchAccountName: function(options) {
            var successCallBack = options.successCallBack || "",
                failCallBack = options.failCallBack || "";
            App.call("searchAccountName", successCallBack, failCallBack)
        },
        /**
         * 绑定微博、京东、1号店、淘宝
         */
        bindNetAccount: function(netAccountType, callback) {
            App.call("bindNetAccount", netAccountType, callback || defaultCallback);
        },
        /**
         * 获取通讯录
         * */
        getContactList: function(limitNum, callback) {
            if (App.IS_SDK) {
                App.call('getContactsInfo', limitNum, callback || defaultCallback);
                return;
            }
            App.call("getContactList", limitNum, callback || defaultCallback);
        },
        /**
         * Android获取通话记录
         * */
        getContactRecord: function(callback) {
            App.call("getContactRecord", callback || defaultCallback);
        },
        /**
         * 选择联系人关系
         * */
        selectRelationList: function(flag, callback) {
            App.call("selectRelationList", flag, callback || defaultCallback);
        },
        /**
         * 人脸识别
         * */
        faceRecognise: function(opts, callback) {
            if (App.IS_SDK) {
                App.call('faceRecognise', opts.faceParam || '', opts.applNo || '', opts.firstStartTime || '', opts.cardNumber || '', callback || defaultCallback);
                return;
            }
            App.call("faceRecognise", opts.faceParam || "", opts.applNo || "", opts.firstStartTime || "", callback || defaultCallback);
        },
        /**
         * 信用加油站
         */
        addCreditRequest: function(applNo, callback) {
            App.call("addCreditRequest", applNo || "", callback || defaultCallback);
        },
        /**
         * 语音输入
         */
        speechInput: function(speakTitle, callback) {
            App.call("speechInput", speakTitle || "", callback || defaultCallback);
        },
        /**
         * 调用拍照
         */
        upLoadPhoto: function(imgDec, imgCode, num, applNo, callback) {
            App.call("upLoadPhoto", imgDec || "", imgCode || 0, num || 0, applNo || "", callback || defaultCallback);
        },
        /**
         *电子签名--3个参数：android<490,ios
         */
        esign: function(opts, callback) {
            App.call("eSignature", opts.barCode, opts.enText, callback || defaultCallback)
        },
        /**
         *电子签名2---4个参数:497>=android>=490,ios此时还是用3个参数的
         */
        esign2:function(opts,callback){
            App.call("eSignature", opts.domesticAlgorithm, opts.barCode, opts.enText, callback || defaultCallback)
        },
        /**
         *电子签名3---5个参数:android和ios>=499版本的
         */
        esign3:function(opts,callback){
            App.call("eSignature", opts.domesticAlgorithm, opts.barCode, opts.enText, opts.keyWord , callback || defaultCallback)
        },
        /**
         * @return {"version":"311","versionName":"3.1.1"}
         */
        getAppVersion: function(callback) {
            if (App.IS_SDK) {
                App.call('getVersionInfo', callback || defaultCallback);
                return;
            }
            App.call('getAppVersion', callback || defaultCallback);
        },
        /**
         *  短信获取与上传
         */
        readUserSMS: function(callback) {
            App.call('readUserSMS', callback || defaultCallback);
        },
        /**
         * icard的RSA加密
         * */
        rSAEncodeIcard:function(json,callback){
            App.call("getRSAEncodeString", json || '', callback || defaultCallback);
        },
        /**
         * RSA加密
         * */
        rSAEncode:function(json,callback){
            if (App.IS_SDK) {
                App.call('getRSAEncodeString', json || '', callback || defaultCallback);
                return;
            }
            App.call("rSAEncode", json || '', callback || defaultCallback);
        },
        /**
         * RSA解密
         * */
        rSADecode:function(json,callback){
            App.call("rSADecode", json || '', callback || defaultCallback);
        },
        //430以后提供
        loadingBeginNew: function (options, cacelable) {
            App.call('loadingBegin', options.msg || "", cacelable);
        },
         /**
         *返回Native页面
         */
        backToRobot:function(lastURL,lastModule){
            App.call('backToRobot',lastURL || '',lastModule || '');
        },
        /**
         *获取恶意app数量maliciousAppCnt 和 网络连接类型connectionType
         */
        getTDParams: function(callback){
            if (App.IS_SDK) {
                App.call('getmaliciousAppCnt', callback || defaultCallback);
                return;
            }
            App.call('getTDParams', callback || defaultCallback);
        },
        //跳转到产险子系统
        processPIBussnise: function(piUrl, tipMsg, backMsg, needForward, callback){
            App.call('processPIBussnise', piUrl || '', tipMsg || '', backMsg || '', needForward || '', callback || defaultCallback);
        },
        //跳转到信息补录--光大银行需求
        paPresent: function(url, jsonData, callback){
            App.call('paPresent', url || '', jsonData || '', callback || defaultCallback);
        },
        //异常用户验证
        pah_loanSuccess: function() {
            App.call('pah_loanSuccess');
        },
        //SDK 方法
        /**
         *  风格自定义获取颜色值
         */
        getUIParams: function (callback) {
            App.call('getUIParams', callback || defaultCallback);
        },
        //获取source和sourceType
        getSourceInfo: function (callback) {
            App.call('getSourceInfo', callback || defaultCallback);
            //获取埋点信息
        },
        getTalkingDataMsg: function (callback) {
            App.call('getTalkingDataMsg', callback || defaultCallback);
        },
        sdkPreCreditInfo: function (callback) {
            App.call('sdkPreCreditInfo', callback || defaultCallback);
        },
        //获取渠道方传入参数
        getChannelInfo: function (callback) {
            App.call('getChannelInfo', callback || defaultCallback())
        },
        // 525新增native本地存储方法
        /**
        * @param moduleName 模块名, 如iloan, paehome
        * @param key 关键字
        * @param callback 回调函数 function(){}
        */
        getLocalValue: function(opts, callback){
            App.call('getLocalValue', opts.moduleName || 'iloanbt', opts.key || '', callback || defaultCallback);
        },
        /**
        *
        * @param moduleName 模块名, 如iloan, paehome
        * @param key 关键字
        * @param value 值
        * @param callback 回调函数 function(){}
        */
        setLocalValue: function(opts, callback){
            App.call('setLocalValue', opts.moduleName || 'iloanbt', opts.key || '', opts.value || '', callback || defaultCallback);
        }
    };
});