﻿/*!
 * SS环境变量，是Common模块的一部分
 * @module env
 * @require js/common/env 根据环境变量返回API
 */
define([
    "js/common/env",
    "js/common/constant",
    "js/common/utils"
    ],function(envJson,Constant,Utils){
    "use strict";
    var env = envJson.ssEnv;
    var prefix = "", configJson = "";
    var prdUrl = !envJson.isGray?'https://puhui-web.pingan.com.cn/manager/prd/paem/':'https://puhui-web.pingan.com.cn/manager/prd/paem_beta/';
    // iLoan定期环境地址
    console.log(env);
    switch(env){
        case "DEVELOPMENT" :
        	prefix = "https://test1-cfs-phone-web.pingan.com.cn/cfsssfront";
            configJson = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config";
            break;
        case "STG1":
            prefix = "https://test1-cfs-phone-web.pingan.com.cn/cfsssfront";
            configJson = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config";
            break;
        case "STG2":
        	prefix = "https://test2-cfs-phone-web.pingan.com.cn/cfsssfront";
            configJson = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config";
        	break;
        case "STG3":
            prefix = "https://test3-cfs-phone-web.pingan.com.cn/cfsssfront";
            configJson = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config";
        	break;
        case "STG4":
        	prefix = "https://test4-cfs-phone-web.pingan.com.cn:16443/cfsssfront";
            configJson = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config";
        	break;
        case "STG5":
        	prefix = "https://test5-cfs-phone-web.pingan.com.cn:34081/cfsssfront";
            configJson = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config";
        	break;
        case 'STG20':
            prefix = 'http://103.28.214.128:8080/MockServer/kepler';
            configJson = 'https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config';
            break;
        default:
            prefix = "https://cfs-phone-web.pingan.com.cn/cfsssfront";
        	configJson = prdUrl +'config';
    }
    var api = env == "DEVELOPMENT" ? {
        //本地开发环境模拟JSON
        PLUGIN_LOGIN                    : prefix+'/V2/login/umLogin.do',
        //RP账户页面本地数据
        ACCOUNT_DATA                    : "data/accountData.json",
        //AP账户页面本地数据
        AP_DATA                         : "data/APData.json",
        //I贷入口查询接口
        QUERY_ILOAN_STATE               : 'data/queryIloanState.json',
        //选择产品接口
        SELECT_PRODUCTION               : "data/loanSelect.json",
        //借款查询接口
        LOAN_INFO_QUERY                 : "data/productList.json",
        //保存新收(还)款卡接口
        ADD_NEW_PAYEE                   : "data/bindAccount.json",
        //还款试算接口
        REPAYMENT_CALCULATE             : "data/repayCalc.json",
        //首次借款签约接口
        SUBMIT_LOAN_APPLY               : "data/commitSign.json",
        //再次借款签约接口
        RESUBMIT_LOAN_APPLY             : "data/commitSignApplV2.json",
        //平安付绑卡异常信息保存
        saveErrorBindCardInfo           : "/V2/business/saveErrorBindCardInfo.do",
        //申请状态查询接口
        QUERY_USER_APPLY_STATE_2        : 'data/accountData.json',
        //iloanh5外置接口
        QUERY_APPH5_ILOAN               : "/h5/queryApplH5CreditBankNo.do",
        //电子签名OCR识别开关
        ALL_ILOAN_SWITCH                : "data/all_switch.json",
        // H5日志上报开关
        LOG_CONFIG_JSON                 : "data/loggerConfig.json",
        INSURE_VERIFY                   : "/data/insureVerify.json",
        //icard_BT配置模块
        //获取申请借款页数据,地址是根据环境自动添加
        GETLOADINITPARAM                : "",
        //还款列表
        QUERYALLREPAYMENT               : "data/icardqueryAllRepayment.json",
        //还款历史
        ALREADYRPYLIST                  : "data/icardalreadyRpyList.json",
        //还款计划
        RPYPLAN                         : "data/icardrpyPlan.json",
        //借款查询接口
        QUERYAPPLYINFO                  : "data/icardqueryApplyInfo.json",
        //还款试算接口
        REPAYMENTTRIAL                  : "data/icardrepaymentTrial.json",
        //借款信息确认提交
        SUBMITSIGNCONTRACT              : "data/icardSubmitSignContract.json",
        //还款确认
        SUBMITRPY                       : "data/icardsubmitRpy.json",
        //借款详情
        LOANDETAIL                      : "data/icardLoanDetail.json",
        //当期还款明细
        QUERYREPAYMENT                  : "data/icardqueryRepayment.json",
        //卡BIN校验接口
        BTQUERYCARDINFO                 : "data/icardqueryCardInfo.json",
        //设置还款日期接口（提交）
        SETGIVEBACKDATE                 : 'data/icardSetRemindDay.json',
        //获取最新额度(轮询)
        QUERYCREDITBIND                 : "data/icardgainNewestLimit.json",
        //可用银行列表查询接口
        QUERYBANKLIST                   : "data/icardqueryBankList.json",
        //新增信用卡(打小钱)
        SUBMITCARDINFO                  : "data/icardsubmitCardInfo.json",
        //新增信用卡小钱轮询
        ICARDTAKETURNS                  : "data/icardTaketurns.json",
        //更改默认借记卡接口
        CHANGELOANCARD                  : "data/icardchangeTolerantLoanCard.json",
        //信用卡银联认证
        CREDITCARDUNIONPAYCERTIFICATION : "data/icardqueryApplyNoByAccountId.json",
        // 申请号
        QUERYAPPLYNOBYACCOUNTID         : "data/icardqueryApplyNoByAccountId.json",
        //选择产品，获取支用申请号
        CHOOSEPRODECT                   : "data/icardChooseProduct.json",
        //查询账户概要信息
        SEARCH_SUMMARY_INFO             : 'data/summaryInfo.json',
        //查询申请贷款信息
        SEARCH_APPL_INFO                : 'data/wxSearchApplInfo.json',
        drawQueryInfo                   : "data/amountList.json",
        //提现
        drawCash                        : "data/success.json",
        //消息列表获取
        getMessage                      : "data/getMessage.json",
        //还款明细
        TRADE_DETAIL                    : 'data/tradeDetail.json',
        //还款额度查询
        DRAW_CREDIT_AMT_QUERY           : "data/repayment.json",
        //获取还款方式信息
        QUERY_CHANGE_REPAY_TYPE         : "data/repayment_mode.json",
        //提交还款方式信息
        SUBMIT_CHANGE_REPAY_TYPE        : "data/submit_change.json",
        //获取H5链接接口
        GET_INSURANCE_H5_lIANK          : "data/getInsuranceH5Link.json",
        // 预警监听开关
        LISTENER_CONFIG_JSON            : "data/listener_config.json",
        LISTENER_CONFIG_KEPLER          : "data/listener_config.json",
        //通知核保接口
        ADVISE_UNDERWRITING             : "data/adviseUnderWriting.json",
        //银行变更接口
        ALERT                           : "data/alert.json",
        //BT电子签名
        BT_UPLOADPOSELECTRONICSIGNATURE : "data/bTuploadPosElectronicSignature.json",
        //绑卡相关接口--查询用户已绑定的银行卡
        BINDBANKCARDS                   : "data/bindBankCards.json",
        //还款金额提交试算接口
        REPAYSUBMITTRY                  : "data/iloanaheadOfTimeRepayCalc.json",
        //迁徙校验接口
        MIGRATE_CHECK                   : "data/migrateCheck.json",
        //迁徙电子签名
        MIGRATE_ESIGN                   : "data/migrateEsign.json",
        //获取H5电子签名算法配置文件
        SWITCH_SIGN                     : "data/switch_sign.json",
        //i贷入口查询接口
        QUERY_ILOAN_STATE               : "data/queryIloanState.json",
        //产品介绍页更新接口
        QUERY_DEPLOY_INFO               : 'data/queryDeployInfo.json',
        //查询用户是否需要心理测评
        IS_NEED_EVALUATION              : 'data/isNeedEvaluation.json'
    }:
    {
        AP_DATA                         : "/data/APData.json",
        PLUGIN_LOGIN                    : '/login/yiQianBaoLogin.do',
        //I贷入口查询接口
        QUERY_ILOAN_STATE               : '/iloan/queryIloanState.do',
        //申请状态查询接口
        QUERY_USER_APPLY_STATE_2        : '/iloan/queryUserApplyState.do',
        //选择产品接口
        SELECT_PRODUCTION               : "/iloan/queryProduct.do",
        //电子签名
        UPLOADPOSELECTRONICSIGNATURE    : '/iloan/uploadPosElectronicSignature.do',
        //绑卡
        REGULARBINDBINKCARD             : '/iloan/ilaonBtBindBankCard.do',
        //绑卡相关接口--换取参数
        QUERYCARDINFO                   : '/V2/business/queryCardInfo.do',
        //绑卡相关接口--查询支持银行列表
        QUERYBANKCARDLIST               : '/V2/business/queryBankCardList.do',
        //绑卡相关接口--解密接口
        DECRYPTIONREQUESTMSG            : '/V2/business/decryptionRequestMsg.do',
        //绑卡相关接口--查询用户已绑定的银行卡
        BINDBANKCARDS                   : '/V2/business/bindBankCards.do',
        //单个联系人校验接口
        SINGLERELATIONSHIP              : '/iloanSDK/checkSingleRelationship.do',
        //通讯录和通话记录保存
        SAVERELATIONSHIP                : '/iloan/saveRelationship.do',
        //轮询
        AUDITPOLLING                    : '/iloan/auditPolling.do',
        //手机运营商验证
        PHONEOPERATOR                   : '/iloan/phoneOperator.do',
        //心跳包地址--解决添加联系人生产问题
        heartbeat                       : "/common/getTimeStamp.do",
        //BT电子签名
        BT_UPLOADPOSELECTRONICSIGNATURE : "/bt/bTuploadPosElectronicSignature.do",
        //BT重新帮卡
        BT_REGULARBINDBANCARD           : "/bt/btBindBankCard.do",
        //借款查询接口
        LOAN_INFO_QUERY                 : "/iloan/queryIloanCreditAmt.do",
        //保存新收(还)款卡接口
        ADD_NEW_PAYEE                   : "/regular/bindAccount.do",
        //还款试算接口
        REPAYMENT_CALCULATE             : "/iloan/repayCalc.do",
        //首次借款签约接口
        SUBMIT_LOAN_APPLY               : "/iloan/updateCommitSign.do",
        //再次借款签约接口
        RESUBMIT_LOAN_APPLY             : "/iloan/commitSignAppl.do",
        //平安付绑卡异常信息保存
        saveErrorBindCardInfo           : "/V2/business/saveErrorBindCardInfo.do",
        //iloanh5外置
        QUERY_APPH5_ILOAN               : "/h5/queryApplH5CreditBankNo.do",
        //电子签名OCR识别开关
        ALL_ILOAN_SWITCH                : "/iloanbt/all_switch.json",
        // H5日志上报开关
        LOG_CONFIG_JSON                 : "/iloanbt/log_switch.json",
        // 预警监听开关
        LISTENER_CONFIG_JSON            : "/iloanbt/listener_config.json",
        LISTENER_CONFIG_KEPLER          : "/kepler/listener_config.json",
        INSURE_VERIFY                   : "/iloan/confirmInsurance.do",
        //查询用户是否需要心理测评
        IS_NEED_EVALUATION              : '/carat/isNeedEvaluation.do',

        //icard_BT配置模块
        //获取申请借款页数据,地址是根据环境自动添加
        GETLOADINITPARAM                : "/icard/getLoadInitParam",
        //还款列表
        QUERYALLREPAYMENT               : "/icard/rpy/queryAllRepayment.do",
        //还款历史
        ALREADYRPYLIST                  : "/icard/rpy/alreadyRpyList.do",
        //还款计划
        RPYPLAN                         : "/icard/rpy/rpyPlan.do",
        //icard/queryApplyInfo.do 借款查询接口
        QUERYAPPLYINFO                  : "/icard/queryApplyInfo.do",
        //还款试算接口
        REPAYMENTTRIAL                  : "/icard/repaymentTrial.do",
        //借款信息确认提交
        SUBMITSIGNCONTRACT              : "/icard/submitSignContract.do",
        //还款确认
        SUBMITRPY                       : "/icard/rpy/submitRpy.do",
        //贷款详情
        LOANDETAIL                      : "/icard/rpy/loanDetail.do",
        //当期还款明细
        QUERYREPAYMENT                  : "/icard/rpy/queryRepayment.do",
        //卡BIN校验接口
        BTQUERYCARDINFO                 : "/icard/queryCardInfo.do",
        //设置还款日期接口（提交）
        SETGIVEBACKDATE                 : '/icard/setRemindDay.do',
        //获取最新额度(轮询)
        QUERYCREDITBIND                 : "/icard/rpy/gainNewestLimit.do",
        //可用银行列表查询接口
        QUERYBANKLIST                   : "/icard/queryBankList.do",
        //新增信用卡
        SUBMITCARDINFO                  : "/icard/submitCardInfo.do",
        //新增信用卡小钱轮询
        ICARDTAKETURNS                  : "/icard/icardTaketurns.do",
        //更改默认借记卡接口
        CHANGELOANCARD                  : "/icard/rpy/changeTolerantLoanCard.do",
        //信用卡银联认证
        CREDITCARDUNIONPAYCERTIFICATION : "/icard/creditCardUnionPayCertification.do",
        // icard/rpy/queryApplyNoByAccountId.do 申请号
        QUERYAPPLYNOBYACCOUNTID         : "/icard/rpy/queryApplyNoByAccountId.do",
        //选择产品，获取支用申请号
        CHOOSEPRODECT                   : "/icard/rpy/chooseProduct.do",
        //获取H5链接接口
        GET_INSURANCE_H5_lIANK          : "/iloan/getinsuranceH5Liank.do",
        //通知核保接口
        ADVISE_UNDERWRITING             : "/iloan/adviseUnderWriting.do",
        //银行变更接口
        ALERT                           : "/iloan/bank/alter.do",
        //还款金额提交试算接口
        REPAYSUBMITTRY                  : "/iloan/aheadOfTimeRepayCalc.do",

        //SDK
        //消息列表获取
        getMessage                      : "/V2/message/getMessage.do",
        //消息状态更新接口
        updateMessageStatus             : "/message/updateMessageStatus.do",
        //查询概要信息
        SEARCH_SUMMARY_INFO             : "/V2/account/searchSummaryInfo.do",
        //查询申请贷款信息
        SEARCH_APPL_INFO                : "/V4/business/wxSearchApplInfo.do",
        //再次动用查询接口
        drawQueryInfo                   : "/V2/business/drawQueryInfo.do",
        //提现
        drawCash                        : "/V2/business/drawCash.do",
        //电子签名新算法接口
        sdkElectronicSignature          : "/V1/common/sdkElectronicSignature.do",
        electronicSignature             : "/V3/business/electronicSignature.do",
        //还款明细
        TRADE_DETAIL                    : "/V2/business/tradeDetai.do",
        //还款额度查询
        DRAW_CREDIT_AMT_QUERY           : "/V2/business/drawCreditAmtQuery.do",
        //立即还款
        SUBMIT_REPAYMENT                : "/V2/account/submitRpAmtForAppl.do",
        //获取还款方式信息
        QUERY_CHANGE_REPAY_TYPE         : "/V2/business/queryChangeRePayType.do",
        //提交还款方式信息
        SUBMIT_CHANGE_REPAY_TYPE        : "/V2/business/submitChangeRePayType.do",
        //预售信接口
        SDK_PRE_CREDIT_LINE             : '/common/sdkPreCreditLine.do',
        //迁徙校验接口
        MIGRATE_CHECK                   : "/iloan/isMigrate.do",
        //迁徙电子签名
        MIGRATE_ESIGN                   : "/iloan/migrateElectronicSignature.do",
        //产品介绍页更新接口
        QUERY_DEPLOY_INFO               : '/deployRule/queryDeployInfo.do'
    };
    var getUrl = function(name, type){
        var type = type || "SS";
        if(type == "SS") {
            return env == "DEVELOPMENT" ? (api[name]) : (prefix + api[name]);
        }
        if(type == "SWITCH") {
            return env == "DEVELOPMENT" ? (api[name]) : (configJson + api[name]);
        }
    };
    return getUrl
});
