;(function(window,undefined){
    window.$$={extend:function(n,o){for(var i in o)o.hasOwnProperty(i)&&(n[i]=o[i])}};
    /**
     * iloan模块新增Native方法
     * */
    var iloanMethodList = {
        'faceRecognise': 'iloanbt',
        'getContactList': 'iloanbt',
        'selectRelationList': 'iloanbt',
        'bindNetAccount': 'iloanbt',
        'addCreditRequest': 'iloanbt',
        'getContactRecord': 'iloanbt',
        'speechInput': 'iloanbt',
        'upLoadPhoto': 'iloanbt',
        'eSignature': 'iloanbt',
        'readUserSMS': 'iloanbt',
        'pah_loanSuccess': 'iloanbt'
    };

    /**
     * kepleribt模块新增Native方法
     * */
    var kepleribtMethodList = {
        'forwardToNewPage': 'BusinessJump',
        'forwardInCurPage': 'BusinessJump',
        'back': 'BusinessJump',
        'forwardModule': 'BusinessJump',
        'setHeader': 'Header',
        'request': 'HttpPlugin',
        'loadingBegin': 'BusinessCommon',
        'loadingFinish': 'BusinessCommon',
        'tip': 'BusinessCommon',
        'getDeviceId': 'BusinessCommon',
        'getDeviceInfo': 'BusinessCommon',
        'log': 'BusinessCommon',
        'TDOnEvent': 'BusinessCommon',
        'readUserSMS': 'BusinessCommon',
        'getUserInfo': 'UserInfo',
        'getLBS': 'Location',
        'getVersionInfo': 'AppInfo',
        'show': 'Header',
        'hide': 'Header',
        'showPicker': 'Picker',
        'selectDateTime': 'Picker',
        'tokenNotEffect': 'BusinessCommon',
        'saveData': 'BusinessCommon',
        'getData': 'BusinessCommon',
        'upLoadImage': 'Task',
        'previewImage': 'Task',
        'repeatUpload': 'Task',
        'saveTimestamp': 'BusinessCommon',
        'clearMsgNum': 'BusinessCommon',
        'gotoLogin': 'BusinessCommon',
        'clearCache': 'Task',
        'startPolling': 'BusinessCommon',
        'getCityName': 'UserInfo',
        'getSourceInfo': 'AppInfo',
        'getmaliciousAppCnt': 'AppInfo',
        'getUIParams': 'PageUI',
        'doTMXProfileRequest': 'BusinessCommon',
        'getRSAEncodeString': 'BusinessCommon',
        'getContactRecord': 'BusinessCommon',
        'getContactsInfo': 'BusinessCommon',
        'faceRecognise': 'BusinessCommon',
        'getTMXSessionId': 'BusinessCommon',
        'dealTimeOut': 'BusinessCommon',
        'loadPage': 'BusinessJump',
        'processPIBussnise': 'BusinessJump',
        'paPresent': 'BusinessJump',
        //预售信接口
        'sdkPreCreditInfo': 'UserInfo',
        //渠道方传入（广告标识及银行卡）
        'getChannelInfo':'UserInfo'
    };
    var App = window.App = window.$$.platformAdapter = {},
        slice = Array.prototype.slice;

    var nativeClass = iloanMethodList;

    /**
     * 常量定义
     */
    var ua = navigator.userAgent.toUpperCase();
    //判断iloan入口来源 
    App.IS_SDK = ua.indexOf('50110001') != -1 || ua.indexOf('50140001') != -1 || ua.indexOf('KEPLER') != -1 || ua.indexOf('PAMIT') != -1;
    
    // 当前环境是否为Android平台
    App.IS_ANDROID = ua.indexOf('ANDROID') != -1;
    // 当前环境是否为IOS平台
    App.IS_IOS = ua.indexOf('IPHONE OS') != -1;
    // 当前环境是否为WP平台
    App.IS_WP = ua.indexOf('WINDOWS') != -1 && ua.indexOf('PHONE') != -1;
    //当前环境是否为本地开发浏览器环境
    App.IS_LOCAL = (location.hostname == 'localhost');

    var toString = Object.prototype.toString;

    if (App.IS_SDK) {
        nativeClass = kepleribtMethodList;
    }

    //=======================Native 宅e贷App 相关开始================================

    var slice = Array.prototype.slice,
        count = 0,
        loop = function () {
        };
    var data=function(key, value) {
        var storage = localStorage;
        var getItemValue = function() {
            var data = storage.getItem(key);
            try {
                data = JSON.parse(data);
            } catch (e) {
                Utils.logs(e.message);
            }
            return data;
        };
        if (key && value === undefined) {
            return getItemValue();
        }else if(key && value === null){
            storage.removeItem(key);
        }else{
            storage.setItem(key, JSON.stringify(value));
        }
    }
    
     function errHandler(error) {
        switch (error.code) {
            case '001':
              
                if(App.IS_IOS){
                var url='easy-js:YDIOS:request%3A%3A%3A%3A%3A%3A%3A:s%3Ahttp%253A%252F%252Ftest1-cfs-phone-web.pingan.com.cn%252Fcfsssfront%252Fcommon%252FgetTimeStamp.do%3As%3Apost%3As%3A%3As%3Atype%253Diloan_contact_num_failed%2526contactNum%253D'+data('iloan_contact_num')+'%2526accountId%253D'+data('BT_ILOAN_USER_LOGIN_INFO').accountId+'%2526token%253D'+data('BT_ILOAN_USER_LOGIN_INFO').token+'%2526os%253DIOS%3As%3A%3As%3A%3At%3A1455958168535';
                     var iFrame;
                    iFrame = document.createElement("iframe");
                    iFrame.setAttribute("src", url);
                    iFrame.setAttribute("style", "display:none;");
                    iFrame.setAttribute("height", "0px");
                    iFrame.setAttribute("width", "0px");
                    iFrame.setAttribute("frameborder", "0");
                    document.body.appendChild(iFrame);
                    // 发起请求后这个iFrame就没用了，所以把它从dom上移除掉
                    iFrame.parentNode.removeChild(iFrame);
                    iFrame = null;   
                }

                App.call('tip', '网络异常，请更换网络环境并重试');
                break;
            case '002':
                App.call('tip', '没有连接网络');
                break;
            case '003':
                App.call('tip', '网络超时');
                break;
            case '004':
                App.call('tip', '服务器发生异常');
                break;
            default:
                App.call('tip', '未知错误');
                break;
        }
    }
    /**
     * 调用一个Native方法
     * @param {String} name 方法名称
     */
     $$.extend(App, {
        /**
         * @private
         * 回调函数集
         */
        _handlers: {},
        /**
         * 调用Native方法
         * @param method
         */
        call:function(method) {
            var self = this;
            if (App.IS_WP) {
                return;
            }

            var args = slice.call(arguments, 1),
                arg = null,
                callback = null,
                hasCallbackFlag = false,
                handlers = {};

            var handlersErrorCallback = function (arg) {

                return function (error) {
                    // if (!error) {
                        arg.apply(window, slice.call(arguments, 1));
                    // } else {
                    //     //TODO: 统一处理入口
                    //     errHandler(error);
                    // }
                };

            };
            /*
             *请注意！！！！！！！！！arg参数（字符串）安卓和IOS需要单独处理。
             *ios不需要加""号。
             *安卓需要加""号。
             */
            // 参数内容处理
            for (var i = 0, len = args.length; i < len; i++) {
                arg = args[i];
                arg = arg || '';
                // 函数型参数转换
                if (toString.call(arg) == '[object Function]') {
                    callback = method + '_' + count++;
                    handlers = App._handlers;
                    //platformAdapter._handlers[callback] = arg;
                    handlers[callback] = handlersErrorCallback(arg);
                    arg = callback;
                } else if (toString.call(arg) == '[object Object]') {
                    arg = JSON.stringify(arg);
                } else if (toString.call(arg) == '[object Array]') {
                    arg = JSON.stringify(arg);
                }

                if (App.IS_ANDROID) {
                    arg = arg.toString().replace(/\|/g, '||');
                    arg = '"' + arg + '"';
                }
                args[i] = arg;
            }

            // console.log(arguments);
            if (App.IS_ANDROID) {
                var getParameter = function (param) {
                    var reg = new RegExp('[&,?]' + param + '=([^\\&]*)', 'i');
                    var value = reg.exec(location.search);
                    return value ? value[1] : '';
                };
                if (getParameter('ydandroid_version') && nativeClass[method] ||  App.IS_SDK && nativeClass[method]) {
                	method = nativeClass[method] + '.' + method;
                }
                prompt('call://' + method + '(' + args.join('|') + ')');
            } else {
                var businessClass = window[nativeClass[method]];
                try {
                	if (businessClass && businessClass[method]) {
                		businessClass[method].apply(businessClass, args);
                	} else {
                		window.YDIOS[method].apply(window.YDIOS, args);
                	}
                } catch (e) {
                    // error
                }
            }
        },
        callback: function (method) {
            var args = slice.call(arguments, 1),
                handlers = App._handlers,
                callback = null;
            callback = handlers[method];
            if (callback && toString.call(callback) == '[object Function]') {
                callback.apply(window, args);
            }
        }
    });
    window.__callback = $$.platformAdapter.callback;

    /**
     * 本地缓存安全整改,5.7.0版本后window.localStorage改为window.native（由Native封装）,原有业务代码无需作任何改动
     * 兼容两种引用方式：
     * 1、window.localStorage.getItem|setItem|removeItem
     * 2、C.Utils.data
     */
    var storageCache = {
        getItem: window.localStorage.getItem,
        setItem: window.localStorage.setItem,
        removeItem: window.localStorage.removeItem,
        nativeStorage: window.native ? window.native : null//是否使用Native数据存储
    };

    // override localStorage
    window.localStorage.getItem = function(key) {
        var data;
        data = storageCache.nativeStorage ? storageCache.nativeStorage.getItem(key) : storageCache.getItem.call(this, key);
        return data;
    };
    window.localStorage.setItem = function(key, value) {
        storageCache.nativeStorage ? storageCache.nativeStorage.setItem(key, value) : storageCache.setItem.call(this, key, value);
    };
    window.localStorage.removeItem = function(key) {
        storageCache.nativeStorage ? storageCache.nativeStorage.setItem(key, null) : storageCache.removeItem.call(this, key);
    };
}(window));
