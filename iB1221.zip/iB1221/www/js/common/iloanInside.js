/**
 * @author: liujinhuan647@pingan.com.cn
 * @date  : 2016-03-18
 * @time  : am 9:36
 *
 * @describe: iloan+iloanBT入口逻辑处理代码
 */
define(["zepto","C"],function($,C){
    'use strict';
    var L = {
        iloanConstant : { 
            USER_LOGIN_INFO         :"ILOAN_USER_LOGIN_INFO",
            PRODUCT_LIST_RES        :"ILOAN_PRODUCT_LIST_RES",
            PRODUCT_LIST_RES_BANK   :"ILOAN_PRODUCT_LIST_RES_BANK",
            SELECT_PRO_ITEM         :"ILOAN_SELECT_PRO_ITEM",
            INFORMATION_TRIAL_RES   :"ILOAN_INFORMATION_TRIAL_RES",
            BIND_ACCOUNT_LIST       :"ILOAN_BIND_ACCOUNT_LIST",
            LOAN_RESULT             :"ILOAN_RESULT",
            INTO_SHAW_REPAY_PARAM   :"ILOAN_INTO_SHAW_REPAY_PARAM",
            SHAWREPAYSCHEDULE       :"ILOAN_SHAWREPAYSCHEDULE",
            INTOSHAWREPAYSCHEDULE   :"ILOAN_INTOSHAWREPAYSCHEDULE",
            ILOANAPPLYNO            :"ILOAN_APPLYNO",
            ILOAN_CUSTNO            :"ILOAN_CUSTNO",
            ILOAN_BILLDAY           :"ILOAN_BILLDAY",
            PRODUCT_TYPE            :"ILOAN_PRODUCT_TYPE",
            CARD_DATA               :"ILOAN_CARD_DATA",
            BEFORE_SOCIAL_OUTHER_HREF   :"ILOAN_BEFORE_SOCIAL_OUTHER_HREF",
            NEED_CONTACT            :"ILOAN_NEED_CONTACT",
            FACE_PARAM              :"ILOAN_FACE_PARAM",
            FACE_STARTTIME          :"ILOAN_FACE_STARTTIME",
            PHONE_AUTH_FLAG         :"ILOAN_PHONE_AUTH_FLAG",
            LOANFAIL_CHANGE_TIME    :"ILOAN_FAIL_CHANGE_TIME",
            CHOOSE_CARD_FROM        :"ILOAN_CHOOSE_CARD_FROM",
            HASBINDED_CARD_INFO     :"ILOAN_HASBINDED_CARD_INFO",
            BINDCARD_FROM_SELECT    :"ILOAN_BINDCARD_FROM_SELECT",
            ACCOUNT_RESULT          :"ILOAN_ACCOUNT_RESULT",
            REPAYMENT_RESULT        :"ILOAN_REPAYMENT_RESULT",
            BIND_CARDS_LIST         :"ILOAN_BIND_CARDS_LIST",
            SELECTCARD_FROM_LIST    :"ILOAN_SELECTCARD_FROM_LIST",
            SHEBAO_CITY_LIST        :"ILOAN_SHEBAO_CITY_LIST",
            BINDED_BINDNO           :"ILOAN_BINDED_BINDNO",
            LOAN_FAIL_FROM_ACCOUNT  :"LOAN_FAIL_FROM_ACCOUNT",
            LOAN_IS_OD              :"LOAN_IS_OD",
            FAIL_RETRY_JSON         :"FAIL_RETRY_JSON",
            FAIL_RETRY_BANKINFO     :"FAIL_RETRY_BANKINFO",
            ILOAN_LOANSEQ           :"ILOAN_LOANSEQ",
            ILOAN_EDIT_CONTACT      :"ILOAN_EDIT_CONTACT",
            ILOAN_INDEX_TYPE        :"ILOAN_INDEX_TYPE",
            ILOAN_INDEX_TIPMSG      :"ILOAN_INDEX_TIPMSG",
            UPLOAD_CONTACT_NUM      :'ILOAN_UPLOAD_CONTACT_NUM'
        },

        xindaiConstant : {
             // 我的账号详情页申请号applNo
            ACCOUNT_DETAIL_APPLNO: "XINDAI_ACCOUNT_DETAIL_APPLNO",
            // 我的账户详情页存储信息
            ACCOUNT_DETAIL: "XINDAI_ACCOUNT_DETAIL",
            // 壹钱包信息
            YIQIANBAO: "XINDAI_YIQIANBAO",
            QUERY_TOP_UP_CUSTOMER_INFO:"QUERY_TOP_UP_CUSTOMER_INFO",
            LUFAX_INFO:"LUFAX_INFO",
            // 追加贷款信息
            APP_INFO: "XINDAI_APP_INFO",
            // 富登还款还款金额
            FD_REPAY_AMT: "XINDAI_FD_REPAY_AMT",
            // 富登还款界面信息查询数据
            SEARCH_FD_PAY_BASEINFO: "XINDAI_FD_PAY_BASEINFO",
            // 信保还款界面信息查询数据
            SEARCH_PAY_BASEINFO: "XINDAI_SEARCH_PAY_BASEINFO",
            // 平安付token
            PAF_TOKEN: "XINDAI_PAPAF_TOKEN",
            // 壹钱包账户余额
            YIQIANBAO_BALANCE: "XINDAI_YIQIANBAO_BALANCE",
            // 查询追加贷款信息数据
            SEARCH_APPL_INFO: "XINDAI_SEARCH_APPL_INFO",
            // topup信息录单相关数据
            INFORMATION_RECORD: "XINDAI_INFORMATION_RECORD",
            INFORMATION_RECORD_MORE: "XINDAI_INFORMATION_RECORD_MORE",
            INFORMATION_RECORD_FROM: "XINDAI_INFORMATION_RECORD_FROM"
        },

        iloanBTConstant:{
        	//城市名---BTILOAN
            BT_ILOAN_CITYNAME       :"BT_ILOAN_CITYNAME",
            //申请状态查询接口--统一数据key
            BT_ILOAN_QUAS_RESULT    :"BT_ILOAN_QUAS_RESULT",
            //申请状态查询接口--是否进行过实名认证
            BT_ILOAN_CHANNELCODE    :"BT_ILOAN_CHANNELCODE",
            // 用户登录数据---BTILOAN
            USER_LOGIN_INFO         :"BT_ILOAN_USER_LOGIN_INFO",
            // 申请号
            ILOANAPPLYNO            :"BT_ILOAN_APPLYNO",
            PRODUCT_TYPE			:"BT_ILAON_PRODUCT_TYPE",
            ILOAN_BILLDAY			:"BT_ILAON_ILOAN_BILLDAY",
            ILOAN_CUSTNO			:"BT_ILAON_ILOAN_CUSTNO",

            //$$.EventListener.onBack的data
            ONBACK_DATA             :"BT_ILAON_ONBACK_DATA",
            //绑卡信息---BTILOAN
            CARD_DATA				:"BT_ILOAN_CARD_DATA",
            //是否需要上传通讯录标示---BTILOAN
            NEED_CONTACT			:"BT_ILOAN_NEED_CONTACT",
            //是否可以手动修改联系人---BTILOAN
            EDIT_CONTACT			:'BT_ILOAN_EDIT_CONTACT',
            //联系人通讯录上传数量---BTILOAN
            UPLOAD_CONTACT_NUM		:'BT_ILOAN_UPLOAD_CONTACT_NUM',
            //人脸识别参数---BTILOAN
            FACE_PARAM				:"BT_ILOAN_FACE_PARAM",
            //人脸识别开始时间---BTILOAN
            FACE_STARTTIME			:"BT_ILOAN_FACE_STARTTIME",
            //鉴权卡时查询已绑定银行卡列表---BTILOAN
            BIND_CARDS_LIST			:"BT_ILOAN_BIND_CARDS_LIST",
            // url--成功后跳转页面 moduleName--成功后跳转模块 route--成功后跳转方式
            BT_ILOAN_BINDCARD_FROM   :"BT_ILOAN_BINDCARD_FROM",
            //支用申请号
            BT_ILOAN_PAYAPPLYNO     :"BT_ILOAN_PAYAPPLYNO",
            //账户协议
            BT_ILOAN_CONTRACT_DATA  :"BT_ILOAN_CONTRACT_DATA",
            // 提现申请信息
            LOAN_APPLY_INFO         :"BT_ILOAN_LOAN_APPLY_INFO",
            // 提现申请金额
            LOAN_APPLY_AMOUNT       :"BT_ILOAN_LOAN_APPLY_AMOUNT",
            // 提现后还款计划试算
            LOAN_REPAY_PLAN         :"BT_ILOAN_LOAN_REPAY_PLAN",
            //BT30天电子签名接口返回
            BT_THRITY_ESIGN_INFO	:"BT_THRITY_ESIGN_INFO",
            //BT邦卡来源标记：1：选择银行卡；2：添加银行卡
            BT_BINDCARD_FLAG		:"1",
            //再贷被拒，点击被拒页面左上角返回帐户页面
            BT_RJ_FROM				:"BT_RJ_FROM"
        },

        nodeObj:{
			"AU":"iloan_production_index.html",
			"AM":"iloan_production_index.html",
			"AF":"iloan_production_index.html",
			"AC":"iloan_production_index.html",
			"AY":"iloan_production_index.html",
			"AP":"iloan_production_index.html",
			"RP":"account_iloan.html",
			"RJ":"iloan_production_index.html",
			"XX":"iloan_production_index.html",
		},

		iloanh5_aboutProductiLoanH5_nodeObj:{
			"AU":"credit_info_list.html",
			"AM":"credit_info_list.html",
			"AF":"credit_info_list.html",
			"AC":"credit_info_list.html",
			"AY":"credit_info_list.html",
			"AP":"loan_select.html",
			"RP":"account_iloan.html",
			"RJ":"credit_fail_result.html",
			"XX":"",
		},

        /**
         * 清除上次存储数据
         * */
        clearLastData: function(key) {
            var _this = this,keyjson;
            if(key=="iloan"){
                keyjson = _this.iloanConstant;
            }else if(key=="xindai"){
                keyjson = _this.xindaiConstant;
            }else if(key =="iloanbt"){
                keyjson = _this.iloanBTConstant;
            }
            $.each(keyjson, function(key, value) {
                C.Utils.data(keyjson[key], null);
            })
        },

        /**
         * 信贷入口
         * type: 1.topup 表示跳转topup 0.表示信保和topup都可以跳转
         * */
        goXindai: function() {
            var _this = this,
                type = arguments[0] ? arguments[0] : 0;
            C.Native.login({}, function() {
                _this.xindaiClick(type);
            });
        },
        /*---start---*/
        //跳转信贷2016.5.26新增需求处理逻辑
        xindaiControl:function(appObj){
            C.Utils.data("XINDAI_ACCOUNT_DETAIL_APPLNO", appObj.applNo);
            if(appObj.type=="1"){//进入详情页
                C.Native.forwardModule({
                    module: 'xindai',
                    url: 'account_detail.html'
                });
            }else if(appObj.type=="2"){//进入可申请流程
                if(appObj.isTopup=="Y"){//线上---进度值为：0，1
                    if(appObj.applNo){//有申请号已经身份验证
                        if(appObj.singleTopup=="Y"){//单双帐户判断
                            C.Native.forwardModule({
                                module: 'xindai',
                                url: 'selection_single.html'
                            }); 
                        }else if(appObj.singleTopup=="N"){
                            C.Native.forwardModule({
                                module: 'xindai',
                                url: 'selection_double.html'
                            });
                        }else{C.Native.tip('数据异常，没有此类型帐户。'); }
                    }else{//没有申请号，从头申请
                        C.Native.forwardModule({
                            module: 'xindai',
                            url: 'information_verification.html'
                        });
                    }
                }else if(appObj.isTopup=="N"){//线下--都是从选择贷款开始
                    C.Native.forwardModule({
                        module: 'xindai',
                        url: 'supplementary-loan-suc.html'
                    });
                }else{ C.Native.tip('数据异常。'); }
            }else{
                C.Native.forwardModule({
                    module: 'xindai',
                    url: 'account.html'
                });
            }
        },
        /*---end---*/

        xindaiClick: function(type) {
            var self = this,stop=false,flag=false;
            /*---start---*/
            //拦截老版本app
            C.Native.getAppVersion(function (res) {
                if (res.version &&parseInt(res.version)<495) {stop=true;}
                if (App.IS_ANDROID && parseInt(res.version)>=430) {flag=true;} 
            });
            if(stop){C.Native.tip('您的app版本过低，请更新。'); return;}
            if(flag){
                C.Native.loadingBeginNew('', false);
            }else{C.UI.loading(); }
            /*--end--*/
        
            self.clearLastData('xindai');
            C.Native.getUserInfo(function(res) {
                C.Utils.data('XINDAI_USER_LOGIN_INFO', res);
                // 请求searchApplInfo判断mark是否为空
                C.Native.getDeviceInfo(function(res) {
                    if(res.code=='1') {
                        $.ajax({
                            url: C.Api.SEARCH_APPL_INFO,
                            data: {
                                'longitude': res.result.longitude,      // 经度
                                'latitude': res.result.latitude,        // 纬度
                                'merReserved': {},                      // 埋点信息 TODO 需要确认埋点信息
                                'cityName': res.result.gpsCity          // 城市
                            },
                            success: function(result) {
                                if(result.flag=='1') {

                                    /*--start--*/
                                    C.Utils.data("XINDAI_SEARCH_APPL_INFO", result.data);
                                    var appObj=C.Utils.data(C.Constant.DataKey.TOPUPLOCALDATA);
                                    C.Utils.data(C.Constant.DataKey.TOPUPLOCALDATA,"");
                                    /*--end--*/


                                    if(result.data.mark!='') {
                                        // 请求判断applType是否为空
                                        $.ajax({
                                            url: C.Api.QUERY_XBLOAN_INFO,
                                            type: 'post',
                                            data: {},
                                            success: function(result) {
                                                C.UI.stopLoading();
                                                var isTopupAppl = false,
                                                    topUpInfor = result.data.topUpInfor;
                                                // 追加贷款为普通追加还是topup追加
                                                if(topUpInfor.isTopup=='Y' && topUpInfor.hasQualification=='Y') {
                                                    // topup追加
                                                    isTopupAppl = true;
                                                } else {
                                                    if(type==1) {
                                                        C.Native.tip('暂时无法申请追加，请按时还款、累计信用，下次再试');
                                                        return;
                                                    }
                                                }
                                                if(result.flag=='1') {
                                                    // 判断applType!=XB，或者lnSumLst==0，没有资格
                                                    var has_xb = false;
                                                    for(var i in result.data.lnSumLst) {
                                                        if(result.data.lnSumLst[i].applType=='XB') {
                                                            has_xb = true;
                                                        }
                                                    }
                                                    if(has_xb) {
                                                        C.Native.forwardModule({
                                                            module: 'xindai',
                                                            url: 'supplementary-loan-fail.html'
                                                        });
                                                    } else {
                                                        /*--start--*/
                                                        if(appObj&&appObj.type!="0"){//5.26新增判断
                                                            //存储topup帐户信息
                                                            C.Utils.data("XINDAI_IS_TOP_UP",topUpInfor);
                                                            var account_data = {
                                                                process: '',    // 申请进度
                                                                creditLine: topUpInfor.creditLine || 0,     // 可借额度
                                                                applNo: '',      // 申请号
                                                                acctType: '',  // 贷款类型
                                                                applType: ''   // 申请类型
                                                            }
                                                            C.Utils.data("XINDAI_ACCOUNT_DETAIL", account_data);
                                                            self.xindaiControl(appObj);
                                                        }else{//原流程
                                                            C.Native.forwardModule({
                                                                module: 'xindai',
                                                                url: 'account.html'
                                                            });  
                                                        }
                                                        /*end*/
                                                        
                                                    }
                                                } else {
                                                    C.Native.tip(result.msg);
                                                }
                                            },
                                            error: function() {
                                                C.UI.stopLoading();
                                                C.Native.tip('网络异常，请稍后再试');
                                            }
                                        });
                                    } else {
                                        

                                        /*--start--*/
                                        if(appObj&&appObj.type!="0"){//5.26新增判断
                                            $.ajax({
                                                url: C.Api.QUERY_XBLOAN_INFO,
                                                type: 'post',
                                                data: {},
                                                success: function(result) {
                                                    C.UI.stopLoading();
                                                    if(result.flag=='1') {
                                                        var topUpInfor = result.data.topUpInfor;
                                                        //存储topup帐户信息
                                                        C.Utils.data("XINDAI_IS_TOP_UP",topUpInfor);
                                                        // 保存数据到localStorage，后续页面使用
                                                        var account_data = {
                                                            process: '',    // 申请进度
                                                            creditLine: topUpInfor.creditLine || 0,     // 可借额度
                                                            applNo: '',      // 申请号
                                                            acctType: '',  // 贷款类型
                                                            applType: ''   // 申请类型
                                                        }
                                                        C.Utils.data("XINDAI_ACCOUNT_DETAIL", account_data);
                                                        self.xindaiControl(appObj);
                                                    }else{C.Native.tip('查询信息失败:'+result.msg);}
                                                },
                                                error: function() {
                                                    C.UI.stopLoading();
                                                    C.Native.tip('网络异常，请稍后再试');
                                                }
                                            });
                                        }else{//原流程
                                            C.UI.stopLoading();
                                            C.Native.forwardModule({
                                                module: 'xindai',
                                                url: 'account.html'
                                            });
                                        }
                                        /*--end--*/
                                    }
                                } else {
                                    C.UI.stopLoading();
                                    C.Native.tip('网络异常，请稍后再试');
                                }
                            },
                            error: function(result) {
                                C.UI.stopLoading();
                                C.Native.tip('网络异常，请稍后再试');
                            }
                        });
                    } else {
                        C.UI.stopLoading();
                        C.Native.tip('查询设备信息出错');
                    }
                });
            });
        },

        /**
         * iloan入口
         * */
        goIloan: function() {
            var _this = this;
            C.Native.login({}, function(){
	           	 C.Native.getUserInfo(function(data){
                    C.Utils.data("ILOAN_USER_LOGIN_INFO",data);
                    _this.userInfo = data;
                    C.Native.getAppVersion(function (res) {
                        if (App.IS_ANDROID && res.version>=430) {
                            C.Native.loadingBeginNew('', false);
                        } else {
                            C.UI.loading();
                        }
                    });
                    // 弹iloan相关产品页
                    $.ajax({
                        type: "post",
                        url: C.Api("QUERY_APPH5_ILOAN"),
                        data: {
                            jsonPara : JSON.stringify({
                                accountId : _this.userInfo.accountId,
                                tel : C.rsaEncrypt(_this.userInfo.mobile)
                            })
                        },
                        success: function (res) {
                            if (res.flag == "1") {
                                if(res.data.resultCode=="1"){
                                	if ((res.data.isAppoint==1 && res.data.isAppl == 1 && res.data.isCredit == 0) || (res.data.isAppoint==1 && res.data.isAppl == 0)) {
                                        C.Utils.data(C.Constant.DataKey.QUERY_ILOAN_H5_RESULT, res.data);
                                        C.Native.forwardModule({
                                        	module:"paehome",
                                            url: 'amount.html'
                                        });
                                        C.UI.stopLoading();
                                    } else {
                                        C.Utils.data(C.Constant.DataKey.QUERY_ILOAN_H5_RESULT, '');
                                        _this.toJumpWhichIloan(fromPage);
                                    }
                                }else{
                                	 C.UI.stopLoading();
                                	 C.Native.tip(res.data.resultMsg);
                                }
                            }
                        },
                        error: function () {
                       	 C.UI.stopLoading();
                        }
                    });
                });
            });
        },
        toJumpWhichIloan:function(){
            var self = this;
            C.Native.getAppVersion(function (res) {
                if (App.IS_ANDROID && res.version>=430) {
                    C.Native.loadingBeginNew('', false);
                } else {
                    C.UI.loading();
                }
            });
           C.Native.getCityName(function(res){
                var cityName = res.cityName;
                if(!!cityName){
                	C.Utils.data("ILOAN_CITYNAME",cityName);
                	C.Utils.data("BT_ILOAN_CITYNAME",cityName);
                }else{
	            	 C.Native.forward({
	                     url: "try_get_cityname.html"
	                 });
                }
                var param = {
                    cityName: cityName
                };
                $.ajax({
                    url: C.Api("QUERY_ILOAN_STATE"),
                    type: "post",
                    data: {
						jsonPara:JSON.stringify(param)
					},
                    success:function(res){
                        if (res.flag == "1" && res.data) {
                            var data = res.data;
                            if(data.realNameAuth=="0"){
                                C.Native.getAppVersion(function (res) {
                                    if (res.version>=470) {
                                        C.Native.realnameVerification('N', function(res){
                                            if(res.flag=="1"){
                                                C.Native.getUserInfo(function(data) {
                                                    C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                                                    self.toJumpWhichIloan();
                                                });
                                            }
                                        });
                                    }else{
                                        C.Native.addUserInfo(function(res){
                                            if(res.code=="1"){
                                                C.Native.getUserInfo(function(data) {
                                                    C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                                                    self.toJumpWhichIloan();
                                                });
                                            }
                                        });
                                    }
                                });
                            }else{
                                 if(data.resultCode == "1") {
                                    if(data.productVersion=="DQ"){
                                        self.iLoanClick();
                                    }else if(data.productVersion=="IBT"){
                                        self.iLoanBTClick();
                                    }
                                 }else{
                                    C.Native.tip(res.data.resultMsg||"网络异常，请稍后再试");
                                 }
                            }
                        }else{
                            C.Native.tip(res.msg||"网络异常，请稍后再试");
                        }
                    },
                    error:function(){
                    	C.UI.stopLoading();
                    }
                });
           });
            
        },

        iLoanClick: function() {
            var _this = this;
            C.Native.getAppVersion(function (res) {
                if (App.IS_ANDROID && res.version>=430) {
                    C.Native.loadingBeginNew('', false);
                } else {
                    C.UI.loading();
                }
            });
            _this.clearLastData('iloan');
            C.Native.getUserInfo(function(data) {
                C.Utils.data("ILOAN_USER_LOGIN_INFO", data);
                C.Native.getCityName(function(result) {
                    var cityName = result.cityName;
                    if(!cityName){
                        C.Native.forwardModule({
                            module: 'iloan',
                            url: "try_get_cityname.html"
                        });
                        return false;
                    }else{
                        C.Utils.data("ILOAN_CITYNAME",cityName);
                    }
                    $.ajax({
                        url: C.Api.QUERY_USER_APPLY_STATE,
                        type: "post",
                        data: {
                            cityName: cityName
                        },
                        success: function(res) {
                            if (res.flag == "1" && res.data) {
                                var data = res.data;
                                if(data.resultCode == "1") {
                                    if(data.channelCodeFlag=="0"){
                                        C.Native.getAppVersion(function (res) {
                                            if (res.version>=470) {
                                                C.Native.realnameVerification('N', function(res){
                                                    if(res.flag=="1"){
                                                        C.Native.getUserInfo(function(data) {
                                                            C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                                                            _this.iLoanClick();
                                                        });
                                                    }
                                                });
                                            }else{
                                                C.Native.addUserInfo(function(res){
                                                    if(res.code=="1"){
                                                        C.Native.getUserInfo(function(data) {
                                                            C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                                                            _this.iLoanClick();
                                                        });
                                                    }
                                                });
                                            }
                                        });
                                        
                                    }else{

                                        //数据缓存
                                        if(data.productType) {
                                            C.Utils.data("ILOAN_PRODUCT_TYPE", data.productType);
                                        }
                                        if(data.applNo) {
                                            C.Utils.data("ILOAN_APPLYNO", data.applNo);
                                        }
                                        if(data.billDate) {
                                            C.Utils.data("ILOAN_BILLDAY", data.billDate);
                                        }
                                        if(data.custNo) {
                                            C.Utils.data("ILOAN_CUSTNO", data.custNo);
                                        }
                                        switch (data.subProcessCode) {
                                            case "AU":
                                            case "XX":
                                            case "RJ":
                                            case "AM":
                                            case "AF":
                                            case "AC":
                                            case "AY":
                                            case "AP":
                                                //跳转到产品介绍页：1、未鉴权，2、申请开关关闭，3、拒绝
                                                C.Utils.data("ILOAN_INDEX_TYPE", data.subProcessCode);
                                                C.Utils.data("ILOAN_INDEX_TIPMSG", data.resultMsg);
                                                C.Native.forwardModule({
                                                    module: 'iloan',
                                                    url: 'iloan_production_index.html?frompage=home'
                                                });
                                                break;
                                            default:
                                                //非授信环节申请状态处理
                                                C.Native.forwardModule({
                                                    module: 'iloan',
                                                    url: 'shaw_account.html?frompage=home'
                                                })
                                                break;
                                        }

                                    }
                                } else if(data.resultCode == "000001") {
                                    var tiphtml = ['<section id="first_in_tip" class="iloan-leayer">'+
                                                '<div class="iloan-dialog iloan-reminder-tip">'+
                                                '<div class="iloan-rmd-con">'+
                                                    '<h2>温馨提示</h2>'+
                                                    '<div class="iloan-tal">'+ data.resultMsg +'</div>'+
                                                    '<div class="btn iloan-mt30 close_tip_win">我知道了</div>' +
                                                '</div></div></section>'].join('');
                                    $('body').append(tiphtml);
                                    $('.close_tip_win').on('click',function(){
                                        $('#first_in_tip').remove();
                                    });
                                    C.UI.stopLoading();
                                } else {
                                    C.UI.stopLoading();
                                    C.Native.tip(data.resultMsg);
                                }
                            } 
                            C.UI.stopLoading();
                        },
                        error:function(){
                        	C.UI.stopLoading();
                        }
                    });
                });
            });
        },
        
        iLoanBTClick:function(){
            var _this = this;
           _this.clearLastData("iloanbt");
           C.Native.getUserInfo(function(data) {
               C.Utils.data("BT_ILOAN_USER_LOGIN_INFO", data);
               C.Native.getCityName(function(res){
                    var cityName = res.cityName;
                   if(!cityName){
                       C.Native.forward({
                           url: "try_get_cityname.html"
                       });
                       return false;
                   }else{
                       C.Utils.data("BT_ILOAN_CITYNAME",cityName);
                   }
                   var param = {};
                   C.Native.getDeviceInfo(function(res) {
                        if (res.code == "1") {
                            param = {
                                cityName : cityName,
                                longitude:(res.result.longitude).toString(),
                                latitude:(res.result.latitude).toString(),
                                applyNo: C.Utils.data("BT_ILOAN_APPLYNO")||""
                            };
                            $.ajax({
                                url: C.Api("QUERY_USER_APPLY_STATE_2"),
                                type: "post",
                                data: {
                                    jsonPara:JSON.stringify(param)
                                },
                                success: function(res) {
                                	C.UI.stopLoading();
                                    if (res.flag == "1" && res.data) {
                                        var data = res.data;
                                        C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, data);
                                        if(data.resultCode == "1") {
                                        	var iloanH5Result = C.Utils.data("QUERY_ILOAN_H5_RESULT");
                                        	//如果是iloanh5外置
                                        	if(iloanH5Result && (iloanH5Result.isAppoint==1 && iloanH5Result.isAppl == 1 && iloanH5Result.isCredit == 0) || (iloanH5Result.isAppoint==1 && iloanH5Result.isAppl == 0)){
                                        		//从相关产品页面点击进入，是原广告页面逻辑+直接进入完善信息
                                        		if(fromPage &&　fromPage=="aboutProductiLoanH5"){
                                        			 if(res.data.applySwitch && res.data.applySwitch == "0"){//申请开关关闭
                                                     	C.Native.tip(res.data.switchMsg);
                                                     }else{//申请开关打开
                                                     	if(_this.iloanh5_aboutProductiLoanH5_nodeObj[res.data.subProcessCode]==""){
                                                 			C.Native.tip(res.data.resultMsg);
                                                 		}else{
                                                 			C.Native.forwardModule({
                                                 				module: 'iloanbt',
                                                 				url : _this.iloanh5_aboutProductiLoanH5_nodeObj[res.data.subProcessCode]
                                                 			});
                                                 		}
                                                     }
                                        		}else{//且从入口+借钱等页面进入的，需要直接进入3秒广告页面
                                        			C.Native.forward({
                                                        url : _this.iloanh5_home_nodeObj[res.data.subProcessCode]
                                                    });
                                        		}
                                        	}else{
                                        		C.Native.forward({
                                                    url : _this.nodeObj[res.data.subProcessCode]
                                                });
                                        	}
                                        }else if(data.resultCode == "000001" || data.resultCode == "000002") {
                                            var tiphtml = ['<section id="first_in_tip" class="iloan-leayer">'+
                                                        '<div class="iloan-dialog iloan-reminder-tip">'+
                                                        '<div class="iloan-rmd-con">'+
                                                            '<h2>温馨提示</h2>'+
                                                            '<div class="iloan-tal">'+ data.resultMsg +'</div>'+
                                                            '<div class="btn iloan-mt30 close_tip_win">我知道了</div>' +
                                                        '</div></div></section>'].join('');
                                            $('body').append(tiphtml);
                                            $('.close_tip_win').on('click',function(){
                                                $('#first_in_tip').remove();
                                            });
                                        } else {
                                            C.Native.tip(data.resultMsg||"网络异常，请稍后重试");
                                        }
                                    } else {
                                        C.Native.tip(res.msg||"网络异常，请稍后重试");
                                    }
                                    C.UI.stopLoading();
                                },
                                error:function(){
                                	C.UI.stopLoading();
                                }
                            });
                        }
                    });
                    
               });
          });
        }
    };
    return L;
});
