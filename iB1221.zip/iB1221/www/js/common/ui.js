/*!
 * ui模块 common子模块
 * @module ui
 * @author 周一平 
 * @history 2015-6-10 add
 */
 define(["zepto","js/common/native"],function($,Native){
 	var ui = {
 		loading:function(){
 			Native.loadingBegin();
 		},
 		stopLoading:function(){
			Native.loadingFinish();
 		}
 	};
    // content 第一行说明
    // content2 第二行说明
    $.extend(ui,{
    	error:function(opt){
            var opt = $.extend({
                icon:'error_alert_logo'
            },opt)
    		ui.dialog(opt);
    	},
    	success:function(opt){
    		var opt = $.extend({
                icon:'ok_alert_logo'
            },opt)
    		ui.dialog(opt);
    	},
        warm:function(opt){
            var opt = $.extend({
                icon:'warn_alert_logo'
            },opt)
            ui.dialog(opt);
        },
        tip:function(opt){
        	ui.toptip(opt);
        },
        select:function(opt){
        	ui.selectDialog(opt);
        }
    });

	// 设置金额，做成zepto插件
	$.fn.setAmt = function(val){
		val = ((val || "0")*1).toFixed(2);
		var n1 = val.split(".")[0];
		var n2 = val.split(".")[1];
		$(this).addClass("text-amt").html("￥"+n1+". <span>"+n2+"</span> ");
	}
	
	$.fn.loadHTML = function(url,callback) {
        var $this = $(this);
        $.ajax({
            url: url,
            type: "get",
            dataType: "html",
            xhr: function() {
                return new window.XMLHttpRequest();
            },
            success: function(res) {
                $this.html(res);
                callback && callback(res);
            },
            complete:function(){}

        })
    }
	//吸顶提示
	ui.toptip = (function() {
		var wrap, active = false;
		return function(opt) {
			if (active) return;
			active = true;
			opt = opt || {};
			wrap = document.createElement('div');
            wrap.className = opt.className || 'wrong';
            wrap.innerHTML = [opt.tip || ''].join('');
			document.body.appendChild(wrap);
			setTimeout(function(){
        		$(wrap).remove();
        		active = false;
        	},opt.time || 5000);
		}
	})();
	
	ui.selectDialog = (function() {
		var selectWrap, doing = false;
		return function(opt) {
			if (doing) return;
			doing = true;
			opt = opt || {};
			opt.title = opt.title || "请选择";
			opt.type = opt.type || "";
			if (!document.getElementById('_iloan_select_box')) {
				selectWrap = document.createElement("div");
				selectWrap.id = "_iloan_select_box";
				selectWrap.style.display = "none";
                if(opt.selectArray && opt.selectArray.length>0){
                	var optionHtml = "";
                	//如果是来自确认借款信息界面的，就用这个样式
                	if(opt.type && opt.type=="style-br"){
                		var i=0;i<data.length;i++
                		for(var i=0;i<opt.selectArray.length;i++){
                    		if(opt.selectArray[i] == opt.showtext) {
                    			optionHtml += '<li class="slected" data-code="'+ i +'">'+ opt.selectArray[i] +'</li>'
                    		} else {
                    			optionHtml += '<li data-code="'+ i +'">'+ opt.selectArray[i] +'</li>'
                    		}
                    		
                    	}
                    	selectWrap.innerHTML = [
    						'<section class="leayer"><div class="dialog dialog-way"><div class="close close-select-dialog"></div>'+
    						'<div class="title"><h2>'+ opt.title +'</h2></div>'+
    						'<ul class="sel-opt">'+ optionHtml +'</ul>'+
    						'</div></section>'].join("");
                	}else{
                		for(var i=0;i<opt.selectArray.length;i++){
                    		if(opt.selectArray[i] == opt.showtext) {
                    			optionHtml += '<li class="slected" data-code="'+ i +'">'+ opt.selectArray[i] +'</li>'
                    		} else {
                    			optionHtml += '<li data-code="'+ i +'">'+ opt.selectArray[i] +'</li>'
                    		}
                    		
                    	}
                    	selectWrap.innerHTML = [
    						'<section class="leayer"><div class="dialog slt-tip" style="margin-top:1px;"><div class="close close-select-dialog"></div>'+
    						'<h2>'+ opt.title +'</h2>'+
    						'<ul class="sel-opt">'+ optionHtml +'</ul>'+
    						'</div></section>'].join("");
                	}
                	
                }
                document.body.appendChild(selectWrap);
                $closeBtn = $('.close-select-dialog');
                $liTerm = $(".sel-opt").find('li');
                if($closeBtn){
                	$closeBtn.on('click',function() {
                		$(selectWrap).remove();
                		doing = false;
                	});
                }
                if($liTerm){
                	$liTerm.on('click',function(e) {
                		var $target = $(e.currentTarget);
                		var callbackdata = {
                				index: $target.attr("data-code"),
                				text: $target.text()
                		}
                		$(selectWrap).remove();
                		doing = false;
                		opt.callback && opt.callback(callbackdata);
                	});
                }
            }
			selectWrap.style.display = "block";
		}
	})();
	
    // 弹出框
 	ui.dialog = (function() {
        var okBtn, cancelBtn, wrap, active = false;
        return function(opt) {
            if (active) return;
            active = true;
            opt = opt || {};
            // ok_alert_logo 成功 error_alert_logo 失败  warn_alert_logo提示
            opt.icon = opt.icon || "ok_alert_logo";
            // 按钮个数，默认1个
            opt.btnnum = opt.btnnum || "0";
            opt.position = opt.position || "bottom";
            opt.title = opt.title || "";
            opt.content = opt.content || "";
            opt.content2 = opt.content2 || "";
            opt.content3 = opt.content3 || "";
            opt.okText = opt.okText || "确定";
            opt.cancelText = opt.cancelText || "取消";
            opt.ok = opt.ok;
            opt.cancel = opt.cancel;
            opt.auto = opt.auto;
            if (!document.getElementById('_ipos_confirm_box')) {
                wrap = document.createElement("div");
                wrap.id = "_ipos_confirm_box";
                wrap.style.display = "none";
                wrap.className = 'w_alert';
                if(opt.btnnum=="2"){
                	wrap.innerHTML = [
						'<h2 class="margin_top_30 margin_b_20">'+opt.title+'</h2>'+
						'<p class="font_size_15">'+opt.content+'</p>'+
						'<p class="font_size_15">'+opt.content2+'</p>'+
						'<p class="font_size_15">'+opt.content3+'</p>'+
						'<div class="double_btn_l" id="_ipos_confirm_box_cancel">'+opt.cancelText+'</div>'+
						'<div class="double_btn_r" id="_ipos_confirm_box_ok">'+opt.okText+'</div>'].join("");

                }else{
                	if(opt.position == "center"){
		                wrap.id = "_ipos_confirm_box";
		                wrap.style.display = "none";
		                wrap.className = 'alert_3';
                		wrap.innerHTML = [
                			'<p><span>'+opt.content+'</span></p>'+
						    '<div class="color_orange font_size_17" id="_ipos_confirm_box_ok"><span>'+opt.okText+'</span></div>'].join("");
                	}else{
                       	wrap.innerHTML = [
							'<div class="'+ opt.icon +'"></div>'+
							'<h2>'+opt.title+'</h2>'+
							'<p class="font_size_15">'+opt.content+'</p>'+
							(opt.content2 ? ('<p class="font_size_15">'+opt.content2+'</p>') : '')+
							(opt.btnnum=="1" ? ('<a class="btn_default" id="_ipos_confirm_box_ok" href="javascript:;">'+ opt.okText +'</a>') : "" )].join("");
                	}
                	}

                document.body.appendChild(wrap);
                var dialogNo = "dialog_" + ~~(Math.random() * 1000000);
                $(document.body).prepend('<div class="mask" id=' + dialogNo + ' style="display:block;"></div>');
                okBtn = document.getElementById('_ipos_confirm_box_ok');
                cancelBtn = document.getElementById('_ipos_confirm_box_cancel');
                if(okBtn){
                	okBtn.onclick = function() {
                		$('#' + dialogNo + '.mask').remove();
                		$(wrap).remove();
                		active = false;
                		opt.ok && opt.ok();
                	}
                }
                if(cancelBtn){
                	cancelBtn.onclick = function() {
                		$('#' + dialogNo + '.mask').remove();
                		$(wrap).remove();
                		active = false;
                		opt.cancel && opt.cancel();
                	}
                }
            }
            if(cancelBtn){
            	cancelBtn.style.display = !!opt.cancelText ? "inlineBlock" : "none";
            }
            wrap.style.display = "block";
            if(opt.btnnum == "0"){
            	setTimeout(function(){
            		$('#' + dialogNo + '.mask').remove();
            		$(wrap).remove();
            		active = false;
            		opt.auto && opt.auto();
            	},5000); 
            }
        }
    })();

    // 带确定的提示框
    ui.warning = (function () {
        var title, content, okBtn, cancelBtn, wrap, active = false;
        return function (opt) {
            if (active) return;
            active = true;
            opt = opt || {};
            opt.title = opt.title || '';
            opt.content = opt.content || '';
            opt.okText = opt.okText || '确定';
            opt.ok = opt.ok;
            opt.cancelText = opt.cancelText || '取消';
            opt.cancel = opt.cancel;
            if (!document.getElementById('_cfb_confirm_box')) {
                wrap = document.createElement('div');
                wrap.id = '_cfb_confirm_box';
                wrap.style.display = 'none';
                wrap.innerHTML = ['<div style="background-color:rgba(0,0,0,0.4);z-index:9999;position:fixed;top:0;left:0;width:100%;height:100%;">',
                    '    <div style="width:90%;top:50%;margin-top:-100px;text-align:center;position:absolute;left: 50%;margin-left: -45%;background-color: rgba(255, 255, 255, 0.9);border-radius:10px;">',
                    '    <div id="_cfb_confirm_box_title" style="color: #333;line-height: 24px;padding-top: 20px;font-size: 20px;"></div>',
                    '    <div id="_cfb_confirm_box_content" style="color: #333;line-height: 20px;font-size: 14px;padding: 10px;"></div>',
                    '    <div style="padding: 10px 0 10px 0;">',
                    '     <div id="_cfb_confirm_box_ok" style="display: inline-block;padding:5px 10px;line-height:30px;font-size:14px;color:#fff;border-radius: 5px;width:220px;margin:10px;text-align:center;color:#fff;background-color:#e15724; "></div>',
                    '     <div id="_cfb_confirm_box_cancel" style="display: inline-block;padding:5px 10px;line-height:30px;font-size:14px;color:#fff;border-radius: 5px;width:220px;margin:10px;text-align:center;color:#fff;background-color:#e15724; "></div>',
                    '    </div>',
                    '    </div>',
                    '</div>'
                ].join('');
                document.body.appendChild(wrap);
                title = document.getElementById('_cfb_confirm_box_title');
                content = document.getElementById('_cfb_confirm_box_content');
                okBtn = document.getElementById('_cfb_confirm_box_ok');
                cancelBtn = document.getElementById('_cfb_confirm_box_cancel');
                okBtn.onclick = function () {
                    wrap.style.display = 'none';
                    active = false;
                    opt.ok && opt.ok();
                };
                cancelBtn.onclick = function () {
                    wrap.style.display = 'none';
                    active = false;
                    opt.cancel && opt.cancel();
                };
            }
            title.innerHTML = opt.title;
            content.innerHTML = opt.content;
            okBtn.innerHTML = opt.okText;
            cancelBtn.innerHTML = opt.cancelText;
            cancelBtn.style.display = !!opt.cancel ? 'inlineBlock' : 'none';
            wrap.style.display = 'block';
        };
    })();
    
 	return ui;
});