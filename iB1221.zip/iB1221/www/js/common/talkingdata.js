/*!
 * talking 模块常量
 * @module talkingdata
 * @author 周一平 
 * @history 2015-6-10 add
 */
define([], function() {
    // 直接将数据写在代码里
    return;
    var TD = {
    	Label:{
    		CERTIFY:"certify",
    		CONTRACT:"contract",
    		LOAN:"loan",
    		APPLY_RECORD_1_1:"0202010201-点击确认",
    		APPLY_RECORD_2_1:"0202010301-点击查询",
    		APPLY_RECORD_2_2:"0202010302-查询成功",
    		APPLY_RECORD_2_3:"0202010303-查询失败",
    		APPLY_RECORD_2_4:"0202010304-确认并提交",
    		APPLY_RECORD_2_5:"0202010305-额度申请失败",
    		APPLY_RECORD_3_1:"0202010401_点击查询",
    		APPLY_RECORD_3_2:"0202010402-查询成功",
    		APPLY_RECORD_3_3:"0202010403-查询失败",
    		APPLY_RECORD_3_4:"0202010404-确认并提交",
            APPLY_RECORD_4_1:"0303030101-点击开始面谈",
    	},
    	Event:{
    		TOUCH:"touch",
    		SUBMIT:"submit",
    		APPLY_RECORD_1:"02020102_个人信息",
    		APPLY_RECORD_2:"02020103_商户POS机编号",
    		APPLY_RECORD_3:"02020104_商户营业执照号",
            APPLY_RECORD_4:"03030301_视频面谈开始",
    	}
    }
    return TD;
});
