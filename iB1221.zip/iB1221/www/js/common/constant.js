/*!
 * constant 模块常量
 * @module constant
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
    "js/common/flag","js/common/env"
], function(
    Flag,
    EnvJson
) {

    /* 平安付配置项 */
    var Env = EnvJson.ssEnv ,PAPAY_ENV = EnvJson.pafEnv,Change_Url,phoneOauth_Url,
        PAPAY_HOST, PAPAY_AUTH, PAPAY_APP_ID, PAPAY_SECRET, PAPAY_BIND_CARD, PAPAY_BIND_YQB, PAPAY_GET_YQB_ACCOUNT,
        DEBUG_MODE = true;
        //电子签名开关配置
    var prdUrl = !EnvJson.isGray?'https://puhui-web.pingan.com.cn/manager/prd/paem/':'https://puhui-web.pingan.com.cn/manager/prd/paem_beta/';
    var switchSign_url = Env == 'PRODUCTION'
        ? prdUrl +'config/keplerStrategy/all_switch.json'
        : 'https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/config/kepleribt/all_switch.json';
    if (Env == "PRODUCTION") {
        PAPAY_ENV = "PRD";
        Change_Url = prdUrl +'public/publicForward.html'; //绑卡中转生产环境地址
        phoneOauth_Url = "https://eloan.pingan.com.cn/credit/xiaoanlogin/";
    }else{
        DEBUG_MODE = true;
        Change_Url = "https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/public/publicForward.html";
        //stg2
        //phoneOauth_Url = "https://gbd-credit-dmzstg2.pingan.com.cn:39443/credit/xiaoanlogin/";
        //stg1
        phoneOauth_Url = "https://gbd-credit-dmzstg1.pingan.com.cn:12443/credit/xiaoanlogin/";
    }
    switch (PAPAY_ENV) {
        case "STG1":
            PAPAY_HOST = "https://test-www.stg.1qianbao.com";
            PAPAY_AUTH = "900000001493 33c6e8446a6c43a5adcf224e7e7a8d6f";
            PAPAY_APP_ID = "900000001493";
            PAPAY_SECRET = "33c6e8446a6c43a5adcf224e7e7a8d6f";
            PAPAY_BIND_CARD = "https://test-www.stg.1qianbao.com/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://test-www.stg.1qianbao.com/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://test-www.stg.1qianbao.com/token/user";
            break;
        case "STG2":
            PAPAY_HOST = "https://test2-www.stg.1qianbao.com:7443";
            PAPAY_AUTH = "900000009498 596ff9657dfb419c85e52eac931207b3";
            PAPAY_APP_ID = "900000009498";
            PAPAY_SECRET = "596ff9657dfb419c85e52eac931207b3";
            PAPAY_BIND_CARD = "https://test2-www.stg.1qianbao.com:7443/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://test2-www.stg.1qianbao.com:7443/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://test2-www.stg.1qianbao.com:7443/token/user";
            break;
        case "STG3":
            PAPAY_HOST = "https://test3-www.stg.1qianbao.com:8450";
            PAPAY_AUTH = "900000000038 ef07457477bc4d70bbd820161c025166";
            PAPAY_APP_ID = "900000000038";
            PAPAY_SECRET = "ef07457477bc4d70bbd820161c025166";
            PAPAY_BIND_CARD = "https://test3-www.stg.1qianbao.com:8450/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://test3-www.stg.1qianbao.com:8450/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://test3-www.stg.1qianbao.com:8450/token/user";
            break;
        case "PRD":
            PAPAY_HOST = "http://www.1qianbao.com";
            PAPAY_AUTH = "900000004158 2c147337721348908d69fbf4145dd50d";
            PAPAY_APP_ID = "900000004158";
            PAPAY_SECRET = "2c147337721348908d69fbf4145dd50d";
            PAPAY_BIND_CARD = "https://1qianbao.com/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://1qianbao.com/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://1qianbao.com/token/user";
            break;
        default:
            PAPAY_HOST = "http://www.1qianbao.com";
            PAPAY_AUTH = "900000004158 2c147337721348908d69fbf4145dd50d";
            PAPAY_APP_ID = "900000004158";
            PAPAY_SECRET = "2c147337721348908d69fbf4145dd50d";
            PAPAY_BIND_CARD = "https://1qianbao.com/common-bindcard/enterview";
            PAPAY_BIND_YQB = "https://1qianbao.com/auth";
            PAPAY_GET_YQB_ACCOUNT = "https://1qianbao.com/token/user";
            break;
    }

    var Constant = {
        Flag:Flag,
        SWITCH_SIGN_URL:switchSign_url,
        DataKey:{
             /*Native接口数据缓存*/
            // 城市名
            BT_ILOAN_CITYNAME       :"BT_ILOAN_CITYNAME",
            // 用户登录数据---BTILOAN
            USER_LOGIN_INFO         :"BT_ILOAN_USER_LOGIN_INFO",
            // TD信息
            TD_MESSAGE              :"BT_ILOAN_TD_MESSAGE",

            //申请状态查询接口--统一数据key
            BT_ILOAN_QUAS_RESULT    :"BT_ILOAN_QUAS_RESULT",
            //申请状态查询接口--是否进行过实名认证
            BT_ILOAN_CHANNELCODE    :"BT_ILOAN_CHANNELCODE",
          
            // ILOAN申请号
            ILOANAPPLYNO            :"BT_ILOAN_APPLYNO",
            // 产品类型
            PRODUCT_TYPE			:"BT_ILAON_PRODUCT_TYPE",
            // 账单日
            ILOAN_BILLDAY			:"BT_ILAON_ILOAN_BILLDAY",
            // 客户号
            ILOAN_CUSTNO			:"BT_ILAON_ILOAN_CUSTNO",
          
            // 用户设备信息
            USER_DEVICE_INFO        :"BT_ILOAN_USER_DEVICE_INFO",
            //渠道信息
            USER_SOURCE_INFO		:"BT_ILOAN_USER_SOURCE_INFO",
            //H5 预授信的额度
            BT_ILOAN_PRE_CREDIT     :"BT_ILOAN_PRE_CREDIT",

            /*页面信息缓存*/
            // H5日志上报
            H5_LOG_CONFIG           :"BT_ILOAN_H5_LOG_CONFIG",
            // listen地址
            LISTENER_URL            :"LISTENER_URL",
            //$$.EventListener.onBack的data
            ONBACK_DATA             :"BT_ILAON_ONBACK_DATA",
            // url--成功后跳转页面 moduleName--成功后跳转模块 route--成功后跳转方式
            BT_ILOAN_BINDCARD_FROM   :"BT_ILOAN_BINDCARD_FROM",
            //BT邦卡来源标记：1：选择银行卡；2：添加银行卡
            BT_BINDCARD_FLAG        :"1",
            // 提现申请金额
            LOAN_APPLY_AMOUNT       :"BT_ILOAN_LOAN_APPLY_AMOUNT",

            //绑卡信息---BTILOAN
            CARD_DATA				:"BT_ILOAN_CARD_DATA",
            //是否需要上传通讯录标示---BTILOAN
            NEED_CONTACT			:"BT_ILOAN_NEED_CONTACT",
            //是否可以手动修改联系人---BTILOAN
            EDIT_CONTACT			:'BT_ILOAN_EDIT_CONTACT',
            //联系人通讯录上传数量---BTILOAN
            UPLOAD_CONTACT_NUM		:'BT_ILOAN_UPLOAD_CONTACT_NUM',
            //人脸识别参数---BTILOAN
            FACE_PARAM				:"BT_ILOAN_FACE_PARAM",
            //人脸识别开始时间---BTILOAN
            FACE_STARTTIME			:"BT_ILOAN_FACE_STARTTIME",
            //鉴权卡时查询已绑定银行卡列表---BTILOAN
            BIND_CARDS_LIST			:"BT_ILOAN_BIND_CARDS_LIST",
 
            //支用申请号
            BT_ILOAN_PAYAPPLYNO     :"BT_ILOAN_PAYAPPLYNO",
            //账户协议
            BT_ILOAN_CONTRACT_DATA  :"BT_ILOAN_CONTRACT_DATA",
            // 提现申请信息
            LOAN_APPLY_INFO         :"BT_ILOAN_LOAN_APPLY_INFO",
            
            // 提现后还款计划试算
            LOAN_REPAY_PLAN         :"BT_ILOAN_LOAN_REPAY_PLAN",
            //BT30天电子签名接口返回
            BT_THRITY_ESIGN_INFO	:"BT_THRITY_ESIGN_INFO",
             // 查询Ilaonh5结果
            QUERY_ILOAN_H5_RESULT   :"QUERY_ILOAN_H5_RESULT",
            
            //再贷被拒，点击被拒页面左上角返回帐户页面
            BT_RJ_FROM				:"BT_RJ_FROM",
            //城市查询被拒，点击被拒页面左上角返回帐户页面
            ILOAN_CITY_FROM			:"ILOAN_CITY_FROM",
            //绑卡卡号
            CARD_NO			        :"BT_ILOAN_CARD_NO",
            //6.0申请的还款数据
            BT_BORROW_DATA          :"BT_BORROW_DATA",
            //Bt_add_credit银行卡数据
            BT_BANKDATA             :"BT_BANKDATA",
            //申请钱数
            LOAN_APPLY_INFO_MONEY   :"BT_ILOAN_LOAN_APPLY_INFO_MONEY",

            /** ICARD调用的调用选择产品接口时初始化缓存 **/

            BT_SIGNCONTRACT         :"BT_ICARD_SIGNCONTRACT",
            //BT申请号
            BTAPPLYNO               :"BT_ICARD_APPLYNO",
            // 调用试算接口以及借款详情接口时缓存计划数据 
            BT_REPAYMENT            : "BT_ICARD_REPAYMENT",
            // 调用当期借款明细接口时缓存数据（以供储蓄卡列表使用）
            BTDEBITCARLIST          :"BT_ICARD_DEBITCARLIST",
            BT_ORDERNO              :"BT_ORDERNO" ,
            // 获取H5链接成功后，存储保险单号
            BT_INSURANCE_NO         :"BT_INSURANCE_NO",

            // 电子签名被拒
            CREDIT_FAIL: 'CREDIT_CREDIT_FAIL',
            // 储蓄卡页面是否跳转回上一个页面
            IS_BACK_PRE: 'BT_ILOAN_IS_BACK_PRE',
            // 跳转进储蓄卡时，保存上一个页面带过来的参数
            BINDCARD_PARAMS: 'BT_ILOAN_BINDCARD_PARAMS',
            //银行卡申请信息
            CARD_INFO: 'BT_ILOAN_CARD_INFO',
            //bt保存新增储蓄卡
            BT_SAVE_NEWBANKCARD: 'BT_SAVE_NEWBANKCARD',
            //bt保存绑卡orderno
            BT_SAVE_BINDORDERNO: 'BT_SAVE_BINDORDERNO',
            //预售信Native字段
            PRE_CREDITCARD_NATIVE_INFO: 'PRE_CREDITCARD_NATIVE_INFO',
            // 身份证有效期的有效性
            BT_ILOAN_IDVALID: "BT_ILOAN_IDVALID",
            // SDK版本号
            SDK_VERSION: "SDK_VERSION",
            // 是否显示广告
            AD_FLAG: "AD_FLAG",
            //广告栏图片
            AD_IMG: "AD_IMG",
            //迁徙数据
            MIGRATE_DATA: "MIGRATE_DATA",
            // 在线客服来源
            ROBOT_INFO: 'ROBOT_INFO'
        },
        // 页面标题设置
        TITLE: {
            PAEM:'平安e贷'
        },
        SELECT:{
            // 学历
            eduexperience	:{'08':'初中及以下','07':'高中','06':'中专','05':'大专','04':'本科','03':'硕士及以上'},
            // 婚姻状况
            marriage		:{'1':'未婚','2':'已婚','3':'离异','4':'丧偶','5':'再婚'},
            // 房屋类型
            houseType		:{"1":"商业按揭购房","2":"无按揭购房","3":"公积金按揭购房","4":"自建房","5":"租用","6":"暂住","8":"亲属住房","9":"单位住房"},
            // 关系
            relationship	:{'1':'父母', '2':'子女', '3':'配偶', '4':'亲戚', '5':'同事', '6':'朋友', '7':'房东'}
        },
        BANKCARD:{
            "浦发银行":"spdb",
            "工商银行":"icbc",
            "上海银行":"shb",
            "兴业银行":"cib",
            "中国建设银行":"ccb",
            "中国光大银行":"ceb",
            "中信银行":"cncb",
            "华夏银行":"hxb",
            "中国农业银行":"abc",
            "平安银行":"pab",
            "中国邮政储蓄银行":"psbc",
            "中国银行":"boc",
            "民生银行":"cmbc"
        },
        PRODUCT_CONFIG:{
        },
        CODE:{
            idNo:'01'
        },
        PRODUCTION:{
            CODE:'1',
            loanCode:'0201',
            channelCode:'APP',
            lastVersionNo: 'v1.2',  //担保模式
            cgiVersionNo: {
                'L': 'v4.0',
                'H': 'v3.1',  // 湖南小贷
                'C': 'v3.2'   //重庆小贷
            },   //联合放款
            dataVersionNo: 'v1.1'
        },
        /**
         * 协议版本号 v1.0 v2.0 v3.0 ......
         * */
        CONTRACT:{
            'v1.0':'loan_contract.html',
            'v1.1':'loan_contract_1.html',
            'v1.2':'loan_contract_1.2.html'  // 九江银行需求增加1.2版本
        },
        CONTRACTCGI:{
            'v2.0':'loan_contract_cgi.html',   //CGI+联合放款 借款协议
            'v3.0':'loan_contract_cgi_3.html',   //新版 CGI+联合放款 借款协议
            'v3.1':'loan_contract_cgi_3.1.html',  //湖南小贷 借款协议
            'v3.2':'loan_contract_cgi_3.2.html', //重庆小贷 借款协议
            'v4.0':'loan_contract_cgi_4.html'  //新版 CGI+联合放款 借款协议
        },
        /*资料代传合同*/
        DATAVERSION:{
            'v1.0':'loan_data_transfer_contract.html',  //CGI+联合放款 
            'v1.1':'loan_data_transfer_contract_1.1.html' //新版 合同
        },
        /*银行对应的ejs*/
        BANKCONTRACT:{
            '重庆银行': 'cq',
            '光大银行':'gd',
            '九江银行': 'jj',
            '渤海银行': 'bh'
        },

        /*下架的渠道*/
        OFFTHESHELF: [
            'yingjiqianbao-test', 'chengniu', 'fenqiguanjia', 'jieleme'
        ],

        /**
         * 配置模块名称
         * */
        MODULE_NAME:{
            home:"paehome",
            iloan:"iloan",
            iloanbt:"iloanbt"
        },
        index_page:"index.html",
        // 平安付请求头授权码
        PAPAY_AUTH: PAPAY_AUTH,
        // 平安付地址
        PAPAY_HOST: PAPAY_HOST,
        // 平安付APP ID
        PAPAY_APP_ID: PAPAY_APP_ID,
        // 平安付密钥
        PAPAY_SECRET: PAPAY_SECRET,
        //平安付绑卡
        PAPAY_BIND_CARD: PAPAY_BIND_CARD,
        //平安付绑定壹钱包
        PAPAY_BIND_YQB: PAPAY_BIND_YQB,
        //平安付换取壹钱包账号
        PAPAY_GET_YQB_ACCOUNT: PAPAY_GET_YQB_ACCOUNT,
        //绑卡公共跳转地址
        Change_Url: Change_Url,
        //手机运营商认证地址
        phoneOauth_Url: phoneOauth_Url,
        partnerId: 'PA_XINBAO_20141120001',

        /**
         * BT模块相关配置
         */
        Enum: {
            //本地ssEnv -- 存储key
            ICARD_SSENV: "ssEnv",
            ILOAN_MODULE:"iloanbt",
            PAEHOME:"paehome",
            FLAG:{
                // 登录超时
                LOGIN_TIMEOUT:"0",
                // 登录成功
                LOGIN_SUCCESS:"001",
                // 系统异常
                ERROR:"004",
                // 操作成功
                SUCCESS:1,
                // 操作失败
                FAIL:0,
                //reBindFlag
                REBINGFLAG_Y:"Y",//银联认证时银行卡账号无效（重新绑卡）
                REBINGFLAG_N:"N",//无需重新绑卡
                //apvFlag
                APVFLAG_PS:"PS",//银联认证通过
                APVFLAG_RJ:"RJ"//银联认证被拒
            },
            LOADING:{
                A1:"A1", //loading 额度变化
                A2:"A2", //bt支用打点规则通过 跳转6.0申请还卡
                A3:"A3", //提现拒绝规则通过 首次动用 跳转3.1
                A4:"A4", //提现拒绝规则通过 再次动用 跳转8.0
                A5:"A5", //未通过 跳转8.0
                A6:"A6", //未动用 跳转3.2 审核拒绝
                A7:"A7" //继续询问
            },
            TITLE:{
                CONTRACT:"借款以担保协议",
                BORROWSUC:"申请成功",
                BORROWFAIL:"申请失败",
                REPAYSUBMITSUC:"还款成功",
                PINNED:"代还信用卡",
                LOANSELECT:"首次动用页面",
                ACCOUNTILOAN:"再次动用页面",
                CREDITLIST:"选择银行卡",
                ADDCREDIT:"添加信用卡",
                REPAYMENTLIST:"还款",
                BORROW:"确认借款信息",
                BORROWDETAIL:"详情",
                REPAYMENTPLAY:"还款计划",
                ILOANINDEX:"帐户首页",
                ADDCARDFAIL:"添加信用卡失败",
                REPAYMENT:"还款列表",
                ADDCARDSUC:"添加信用卡成功",
                SAVEINGSLIST:"选择还款储蓄卡",
                ALTER:"额度变化",
                CREDITFAILRESULT:"拒绝",
                REPAYDETAIL:"当期应还明细",
                NOWREPAYMENT:"立即还款",
                EARLYREPAYMENT:"提前还款",
                LOADING:"加载中"
            },
            ICARD:{
                PAYSTATE:{
                    //TD 待放款;DB 已放款;RP 待还款;OD 逾期;SE 已结清;LP 追偿代偿
                    TD:{ title: "待放款",className:"pending",amtText:"到期应还;" },
                    DB:{ title: "已放款",className:"",amtText:"到期应还" },
                    RP:{ title: "还款中",className:"",amtText:"到期应还",tipText:"距离还款日还有"},
                    OD:{ title: "已逾期",className:"overdue",amtText:"逾期应还" ,tipText:"已逾期"},
                    SE:{ title: "已结清",className:"settled",amtText:"到期应还" ,tipText:"这笔贷款已结清"},
                    HK:{title: "还款中",className:"",amtText:"到期应还",tipText:"距离还款日还有"},
                    LP:{ title: "已逾期",className:"overdue",amtText:"逾期应还" ,tipText:"已逾期"},
                    isDeduct:"1"
                },

                //协议版本NOWVERSON来配置。
                CONTRACT:{
                    NOWVERSON:"v1.0",
                    VERSONVIEW:{
                        "v1.0":"contract.html",
                        "v2.0":"contract2.html"
                    }
                },

                //新增信用卡(应答码)
                //00  绑卡成功
                //01  绑卡失败
                //02  该卡已添加过且失败
                //03  添加次数超过5次
                //08  该卡已添加过且成功
                //20  仍在回盘过程中(触发轮询)
                //98  账号资金不足，银行卡问题、系统问题等导致平安付指令无法发出
                //S1  今日添加次数已满
                //S2  请勿重复添加
                //S3  此卡正在验证中
                //S4  请填写本人名下有效信用卡
                //S5  系统繁忙
                RESPONDCODE:["00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","20","98","99","S1","S2","S3","S4","S5","88"]
            },
            //银行卡信息
            BANKINFO:{
                bindType:{
                    S:'储蓄卡',
                    C:'信用卡',
                    E:'壹钱包'
                },
                //bankCode  银行代码
                //bankName  银行名称
                //logo  添加信用卡页面银行背景色、图片路径
                BANKLIST:{
                    ABC:{'bankName':'农业银行','logo':'abc','bankCode':'01030000'},
                    BOC:{'bankName':'中国银行','logo':'boc','bankCode':'01040000'},
                    CCB:{'bankName':'建设银行','logo':'ccb','bankCode':'01059999'},
                    CEB:{'bankName':'光大银行','logo':'ceb','bankCode':'63030000'},
                    CIB:{'bankName':'兴业银行','logo':'cib','bankCode':'03090010'},
                    CNCB:{'bankName':'中信银行','logo':'citic','bankCode':'63020000'},
                    CMBC:{'bankName':'民生银行','logo':'cmbc','bankCode':'03050001'},
                    HXB:{'bankName':'华夏银行','logo':'hxb','bankCode':'63040000'},
                    ICBC:{'bankName':'工商银行','logo':'icbc','bankCode':'01020000'},
                    PAB:{'bankName':'平安银行','logo':'pab','bankCode':'05105840'},
                    PSBC:{'bankName':'邮政储蓄银行','logo':'psbc','bankCode':'61000000'},
                    BOS:{'bankName':'上海银行','logo':'bos','bankCode':'04012902'},
                    BCCB:{'bankName':'北京银行','logo':'bccb','bankCode':'64031000'},
                    SPDB:{'bankName':'浦东发展银行','logo':'spdb','bankCode':'03100000'},
                    BOCOM:{'bankName':'交通银行','logo':'bcm','bankCode':'03010000'},
                    GDB:{'bankName':'广发银行','logo':'gdb','bankCode':'03060000'},
                    CMB:{'bankName':'招商银行','logo':'cmb','bankCode':'03080000'},
                    YQB:{'bankName':'壹钱包','logo':'yqb','bankCode':'05083000'}
                }
            }
        },
        DataUrl: {
            ICARD: {
                /** 调用选择产品接口时初始化缓存 **/
                //申请号
                BTAPPLYNO: 'BT_ICARD_APPLYNO',
                //支用申请号
                BTPAYAPPLYNO: 'BT_ICARD_PAYAPPLYNO',

                /** 调用试算接口以及借款详情接口时缓存计划数据 **/
                BTPLANDATA: 'bt_Plan_data',

                /** 调用借款详情接口时缓存数据（以供9.4模块使用） **/
                BTBORROWDETAIL: 'BT_ICARD_BORROWDETAIL',

                /** 调用当期借款明细接口时缓存数据（以供储蓄卡列表使用） **/
                BTDEBITCARLIST: 'debitCarList_bt',

                /** 调用借款明细接口和试算接口时缓存数据（以供借款确认使用） **/
                BTBORROWDATA: 'bt_borrow_data'
            },
            //内页跳转链接
            TRANSPAGE:{
                PAEHOMEINDEX:"index.html",
                //首次动用
                LOANSELECT:"loan_select.html",
                //8.0账户首页
                ACCOUNTILOAN:"account_iloan.html",
                //申请贷款
                PINNED:"icard_pinned.html",
                //选择收款信用卡
                CREDITLIST:"icard_credit_list.html",
                //添加收款信用卡
                ADDCREDIT:"icard_add_credit.html",
                //贷款详情页面
                BORROWDETAIL:"repay_details.html",
                //贷款信息确认页面
                BORROW:"icard_borrow.html",
                //查看协议
                CONTRACT:"contract.html",
                //借款成功
                BORROWSUC:"icard_borrow_suc.html",
                //借款失败
                BORROWFAIL:"icard_borrow_fail.html",
                //还款计划
                REPAYMENTPLAN:"icard_repayment_plan.html",
                //还款确认页面（逾期）
                OVERDUE:"detailsRepayment.html#overdue",
                //还款确认页面
                REPAYMENTOPERATION:"repay_confirm.html",
                //还款成功页面
                REPAYSUBMITSUC:"repay_submit_suc.html",
                //还款失败
                REPAYFAIL:"repayFail.html",
                //iloan首页
                ILOANINDEX:"loanSelect.html",
                //增加信用卡失败
                ADDCARDFAIL:"icard_add_card_fail.html",
                //添加储蓄卡
                ADDCREDITBIND:"credit_bind_card.html",
                //还款列表
                REPAYMENT:"repay_list_record.html",
                //添加信用卡成功
                ADDCARDSUCCESS:"icard_add_card_suc.html",
                //选择还款储蓄卡
                SAVEINGSLIST:"repay_saving_card.html",
                //额度变化
                ALTER:"alter.html",
                //3.2审核拒绝
                CREDITFAILRESULT:"credit_fail_result.html",
                INTRO:"intro.html",
                //投保单页
                POLICY: "icard_policy.html",
                //提现成功
                LOANSUC:"loan_suc.html",
                //提现失败
                LOANFAIL:"loan_fail.html",
                //提现详情
                LOANINFO:"loan_info.html",
                //当期应还明细
                REPAYDETAIL:"repay_current_detailed.html",
                //预售信页面
                ILOANPRECREDIT: 'iloan_pre_credit.html',
                //帐户制的补录信息页
                IDCARDVALID: App.IS_SDK ? "index.html" : "add-idcard-valid.html"
            }
        }
    };
    return Constant;
});
