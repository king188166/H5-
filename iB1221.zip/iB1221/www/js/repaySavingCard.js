/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2017-03-10
 * @describe: BT-储蓄卡列表页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';

    var Page = View.extend(_.extend({
        liTpl: _.template($('#checkBank').html()),
        /**绑定事件**/
        events: {
            'tap .js_tap': 'doSelect', //选择储蓄卡
            'tap #verify': 'skipPinned'//点击下一步，跳转至9.0或者9.4页面
        },
        /**初始化**/
        initialize: function () {
            var $this = this;
            $this.paramers = C.Utils.getQueryMap();//获取页面参数 包括页面地址from /默认储蓄卡绑定号loanBindNo
            //设置头部
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.CREDITLIST,
                isBack: 1,
                leftCallback: function () {
                    C.Native.back();
                },
                rightIcon: 'add',
                rightCallback: function () {
                    if ($this.paramers.from) {
                        C.Native.forward({
                            url: C.Constant.DataUrl.TRANSPAGE.ADDCREDITBIND, //跳转到添加储蓄卡页面
                            data: {
                                url: $this.paramers.from, //添加完储蓄卡后需要跳转回的页面地址
                                moduleName: 'icard', //跳转标识符
                                route: 'back'
                            }
                        });
                    }
                }
            });
            $this.render();
        },

        /**渲染页面数据**/
        render: function () {
            var $this = this,
                list = C.Constant.Enum.BANKINFO.BANKLIST;//获取到本地银行配置信息
            $this.debitCarList = C.Utils.data('ICARD_DEBITICARDLIST');
            //处理数据，增加logo字段
            $.each($this.debitCarList, function (index, item) {
                if (item.loanBindNo == $this.paramers.loanBindNo) {
                    item.isChoosed = true;
                } else {
                    item.isChoosed = false;
                }
                if (item.bankNo in list) {
                    item.logo = list[item.bankNo].logo;
                } else {
                    item.logo = '';
                }
            });
            //渲染页面
            $('#getBank').html($this.liTpl({data: $this.debitCarList}));
        },

        createRequest: function (option) {
            var $this = this;
            C.UI.loading();
            //发起AJAX请求，调用相应接口
            $.ajax({
                url: option.url,
                type: option.type,
                data: {
                    jsonPara: JSON.stringify(option.data)
                },
                success: function (res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        option.callback.call($this, res.data);
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        },
        doSelect: function (e) {
            var target = $(e.currentTarget);
            if (target.hasClass('active')) {
                return;
            }
            target.addClass('active').siblings().removeClass('active');
        },
        skipPinned: function () {
            var $this = this, loanBindNo, selectInfo;
            $.each($('.js_tap'), function (index, item) {
                if ($(item).hasClass('active')) {
                    loanBindNo = $(item).attr('data-BindNo');
                }
            });
            $.each($this.debitCarList, function (index, item) {
                if (item.loanBindNo == loanBindNo) {
                    selectInfo = $this.debitCarList[index];
                }
            });
            console.log(selectInfo);
            // 获取选定的银行卡信息
            if (selectInfo.loanBindNo && selectInfo.cardName) {
                //发起AJAX请求，调用更改默认储蓄卡接口
                C.UI.loading();
                $.ajax({
                    url: C.Api('CHANGELOANCARD'),
                    type: 'post',
                    data: {
                        bindNo: selectInfo.loanBindNo//还款卡绑定号
                    },
                    dataType: 'json',
                    success: function (data) {
                        console.log(data);
                        C.UI.stopLoading();
                        if (data.data && data.flag == C.Flag.SUCCESS) {
                            //跳转回9.0或者9.4页面(跳转回9.4时需要传送参数)
                            C.Native.back({
                                url: $this.paramers.from,
                                data: {
                                    //reload: true//返回后页面执行刷新动作
                                    rpyBankName: selectInfo.cardName,
                                    rpyBindNo: selectInfo.loanBindNo
                                }
                            });
                        }
                    }
                });
            }
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
