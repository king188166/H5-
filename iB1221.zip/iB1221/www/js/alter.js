/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2016-07-04
 * @time  : 上午09:40
 * @describe: BT-额度发生变更
 */

define(['zepto', 'C', 'view'], function($, C, View){

    'use strict';
    var Page = View.extend(_.extend({
        el: 'body',
        initialize: function(){
            //埋点 额度变更页  
            C.Native.TDOnEvent({
                eventId: '$_03_0_4_20_额度变更页'
            });
            var $this = this,
                _isLoading = C.Utils.getQueryMap().isLoading;
            $this.handler && clearTimeout($this.handler);
            $this.handler = setTimeout(function(){
                C.Native.forward({
                    url: C.Constant.DataUrl.TRANSPAGE.PINNED,
                    data: { isLoading: !isNaN(_isLoading) && parseInt( _isLoading) }
                });
            }, 4000);
        }
    }));

    $(function(){
        new Page();
    });
});