/**
 * @author: EX-HUANGKANG001@pingan.com.cn
 * @date  : 2016-10-10
 * @time  : pm 14:47
 *
 * @describe: iLoan新战略-还款指引
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #js-btn-confirm': 'confirm'
        },
        initialize: function() {
            var self = this;
            C.Native.setHeader({
                title: 'i贷到期还款',
                isBack: false
            });
            self.from = decodeURIComponent(C.Utils.getParameter('fromPage')) || '';
        },
        confirm: function(){
            var self = this;
            if(self.from == 'accountIloan'){
                //C.Native.forwardModule({
                //    url: 'repayment.html',
                //    moduleName: 'icard'
                //});
                C.Native.forward({
                    url: 'repay_list_record.html'
                });
            }else{
                C.Native.back();
            }
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});