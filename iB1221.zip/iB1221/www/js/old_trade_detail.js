/**
 * @author: 郭晶晶
 * @date  : 2015-10-09
 * @time  : 上午10:21
 *
 * @describe: 开普勒-还款明细
 */
define(['zepto', 'C', 'view', 'underscore', 'js/old_encrypt'], function ($, C, View, _, Encrypt) {
    'use strict';

    var acctNo = Encrypt.rsaEncrypt(C.Utils.getParameter('acctNo'));
    var applNo = Encrypt.rsaEncrypt(C.Utils.getParameter('applNo'));
    //var acctNo = '';
    //var applNo = '';
    var Page = View.extend(_.extend({

        events: {},
        initialize: function () {
            var self = this;
            C.UI.loading();
            C.Native.setHeader({
                title: C.Constant.TITLE.DETAIL,
                leftCallback: function () {
                    C.Native.back();
                }
            });
            this.getTradeDetai(function (res) {
                C.UI.stopLoading();
                if (res.flag == C.Flag.SUCCESS) {
                    var data = res.data;
                    self.render(data);
                } else {
                    C.UI.error(res.msg);
                }
            }, function (err) {
                C.UI.error(JSON.stringify(err));
            });
            //var data={'resultObj':[{'Tamt":2000,"Tdate":"20150929","Taccount":"8698","Ttype":"动用"}]};
            //self.render(data);
            C.UI.stopLoading();
        },
        //获取交易明细数据
        getTradeDetai: function (success, error) {
            return $.ajax({
                url: C.Api('TRADE_DETAIL'),
                type: 'GET',
                dataType: 'json',
                data: {
                    acctNo: acctNo,
                    applNo: applNo,
                    applType: 'WX',
                    DetailVer: '2.0'
                },
                success: success,
                error: error
            });
        },
        render: function (data) {
            var html = '<tr><th width="28%">日期</th><th width="22%">类型</th><th width="25%">金额</th><th width="25%">账户</th></tr>';
            if (!data.resultObj.length) {
                html = '<div  class="_repaytxt"><span class="fail_repaytxt">暂无还款交易记录</span></div>';
                $('#trade_details_tmp').html(html);
                return;
            }
            for (var i = 0; i < data.resultObj.length; i++) {
                //交易日期
                var Tdate = data.resultObj[i].Tdate;

                if (Tdate && Tdate.length == 8) {
                    Tdate = Tdate.substr(0, 4) + '-' + Tdate.substr(4, 2) + '-' + Tdate.substr(6, 2);
                }
                //交易银行
                var Taccount = data.resultObj[i].Taccount;
                if (Taccount == '壹钱包') {
                    Taccount = '';
                }

                //交易金额
                var Tamt = '¥' + C.Utils.parseThousands(data.resultObj[i].Tamt.toFixed(2));
                //交易类型
                var Ttype = data.resultObj[i].Ttype;
                //if(data.resultObj[i].Ttype=="动用"){
                //	Ttype = "动用";
                //}else{
                //	Ttype = "还款";
                //}
                $.extend(data.resultObj[i], {
                    Tdate: Tdate,
                    Taccount: Taccount,
                    Tamt: Tamt,
                    Ttype: Ttype
                });
                html += _.template($('#trade_details_ul_tmp').html())(data.resultObj[i]);
            }
            $('#trade_details_tmp').html(html);

        }

    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});
