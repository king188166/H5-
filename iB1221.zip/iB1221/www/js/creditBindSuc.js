/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: iLoan定期-绑卡成功和失败
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #bind_next': 'clickFunction'
        },
        initialize: function () {
            var _this = this;

            C.Native.setHeader({
                title: '添加银行卡',
                isBack: false
            });
            _this.userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            _this.from = C.Utils.data(C.Constant.DataKey.BT_ILOAN_BINDCARD_FROM);

            var responseMsg, respCode, requestNo;
            //mock环境不跳转平安付绑卡 所以写死返回码
            if (C.Env === 'STG20') {
                responseMsg = '操作成功!';
                respCode = 'api029';
                requestNo = '';
            } else {
                responseMsg = decodeURIComponent(C.Utils.getParameter('responseMsg'));
                respCode = decodeURIComponent(C.Utils.getParameter('respCode'));
                requestNo = decodeURIComponent(C.Utils.getParameter('requestNo'));
            }

            _this.respCode = respCode;
            _this.requestNo = requestNo;
            if (respCode || responseMsg) {
                _this.cardNo = C.Utils.data(C.Constant.DataKey.CARD_DATA).cardNo;
                if (respCode != 'api029') {
                    C.UI.stopLoading();
                    
                    _this.saveErrorBindCardInfo(_this.respCode); //平安付给的异常信息保存
                    
                } else if (respCode == 'api029') {               //平安付传过来029为成功
                    $('#wait_part').show();
                    $('#fail_tip_part').hide();
                    _this.decryptResponseMsg(responseMsg, _this.cardNo); //进行解密
                }
            } else {
                if (_this.from.url == 'icard_loading.html') {
                    if (C.Utils.data(C.Constant.DataKey.BT_BINDCARD_FLAG) == '1') { // 1 标识选择银行卡，2标识添加银行
                        C.Native.TDOnEvent({
                            eventId: 'iBT-03010201010102-下一步',
                            eventLable: 'iBT-0301020101010202-失败'
                        });
                        
                    } else {
                        C.Native.TDOnEvent({
                            eventId: 'iBT-030102020402-下一步',
                            eventLable: 'iBT-03010202040202-成失败'
                        });
                        //埋点 重查征信新绑卡页 事件失败 (还卡流程) 标识添加
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_4_19_02_重查征信新绑卡页'
                        });
                    }
                } else {
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0202010402-下一步',
                        eventLable: 'iBT-020201040202-失败'
                    });
                    //埋点 添加银行卡页 事件失败 (申请流程) 
                    C.Native.TDOnEvent({
                        eventId: '$_03_2_2_01_02_添加银行卡页'
                    });
                }

                $('#wait_part').hide();
                $('#fail_tip_part').show();
                C.UI.stopLoading();
            }
        },

        errorTip: function (code) {
            var _this = this,
                errormsg = '';
            switch (code) {
                case 'api025':
                    errormsg = '您已经绑定该银行卡';
                    break;
                case 'api026':
                    errormsg = '您的银行卡正在签约中，请稍后查看';
                    break;
                case 'api027':
                    errormsg = '您的银行卡签约但已关闭快捷支付，<br>请到官网进行开通';
                    break;
                case 'api028':
                    errormsg = '暂不支持该卡签约';
                    break;
                default:
                    errormsg = '银行卡绑定失败';
                    break;
            }

            _this.renderBack(errormsg, false);
        },

        decryptResponseMsg: function (responseMsg, cardNo) {
            var _this = this;
            C.Native.getDeviceInfo(function (res) {
                if (res.code == '1') {
                    _this.deviceInfo = res.result;
                    var param = {
                        curVer: _this.deviceInfo.appVersion,
                        machineSN: _this.deviceInfo.MachineSN || _this.deviceInfo.machinesn,
                        requestMsg: responseMsg
                    };
                    $.ajax({
                        url: C.Api('DECRYPTIONREQUESTMSG'),
                        data: param,
                        type: 'POST',
                        success: function (res) {
                            console.log(res);
                            if (res.flag == C.Flag.SUCCESS && res.data) {
                                _this.returnData = res.data;
                                //参数解密成功直接提交绑卡信息
                                _this.getBindData();
                            } else {
                                $('#wait_part').hide();
                                $('#fail_tip_part').show();
                                C.UI.stopLoading();
                            }
                        },
                        complete: function () {
                            C.UI.stopLoading();
                        }
                    });
                } else {
                    C.Native.tip('获取提交信息失败');
                }
            });
        },

        saveErrorBindCardInfo: function (respCode) {
            var self = this;
            C.UI.loading();
            C.Native.getDeviceInfo(function (res) {
                if (res.code == '1') {
                    self.deviceInfo = res.result;
                    var param = {
                        curVer: self.deviceInfo.appVersion,
                        machineSN: self.deviceInfo.MachineSN || self.deviceInfo.machinesn,
                        mobile: self.userdata.mobile,
                        paPayAccount: '',
                        bankCard: self.cardNo,
                        cardType: C.Utils.data(C.Constant.DataKey.CARD_DATA).cardType,
                        bankNo: C.Utils.data(C.Constant.DataKey.CARD_DATA).bankNo,
                        bindingSource: 'ILOANBT',
                        requestNo: self.requestNo,
                        errorCode: self.respCode,
                        description: ''
                    };
                    if (self.from.url == 'icard_loading.html') {
                        param.bindingSource = 'BT';
                    }
                    $.ajax({
                        url: C.Api('saveErrorBindCardInfo'),
                        data: param,
                        type: 'POST',
                        success: function (res) {
                            C.UI.stopLoading();
                            self.errorTip(respCode);
                        },
                        compelete: function () {
                            C.UI.stopLoading();
                        }
                    });
                } else {
                    C.Native.tip('获取提交信息失败');
                }
            });
        },

        /**
         * 绑卡保存信息接口调用失败后回退
         * */
        renderBack: function (msg, flag) {
            this.isSuccess = flag;
            var classname = !!flag ? 'icon-suc' : 'icon-fail',
                otherclass = !!flag ? 'icon-fail' : 'icon-suc',
                btnname = !!flag ? '确定' : '返回';
            $('#tip_icon').removeClass(otherclass).addClass(classname);
            $('#tip_text').html(msg);
            $('#wait_part').hide();
            $('#bind_next').text(btnname).removeClass('btn-disable').addClass('btn');
            $('#bind_next').parent().removeClass('dn');
            $('#fail_tip_part').show();
            C.UI.stopLoading();
        },

        /**
         * 按钮点击事件
         * */
        clickFunction: function (e) {
            if(this.from.url == 'icard_loading.html'){
                if(!!this.isSuccess){
                    //埋点 成功确定 按钮
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_19_05_重查征信新绑卡页'
                    });
                }else{
                    //埋点 失败返回 按钮
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_4_19_06_重查征信新绑卡页'
                    });
                }
            }else{
                if(!!this.isSuccess){
                    //埋点 成功确定 按钮
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_06_05_添加银行卡页'
                    });
                }else{
                    //埋点 失败返回 按钮
                    C.Native.TDOnEvent({
                        eventId: '$_03_1_2_06_06_添加银行卡页'
                    });
                }
            }
            if ($(e.currentTarget).hasClass('btn-disable')) {
                return false;
            }
            // 根据缓存中的参数，跳转到不同页面并刷新
            if (!this.isSuccess && this.from.failUrl) {
                C.Native[this.from.failRoute || this.from.route]({
                    url: this.from.failUrl,
                    moduleName: this.from.failModuleName || this.from.moduleName,
                    data: {
                        reload: this.isSuccess
                    }
                });
            } else {
                if (this.from.url == 'icard_loading.html' && this.isEsPass == 'N') {
                    C.Native.forward({
                        url: 'loan_select.html'
                    });
                } else {
                    C.Native[this.from.route]({
                        url: this.from.url,
                        moduleName: this.from.moduleName,
                        data: {
                            reload: this.isSuccess,
                            bindNo: this.bankBindNo
                        }
                    });
                }
            }
        },

        /**
         * 绑卡回退获取参数
         * */
        getBindData: function (e) {
            var _this = this,
                cardData = C.Utils.data(C.Constant.DataKey.CARD_DATA);
            var data = _this.returnData;
            var sourData = {};
            C.Native.getDeviceInfo(function (res) {
                if (res.code == '1') {
                    _this.deviceInfo = res.result;
                    var param = {
                        name: _this.userdata.custName,
                        paPayAccount: data.customerId,
                        id: _this.userdata.Id,
                        tel: _this.userdata.mobile,
                        bankCardNo: _this.cardNo,
                        bankCardTel: data.mobile,
                        simMobile: _this.deviceInfo.simMobile,
                        bankName: cardData.bankName,
                        reserveBankMobile: (C.Env === 'STG20') ? (C.Utils.data('stg20_addCard_tel').reserveBankMobile) : ''
                    };
                    var paramOld = {
                        bankNo: cardData.bankNo,
                        cardType: cardData.cardType,
                        bankName: cardData.bankName,
                        bankCardNo: _this.cardNo,
                        bankCardTel: data.mobile,
                        paPayAccount: data.customerId
                    };
                    C.Native.rSAEncode(param, function (res) {
                        if (res.code == '1') {
                            var paramNew = {
                                name: res.result.name,
                                paPayAccount: res.result.paPayAccount,
                                id: res.result.id,
                                tel: res.result.tel,
                                bankCardNo: res.result.bankCardNo,
                                bankCardTel: res.result.bankCardTel,
                                simMobile: res.result.simMobile || '',
                                bankName: res.result.bankName,
                                reserveBankMobile: res.result.reserveBankMobile || '',
                                bankNo: cardData.bankNo,
                                cardType: cardData.cardType,
                                bindingSource: 'ILOANBT',
                                platform: App.IS_IOS ? 'IOS' : 'A',
                                machineSN: _this.deviceInfo.MachineSN || _this.deviceInfo.machinesn,
                                address: _this.deviceInfo.address,
                                longitude: _this.deviceInfo.longitude,
                                latitude: _this.deviceInfo.latitude,
                                cityName: _this.deviceInfo.gpsCity,
                                provinceName: _this.deviceInfo.gpsProvince,
                                registNo: _this.userdata.mobile,
                                callType: '鉴权绑卡',
                                callChannel: '平安易贷',
                                appVersion: _this.deviceInfo.appVersion,
                                mobileBrand: _this.deviceInfo.mobileBrand,
                                mobileOsVer: _this.deviceInfo.mobileOsVer,
                                sdkReturnStr: _this.deviceInfo.sdkReturnStr,
                                ip: _this.deviceInfo.ip,
                                mac: _this.deviceInfo.mac || ''
                            };
                            if (App.IS_SDK) {
                                sourData = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
                                paramNew.thirdChannel = sourData.source;
                                paramNew.channelType = sourData.sourceType;
                            }
                            if (!paramNew.longitude || !paramNew.cityName) {
                                //未获取到定位信息提示
                                C.Native.tip('无法获取当前城市，请允许定位重新尝试');
                                if (_this.from.moduleName) {
                                    C.Native.backModule({
                                        url: _this.from.url,
                                        moduleName: _this.from.moduleName
                                    });
                                } else if (_this.from.url == 'icard_loading.html') {
                                    C.Native.back({
                                        url: 'loan_select.html'
                                    });
                                } else {
                                    C.Native.back({
                                        url: _this.from.url
                                    });
                                }
                            } else if (_this.from.url == 'credit_info_list.html') {
                                // 添加鉴权卡
                                _this.submitBindData(paramNew);
                            } else if (_this.from.url == 'icard_loading.html') {
                                // BT30天重查征信添加鉴权卡
                                _this.submitBindData(paramNew, 'icard_loading');
                            } else {
                                // 添加收还款卡
                                _this.updateBindData(paramOld);
                            }
                        } else {
                            C.Native.tip('安全数据加密失败');
                        }
                    });
                } else {
                    C.Native.tip('获取提交信息失败');
                }
            });
        },

        /**
         * 提交保存鉴权卡信息
         * */

        submitBindData: function (param, from) {
            var _this = this;
            _this.submitCardData = param;
            var url = '';
            //如果是BT30天重新鉴权帮卡的话，调用新鉴权帮卡接口
            if (from && from == 'icard_loading') {
                url = C.Api('BT_REGULARBINDBANCARD');
                $.extend(param, {
                    payApplyNo: C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO),
                    applyNo: C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).applyNo,
                    businessNo: C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO).businessNo,
                    imgDenseStrFileId: C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO).imgDenseStrFileId,
                    imgFileId: C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO).imgFileId,
                    bankType: C.Utils.data(C.Constant.DataKey.CARD_DATA).cardType,
                    bindingSource: 'BT',
                    bankCode: C.Utils.data(C.Constant.DataKey.CARD_DATA).bankNo
                });
            } else {
                url = C.Api('REGULARBINDBINKCARD');
            }
            $.ajax({
                url: url,
                data: {
                    jsonPara: JSON.stringify(param)
                },
                type: 'POST',
                success: function (res) {
                    C.UI.stopLoading();
                    console.log(JSON.stringify(res));
                    if (res.flag == C.Flag.SUCCESS && res.data) {
                        //1025新增电子签名失败提示
                        if (res.data.isEsPass == 'N') {
                            _this.isEsPass = 'N';
                            C.Native.tip(res.data.resultMsg);
                        }
                        if (res.data.resultCode == '1') {
                            // 2017.2.23版本,绑卡成功后的回调传入iloancustId给native
                            C.Native.setUserInfo({
                                custNo: res.data.custNo
                            });
                            if (from == 'icard_loading') {
                                if (C.Utils.data(C.Constant.DataKey.BT_BINDCARD_FLAG) == '1') { // 1 标识选择银行卡，2标识添加银行
                                    C.Native.TDOnEvent({
                                        eventId: 'iBT-03010201010102-下一步',
                                        eventLable: 'iBT-0301020101010201-成功'
                                    });
                                } else {
                                    C.Native.TDOnEvent({
                                        eventId: 'iBT-030102020402-下一步',
                                        eventLable: 'iBT-03010202040201-成功'
                                    });
                                    //埋点 重查征信新绑卡页 事件结果 成功 (还卡流程)
                                    C.Native.TDOnEvent({
                                        eventId: '$_03_2_4_19_01_重查征信新绑卡页'
                                    });
                                }
                            } else {
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-0202010402-下一步',
                                    eventLable: 'iBT-020201040201-成功'
                                });
                                //埋点 添加银行卡页 事件成功 (申请流程)
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_2_06_01_添加银行卡页'
                                });

                            }
                            //邦卡之后保存生成的applyNo
                            C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, res.data.applNo);
                            C.Utils.data(C.Constant.DataKey.NEED_CONTACT, res.data.uploadTelBookFlag);
                            C.Utils.data(C.Constant.DataKey.CARD_NO, _this.cardNo);
                            _this.renderBack('添加成功', true);
                        } else {
                            if (from == 'icard_loading') {
                                if (res.data.blazeSwitch && res.data.blazeSwitch == '0') {
                                    C.Native.tip(res.data.blazeSwitchMsg);
                                }
                                if (C.Utils.data(C.Constant.DataKey.BT_BINDCARD_FLAG) == '1') { // 1 标识选择银行卡，2标识添加银行
                                    C.Native.TDOnEvent({
                                        eventId: 'iBT-03010201010102-下一步',
                                        eventLable: 'iBT-0301020101010202-失败'
                                    });
                                    
                                } else {
                                    C.Native.TDOnEvent({
                                        eventId: 'iBT-030102020402-下一步',
                                        eventLable: 'iBT-03010202040202-失败'
                                    });
                                    //埋点 重查征信新绑卡页 事件结果 失败 (还卡流程) 标识添加
                                    C.Native.TDOnEvent({
                                        eventId: '$_03_2_4_19_02_重查征信新绑卡页'
                                    });
                                }
                            } else {
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-0202010402-下一步',
                                    eventLable: 'iBT-020201040202-失败'
                                });
                                //埋点 添加银行卡页 事件结果 失败 (申请流程)
                                C.Native.TDOnEvent({
                                    eventId: '$_03_2_2_06_02_添加银行卡页'
                                });
                            }
                            _this.renderBack('绑卡失败，请重新绑卡', false);
                            console.log(res.data.resultMsg);
                        }
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        },

        /**
         * 提交更改借还款卡信息
         */
        updateBindData: function (param) {
            var _this = this;
            param = {
                bankNo: param.bankNo,
                bankCardNo: param.bankCardNo,
                bankCardTel: param.bankCardTel,
                cardType: param.cardType,
                bankName: param.bankName,
                paPayAccount: param.paPayAccount,
                bindingSource: 'ILOAN'
            };
            $.ajax({
                url: C.Api('ADD_NEW_PAYEE'),
                data: param,
                type: 'POST',
                success: function (res) {
                    C.UI.stopLoading();
                    console.log(JSON.stringify(res));
                    if (res.flag == C.Flag.SUCCESS && res.data) {
                        if (res.data.resultCode == '1') {
                            _this.renderBack('添加成功', true);
                            _this.bankBindNo = res.data.bankBindNo;
                        } else {
                            _this.renderBack('绑卡失败，请重新绑卡', false);
                        }
                    } else {
                        _this.renderBack('绑卡失败，请重新绑卡', false);
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        }

    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});