/**
 * @author: EX-HUANGYANFENG001
 * @date  : 2017/03/08
 * @describe: 借款详情页
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        todoTpl: _.template($('#container').html()),
        events: {
            'tap #repayment': 'goRepayment',
            'tap #plan': 'goPlan',
            'tap #continueRpy': 'goConfirm',
            'tap #cancelRpy': 'goAccount'
        },
        /*** 初始化：设置头部 ***/
        initialize: function() {
            var $this = this;
            // 埋点 借款详情页
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_41_借款详情页'
            });
            $this.paramer = C.Utils.getQueryMap(); //获取页面参数 还款列表带过来的loanId
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.BORROWDETAIL,
                isBack: 1
            });
            C.UI.loading();
            $.ajax({
                url: C.Api('LOANDETAIL'),
                type: 'POST',
                data: {
                    loanId: $this.paramer.loanId
                },
                success: function(res) {
                    C.UI.stopLoading();
                    if (res && res.flag == C.Flag.SUCCESS) {
                        $this.payState = res.data.payState.toUpperCase();
                        $this.isRepayDate = res.data.isRepayDate;
                        $this.isPrepaymentAlert = res.data.isPrepaymentAlert || ''; // 风险警示开关是否打开
                        $this.loanId = res.data.loanId;
                        C.Utils.data(C.Constant.DataKey.BT_REPAYMENT, res.data); //存储数据给到还款计划
                        $this.render($this.handleData(res.data));
                    }
                }
            });
        },
        /*** 渲染页面元素 ***/
        render: function(data) {
            var $this = this,
                stateCont = $('#state-Cont'), //获取页面顶部父元素
                plan = $('#plan'), //获取还款计划父元素
                support = $('#support'), //获取免手续费父元素
                repayment = $('#repayment'), //获取底部按钮元素
                repaymentBtn = $('#repayment-btn'), //获取底部按钮父元素
                paramer = C.Constant.Enum.ICARD.PAYSTATE; //获取本地信息
            $('section.containter').removeClass('dn');
            $('#brDetail').append($this.todoTpl(data));
            if ($this.payState in paramer) {
                var createElm = ['<p>', paramer[$this.payState].amtText, '(元)</p><p class="money">', data.rpyTotalAmt, '</p><p class="txt mt1">', paramer[$this.payState].tipText, '：', data.munDay, '天</p><div class="btn-state">', paramer[$this.payState].title, '</div>'].join('');
                switch ($this.payState) {
                    case 'SE': //已结清状态
                        createElm = ['<p>', paramer[$this.payState].amtText, '(元)</p><p class="money">', data.rpyTotalAmt, '</p><p class="txt mt1">', paramer[$this.payState].tipText, '</p><div class="btn-state">', paramer[$this.payState].title, '</div>'].join('');
                        stateCont.html(createElm).addClass('settled');
                        $('#principal').hide(); //不显示剩余本金
                        $('#day').hide(); //不显示到期还款日
                        return false;
                    case 'OD': //逾期
                        stateCont.addClass('overdue');
                        repayment.text('立即还款');
                        break;
                    case 'HK': //提前还款
                    case 'RP':
                        support.show(); //显示还款免手续提示
                        repayment.text((data.isRepayDate && data.isRepayDate == 'Y') ? '立即还款' : '提前还款');
                        break;
                }
                stateCont.html(createElm);
            }
            if (data.isDeduct == paramer.isDeduct || C.Utils.getQueryMap().isOver == paramer.isDeduct || data.disbDateRpyFlag == '0') {
                //报盘(扣款)中状态或者还款列表中有逾期的情况下 以及提前还款状态时当日借款不能进行还款操作（如非提前还款状态disbDateRpyFlag值为1）
                if (data.disbDateRpyFlag == '0') {
                    //提示“借款日当天无法进行提前还款操作，请明日再试”
                    $('#disbDateRpyFlag').show();
                }
                $('#repayment')[0].removeAttribute('style');
                //禁用按钮
                repayment.addClass('btn-dis').off();
            }
            plan.show(); //显示还款计划
            repaymentBtn.show(); //显示底部按钮
        },
        /*** 数据处理 ***/
        handleData: function (data) {
            data.fundingModel = data.fundingModel ? data.fundingModel.toUpperCase() : 'L';
            data.rpyTotalAmt = isNaN(data.rpyTotalAmt) ? data.rpyTotalAmt : C.Utils.formatMoney(Number(data.rpyTotalAmt));
            data.loanAmt = isNaN(data.loanAmt) ? data.loanAmt : C.Utils.formatMoney(Number(data.loanAmt));
            data.remainAmt = isNaN(data.remainAmt) ? data.remainAmt : C.Utils.formatMoney(Number(data.remainAmt));
            data.counterFeeShow = isNaN(data.counterFeeShow) ? data.counterFeeShow : C.Utils.formatMoney(Number(data.counterFeeShow));
            data.rpyAmt = isNaN(data.rpyAmt) ? data.rpyAmt : C.Utils.formatMoney(Number(data.rpyAmt));
            data.rateFee = isNaN(data.rateFee) ? data.rateFee : C.Utils.formatMoney(Number(data.rateFee));
            data.overInt = isNaN(data.overInt) ? data.overInt : C.Utils.formatMoney(Number(data.overInt));
            data.serviceCharge = isNaN(data.serviceCharge) ? data.serviceCharge : C.Utils.formatMoney(Number(data.serviceCharge));
            data.insuranceFee = isNaN(data.insuranceFee) ? data.insuranceFee : C.Utils.formatMoney(Number(data.insuranceFee));
            data.fundingModel && data.fundingModel.toUpperCase() == 'L' ? data.rateSum = [C.Utils.formatFloat(C.Utils.accAdd(data.rate, data.guaranteeRate)), '%'].join('') : data.rateSum = [C.Utils.formatFloat(C.Utils.accAdd(data.rate, data.insuranceRate, data.serviceChargeRate)), '%'].join('');
            return data;
        },
        /*** 跳转至还款确认页 ***/
        goRepayment: function(e) {
            var $this = this;
            if ($(e.currentTarget).hasClass('btn-dis')) {
                return;
            }
            if ($this.payState == 'RP') {
                C.Native.TDOnEvent({eventId: 'iBT-06010101-提前还款', eventLable: 'iBT-0601010101-提前还款'});
                //埋点 提前还款
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_41_02_借款详情页'
                });
            } else {
                C.Native.TDOnEvent({eventId: 'iBT-06010101-立即还款', eventLable: 'iBT-0601010101-立即还款'});
                //埋点 立即还款
                C.Native.TDOnEvent({
                    eventId: '$_03_1_3_41_03_借款详情页'
                });
            }
            C.Utils.data('loanId', $this.loanId);//本地存储借款id
            if ($this.payState == 'RP' &&　$this.isRepayDate == 'N' && $this.isPrepaymentAlert == 'Y') {
                // 非还款日当天提前还款，且控台开关打开，展示风险警示框
                $('#riskTip').show();
                return;
            }
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTOPERATION
            });
        },
        /*** 跳转至还款计划页 ***/
        goPlan: function() {
            //埋点 借款详情页 还款计划
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_41_01_借款详情页'
            });
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTPLAN,
                data: {
                    from: 'detail' //进入详情计划页 detail标识符
                }
            });
        },
        /*** 跳转至还款确认页 ***/
        goConfirm: function() {
            $('#riskTip').hide();
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.REPAYMENTOPERATION
            });
        },
        /*** 跳转至账户页 ***/
        goAccount: function() {
            $('#riskTip').hide();
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN
            });
        }
    }));

    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});