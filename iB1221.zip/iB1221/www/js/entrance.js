/**
 * @author: zhoujun261@pingan.com.cn
 * @date  : 2017-03-21
 * @time  : 上午09:10
 *
 * @describe: SDK入口逻辑判断页
 */
define(['zepto', 'C', 'js/refresh'], function ($, C, RE) {
    'use strict';
    var GVS = {
        cityName: '',
        sourceType: '',
        source: '',
        packageDate: '',
        iloanVersion: '',
        sdkFlag: '',
        machineSN: ''
    };
    var nodeObj = {
        'AU': 'credit_info_list.html',
        'AM': 'credit_info_list.html',
        'AF': 'credit_info_list.html',
        'AC': 'credit_info_list.html',
        'AY': 'credit_info_list.html',
        'AP': 'loan_select.html',
        'RP': 'account_iloan.html',
        'RJ': 'credit_fail_result.html',
        'XX': ''
    };
    /**
     * 清除上次存储数据
     * */
    var clearLastData = function() {
        $.each(C.Constant.DataKey, function(key, value) {
            C.Utils.data(C.Constant.DataKey[key], null);
        });
    };

    var init = function() {
        queryIloan();
    };

    var queryIloan = function () {
        clearLastData();
        C.Native.getAppVersion(function (res) {
            GVS.iloanVersion = res.iloanVersion;
            //通过iloanVersion判断是否有getChannelInfo的方法
            if(GVS.iloanVersion) {
                C.Native.getChannelInfo(function (res) {
                    GVS.sdkFlag = res.adFlag;
                    C.Utils.data(C.Constant.DataKey.AD_FLAG, res.adFlag);
                });
                C.Utils.data(C.Constant.DataKey.SDK_VERSION, res.iloanVersion);
            } else {
                GVS.sdkFlag = '1';      //始终展示
            }
        });
        var param = {};
        var getCityName = function () {
            var dtd = $.Deferred();
            C.Native.getCityName(function (res) {
                GVS.cityName = res.cityName;
                if (!!GVS.cityName) {
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_CITYNAME, GVS.cityName);
                } else {
                    C.Native.forward({
                        url: 'try_get_cityname.html'
                    });
                }
                dtd.resolve();
            });
            return dtd.promise();
        };
        var getSourceInfo = function () {
            var dtd = $.Deferred();
            C.Native.getSourceInfo(function (res) {
                C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO, res);
                GVS.source = res.source;
                GVS.sourceType = res.sourceType;
                if ($.inArray(GVS.source, C.Constant.OFFTHESHELF) !== -1) {
                    C.UI.warning({
                        content: '尊敬的客户您好，该入口已不提供平安普惠i贷服务，请至平安普惠App或其他入口申请，谢谢！',
                        ok: function () {
                            C.Native.back({
                                data: {
                                    'exitSDK': '1'
                                }
                            });
                        }
                    });
                    return;
                }

                param = {
                    cityName: GVS.cityName,
                    thirdChannel: GVS.source,
                    channelType: GVS.sourceType
                };
                dtd.resolve();
            });
            return dtd.promise();
        };
        var getUserInfo = function () {
            var dtd = $.Deferred();
            C.Native.getUserInfo(function (data) {
                C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                dtd.resolve();
            });
            return dtd.promise();
        };
        var queryIloanState = function () {
            C.UI.loading();
            $.ajax({
                url: C.Api('QUERY_ILOAN_STATE'),
                type: 'post',
                data: {
                    jsonPara: JSON.stringify(param)
                },
                success: function (res) {
                    if (res.flag == '1' && res.data) {
                        var data = res.data;
                        if (data.realNameAuth == '0') {
                            C.Native.realnameVerification('N', function (res) {
                                if (res.flag == '1') {
                                    C.Native.getUserInfo(function (data) {
                                        C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                                        queryIloan();
                                    });
                                }
                            });
                        } else {
                            if (data.resultCode == '1') {
                                if (data.errerCode == '000002' || data.errorCode == '000002') {
                                    var tip = data.errerMsg ? data.errerMsg : data.errorMsg;
                                    C.UI.warning({
                                        content: tip,
                                        ok: function () {
                                            C.Native.back({
                                                data: {
                                                    'exitSDK': '1'
                                                }
                                            });
                                        }
                                    });
                                    return;
                                }
                                if (data.productVersion == 'OLD' || data.productVersion == 'DQ') {
                                    iLoanOLDClick();
                                } else if (data.productVersion == 'IBT') {
                                    iLoanBTClick();
                                }
                            } else {
                                C.UI.warning({
                                    content: data.resultMsg || '网络异常，请稍后再试',
                                    ok: function () {
                                        C.Native.back({
                                            data: {
                                                'exitSDK': '1'
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    } else {
                        C.UI.warning({
                            content: res.msg || '网络异常，请稍后再试',
                            ok: function () {
                                C.Native.back({
                                    data: {
                                        'exitSDK': '1'
                                    }
                                });
                            }
                        });
                    }
                },
                error: function (error) {
                    var tip = '';
                    if (error && error != 'null') {
                        tip = error;
                    } else {
                        tip = '网络异常，请稍后再试';
                    }
                    C.UI.warning({
                        content: tip,
                        ok: function () {
                            C.Native.back({
                                data: {
                                    'exitSDK': '1'
                                }
                            });
                        }
                    });
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        };
        $.when(getCityName())
            .then(getSourceInfo)
            .then(getUserInfo)
            .then(queryIloanState);
    };

    //老的随借随还贷后管理
    var iLoanOLDClick = function () {
        C.Native.forwardInCurPage({
            url: 'old_home.html'
        });
    };
    //新战略3.0
    var iLoanBTClick = function () {
        var param = {};
        var getDeviceInfo = function () {
            var dtd = $.Deferred();
            C.Native.getDeviceInfo(function (res) {
                C.Utils.data(C.Constant.DataKey.USER_DEVICE_INFO, res.result);
                GVS.machineSN = C.Utils.data(C.Constant.DataKey.USER_DEVICE_INFO).MachineSN || '';  //机器设备号
                GVS.packageDate = res.result.packageDate;
                if (res.code == '1') {
                    param = {
                        cityName: GVS.cityName,
                        longitude: (res.result.longitude).toString(),
                        latitude: (res.result.latitude).toString(),
                        thirdChannel: GVS.source,
                        channelType: GVS.sourceType
                    };
                }
                dtd.resolve();
            });
            return dtd.promise();
        };
        var queryUserApplyState = function () {
            C.UI.loading();
            var ddd = $.Deferred();
            $.ajax({
                url: C.Api('QUERY_USER_APPLY_STATE_2'),
                type: 'post',
                data: {
                    jsonPara: JSON.stringify(param)
                },
                success: function (res) {
                    if (res.flag == '1' && res.data) {
                        var data = res.data;

                        if (data.subProcessCode == 'RJ') {
                            data.applyNo = null;
                        }
                        C.Utils.data('BT_ILOAN_QUAS_RESULT', data);
                        C.Utils.data('BT_ILOAN_APPLYNO', data.applyNo);
                        if (data.resultCode == '1') {
                            //进入再贷页面
                            if (data.subProcessCode == 'RP' && GVS.packageDate >= 20170214) {
                                C.Native.forwardInCurPage({
                                    url: 'account_iloan.html'
                                });
                            } else {  
                                // 调用产品介绍页更新接口
                                $.ajax({
                                    type: 'post',
                                    url: C.Api('QUERY_DEPLOY_INFO'), //产品介绍页更新接口
                                    data: {
                                        ruleId: 'Iloan0009',
                                        machineSN: GVS.machineSN   
                                    },
                                    success: function(result){
                                        if(result.flag == '1' && result.data.ruleSwitch == '1' && result.data.rule === 'A') {  // 开关打开
                                            C.Native.forward({
                                                url: 'iloan_production_index_new.html'
                                            });
                                        } else {
                                            if (GVS.sdkFlag != '0') {
                                                $('#content').show();
                                            }
                                        }   
                                    },
                                    error: function() {
                                        if (GVS.sdkFlag != '0') {
                                            $('#content').show();
                                        }
                                    }
                                });                            
                            }
                        } else if (data.resultCode == '000001' || data.resultCode == '000002') {
                            C.UI.warning({
                                content: data.resultMsg,
                                ok: function () {
                                    C.Native.back({
                                        data: {
                                            'exitSDK': '1'
                                        }
                                    });
                                }
                            });
                        } else {
                            C.UI.warning({
                                content: data.resultMsg || '网络异常，请稍后再试',
                                ok: function () {
                                    C.Native.back({
                                        data: {
                                            'exitSDK': '1'
                                        }
                                    });
                                }
                            });
                        }
                    } else {
                        C.UI.warning({
                            content: res.msg,
                            ok: function () {
                                C.Native.back({
                                    data: {
                                        'exitSDK': '1'
                                    }
                                });
                            }
                        });
                    }
                    ddd.resolve();
                },
                error: function (error) {
                    var tip = '';
                    if (error && error != 'null') {
                        tip = error;
                    } else {
                        tip = '网络异常，请稍后再试';
                    }
                    C.UI.warning({
                        content: tip,
                        ok: function () {
                            C.Native.back({
                                data: {
                                    'exitSDK': '1'
                                }
                            });
                        }
                    });
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
            return ddd.promise();
        };
        //判断预售信的方法
        var judgePreCredit = function () {
            var preCreditcardNativeInfo;
            C.Native.sdkPreCreditInfo(function (res) {
                var preStateDate = C.Utils.data('BT_ILOAN_QUAS_RESULT');
                //如果不是AU节点则跳过预售信接口
                if (preStateDate.subProcessCode != 'AU') {
                    if (GVS.sdkFlag == '0') {
                        experienceLoan();
                    }
                    return false;
                }
                if (res.code === '1') {
                    if (res.result.accountId && res.result.jsonPara) {
                        preCreditcardNativeInfo = {
                            accountId: res.result.accountId,
                            jsonParaSDK: res.result.jsonPara
                        };
                    } else {
                        if (GVS.sdkFlag == '0') {
                            experienceLoan();
                        }
                        return false;
                    }
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('SDK_PRE_CREDIT_LINE'),
                        type: 'post',
                        data: preCreditcardNativeInfo,
                        success: function (res) {
                            if (res.flag === '1' && res.data) {
                                var data = res.data;
                                //说明是预授信用户
                                if (data.resultCode == '1' && data.channelCfg == '1' && data.preCreditLine && data.preCreditLine != 0) {
                                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_PRE_CREDIT, data.preCreditLine);
                                    C.Native.forward({
                                        url: C.Constant.DataUrl.TRANSPAGE.ILOANPRECREDIT
                                    });
                                } else {
                                    if (GVS.sdkFlag == '0') {
                                        experienceLoan();
                                    }
                                }
                            } else {
                                if (GVS.sdkFlag == '0') {
                                    experienceLoan();
                                }
                                console.log('操作不成功或data为空');
                            }
                        },
                        error: function (error) {
                            if (GVS.sdkFlag == '0') {
                                experienceLoan();
                            }
                            console.log(error);
                        },
                        complete: function () {
                            C.UI.stopLoading();
                        }
                    });
                } else {
                    console.log(res.msg);
                }
            });
        };

        var experienceLoan = function () {
            var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO),
                xydSign = C.Utils.data('XIAO_YUAN_DAI') || [],
                data = C.Utils.data('BT_ILOAN_QUAS_RESULT');
            //封堵SDK未升级包的用户
            if (data.fundingModel == 'D' || data.fundingModel == 'U') {
                if (App.IS_SDK && !GVS.iloanVersion) {
                    C.Native.tip('尊敬的客户，为了让您更快更好的使用产品，请您将APP更新至最新版本！');
                    return;
                }
            }
            if (data.applySwitch && data.applySwitch == '0') {//关闭
                C.UI.warning({
                    content: data.switchMsg,
                    ok: function () {
                        C.Native.back({
                            data: {
                                'exitSDK': '1'
                            }
                        });
                    }
                });
            } else {//打开
                if (nodeObj[data.subProcessCode] == '') {
                    C.UI.warning({
                        content: data.resultMsg,
                        ok: function () {
                            C.Native.back({
                                data: {
                                    'exitSDK': '1'
                                }
                            });
                        }
                    });
                } else {
                    if (data.subProcessCode == 'RJ') {
                        //埋点 授信结果页 审核拒绝 （事件结果）
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_2_11_02_授信结果页'
                        });
                        C.Native.TDOnEvent({
                            eventId: 'iBT-02-完善信息',
                            eventLable: 'iBT-07-拒绝'
                        });
                    }
                    //新增禁止校园贷优化需求
                    if (data.subProcessCode !== 'RP' && xydSign && xydSign.indexOf(userInfo.accountId) == -1 && userInfo.Id && C.Utils.ageCheck(userInfo.Id, 18, 23) == 1) {
                        xydSign.push(userInfo.accountId);
                        C.Utils.data('XIAO_YUAN_DAI', xydSign);
                        C.Native.tip('在校学生禁止申请，如发现借款人身份为学生，我公司可采取停止发放借款、要求提前还款等措施');
                        setTimeout(function () {
                            C.Native.forward({
                                url: nodeObj[data.subProcessCode],
                                data: {
                                    route: 'entrance'
                                }   
                            });
                        }, 2000);
                        return;
                    }
                    C.Native.forward({
                        url: nodeObj[data.subProcessCode],
                        data: {
                            route: 'entrance'
                        }
                    });
                }
            }
        };
        $.when(getDeviceInfo())
            .then(queryUserApplyState)
            .then(judgePreCredit);
    };

    return {
        init: init
    };
});