/**
 * @author: EX-ZHANGKEMING001@pingan.com.cn
 * @date  : 2016-11-14
 * @describe: 平安个人借款保证保险条款(CGI模式下)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            C.Native.setHeader({
                title: '平安个人借款保证保险条款',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
          
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});