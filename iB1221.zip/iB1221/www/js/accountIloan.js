/*
*@describe选择产品-再贷页
*/
define(['zepto', 'C', 'view', 'js/refresh', 'js/callback'], function($, C, View, RE, CB) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .js-tixian': 'toTixian',
            'tap .js-addCredit': 'toAddCredit',
            'tap .js-huanka': 'toBT',
            'tap .js-huanka-rj': 'toHuanKaRJ',
            'tap .js-accpay': 'toAccPay',
            'tap .js-readcontact': 'toReadContact',
            'tap #loan_contract_cgi': 'readCgiLoanContact',
            'tap #loan_data_transfer_cgi': 'readCgiDataTransferContact',
            'tap #cancel': 'cancel_leayer',
            'tap #disagree_btn': 'hideEsignTpl',
            'tap #agree_btn': 'submitEsign',
            'tap .qianming': 'esign'
        },
        initialize: function() {
            var self = this;
            C.Utils.data('iloan_From_Page', null);
            C.Utils.data(C.Constant.DataKey.ILOAN_LOANCODE, '');
            //清空迁徙数据
            C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, null);
            self.barCode = '';
            self.online_domesticAlgorithm = 'Y';
            self.online_OcrKey = 'N';
            self.online_OcrNeed = 'N';
            self.eleFlag = false;//用于标识，是否有签过名，false 未签名
            self.frompage = C.Utils.getParameter('frompage') || '';
            self.lastURL = C.Utils.getParameter('lastURL') || '';
            self.lastModule = C.Utils.getParameter('lastModule') || '';
            self.iloanVersion = C.Utils.data(C.Constant.DataKey.SDK_VERSION);//是否是Native最新版本
            if (self.frompage == 'home') {
                C.Utils.data('iloan_From_Page', 'home');
            }
            //埋点 I贷账户页
            C.Native.TDOnEvent({
                eventId: '$_03_0_3_13_我的I贷账户页'
            });

            if (App.IS_SDK) {
                C.Native.getUIParams(function (data) {
                    var productName = data.productName || data.proName;
                    C.Native.setHeader({
                        title: productName ? ('我的' + productName) : '我的i贷',
                        leftCallback: function () {
                            CB.init();
                        }
                    });
                });
            } else {
                C.Native.setHeader({
                    title: '我的i贷',
                    leftCallback: function () {
                        if(self.frompage == 'home') {
                            C.Native.back();
                        } else if(self.lastURL && self.lastModule){
                            C.Native.backToRobot(self.lastURL, self.lastModule);
                        }else {
                            C.Native.backModule({
                                moduleName: C.Constant.MODULE_NAME.home,
                                url: C.Constant.index_page
                            });
                        }
                    }
                });
                //异常用户验证
                C.Native.pah_loanSuccess();
            }

            self.getSwitch();
            self.getInfo();
            self.resultData = {};
        },
        //判断是否第一次点击"立即还款"
        isFirstClick: function() {
            var self = this;
            self.account = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO).accountId || ''; //获取用户的ID
            self.accountGroup = C.Utils.data('BT_ILOAN_REPAY_CLICK') || [];//存储用户登录信息（用户id 和 点击次数）
            for (var i = 0, len = self.accountGroup.length; i < len; i++) {
                if (self.account == self.accountGroup[i].account && self.accountGroup[i].clickTime == 1) {
                    return false;
                }
            }
            return true;
        },
        getInfo: function() {
            var self = this;
            RE.init(function(res) {
                C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT, res.data);
                C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, res.data.applyNo || null);
                self.resultData = res.data;
                self.showView(res.data);

                if (App.IS_SDK) {
                    C.Native.getUIParams(function (data) {
                        var productName = data.productName || data.proName;
                        C.Native.setHeader({
                            title: productName ? ('我的' + productName) : '我的i贷',
                            leftCallback: function () {
                                CB.init();
                            },
                            rightText: '立即还款',
                            rightCallback: function () {
                                C.Native.TDOnEvent({
                                    eventId: 'iBT-06-帐户',
                                    eventLable: 'iBT-0601-立即还款'
                                });
                                //埋点 I贷账户页 立即还款
                                C.Native.TDOnEvent({
                                    eventId: '$_03_1_3_16_09_I贷账户页'
                                });
                                var isFirstClick = self.isFirstClick();
                                if(self.resultData.rpyInfo.rpyStatus=='LP'){
                                    C.Native.forward({
                                        url: 'repay_current_detailed.html'
                                    });
                                }else if(isFirstClick == true){
                                    C.Native.forward({
                                        url: 'intro.html?fromPage=accountIloan'
                                    });
                                    self.clickTime = 1;
                                    var userLogin = {};
                                    userLogin.account = self.account;
                                    userLogin.clickTime = self.clickTime;
                                    self.accountGroup.push(userLogin);
                                    C.Utils.data('BT_ILOAN_REPAY_CLICK', self.accountGroup);
                                }else{
                                    //C.Native.forwardModule({
                                    //    url: 'repayment.html',
                                    //    moduleName: 'icard'
                                    //});
                                    C.Native.forward({
                                        url: 'repay_list_record.html'
                                    });
                                }
                            }
                        });
                    });
                } else {
                    C.Native.setHeader({
                        title: '我的i贷',
                        leftCallback: function () {
                            if(self.frompage == 'home') {
                                C.Native.back();
                            } else if(self.lastURL && self.lastModule){
                                C.Native.backToRobot(self.lastURL, self.lastModule);
                            }else {
                                C.Native.backModule({
                                    moduleName: C.Constant.MODULE_NAME.home,
                                    url: C.Constant.index_page
                                });
                            }
                        },
                        rightText: '立即还款',
                        rightCallback: function () {
                            C.Native.TDOnEvent({
                                eventId: 'iBT-06-帐户',
                                eventLable: 'iBT-0601-立即还款'
                            });
                            //埋点 I贷账户页 立即还款
                            C.Native.TDOnEvent({
                                eventId: '$_03_1_3_16_09_I贷账户页'
                            });
                            var isFirstClick = self.isFirstClick();
                            if(self.resultData.rpyInfo.rpyStatus=='LP'){
                                C.Native.forward({
                                    url: 'repay_current_detailed.html'
                                });
                            }else if(isFirstClick == true){
                                C.Native.forward({
                                    url: 'intro.html?fromPage=accountIloan'
                                });
                                self.clickTime = 1;
                                var userLogin = {};
                                userLogin.account = self.account;
                                userLogin.clickTime = self.clickTime;
                                self.accountGroup.push(userLogin);
                                C.Utils.data('BT_ILOAN_REPAY_CLICK', self.accountGroup);
                            }else{
                                //C.Native.forwardModule({
                                //    url: 'repayment.html',
                                //    moduleName: 'icard'
                                //});
                                C.Native.forward({
                                    url: 'repay_list_record.html'
                                });
                            }
                        }
                    });
                }
            });
        },
        showView: function(data) {
            var self = this,
                html = '';
            if (App.IS_SDK) {
                //只要有一个是临时冻结或者冻结，Iloan和Bt都改为冻结，修改者：Yuejianglei
                if (data.ICreditInfo.accountStatus == 'FZ' || data.BTCreditInfo.accountStatus == 'FZ') {
                    data.ICreditInfo.accountStatus = data.BTCreditInfo.accountStatus = 'FZ';
                }
                if (data.BTCreditInfo.accountStatus == 'FF' || data.ICreditInfo.accountStatus == 'FF') {
                    data.ICreditInfo.accountStatus = data.BTCreditInfo.accountStatus = 'FF';
                }
            }

            data.availableCredit = C.Utils.formatMoney(data.availableCredit);
            if (data.rpyInfo) {
                data.rpyInfo.rpyAmt = C.Utils.formatMoney(data.rpyInfo.rpyAmt);
            }
            if (data.ICreditInfo && (typeof data.BTCreditInfo) == 'undefined') {
                html = _.template($('#rp-body-only-iloan').html(), {
                    data: data
                });
            } else if (data.ICreditInfo && data.BTCreditInfo.creditStatus == 'NN') {
                html = _.template($('#rp-body-only-iloan').html(), {
                    data: data
                });
            } else if (data.ICreditInfo && data.BTCreditInfo.creditStatus != 'NN') {
                html = _.template($('#rp-body-iloan-bt').html(), {
                    data: data
                });
            }
            $('section#content-body').html(html);
            self.initAnimation(C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).availableCredit, data.credit);
        },

        //仪表盘进度
        initAnimation: function(availableNum, allNum) {
            var dior = availableNum / allNum;
            var num1 = Math.floor(471 * dior),
                num2 = 471 - num1;
            $('#path').css('stroke-dasharray', num1 + ' ' + num2);
            if (availableNum == '0' || availableNum == 0) {
                $('.account-svg').addClass('account-zreo');
            }
        },

        //提现
        toTixian: function(e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-06-帐户',
                eventLable: 'iBT-0604-提现再贷'
            });
            //埋点 I贷账户页 提现再贷
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_11_I贷账户页'
            });
            if (this.resultData.signSwitch == '0') {
                C.Native.tip(this.resultData.switchMsg);
            } else {
                if (this.resultData.isCreditEnough == 'Y') {
                    this.toSelect(this.resultData.ICreditInfo.loanCode, this.toJudgeGoiLoan);
                } else {
                    C.Native.tip('额度不足');
                }
            }

        },

        //点击BT，请求选择产品接口
        toBT: function(e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-06-帐户',
                eventLable: 'iBT-0605-还卡再贷'
            });
            //埋点 I贷账户页 还卡再贷
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_12_I贷账户页'
            });
            if (this.resultData.signSwitch == '0') {
                C.Native.tip(this.resultData.switchMsg);
            } else {
                if (this.resultData.isCreditEnough == 'Y') {
                    this.toSelect(this.resultData.BTCreditInfo.loanCode, this.toJudgeGoBT);
                } else {
                    C.Native.tip('额度不足');
                }
            }

        },

        //点击BT，请求选择产品接口
        toSelect: function(loanCode, callback) {
            var self = this;
            var param = {
                applyNo: self.resultData.applyNo,
                loanCode: loanCode
            };
            if (App.IS_SDK) {
                param.channelType = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO).sourceType;
            }
            self.dataRequest({
                url: C.Api('SELECT_PRODUCTION'),
                callback: callback,
                type: 'POST',
                data: param
            });
        },

        //选择产品－－iloan
        toJudgeGoiLoan: function(res) {
            console.log(res);
            var self = this,
                params = {};
            if (res.data.resultCode != '0') {
                //资金开关关闭
                if (res.data.signSwitch && res.data.signSwitch == '0') {
                    C.Native.tip(res.data.switchMsg || res.data.resultMsg);
                } else {
                    params.idvalid = res.data.idvalid;
                    params.isFirstPay = res.data.infoMap.isFisrtPay;
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, params); //将身份证有效性本地存储，给到试算页使用
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO, res.data.payApplyNo);
                    self.fundingModel = res.data.fundingModel;
                    self.loanCompanyCode = res.data.loanCompanyCode || 'L';
                    self.isCredit = res.data.isCredit;
                    self.newBankName = res.data.newBank;
                    self.bankCode = res.data.bankCode;
                    if (res.data.infoMap.apvFlag == 'PS') {
                        self.toLoanApply(res);
                    } else if (res.data.infoMap.apvFlag == 'RJ') {
                        C.Utils.data(C.Constant.DataKey.BT_RJ_FROM, 'RP');
                        C.Native.forward({
                            url: 'credit_fail_result.html'
                        });
                    }
                }
            } else {
                C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
            }
        },
        //在跳转到loan_apply之前，进行银行有效性的校验
        toLoanApply: function(res){
            var self = this;
            console.log(res);
            // 新增迁徙无欠款校验逻辑
            var migrateMap = res.data.migrateMap ? res.data.migrateMap : '';
            if (migrateMap && migrateMap.isMigrate == 'Y' && migrateMap.isDebt == 'N' && (self.iloanVersion || !App.IS_SDK)) {
                //埋点 无欠款迁徙
                C.Native.TDOnEvent({
                    eventId: '$_03_2_0_13_01_我的I贷账户页'
                });
                migrateMap.loanCode = (res.data.infoMap && res.data.infoMap.loanCode) ? res.data.infoMap.loanCode : '';
                C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, migrateMap);
                if (migrateMap.isSign == 'Y') {
                    //需要电子签名
                    if (App.IS_SDK) {
                        //SDK3.0用户 跳转到H5电子签名
                        C.Native.forward({
                            url: 'old_personal-credit.html',
                            data: {
                                fromPage: 'account_iloan',
                                fundingModel: migrateMap.fundingModel,
                                loanCompanyCode: migrateMap.loanCompanyCode,
                                isCredit: migrateMap.isCredit,
                                newBankName: migrateMap.signCode == 'S00002'?migrateMap.newBank : migrateMap.cgiBankName,
                                bankCode: migrateMap.bankCode
                            }
                        });
                        return;
                    }
                    //APP2.0用户 跳转到迁徙综合授权书
                    C.Native.forward({
                        url: 'migrate_shouquan.html',
                        data: {
                            fromPage: 'account_iloan',
                            applyNo: res.data.applyNo
                        }
                    });
                    return;
                }
                //已电子签名 跳转到申请提现页
                C.Native.forward({
                    url: 'loan_apply.html'
                });
                return;
            }
            if(res.data.isValidity && res.data.isValidity == '0'){
                //银行无效
                if(res.data.fundingModel && res.data.fundingModel == 'U'){//cgi+小贷+银行
                    if(!res.data.newBank){
                        //新银行无效,弹出新日额度已抢光提示
                        C.Native.tip(res.data.resultMsg);
                    }else{//新银行有效
                        if(res.data.isCredit && res.data.isCredit == '1'){
                            //需要征信，去电子签名，显示对应银行征信
                            var bankClass = C.Constant.BANKCONTRACT[res.data.newBank];
                            $('.bankItem').addClass('dn');
                            $('.'+bankClass).removeClass('dn');
                            self.isLoanApply = true;
                            self.eleFlag = false;
                            self.isSigned();
                        }else{
                            //不需要征信，调用银行变更接口
                            self.isLoanApply = true;
                            self.doBankAlert(res);
                        }
                    }
                }else if(res.data.fundingModel && res.data.fundingModel == 'D'){
                    //cgi+小贷
                    C.Native.forward({
                        url: 'loan_apply.html'
                    });
                }else{//担保+小贷，弹出新日额度已抢光提示
                    C.Native.tip(res.data.resultMsg); 
                }
            }else{
                //银行有效，直接跳转到试算页
                C.Native.forward({
                    url: 'loan_apply.html'
                });
            }
        },
        //银行变更接口
        doBankAlert: function(res){
            var self = this;
            console.log(res);
            var params = {
                payApplyNo: res.data.payApplyNo,
                applyNo: res.data.applyNo,
                bankCode: res.data.bankCode,
                bankName: res.data.newBank //变更后的银行
            };
            C.UI.loading();
            $.ajax({
                url: C.Api('ALERT'),
                type: 'POST',
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function(data){
                    console.log(data);
                    if(data.flag == C.Flag.SUCCESS){
                        if(data.data.resultCode == '1'){
                            if(self.isLoanApply){//提现，跳转到试算页
                                C.Native.forward({
                                    url: 'loan_apply.html'
                                });
                            }else{//还卡
                                if(self.apvFlag == 'PA'){
                                    C.Native.forward({
                                        url: 'icard_loading.html'
                                    });
                                }else if(self.apvFlag == 'BTPS'){
                                    C.Native.forward({
                                        url: 'icard_pinned.html'
                                    });
                                }   
                            }
                        }else{
                            C.Native.tip(data.data.resultMsg || data.msg);
                        }
                    }                    
                },
                complete: function(){
                    C.UI.stopLoading();
                }
            });
        },


        //选择产品－－BT
        toJudgeGoBT: function(res) {
            var self = this,
                params = {};
            if (res.data.resultCode != '0') {
                //资金开关关闭
                if (res.data.signSwitch && res.data.signSwitch == '0') {
                    C.Native.tip(res.data.switchMsg || res.data.resultMsg);
                } else {
                    params.idvalid = res.data.idvalid;
                    params.isFirstPay = res.data.infoMap.isFisrtPay;
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_IDVALID, params); //将身份证有效性本地存储，给到试算页使用
                    C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO, res.data.payApplyNo);
                    self.fundingModel = res.data.fundingModel;
                    self.loanCompanyCode = res.data.loanCompanyCode || 'L';
                    self.isCredit = res.data.isCredit;
                    self.newBankName = res.data.newBank;
                    self.bankCode = res.data.bankCode;
                    self.apvFlag = res.data.infoMap.apvFlag;
                    if (res.data.infoMap.apvFlag == 'BTPS' || res.data.infoMap.apvFlag == 'PA') {//BT打点规则通过
                        self.toLoading(res);
                    } else if (res.data.infoMap.apvFlag == 'RJ') {
                        C.Utils.data(C.Constant.DataKey.BT_RJ_FROM, 'RP');
                        C.Native.forward({
                            url: 'credit_fail_result.html'
                        });
                    }
                }
            } else {
                C.Native.tip(res.data.resultMsg || '网络异常，请稍后再试');
            }
        },
        toLoading: function(res){
            var self = this;
            // 新增迁徙无欠款校验逻辑
            var migrateMap = res.data.migrateMap ? res.data.migrateMap : '';
            if (migrateMap && migrateMap.isMigrate == 'Y' && migrateMap.isDebt == 'N' && (self.iloanVersion || !App.IS_SDK)) {
                C.Native.TDOnEvent({
                    eventId: '$_03_2_0_13_01_我的I贷账户页'
                });
                migrateMap.loanCode = (res.data.infoMap && res.data.infoMap.loanCode) ? res.data.infoMap.loanCode : '';
                C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, migrateMap);
                if (migrateMap.isSign == 'Y') {
                    //需要电子签名
                    if (App.IS_SDK) {
                        //SDK3.0用户 跳转到H5电子签名
                        C.Native.forward({
                            url: 'old_personal-credit.html',
                            data: {
                                fromPage: 'account_iloan',
                                fundingModel: migrateMap.fundingModel,
                                loanCompanyCode: migrateMap.loanCompanyCode,
                                isCredit: migrateMap.isCredit,
                                newBankName: migrateMap.signCode == 'S00002'?migrateMap.newBank : migrateMap.cgiBankName,
                                bankCode: migrateMap.bankCode,
                                isAuthFlag: 'BTRP'
                            }
                        });
                        return;
                    }
                    //APP2.0用户 跳转到迁徙综合授权书
                    C.Native.forward({
                        url: 'migrate_shouquan.html',
                        data: {
                            fromPage: 'account_iloan',
                            applyNo: res.data.applyNo
                        }
                    });
                    return;
                }
                //已电子签名 跳转到代还信用卡页
                C.Native.forward({
                    url: 'icard_pinned.html'
                });
                return;
            }
            if(res.data.isValidity && res.data.isValidity == '0'){
                //银行无效，需要变更
                if(self.fundingModel == 'U' && res.data.newBank){
                    if(res.data.isCredit && res.data.isCredit == '1'){
                        //需要征信，去电子签名，显示银行征信
                        var bankClass = C.Constant.BANKCONTRACT[res.data.newBank];
                        $('.bankItem').addClass('dn');
                        $('.'+bankClass).removeClass('dn');
                        self.isLoanApply = false;
                        self.eleFlag = false;
                        self.isSigned();
                    }else{
                        //不需要征信，调用银行变更接口
                        self.isLoanApply = false;
                        self.doBankAlert(res);
                    }   
                }else if((!self.newBankName && self.fundingModel == 'U') || self.fundingModel == 'L'){
                    C.Native.tip(res.data.resultMsg);
                }else if(self.fundingModel == 'D'){
                    if(self.apvFlag == 'PA'){
                        C.Native.forward({
                            url: 'icard_loading.html'
                        });
                    }else if(self.apvFlag == 'BTPS'){
                        C.Native.forward({
                            url: 'icard_pinned.html'
                        });
                    }
                }
            }else{
                if(self.apvFlag == 'PA'){
                    C.Native.forward({
                        url: 'icard_loading.html'
                    });
                }else if(self.apvFlag == 'BTPS'){
                    C.Native.forward({
                        url: 'icard_pinned.html'
                    });
                }
            }
        },
        //判断是否可以电子签名
        isSigned: function () {
            var self = this,
                userdata = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO);
            if (self.eleFlag) {
                //显示大白圆
                self.hideEsignTpl();
                if(self.isLoanApply){//若是提现的电子签名,直接跳转页面
                    C.Native.forward({
                        url: 'loan_apply.html'
                    });
                }
                //已电子签名
                if (userdata.paPayToken){
                    C.Native.TDOnEvent({
                        eventId: 'iBT-0301-重查征信',
                        eventLable: 'iBT-030102-绑银行卡'
                    });
                    if(self.apvFlag == 'PA'){
                        C.Native.forward({
                            url: 'icard_loading.html'
                        });
                    }else if(self.apvFlag == 'BTPS'){
                        C.Native.forward({
                            url: 'icard_pinned.html'
                        });
                    } 
                } else {
                    //没有静默注册成功
                    C.Native.loginOrRegistPaOne(function () {
                        C.Native.getUserInfo(function (data) {
                            C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
                        });
                    });
                }
            } else {
                C.Native.TDOnEvent({
                    eventId: 'iBT-0301-重查征信',
                    eventLable: 'iBT-030101-综合授权书'
                });
                //埋点 重查征信页  
                C.Native.TDOnEvent({
                    eventId: '$_03_0_4_17_重查征信页'
                });
                if (App.IS_SDK) {
                    //跳转到H5电子签名
                    C.Native.forward({
                        url: 'old_personal-credit.html',
                        data: {
                            fromPage: 'account_iloan',
                            fundingModel: self.fundingModel,
                            loanCompanyCode: self.loanCompanyCode,
                            isCredit: self.isCredit,
                            newBankName: self.newBankName,
                            bankCode: self.bankCode,
                            isAuthFlag: self.isLoanApply ? '' : 'BTRP'
                        }
                    });
                    return;
                }
                
                //当银行无效，新银行需要征信，展示对应银行的征信协议
                $('#zxsq_cgi').show();
                $('.isShow').addClass('dn');//隐藏个人征信和综合授权书
                self.authText = $('#zxsq_cgi').html();
                
                //否则会有一个大白圆
                $('.account-svg').addClass('dn');
                $('#esign_section').find('.signature').show();
                $('#esign_section').show();
            }
        },

        //隐藏授权书电子签名
        hideEsignTpl: function () {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010103-不同意'
            });
            //埋点 重查征信页  不同意
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_17_03_重查征信页'
            });
            $('#esign_section').hide();
            $('#img').hide().attr('src', '');
            $('#result').val('');
            $('#qian-input').show();
            $('.account-svg').removeClass('dn');
        },

        // 提交电子签名
        submitEsign: function () {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010102-同意'
            });
            //埋点 重查征信页  同意
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_17_02_重查征信页'
            });
            var self = this;

            var isSigned = !$('#result')[0].value ? false : true;
            if (!isSigned) {
                C.Native.tip('请先签名');
                return;
            }
            var params = {
                imgDenseStr: self.imgDenseStr,
                imgBytes: self.imgBytes,
                productType: C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT).productType,
                loanCompanyCode: self.loanCompanyCode,
                platform: App.IS_IOS ? 'IOS' : 'A',
                businessNo: self.barCode
            };
            params.ocrKey = self.online_OcrKey;
            params.ocrNeed = self.online_OcrNeed;
            params.productId = 'ILOANBT';
            params.isDomesticAlgorithm = self.online_domesticAlgorithm;
            //传给SS，用于标识是否需要调用银行变更接口，若为空，SS则不需调用
            params.applyNo = self.resultData.applyNo;
            params.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO);
            params.bankName = self.newBankName || '';
            params.bankCode = self.bankCode || '';
            self.dataRequest({
                url: C.Api('BT_UPLOADPOSELECTRONICSIGNATURE'),
                callback: self.toSubmitEsign,
                type: 'POST',
                data: params
            }, false, function () {
                // empty
            });
        },
        //提交电子签名callBack
        toSubmitEsign: function (res) {
            console.log(res);
            var self = this;
            if (res.flag == '1') {
                if(res.data.resultCode && res.data.resultCode == '0'){//银行变更接口失败
                    C.Native.tip(res.data.resultMsg);
                    return;
                }
                C.Utils.data(C.Constant.DataKey.BT_THRITY_ESIGN_INFO, res.data);
                self.eleFlag = true;
                self.isSigned();
            } else { //OCR识别的结果校验，=3代表校验不通过需要重新签名;=2代表接口有问题
                $('#img').hide().attr('src', '');
                $('#result').val('');
                $('#qian-input').show();
            }
        },
        // 调用Native电子签名接口
        esign: function (e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010101-电子签名'
            });
            //埋点 重查征信页  电子签名
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_17_01_重查征信页'
            });
            var self = this;
            var $target = $(e.currentTarget);
            var barCode = 'iloanbt' + Math.round(Math.random() * 1000) + new Date().getTime();
            
            if ($target.hasClass('justClick')) {
                return;
            }
            $target.addClass('justClick');
            setTimeout(function () {
                $target.removeClass('justClick');
            }, 2000);

            C.Native.esign3({
                domesticAlgorithm: self.online_domesticAlgorithm,
                barCode: barCode,
                enText: self.authText,
                keyWord: ''
            }, function (res) {
                console.log(res);
                if (typeof res == 'string') {
                    res = JSON.parse(res);
                }
                if (typeof res.signData == 'string') {
                    res.signData = JSON.parse(res.signData);
                }
                if (res.code == '1') {
                    if (res.result && res.result.imageData) {
                        //全局保存barCode
                        self.barCode = barCode;
                        self.imgBytes = res.result.imageData;
                        self.imgDenseStr = res.result.signData;
                        $('#qian-input').hide();
                        var srcStr = 'data:image/jpg;base64,' + self.imgBytes;
                        $('#img').attr('src', srcStr).show();
                        $('#result').attr('value', self.imgDenseStr);
                    }
                } else {
                    C.Native.tip('电子签名出错' + res.msg);
                }
            });
        },

        // Ajax请求数据
        dataRequest: function(json) {
            var self = this;
            if (self.isLoading) {
                return;
            }
            C.UI.loading();
            self.isLoading = true;
            $.ajax({
                url: json.url,
                type: json.type,
                data: {
                    jsonPara: JSON.stringify(json.data)
                },
                success: function(res) {
                    if (res && res.flag == C.Flag.SUCCESS) {
                        json.callback.call(self, res);
                    }
                },
                complete: function() {
                    C.UI.stopLoading();
                    self.isLoading = false;
                }
            });
        },

        //提升额度
        toAddCredit: function(e) {
            C.Native.forwardModule({
                moduleName: 'paehome',
                url: 'credit-information.html?module=iloanbt'
            });
        },

        //还卡
        toHuanka: function(e) {
            C.Native.forward({
                url: C.Constant.DataUrl.TRANSPAGE.PINNED
                //moduleName: "icard"
            });
        },

        //还卡-暂不能提供服务
        toHuanKaRJ: function(e) {
            C.Utils.data(C.Constant.DataKey.BT_RJ_FROM, 'RP');
            C.Native.forward({
                url: 'credit_fail_result.html'
            });
        },

        //还款明细
        toAccPay: function(e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-06-帐户',
                eventLable: 'iBT-0602-当期应还金额'
            });
            //埋点 I贷账户页 当期应还金额
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_08_I贷账户页'
            });
            C.Native.forward({
                url: 'repay_current_detailed.html'
            });
        },

        //阅读协议
        toReadContact: function(e) {
            C.Native.TDOnEvent({
                eventId: 'iBT-06-帐户',
                eventLable: 'iBT-0603-查看协议'
            });
            //埋点 I贷账户页 查看协议
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_10_I贷账户页'
            });
            if(this.resultData.fundingModel && (this.resultData.fundingModel == 'U' || this.resultData.fundingModel == 'D')){
                $('#contract_cgi').show();
            }else{
                C.Native.forward({
                    url: C.Constant.CONTRACT[this.resultData.versionNo]
                });
            }
        },
        //隐藏借款协议列表蒙层
        cancel_leayer: function(){
            $('#contract_cgi').hide();
        },
        //查看资料代传协议
        readCgiDataTransferContact: function(){
            //埋点 I贷账户页 查看资料代传协议
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_14_I贷账户页'
            });
            C.Native.forward({
                url: C.Constant.DATAVERSION[this.resultData.dataVersionNo]
            });
        },
        //查看借款协议
        readCgiLoanContact: function(){
            //埋点 I贷账户页 查看借款协议
            C.Native.TDOnEvent({
                eventId: '$_03_1_3_16_13_I贷账户页'
            });
            C.Native.forward({
                url: C.Constant.CONTRACTCGI[this.resultData.versionNo]
            });
        },
        //获取电子签名在线开关文件
        getSwitch: function () {
            var self = this;
            $.ajax({
                url: C.Api('ALL_ILOAN_SWITCH', 'SWITCH'),
                cache: false,
                type: 'GET',
                success: function (res) {
                    if (res.code == '1' && res.data) {
                        self.online_domesticAlgorithm = res.data.esignOCR.domesticAlgorithm;
                        self.online_OcrNeed = res.data.esignOCR.OcrNeed;
                        self.online_OcrKey = res.data.esignOCR.OcrKey;
                    }
                }
            });
        }
    }));
    (function() {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function() {
            location.reload();
        };
    })();
});