/**
 * Created by ex-huangyanfeng001 on 17/9/14.
 */

define(['zepto', 'C', 'view'], function ($, C, View) {
    //使用严格模式
    'use strict';
    C.FastClick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap .qianming': 'esign',
            'tap #disagree_btn': 'hideEsignTpl',
            'tap #agree_btn': 'submitEsign'
        },
        initialize: function () {
            //埋点 迁徙 无欠款综合授权页
            C.Native.TDOnEvent({
                eventId: '$_03_0_0_57_无欠款迁徙授权页'
            });
            //APP1.0传参
            var self = this,
                migrateMap = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA);
            self.online_domesticAlgorithm = 'Y';
            //获取迁徙所需数据
            self.applyNo = C.Utils.getParameter('applyNo') || '';   //返回支用申请号
            self.fromPage = C.Utils.getParameter('fromPage') || '';  //返回的url地址
            self.ratio = migrateMap.ratio;
            self.isSign = migrateMap.isSign || 'Y';//是否需要电子签名
            self.bankCode = migrateMap.bankCode;
            self.isCredit = migrateMap.isCredit;  //银行是否需要综合授权书
            self.signCode = migrateMap.signCode; //银行是否有变更
            self.productId = migrateMap.loanCode; //2.0产品代码，判断提现或换卡
            self.fundingModel = migrateMap.fundingModel; //资金模式:L 担保+小贷, D CGI+小贷,U CGI+联合放款
            self.loanCompanyCode = migrateMap.loanCompanyCode; //小贷公司编码
            self.bankName = (migrateMap.signCode == 'S00002')?migrateMap.newBank : migrateMap.cgiBankName;  //目前支持重庆银行cq、光大银行gd、九江银行jj
            //设置头部
            C.Native.setHeader({
                title: '综合授权',
                leftCallback: function () {
                    C.Native.back();
                }
            });

            //获取电子签名在线开关文件
            self.getSwitch();
            //获取支持银行的配置信息
            var bankClass = C.Constant.BANKCONTRACT[self.bankName];
            $('.personal-credit-cg').show();
            //联合放款模式显示《个人征信查询及信息使用授权书》和《综合授权书》
            $('.model_UD').show();
            //根据渠道银行开关有效性展示相应的《重庆银行查询使用个人信用信息基础数据库授权书》或《光大银行查询使用个人信用信息基础数据库授权书》或《九江银行查询使用个人信用信息基础数据库授权书》
            //银行是否需要综合授权书
            if (self.isCredit == '1' && self.fundingModel == 'U') {
                $('.'+bankClass).removeClass('dn');
            } else {
                $('.'+bankClass).addClass('dn');
            }
            //根据资金模式展示相应的授权书
            if (self.fundingModel && (self.fundingModel == 'U' || self.fundingModel == 'D')) {
                //获取所有授权书的条款内容在电子签名的时候传送给Native
                self.authText = $('#zxsq_cgi').html();
                //根据后端返回的标识字段展示相应授权书的详细条款: C重庆小贷 H湖南小贷 L深圳小贷
                switch (self.loanCompanyCode.toUpperCase()) {
                    case 'C':
                        $('.zxsq_cgi_c').show();
                        break;
                    case 'H':
                        $('.zxsq_cgi_h').show();
                        break;
                    default:
                        $('.zxsq_cgi_l').show();
                        break;
                }
            } else {
                if (self.loanCompanyCode.toUpperCase() == 'C') {
                    $('#zxsq_l').hide();
                    $('#zxsq_c').show();
                    self.authText = $('#zxsq_c').html();
                } else {
                    $('#zxsq_c').hide();
                    $('#zxsq_l').show();
                    self.authText = $('#zxsq_l').html();
                }
            }

        },
        /*
         * 获取电子签名在线开关文件
         *
         * */
        getSwitch: function () {
            var self = this;
            C.UI.loading();
            $.ajax({
                url: C.Api('ALL_ILOAN_SWITCH', 'SWITCH'),
                cache: false,
                type: 'GET',
                success: function (res) {
                    if (res.code == '1' && res.data) {
                        self.online_domesticAlgorithm = res.data.esignOCR.domesticAlgorithm;
                        self.online_OcrNeed = res.data.esignOCR.OcrNeed;
                        self.online_OcrKey = res.data.esignOCR.OcrKey;
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                }
            });
        },
        /*
        * 调用Native电子签名接口
        *
        * */
        esign: function (e) {
            //埋点 无欠款迁徙综合授权页 电子签名
            C.Native.TDOnEvent({
                eventId: '$_03_1_0_57_01_无欠款迁徙授权页'
            });
            var self = this,
                $target = $(e.currentTarget),
                barCode = 'iloanbt' + Math.round(Math.random() * 1000) + new Date().getTime();
            //防重
            if ($target.hasClass('justClick')) {
                return;
            }
            $target.addClass('justClick');
            setTimeout(function () {
                $target.removeClass('justClick');
            }, 2000);

            C.Native.esign3({
                domesticAlgorithm: self.online_domesticAlgorithm,
                barCode: barCode,
                enText: self.authText,
                keyWord: ''
            }, function (res) {
                console.log(res);
                if (typeof res == 'string') {
                    res = JSON.parse(res);
                }
                if (typeof res.signData == 'string') {
                    res.signData = JSON.parse(res.signData);
                }
                if (res.code == '1') {
                    if (res.result && res.result.imageData) {
                        //全局保存barCode
                        self.barCode = barCode;
                        self.imgBytes = res.result.imageData;
                        self.imgDenseStr = res.result.signData;
                        $('#qian-input').hide();
                        var srcStr = 'data:image/jpg;base64,' + self.imgBytes;
                        //显示签名页
                        $('#img').attr('src', srcStr).show();
                        $('#result').attr('value', self.imgDenseStr);
                    }
                } else {
                    C.Native.tip('电子签名出错' + res.msg);
                }
            });
        },
        /*
        * 不同意返回账户页
        *
        * */
        hideEsignTpl: function () {
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010103-不同意'
            });
            //隐藏签名页
            $('#img').hide().attr('src', '');
            $('#result').val('');

            C.Native.back();
        },
        /*
        * 提交电子签名
        *
        * */
        submitEsign: function () {
            var self = this;
            //埋点 迁徙综合授权页 同意
            C.Native.TDOnEvent({
                eventId: '$_03_1_0_57_02_无欠款迁徙授权页'
            });
            var isSigned = !$('#result')[0].value ? false : true;

            if (!isSigned) {
                C.Native.tip('请先签名');
                return;
            }
            //防止重复提交
            if(self.isRepeat){
                return;
            }
            self.isRepeat = true;
            //埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-030101-综合授权书',
                eventLable: 'iBT-03010102-同意'
            });
            //参数
            var params = {
                imgDenseStr: self.imgDenseStr, //native返回
                imgBytes: self.imgBytes, //native返回
                loanCompanyCode: self.loanCompanyCode, //小贷编码
                platform: App.IS_IOS ? 'IOS' : 'A',
                businessNo: self.barCode //native返回
            };
            params.ocrKey = self.online_OcrKey; //在线开关文件
            params.ocrNeed = self.online_OcrNeed; //在线开关文件
            params.isDomesticAlgorithm = self.online_domesticAlgorithm; //在线开关文件
            params.ratio = self.ratio;  //银行放款比例
            params.isSign = self.isSign || ''; 
            params.applyNo = self.applyNo; //申请号
            params.productId = self.productId;
            params.signCode = self.signCode || '';  //传给SS，用于标识是否需要调用银行变更接口
            params.bankName = self.bankName || ''; //新银行名称
            params.bankCode = self.bankCode || ''; //新银行编码
            params.fundingModel = self.fundingModel;
            params.payApplyNo = C.Utils.data(C.Constant.DataKey.BT_ILOAN_PAYAPPLYNO); //支用申请号
            params.isMigrate = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA).isMigrate || '';

            C.UI.loading();
            $.ajax({
                url: C.Api('BT_UPLOADPOSELECTRONICSIGNATURE'), //调用原有BT授信接口
                type: 'POST',
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function (res) {
                    var data = res.data;
                    if (res && res.flag && res.flag == '1') {
                        if (data.resultCode && data.resultCode != '1') {
                            //埋点 迁徙综合授权页 签名失败
                            C.Native.TDOnEvent({
                                eventId: '$_03_2_0_57_02_无欠款迁徙授权页'
                            });
                            C.Native.tip(data.resultMsg || '网络错误，请稍后重试');
                            return;
                        }
                        //埋点 迁徙综合授权页 签名成功
                        C.Native.TDOnEvent({
                            eventId: '$_03_2_0_57_01_无欠款迁徙授权页'
                        });
                        if (self.productId == '0201' || self.productId == '0101') {
                            C.Native.loadPage({
                                url: 'loan_apply.html'
                            });
                        } else if (self.fromPage == 'loan_select' && self.productId == '0202') {
                            //首贷还卡跳转小车轮循
                            C.Native.loadPage({
                                url: 'icard_loading.html'
                            });
                        } else {
                            C.Native.loadPage({
                                url: 'icard_pinned.html'
                            });
                        }
                    }
                },
                complete: function () {
                    C.UI.stopLoading();
                    self.isRepeat = false;
                }
            });
        }

    }));
    (function () {
        new Page({
            el: $('body')[0]
        });
    })();
});
