
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        /****指定根元素****/
        el: 'body',
        initialize: function() {
            var $this = this,
                paramer = C.Utils.getQueryMap().from, //当值为'pinned'时执行试算计划；值为'detail'时执行所有计划
                data = C.Utils.data(C.Constant.DataKey.BT_REPAYMENT);
            data.fundingModel = C.Utils.getQueryMap().fundingModel;
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.REPAYMENTPLAY,
                isBack: 1,
                leftCallback: function() {
                    C.Native.back();
                }
            });
            // 计算还款计划列表中还款金额的宽度百分比,最大100%,最小50%
            $this.addListWidth(data.planList, 100, 50);
            if(paramer && paramer == 'pinned'){
                data.paramer = 'pinned';//试算计划标记
            }
            if(paramer && (paramer == 'detail' || paramer == 'repayment')){
                data.paramer = 'common';//详情计划 所有计划标记
                if(!data.rpyDay){
                    data.rpyDay = (String(data.rpyDate).substring(String(data.rpyDate).lastIndexOf('-')+1)).split('');
                    data.rpyDay[0] == '0' ? data.rpyDay = data.rpyDay[1] : data.rpyDay = String(data.rpyDay[0]) + String(data.rpyDay[1]);
                    data.isRpyDay = true;
                }
                if(!data.rpyTotalAmt && !data.rpyBankName){
                    data.rpyTotalAmt = data.notPayAmt;
                    data.rpyBankName = data.bankCardName;
                }else if(data.remainAmt && data.interestFee){
                    data.rpyTotalAmt = $this.rMoney(data.remainAmt) + $this.rMoney(data.interestFee+'');
                }
            }
            //渲染页面数据
            $('#js-wrap-plan').html(_.template($('#js-html-plan').html(), data));
        },
        rMoney: function(s){ 
            return parseFloat(s.replace(/[^\d.-]/g, '')); 
        }, 
        addListWidth: function(lists, max, min) {
            var maxAmt = _.max(lists, function(list) {
                    return parseFloat(list.rpyAmt);
                }).rpyAmt,
                minAmt = _.min(lists, function(list) {
                    return parseFloat(list.rpyAmt);
                }).rpyAmt;
            _.map(lists, function(element) {
                if (maxAmt - minAmt > 0) {
                    element.percent = (min + (element.rpyAmt - minAmt) * (max - min) / (maxAmt - minAmt)).toFixed(2);
                } else {
                    element.percent = max;
                }
            });
        }
    }));
    $(function() {
        new Page();
    });
});