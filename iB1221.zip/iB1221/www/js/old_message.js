define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {},
        initialize: function () {
            var self = this;
            // 设置标题
            C.Native.setHeader({
                title: '消息',
                leftCallback: function () {
                    C.Native.back({
                        data: {
                            'fromPage': 'Msg',
                            msgRead: 'Y'
                        }
                    });
                },
                data: {
                    'msgCount': '0'
                }
            });
            self.init();
            self.bind();
        },
        requestData: function (json) {
            C.UI.loading();
            $.ajax({
                type: json.type,
                url: json.url,
                data: json.data,
                success: function (data) {
                    if (data.flag == C.Flag.SUCCESS && data.data) {
                        json.successCall(data);
                    }
                    C.UI.stopLoading();
                },
                complete: function (data) {
                    json.completeCall();
                    C.UI.stopLoading();
                }
            });
        },
        pageInit: function () {
            var self = this;
            self.drawOrder = C.Utils.data('SUMMARY_INFO');
            var json = {
                url: C.Api('getMessage'),
                type: 'post',
                data: {
                    queryDate: '0',
                    count: '0'
                }
            };
            var successCall = function (data) {
                self.render(data);
                self.init();
                self.bind();

            };
            var completeCall = function () {
                // console.log()
            };

            json.successCall = successCall;
            json.completeCall = completeCall;
//			this.requestData(json);
        },
        render: function (data) {
            var self = this;
//			var data = C.Utils.data(C.Constant.DataKey.MSG_LIST);
            self.idSeqNo = '';
            var messageList = [];
            messageList = data.msgInfo;
            self.queryDate = data.msgInfo[0].queryDate;
            //渲染卡列表
            var html = '';
            for (var item in messageList) {
                var itemMessage = messageList[item];
               // var accountTypeName = messageList[item].accountTypeName;
                var status = messageList[item].status;
               // var bindType = messageList[item].bindType;
                if (status === '0') {
                    html += '<li class="focus" data-idSeqNo=' + itemMessage.idSeqNo + ' ><div class="title"><span class="time">' + itemMessage.msgDate + '</span>消息提醒</div><div class="con"> ' + itemMessage.msgInfo + '</div></li>';
                    self.idSeqNo = self.idSeqNo + itemMessage.idSeqNo + '|';
                    console.log(self.idSeqNo);
                } else if (status != '0') {
                    html += '<li data-idSeqNo=' + itemMessage.idSeqNo + '><div class="title"><span class="time">' + itemMessage.msgDate + '</span>消息提醒</div><div class="con"> ' + itemMessage.msgInfo + '</div></li>';
                }
            }
            $('.message-list').html(html);
            self.messageLength = $('.message-list li').length;
            self.pagingSubmitted();
        },
        init: function () {
            var self = this;
            var count = 0;
            var query = 0;
            var json = {
                url: C.Api('getMessage'),
                data: {
                    count: count,
                    queryDate: query
                },
                type: 'post'
            };
            var successCall = function (data) {
                var messageList = data.data;
                if (data.flag === '1') {
                    self.render(messageList);
                } else if (data.flag === '4') {
                    C.Native.tip(data.msg);
                } else {
                    C.Native.tip(data.msg);
                }
            };
            var completeCall = function () {
                // console.log()
            };

            json.successCall = successCall;
            json.completeCall = completeCall;
            this.requestData(json);

        },
        /*
         * 消息列表下拉查询
         */
        pagingQuerying: function () {
            var self = this;
            var count = $('.message-list li').length;
            var query = self.queryDate.substring(0, 10);
            var json = {
                url: C.Api('getMessage'),
                data: {
                    count: count,
                    queryDate: query
                },
                type: 'post'
            };
            var successCall = function (data) {
                var messageList = data.data.msgInfo;
                if (data.flag === '1') {
                    for (var item in messageList) {
                        var itemMessage = messageList[item];
                      //  var accountTypeName = messageList[item].accountTypeName;
                      //  var status = messageList[item].status;
                       // var bindType = messageList[item].bindType;
                        $('.message-list').append('<li data-idSeqNo=' + itemMessage.idSeqNo + '><div class="title"><span class="time">' + itemMessage.msgDate + '</span>消息提醒</div><div class="con"> ' + itemMessage.msgInfo + '</div></li>');
                    }
                } else if (data.flag === '4') {
                    C.Native.tip(data.msg);
                } else {
                    C.Native.tip(data.msg);
                }

            };
            var completeCall = function () {
                // console.log()
            };

            json.successCall = successCall;
            json.completeCall = completeCall;
            this.requestData(json);
        },
        refreshRender: function (data) {
            var self = this;
            self.idSeqNo = '';
            var messageList = [];
            messageList = data.msgInfo;
            //渲染卡列表

            for (var item in messageList) {
                var itemMessage = messageList[item];
                $('.message-list').append('<li data-idSeqNo=' + itemMessage.idSeqNo + ' ><div class="title"><span class="time">' + itemMessage.msgDate + '</span>贷款还款提醒</div><div class="con"> ' + itemMessage.msgInfo + '</div></li>');
            }
            self.messageLength = $('.message-list li').length;
        },
        /*
         * 消息阅读提交
         */
        pagingSubmitted: function () {
            var self = this;
            var idSeqNo = self.idSeqNo.substring(0, self.idSeqNo.length - 1);
            var json = {
                url: C.Api('updateMessageStatus'),
                data: {
                    idSeqNo: idSeqNo
                },
                type: 'post'
            };
            var successCall = function (data) {
                if (data.flag === '2') {
                    C.Native.tip(data.msg);
                }

            };
            var completeCall = function () {
               // console.log()
            };

            json.successCall = successCall;
            json.completeCall = completeCall;
            this.requestData(json);
        },
        bind: function () {
            var self = this;
            $(window).scroll(function () {
                console.log('滚动条到顶部的垂直高度: ' + $(document).scrollTop());
                console.log('页面的文档高度 ：' + $(document).height());
                console.log('浏览器的高度：' + $(window).height());
                self.load();
            });
        },
        load: function () {
            var self = this;
            var totalheight = 0;
            totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
            if ($(document).height() <= totalheight) {

                self.pagingQuerying();
            }
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    });
});