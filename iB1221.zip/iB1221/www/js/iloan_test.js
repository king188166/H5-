define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap .testForward': 'forward',
            'tap .testForward2': 'forwardMoudle'
        },
        initialize: function() {
            var self = this;
            //设置标题
            var title = '测试页';
            C.Native.setHeader({
                title: title,
                leftCallback: function() {
                    C.Native.back({});
                }
            });
            C.Native.getUserInfo(function(data) {
                self.userdata = data;
                C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO, data);
            });
            C.UI.stopLoading();
        },
        forwardText: function() {
            
            C.Native.forward({
                url: 'onlineTalking1.html'
            });
        },
        forward: function( e ) {

            var etarget = $(e.target).attr('data');

            this.allForward(etarget+'.html');
        },
        forwardMoudle: function( e ) {

            var etarget = $(e.target).attr('data');

            this.allForward(etarget+'.html', 'iloan');
        },
        allForward: function( url, mid ){
            var self = this;
            var len = arguments.length;
            var urlHref = window.location.href;
            var url1 = urlHref.replace(/\/([a-zA-Z0-9_-]+\.html)/, '/'+url);
            url1 = self.addParams( url1, {'ssEnv': 'STG20'}, true);
            var appPlatform = this.appPlatform();
            if (len == 1 ){
                alert(url1);
                if(appPlatform.IS_ANDROID){
                    window.location.href = 'payidai://paem.com?url='+url1;
                }else{
                    window.location.href = 'PAYiDai://?PA_URL='+url1;
                }
            }else{
                if(appPlatform.IS_ANDROID){
                    window.location.href = 'payidai://paem.com?mid='+mid+'&url='+url;
                }else{
                    window.location.href = 'PAYiDai://?ModuldName='+mid+'&FileName='+url;
                }
            }
        },
        appPlatform: function(){
            var ua = navigator.userAgent.toUpperCase();
            var platform = {};

            // 当前环境是否为Android平台
            platform.IS_ANDROID = ua.indexOf('ANDROID') != -1;
            // 当前环境是否为IOS平台
            platform.IS_IOS = ua.indexOf('IPHONE OS') != -1;

            return platform;
        },
        addParams: function(url, param, replace){
            var a=document.createElement('a');
            a.href=url;
            var search=a.search.replace(/^\?+/, '');
            search=search ? search.split('&') : [];
            //合并参数
            for(var i=0, len=search.length;i<len;i++){
                var p=search[i].split('='), p0=p[0], p1=typeof p[1]=='undefined'? '' : p[1], t=typeof param[p0]!='undefined';
                if(t&&replace){
                    continue;
                }
                if(t){
                    if(Array.isArray(param[p0])){
                        param[p0].unshift(p1);
                    }else{
                        param[p0]=[p1, param[p0]];
                    }
                }else{
                    param[p0]=p1;
                }
            }   
            //拼接参数
            var s=[];
            for(var q in param){
                var v=param[q];
                if(Array.isArray(v)){
                    for(var d=0, lens=v.length;d<lens;d++){
                        s.push(q+'='+v[d]);
                    }
                }else{
                    s.push(q+'='+v);
                }
            }
            a.search=s.join('&');
            //返回
            return a.href;
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});