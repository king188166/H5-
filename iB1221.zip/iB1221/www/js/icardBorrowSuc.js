/**
 * @author: xuke163@pingan.com.cn
 * @date  : 2016-10-18
 * @describe: 申请成功
 */
 define(['zepto', 'C', 'view'], function ($, C, View) {
    // body...
     'use strict';
     var Page = View.extend({
         events: {
             'tap #js-btn': 'knowBtn',
             'tap #js-tip': 'toggleTip',
             'tap .ios7CBox': 'switchRemind',
             'tap #js-option': 'selectDate',
             'tap #js-close': 'hideSelect',
             'tap .js-date': 'selectDay',
             'tap #js-myiloan': 'goILoan',
             'tap #js-pay': 'continuePay',
             'tap p.link-udr': 'goPayIntro'
         },
         talkingDate: function(key) {
             var first = {
                 '确认借款': {
                     eventId: 'iBT-0303010102-确认借款',
                     eventLable: 'iBT-030301010201-还款警示'
                 },
                 '还款提醒': {
                     eventId: 'iBT-0303010102010101-借款成功',
                     eventLable: 'iBT-030301010201010101-还款提醒'
                 },
                 '我的i贷': {
                     eventId: 'iBT-0303010102010101-借款成功',
                     eventLable: 'iBT-030301010201010102-我的i贷'
                 },
                 '继续还卡': {
                     eventId: 'iBT-0303010102010101-借款成功',
                     eventLable: 'iBT-030301010201010103-继续还卡'
                 },
                 '借款成功页': {
                     eventId: '$_03_0_4_29_借款成功页'
                 },
                 '还款提醒2.0': {
                     eventId: '$_03_1_4_29_03_借款成功页'
                 },
                 '我的i贷2.0': {
                     eventId: '$_03_1_4_29_01_借款成功页'
                 },
                 '继续还卡2.0': {
                     eventId: '$_03_1_4_29_02_借款成功页'
                 }
             };
             var noFirst = {
                 '确认借款': {
                     eventId: 'iBT-0605020101-确认借款',
                     eventLable: 'iBT-060502010101-成功'
                 },
                 '还款提醒': {
                     eventId: 'iBT-060502010101-成功',
                     eventLable: 'iBT-06050201010101-还款提醒'
                 },
                 '我的i贷': {
                     eventId: 'iBT-060502010101-成功',
                     eventLable: 'iBT-06050201010102-我的i贷'
                 },
                 '继续还卡': {
                     eventId: 'iBT-060502010101-成功',
                     eventLable: 'iBT-06050201010103-继续还卡'
                 },
                 '借款成功页': {
                     eventId: '$_03_0_4_54_还卡再贷成功页'
                 },
                 '还款提醒2.0': {
                     eventId: '$_03_1_4_54_02_还卡再贷成功页'
                 },
                 '我的i贷2.0': {
                     eventId: '$_03_1_4_54_01_还卡再贷成功页'
                 },
                 '继续还卡2.0': {
                     eventId: '$_03_1_4_54_03_还卡再贷成功页'
                 }
             };
             return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
         },
         //初始化
         initialize: function(){
             var self = this;
             //设置头部
             C.Native.setHeader({
                 title: C.Constant.Enum.TITLE.BORROWSUC,
                 isBack: false,
                 leftCallback: function () {
                     return this;
                 } 
             });
             //清空迁徙数据
             C.Utils.data(C.Constant.DataKey.MIGRATE_DATA, null);

             var arr=[
                 C.Constant.DataKey.BT_SIGNCONTRACT, //SDK中使用的SignContract_data
                 C.Constant.DataKey.USER_LOGIN_INFO,
                 C.Constant.DataKey.BT_BORROW_DATA
             ];
             
             var param = self.concatLocalData(arr);
            
             this.isFirstPay = param.isFirstPay;
             this.accountId = param.accountId;
             this.remindSwitch = param.remindSwitch;
             this.remindDay = param.remindDay;
             this.applyNo = param.applyNo;

             C.Native.TDOnEvent(this.talkingDate('确认借款'));
             // 新埋点 借款成功页
             C.Native.TDOnEvent(this.talkingDate('借款成功页'));
             self.render(param);
             C.UI.stopLoading();	
         },
         concatLocalData: function(arr){
             var obj={};
             for(var i = 0; i<arr.length; i++){
                 var arrData = C.Utils.data(arr[i]).data || C.Utils.data(arr[i]);
                 if(_.isObject(arrData)){
                     obj = _.extend(obj, arrData);
                 }
             }
             //返回obj，其他地方用
             return obj;
         },
         render: function(data){
             $('#js-warp-suc').html(_.template($('#js-html-suc').html(), data));
             if(this.remindSwitch == 'Y'){
                 $('.ios7CBox').addClass('checked').attr('checked', true).parents('li').next().removeClass('dn');				
             }
             $('#js-option').prepend(!this.remindDay ? '请选择' : ('每月' + parseInt(this.remindDay) + '日')); //"" "27"  TODO
             if(data.remainAmt > 0){
                 $('#js-remainAmt').html(data.remainAmt).parents('p').removeClass('dn');
                 $('.btn-full').removeClass('dn');
             }
             $('#rpyDay').text('每月'+parseInt(data.rpyDay)+'日');
             $('#debitCard').text(data.rpyBnakName);
         },
         //关闭借款友情提示
         knowBtn: function(){
             C.Native.TDOnEvent({
                 eventId: 'iBT-030301010201-还款警示',
                 eventLable: 'iBT-03030101020101-我知道了'
             });
             //埋点 还款警示页 
             C.Native.TDOnEvent({
                 eventId: '$_03_0_4_28_还款警示页'
             }); 
             $('#js-leayer').addClass('dn');
             C.Native.TDOnEvent({
                 eventId: 'iBT-03030101020101-我知道了',
                 eventLable: 'iBT-0303010102010101-借款成功'
             });
             //埋点 还款警示页 我知道了
             C.Native.TDOnEvent({
                 eventId: '$_03_1_4_28_01_还款警示页'
             }); 
         },
         //展示设置还款日期的提示框
         toggleTip: function(){
             $('.tooltip').toggleClass('dn');
         },
         /**
         *选择是否展示时间选择
         */
         switchRemind: function(e){	
             C.Native.TDOnEvent(this.talkingDate('还款提醒'));
             // 新埋点 借款成功页 还款提醒
             C.Native.TDOnEvent(this.talkingDate('还款提醒2.0'));		
             if(this.remindSwitch == 'Y'){
                 this.remindSwitch = 'N';
                 $('.ios7CBox').removeClass('checked').removeAttr('checked').parents('li').next().addClass('dn');                
             }else{
                 this.remindSwitch = 'Y';
                 $('.ios7CBox').addClass('checked').attr('checked', true).parents('li').next().removeClass('dn');
             }	
             if($('#js-option').text() =='请选择'){
                 return;
             }
             var data = {
                 remindSwitch: this.remindSwitch,
                 remindDay: (parseInt(this.remindDay) < 10 ? ['0', parseInt(this.remindDay)].join('') : this.remindDay),
                 accountId: this.accountId
             };
             this.dataRequest({
                 url: C.Api('SETGIVEBACKDATE'),
                 type: 'POST',
                 data: data,
                 callback: function(){
                    // empty
                 }
             });		
         },
         selectDate: function(){
             if(!$('#js-leayer-select ul').attr('enable')){
                 $('#js-leayer-select ul').html(_.template($('#js-html-date').html())).attr('enable', 'true');
             }
             $('#js-leayer-select').removeClass('dn');
         },
         hideSelect: function(){
             $('#js-leayer-select').addClass('dn');
         },

         selectDay: function(e){
        //debugger;
        //var self = this;
        //self.selectDate=;
             var selectDate = e.currentTarget.innerText;
             $('#js-option').html('每月' + selectDate + '<span class="icon-sm icon-arrow"></span>');
             $('#js-leayer-select').addClass('dn');
             C.Native.TDOnEvent(this.talkingDate('还款提醒'));
             //新埋点 借款成功页 还款提醒
             C.Native.TDOnEvent(this.talkingDate('还款提醒2.0'));
            
             this.remindDay = parseInt(selectDate);
            //C.Utils.data(C.Constant.DataKey.LOAN_APPLY_AMOUNT,{selectDate:selectDate});//将当前的只保存起来，注意要键值对
             var data = {
                 remindSwitch: this.remindSwitch,
                 remindDay: (parseInt(this.remindDay) < 10 ? ['0', parseInt(this.remindDay)].join('') : this.remindDay),   
                 accountId: this.accountId
             };
             this.dataRequest({
                 url: C.Api('SETGIVEBACKDATE'),
                 type: 'POST',
                 data: data,
                 callback: function(){
                    // empty
                 }
             });
         },
         /**
         * 点击我的i贷 跳转
         */
         goILoan: function(){
             C.Native.TDOnEvent(this.talkingDate('我的i贷'));
             //新埋点 借款成功页 我的i贷
             C.Native.TDOnEvent(this.talkingDate('我的i贷2.0'));
             C.Native.loadPage({
                 title: C.Constant.Enum.TITLE.ACCOUNTILOAN,
                 url: [C.Constant.DataUrl.TRANSPAGE.ACCOUNTILOAN].join('/')
             });
         },
         /**
         * 点击继续还款 跳转
         */
         continuePay: function(){
             var self = this;
             var sourceInfo = C.Utils.data(C.Constant.DataKey.USER_SOURCE_INFO);
             self.thirdChannel = sourceInfo ? sourceInfo.source : '';
             self.channelType = sourceInfo ? sourceInfo.sourceType : '';
             this.dataRequest({
                 url: C.Api('CHOOSEPRODECT'),
                 type: 'POST',
                 data: {
                     accountId: self.accountId,
                     applyNo: self.applyNo,
                     thirdChannel: self.thirdChannel,
                     channelType: self.channelType 
                 },
                 callback: function(data){
                     C.Native.TDOnEvent(this.talkingDate('继续还卡'));
                     //新埋点 借款成功页 继续还卡
                     C.Native.TDOnEvent(this.talkingDate('继续还卡2.0'));

                     C.Utils.data('BT_ILOAN_PAYAPPLYNO', data.payApplyNo, 0);
                     C.Native.loadPage({
                         title: C.Constant.Enum.TITLE.CREDITLIST,
                         url: [C.Constant.DataUrl.TRANSPAGE.CREDITLIST].join('/'),
                         data: {
                             form: 'icardPinned.html',
                             loanBindNo: C.Utils.data(C.Constant.DataKey.BT_BORROW_DATA).loanBindNo,
                             success: 1
                         }
                     });
                 }
             });
         },
         goPayIntro: function(){
             //埋点 借款成功页 按钮 查看还款指引
             C.Native.TDOnEvent({
                 eventId: '$_03_1_4_29_04_借款成功页'
             });
             C.Native.forward({
                 url: [C.Constant.DataUrl.TRANSPAGE.INTRO].join('/')
             });

         },
         dataRequest: function(json) {
             C.UI.loading();
             var self = this;
             $.ajax({
                 url: json.url,
                 type: json.type,
                 data: json.data,
                 success: function(res) {
                     if (res && res.flag == C.Flag.SUCCESS) {
                         json.callback.call(self, res.data);
                     }
                 },
                 complete: function() {
                     C.UI.stopLoading();
                 }
             });
         }
     });
     $(function() {
         new Page({
             el: $('body')[0]
         });
     });
 });