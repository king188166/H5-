/**
 * @author: yerencheng501@pingan.com.cn
 * @date  : 2016-3-16
 * @describe: 申请失败
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        events: {
            'tap #js-btn-fail': 'goAccount'
        },
        talkingDate: function(key){
            var first= {
                '提现失败页': {
                    eventId: '$_03_0_4_37_提现失败页'
                },
                '失败页确定': {
                    eventId: '$_03_1_4_37_01_提现失败页'
                }
            };
            var noFirst = {
                '提现失败页': {
                    eventId: '$_03_0_4_51_提现再贷失败页'
                },
                '失败页确定': {
                    eventId: '$_03_1_4_51_01_提现再贷失败页'
                }
            };
            return this.isFirstPay == 'Y'? first[key] : noFirst[key];
        },
        initialize: function() {
            C.Native.setHeader({
                title: '申请失败',
                isBack: false,
                leftCallback: function(){
                    return this;
                }
            });
            this.isFirstPay = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO).isFirstPay;
            //新埋点 提现失败页
            C.Native.TDOnEvent(this.talkingDate('提现失败页'));
        },
        goAccount: function(e) {
            // 获取迁徙存储数据
            var migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
            // 新埋点
            C.Native.TDOnEvent(this.talkingDate('失败页确定'));
            // 迁徙失败跳转至原渠道账户页
            if (migrateData && migrateData.fromPage && migrateData.fromPage === 'old_home') {
                // SDK1.0账户页
                C.Native.back({
                    url: 'old_home.html'
                });
                return;
            }
            if (migrateData && migrateData.fromPage && migrateData.fromPage === 'shaw_account') {
                // APP1.0账户页
                C.Native.backModule({
                    moduleName: 'iloan',
                    url: 'shaw_account.html'
                });
                return;
            }
            if (this.isFirstPay == 'Y') {
                if (C.Utils.getParameter('isSignSuccess') == '1') {
                    // 签约成功跳转到账户页
                    C.Native.loadPage({
                        url: 'account_iloan.html'
                    });
                } else {
                    C.Native.back({
                        url: 'loan_select.html'
                    });
                }
                // 埋点
                C.Native.TDOnEvent({
                    eventId: 'iBT-040101010202-借款失败',
                    eventLable: 'iBT-04010101020201-确定'
                });
            } else {
                C.Native.back({
                    url: 'account_iloan.html'
                });
                // 埋点
                C.Native.TDOnEvent({
                    eventId: 'iBT-06040101010102-失败',
                    eventLable: 'iBT-0604010101010201-确定'
                });
            }
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});