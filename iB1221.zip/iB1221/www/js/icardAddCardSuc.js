/**
 * @author: EX-ZHANGKEMING001
 *
 * @describe:icardBT添加信用卡成功
 * @addCardSuc-bt
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #sure': 'sureFun'
        },
        initialize: function(){
            //设置头部
            C.Native.setHeader({
                title: C.Constant.Enum.TITLE.ADDCARDSUC,
                isBack: false,
                leftCallback: function(){
                    return this;
                }
            });
        },
        sureFun: function(){
            //设置埋点
            C.Native.TDOnEvent({
                eventId: 'iBT-0304010205-成功',
                eventLable: 'iBT-030401020501-确定'
            });
            //埋点 添加信用卡页 成功确定
            C.Native.TDOnEvent({
                eventId: '$_03_1_4_23_03_添加信用卡页'
            });
            //跳转 （SDK跳转用的参数from，以APP为准）
            if(C.Utils.getQueryMap().from == C.Constant.DataUrl.TRANSPAGE.PINNED){
                //用于还卡页面银行卡的重新渲染
                C.Native.back({
                    url: C.Constant.DataUrl.TRANSPAGE.PINNED,
                    data: {
                        success: C.Utils.getQueryMap().success,
                        loanBindNo: C.Utils.getQueryMap().loanBindNo,
                        cardName: C.Utils.getQueryMap().cardName
                    }              
                });
            }else{
                C.Native.loadPage({
                    url: C.Constant.DataUrl.TRANSPAGE.CREDITLIST,
                    data: {
                        success: C.Utils.getQueryMap().success,
                        loanBindNo: C.Utils.getQueryMap().loanBindNo
                    }              
                });  
            }
              
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});