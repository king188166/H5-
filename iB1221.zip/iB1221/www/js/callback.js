/**
 * Created by tusm on 17/3/9.
 */
define(['zepto', 'C', 'view', 'js/refresh'], function ($, C, View, RE) {
    'use strict';
    //初始化
    var init = function () {
        var userInfo = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO),
            queryResult = C.Utils.data(C.Constant.DataKey.BT_ILOAN_QUAS_RESULT),
            time = C.Utils.parseDateFormat(new Date(), 'yyyy年MM月dd日 hh时mm分ss秒'),
            node_name = '',
            backDate = null;

        if (userInfo && queryResult) {
            switch (queryResult.subProcessCode) {
                case 'AU':
                    node_name = '已注册';
                    break;
                case 'AM':
                case 'AF':
                case 'AY':
                case 'AC':
                    node_name = '已申请';
                    break;
                case 'AP':
                    node_name = '已出额';
                    break;
                case 'RP':
                    node_name = '已签约';
                    break;
            }

            backDate = {
                'flag': queryResult.resultCode,
                'msg': queryResult.resultMsg,
                'id': {
                    'accountId': userInfo.accountId,
                    'accountKey': userInfo.accountKey || null
                },
                'node_name': node_name,
                'time': time
            };

            C.Native.back({
                data: {
                    'exitSDK': 1,
                    'onCloseSDKCallback': backDate
                }
            });
        } else {
            C.Native.back();
        }
    };
    return {
        init: init
    };
});