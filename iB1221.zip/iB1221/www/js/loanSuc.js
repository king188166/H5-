/**
 * @author: yerencheng501@pingan.com.cn
 * @date  : 2016-3-16
 * @describe: 申请成功
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        events: {
            'tap #js-btn-result': 'hideRisk',
            'tap #js-btn-suc': 'goAccount',
            'tap #js-btn-tip': 'goIntro'
        },
        talkingDate: function(key) {
            var first = {
                '我知道了': {
                    eventId: 'iBT-040101010201-还款警示',
                    eventLable: 'iBT-04010101020101-我知道了'
                },
                '借款成功': {
                    eventId: 'iBT-04010101020101-我知道了',
                    eventLable: 'iBT-0401010102010101-借款成功'
                },
                '确定成功': {
                    eventId: 'iBT-0401010102010101-借款成功',
                    eventLable: 'iBT-040101010201010101-确定'
                },
                '提现成功页': {
                    eventId: '$_03_0_4_36_提现成功页'
                },
                '提现确定': {
                    eventId: '$_03_1_4_36_01_提现成功页'
                },
                '还款警示页': {
                    eventId: '$_03_0_4_28_还款警示页'
                },
                '我知道了2.0': {
                    eventId: '$_03_1_4_28_02_还款警示页'
                }
            };
            var noFirst = {
                '我知道了': {
                    eventId: 'iBT-06040101010101-还款警示',
                    eventLable: 'iBT-0604010101010101-我知道了'
                },
                '借款成功': {
                    eventId: 'iBT-0604010101010101-我知道了',
                    eventLable: 'iBT-060401010101010101-借款成功'
                },
                '确定成功': {
                    eventId: 'iBT-060401010101010101-借款成功',
                    eventLable: 'iBT-06040101010101010101-确定'
                },
                '提现成功页': {
                    eventId: '$_03_0_4_50_提现再贷成功页'
                },
                '提现确定': {
                    eventId: '$_03_1_4_50_01_提现再贷成功页'
                },
                '还款警示页': {
                    eventId: '$_03_0_4_49_再贷还款警示页'
                },
                '我知道了2.0': {
                    eventId: '$_03_1_4_49_01_再贷还款警示页'
                }
            };
            return this.isFirstPay == 'Y' ? first[key] : noFirst[key];
        },
        initialize: function() {
            C.Native.setHeader({
                title: '申请成功',
                isBack: false,
                leftCallback: function(){
                    return this;
                }
            });
            this.isFirstPay = C.Utils.data(C.Constant.DataKey.LOAN_APPLY_INFO).isFirstPay;
            var arr = [
                C.Constant.DataKey.LOAN_APPLY_INFO,
                C.Constant.DataKey.LOAN_APPLY_AMOUNT
            ];
            // 埋点 提现（再贷）成功页
            C.Native.TDOnEvent(this.talkingDate('提现成功页'));
            this.render(this.concatLocalData(arr));
        },
        // 初始页面渲染
        render: function(data) {
            $('#js-wrap-result').html(_.template($('#js-html-result').html(), data));
            $('#js-wrap-tip').html(_.template($('#js-html-tip').html(), data));
            // 埋点
            C.Native.TDOnEvent(this.talkingDate('我知道了'));
        },
        // 拼接本地数据
        concatLocalData: function(arr) {
            var obj = {};
            for (var i = 0; i < arr.length; i++) {
                var sources = C.Utils.data(arr[i]);
                if (_.isObject(sources)) {
                    obj = _.extend(obj, sources);
                }
            }
            return obj;
        },
        // 还款警示 点击我知道了
        hideRisk: function(e) {
            // 埋点 还款警示页 按照还卡的埋点位置埋
            C.Native.TDOnEvent(this.talkingDate('还款警示页'));
            $('#js-block-risk').hide();
            // 埋点
            C.Native.TDOnEvent(this.talkingDate('借款成功'));
            // 埋点 我知道了
            C.Native.TDOnEvent(this.talkingDate('我知道了2.0'));
        },
        // 跳转账户页
        goAccount: function(e) {
            // 获取迁徙存储数据
            var migrateData = C.Utils.data(C.Constant.DataKey.MIGRATE_DATA) || {};
            // 埋点
            C.Native.TDOnEvent(this.talkingDate('确定成功'));
            // 埋点 提现确定
            C.Native.TDOnEvent(this.talkingDate('提现确定'));

            if (this.isFirstPay == 'Y' || (migrateData && migrateData.fromPage && (migrateData.fromPage === 'old_home' || migrateData.fromPage === 'shaw_account'))) {
                // 首贷新开账户页面 SDK1.0以及定期APP迁徙成功后跳转至再贷账户页
                C.Native.loadPage({
                    url: 'account_iloan.html'
                });
            } else {
                // 再贷返回账户页面
                C.Native.back({
                    url: 'account_iloan.html'
                });
            }
        },
        //还款指引
        goIntro: function(){
            C.Native.forward({
                url: 'intro.html'
            });
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});