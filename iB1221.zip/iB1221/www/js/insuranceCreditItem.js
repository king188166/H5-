/**
 * @author: EX-ZHANGKEMING001@pingan.com.cn
 * @date  : 2016-11-14
 * @describe: 信用信息查询及使用授权书(CGI模式下)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            C.Native.setHeader({
                title: '信用信息查询及使用授权书',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
          
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});