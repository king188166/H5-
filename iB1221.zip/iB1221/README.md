ZURK framework
================

A quick demo of using zepto underscore knockout require