var gulp = require('gulp');
var gutil = require('gulp-util'); 
var chalk = require('chalk');
var fs=require('fs');
var _=require('underscore');
var path = require('path');
var amdOptimize = require('amd-optimize');
var concat = require('gulp-concat');
var rimraf = require('gulp-rimraf');
var uglify = require('gulp-uglify');
var through2 = require('through2');
var ejs = require('gulp-ejs');
var less = require('gulp-less');
var minifyCSS = require('gulp-minify-css');
var runSequence = require('run-sequence');
// var imagemin = require('gulp-imagemin');
var zip = require('gulp-zip');
var eslint = require('gulp-eslint');
var replace = require('gulp-replace');
var concat = require('gulp-concat');

var pkg = require('./package.json');
var BUILD_TIMESTAMP = gutil.date(new Date(), 'yyyymmddHHMMss');
pkg.build = BUILD_TIMESTAMP;

// 设置默认工作目录为./www
process.chdir('www');

// 获取env
var argv = process.argv.slice(2);
var isBetaVersion = false;  //灰度标示
var env = 'DEVELOPMENT';
(function(){
    console.log(argv);
    if(argv.indexOf('-env')!=-1 || argv.indexOf('-e')!=-1){
        var envIndex = Math.max(argv.indexOf('-env'), argv.indexOf('-e'));
        var envValue = argv[envIndex+1];
        var envs = ['DEVELOPMENT', 'STG1', 'STG2', 'STG3', 'PRODUCTION'];
        if (envValue == 'PRODUCTION_BETA') {   //灰度环境 env设置为PRODUCTION
            env = 'PRODUCTION';
            isBetaVersion = true;
        } else if (envValue && envs.indexOf(envValue) != -1) {
            env = envValue;
        }
    }
})();

var CONTEXT_PATH = '';
if(env != 'DEVELOPMENT'){
    CONTEXT_PATH = '';
    console.log(CONTEXT_PATH);
}

gutil.log(
      'Working directory :',
      chalk.magenta(__dirname + '/www')
);

var paths = {
    src: '.',
    dest: '../dist',
    output: '../output',
    templates: '../templates',
    lintDir: '../report/lint'
};

var handleEnv = function () {
    return through2.obj(function(file, enc, cb) {
            // console.log(file.path);
            // 替换环境配置
        // if(file.path.indexOf('env.js')!=-1){
        //     file.contents = new Buffer(file.contents.toString().replace('DEVELOPMENT', env));
        // }
        // 灰度环境替换地址
        // if(isBetaVersion && (file.path.indexOf('constant.js')!=-1 || file.path.indexOf('api.js')!=-1)) {
        //     file.contents = new Buffer(file.contents.toString().replace(/puhui-web.pingan.com.cn\/manager\/prd\/paem\//g, 'puhui-web.pingan.com.cn/manager/prd/paem_beta/'));
        // }
        return cb(null, file);
    });
};

/*
* 页面速度检测工具
*/
var t = argv[4] || "TEST";
paths["speedSrt"] ="../../ph-speed";

//rm 目录
gulp.task('rmSpeed', function() {
    return  gulp.src([paths.src + '/js/speed/'], {read: false})
                .pipe(rimraf({force: true}))

});

//rm footejs
gulp.task('rmfootejs', function() {
    return  gulp.src(paths.src+"/../templates/include/_footer.ejs")
                .pipe(replace(/<!-- speedStart -->(.|\n)*<!-- speedEnd -->\n?/g,""))
                .pipe(gulp.dest(paths.src+"/../templates/include/"))
});

// 检查工具代码目录
gulp.task('checkSpeedTool', ['rmSpeed', "rmfootejs"], function() {
    if(t == "P"){
        console.log("当前参数为P,拒绝打包速度工具");
        return false
    }
    console.log("当前运行参数",env);
    if(env == "DEVELOPMENT" || env == "TEST" || env == "STG1" || env == "STG2" || env == "STG3"){
        console.log("执行打包速度监控工具");
        console.log(paths.speedSrt+"www/js/**/*");
          fs.readFile(paths.speedSrt+"/init.ejs","utf-8", function(err, data){
            if(err){
                console.log("读取文件fail " + err);
            }else{
                // 读取成功时
                console.log("读取入口文件成功");
                gulp.src(paths.src+"/../templates/include/_footer.ejs")
                    .pipe(replace(/<!-- speed -->/g,data))
                    .pipe(gulp.dest(paths.src+"/../templates/include/"));
            }
        });
        gulp.src([
            paths.speedSrt+"/www/js/**/*"
        ])
            .pipe(gulp.dest(paths.src+"/js/speed/"));
    }else{
        console.log("当前参数为env为" + env + ",拒绝打包速度工具");
    }
});

/*
* 清空目标工程目录
*/
gulp.task('clean', function() {
    return gulp.src(paths.dest+'/*', { read: false })
    .pipe(rimraf({ force: true }));
});

/**
 * 清空dist目录不必要文件
 */
gulp.task('cleanDist', function() {
    return gulp.src([paths.dest+'/less', paths.dest+'/data', paths.dest+'/src'])
        .pipe(rimraf({ force: true}));
});

/*
* 拷贝文件到目标工程目录
*/
gulp.task('copy', function() {
    return gulp.src([
        paths.src+'/**/*',
        '!'+paths.src+'/data',
        '!'+paths.src+'/less'
    // ,
    // "!"+paths.src+"/web-server.js"
    ])
    .pipe(handleEnv())
    .pipe(gulp.dest(paths.dest));
});

/*
* 拷贝源文件文件到目标工程目录
*/
gulp.task('source', function() {_;
    return gulp.src(paths.src+'/js/**/*.js')
    .pipe(gulp.dest(paths.dest+'/src/js'));
});
/*
* 编译ejs页面
*/
gulp.task('ejs', function(){
    return gulp.src([paths.templates + '/**/*.ejs', '!' + paths.templates + '/include/**/*.ejs'])
    .pipe(ejs({
        ctx: CONTEXT_PATH,
        _build: {
            pkg: pkg,
            version: pkg.version,
            ts:BUILD_TIMESTAMP,
            env: env
        },
        data: {},
        delimiter: '@'
    }, {
        root: __dirname+'/templates'
    }))
    .pipe(gulp.dest('.', {cwd: paths.dest}));
});

/*
* 编译less
*/
gulp.task('less', function () {
    return gulp.src(paths.src+'/less/*.less')
    .pipe(less({
        paths: [ path.join(__dirname, 'less', 'includes') ]
    }))
    .pipe(minifyCSS())
    .pipe(gulp.dest(paths.src+'/css'));
});

/*
* 编译压缩css
*/
gulp.task('minifycss', function () {
    return gulp.src(paths.src+'/css/**/*.css')
    .pipe(minifyCSS())
    .pipe(gulp.dest(paths.dest+'/css'));
});

// /*
// * 图片压缩
// */
// gulp.task("imagemin",function(){
//  return gulp.src(paths.src+'/images/*')
//         .pipe(imagemin({
//             progressive: true,
//             optimizationLevel:3,
//             svgoPlugins: [{removeViewBox: false}]
//         }))
//         .pipe(gulp.dest(paths.dest+'/images'));
// })

/**
 * 生成代码检查报告目录
 **/
gulp.task('mklintdir', ["checkSpeedTool"], function() {
    var mkdirsSync = function(dirname) {
        if(fs.existsSync(dirname)) {
            return true;
        } 
        if(mkdirsSync(path.dirname(dirname))) {
            fs.mkdirSync(dirname);
            return true;
        }
        
    };
    mkdirsSync(paths.lintDir);
});

 /*
 ** 通过eslint检查代码格式
 **/
gulp.task('lint', ['mklintdir'], function() {
    var fileName = BUILD_TIMESTAMP + '.html';
    return gulp.src(['./js/**/*.js', '!./js/common/*.js', '!./js/**/old_personal-credit.js'])
             .pipe(eslint({configFle: __dirname+ '/.eslintrc'}))
                .pipe(eslint.format('html', fs.createWriteStream(path.join(paths.lintDir, fileName))))
                .pipe(eslint.format())
                .pipe(eslint.failAfterError());
});

/*
* 编译压缩js
*/
gulp.task('uglifyjs', function () {
    return gulp.src([
        paths.dest+'/js*/**/*.js',
        paths.dest+'/libs*/require-config.js'
    ])
    .pipe(handleEnv())
    .pipe(uglify({output: {max_line_len: 120}}).on('error', gutil.log))
    .pipe(gulp.dest(paths.dest));
});

/*
* require js 优化
*/
gulp.task('js_optimize', function() {

    // 优化common
    console.log('*************=======1====************');
    gulp.src(paths.src+'/js/**/*.js')
        .pipe(amdOptimize('C', {
            configFile: paths.src+'/libs/require-config.js',
            exclude: ['zepto', 'ko', 'underscore', 'swipe', 'fastclick', 'libs/jsencrypt']
        }))
        .pipe(handleEnv())
        // 合并
        .pipe(concat('common.js'))
        .pipe(uglify().on('error', gutil.log))
            // 输出
        .pipe(gulp.dest(paths.dest+'/js/common'));
    console.log('*************======2=====************');
    // 优化zepto
    gulp.src(paths.src+'/libs/**/*.js')
        .pipe(amdOptimize('zepto', {
            configFile: paths.src+'/libs/require-config.js'
        }))
            // 合并
        .pipe(concat('zepto.js'))
        .pipe(uglify().on('error', gutil.log))
            // 输出
        .pipe(gulp.dest(paths.dest+'/libs'));
});

/*
* 打包zip
*/
gulp.task('archive', function () {
    return gulp.src(paths.dest+'/**/*')
        .pipe(zip(pkg.name + '_v_' + pkg.version.replace(/\./g, '_') + '_' + env.toLowerCase() + '_'+BUILD_TIMESTAMP+'.zip'))
        .pipe(gulp.dest(paths.output));
});

/*
* 输出包名
*/
gulp.task('outputPkgName', ['archive'], function () {
    var output = pkg.name + '_v_' + pkg.version.replace(/\./g, '_') + '_' + env.toLowerCase() + '_'+BUILD_TIMESTAMP+'.zip';
    fs.writeFileSync('../upgrade/pkgName.txt', output, 'binary');
});

gulp.task('watch', function() {
    gulp.watch(paths.src+'/less/**/*.less', ['less']);
});

/*
* 用于jenkins自动构建打包
*/
gulp.task('auto-build', function (callback) {
    runSequence(
        'archive',
        'outputPkgName',
        function (error) {
            if (error) {
                console.log(error.message);
            } else {
                console.log('RELEASE FINISHED SUCCESSFULLY');
            }
            callback(error);
        });
});

/*
* 开始构建
*/
gulp.task('build', ['lint'], function (callback) {

    var args = [
        'clean',
        'copy',
        'ejs',
        'source',
        'js_optimize',
        'uglifyjs',
        'less',
        'minifycss',
        'cleanDist',
        'archive',
        'outputPkgName',
        function (error) {
            if (error) {
                console.log(error.message);
            } else {
                console.log('RELEASE FINISHED SUCCESSFULLY');
            }
            callback(error);
        }];
    console.log(env);
    //非生产包 去掉js压缩  方便调试
    if (env !== 'PRODUCTION') {
        args.splice(4, 2);
    }
    
    runSequence.apply(this, args);

});
