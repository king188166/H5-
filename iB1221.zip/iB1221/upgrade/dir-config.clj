; "目录配置及规则配置，如有疑问请联系liujun842"

; --------------------------------
; @author:	liujun842
; @mail:	liujun842@pingan.com.cn
; --------------------------------

(fn [env] 
{
	; 全量包需要的文件
	:all-file-regex [
		;项目dist目录所需文件正则，括号内为需要保留的目录结构
		#".+/dist/(.+\.html)$"  
		#".+/dist/(js/.+)$"	
		#".+/dist/(css/.+\.css)$" 
		#".+/dist/(images/.+)$" 
		#".+/dist/(libs/.+)$" 
		#".+/dist/(test/.+)$" 
	]
	:mapping [
		; 1全量文件名正则 2需要移动的条件 3移动目标路径
		[#".+/(.+)\.html" 
			["include/_header.ejs" "include/_footer.ejs" "templates/$1.ejs"] 
			"$1.html"]
		[#".+/images/(.+)" 
			["www/images/$1"] 
			"images/$1"]
		[#".+/libs/(.+)\.js" 			["www/libs/$1.js"]													"libs/$1.js"]
		[#".+/js/(.+)\.js" 
			["www/js/$1.js"] 
			"js/$1.js"]
		; 生产包时 common目录下的任意文件改动 都需要拷贝common.js
		[#".+/js/common/common\.js" 
			(if (= "PRODUCTION" env) [#"www/js/common/.+\.js"] [])	
			"js/common/common.js"]
		[#".+/css/(.+)\.css" 
			["www/less/$1.less"] 
			"css/$1.css"]

		; 电子签名综合授权书引入了两个贷款协议
		[#".+/(credit_esign_tpl)\.html" 
			["_zhengxinshouquan_l.ejs" "_zhengxinshouquan_c.ejs"] 
			"$1.html"]
		; 所有less编译成css后会被压缩成一个iloan_BT.css
		[#".+/css/iloan_BT.css" 
			[#"www/less/.+\.less"] 
			"css/iloan_BT.css"]
	]
	;模块历史增量包目录
	:prj-update-dir "upgrade/update/"
	:prj-dist "dist/"
})