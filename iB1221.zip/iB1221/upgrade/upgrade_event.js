var fs = require("fs");
var path = require("path");
var Config = require("./config.json");
var ENV = 'DEVELOPMENT';
var MOD = '';
var UPDATE = 'update/';
var IMPORT = 'import/';
var ursa = require('ursa');
var ursa_key = ursa.createPrivateKey('-----BEGIN RSA PRIVATE KEY-----\n'+
'MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAPAdBTvu2wwE1sqf\n'+
'NV345l4g2zus+AZ1XyjCtq7U7H1rlrGsnadqTd0NCIP1m39R+RyRmGoViEObPFg6\n'+
'CRgOag/h9Mx6ojBjh7Sbj5YNMXoR/vi0RbZJ43BRWoG1woP4MYTH1BNpaM4u77Aj\n'+
'Dh/iBG66ujbuhJy3I0l+InrbkLfZAgMBAAECgYEA2+hYQNmzeEB+T7icceJhadgB\n'+
'sZfq2E9qxbP/CAQuS3fb3gHPqeKsSUWEhQbOUT9MPaQCyTXLRM/J5qvQZF3fN8KA\n'+
'OxJUXxu8iy2qb2XPv/9/1dZf0i2uCDivjaCc8/PviXMZs0a0P4HDHsHHffn6vcYI\n'+
'iEnhCf2eMMIdV3nZxeECQQD4jr4qKMVVMtOme11COJgBnlHVv6CmTLeTGv8rz4LM\n'+
'zeBSJJfMVjfLpHf8Ivo4mVdx7VBlbNIVi7jwBVPLE4CtAkEA902M6tJ8BahnEX6o\n'+
'P1p6W2A2ChA6leE7wWnrtzDjiCG9nNExUFHhdCE5EceV8nfLIcX9XE/t6voEyVJU\n'+
'5pD9XQJBAJqBEJBgW5nESHA6SxQ43bRT14bI4XG+SnZ0151CFop8hy5IdNud1H0P\n'+
'tU3T6Dp6hzLYU5tYc5bVDZaVmSqo6tkCQFzNJDFGVTYGUM8W2WoUuM+rVfwGxQVT\n'+
'ZQoahlLTLL778lxzf+7lGxZqFTFf1RwM6hQ9aOsIL3663aryk1uGUx0CQAp0fGJM\n'+
'/Y5Ic+rrZA46kV5+BtXJulkIRTVBTMW1vv714iCk6selXIzQo2sU0gD0BUVlx8V1\n'+
'yoKileuksRbuU5k=\n'+
'-----END RSA PRIVATE KEY-----');



// 获取chdir
var argv = process.argv.slice(2);
// 设置默认工作目录为./dist
if ((argv_env = argv.indexOf("-env")) != -1) {
    var value = argv[argv_env + 1];
    ENV = value || "DEVELOPMENT";
}
if ((argv_mod = argv.indexOf("-mod")) != -1) {
    var value = argv[argv_mod + 1];
    MOD = value || "";
}

var Create = {
    getCSV: function (v, url, t, md5) {
        if (md5) {
            return [v, url, t, md5].join(",") + "\n";
        } else {
            return [v, url, t].join(",") + "\n";
        }
    },
    getInsertSQL: function (v, t, url, md5) {
        return "insert into ss_el_html_version (ID_SS_EL_HTML_VERSION, VERSION_CODE, DESCRIPTION, CATALOGUE, UPDATE_TO_VERSION, MD5, DATA_STATE, CREATED_BY, DATE_CREATED, UPDATED_BY, DATE_UPDATED) values (sys_guid(), '" + v + "', '', '" + url + "', '" + t + "', '" + md5 + "', '0', 'yulicheng661', sysdate, 'yulicheng661', sysdate);\n\r";
    },
    getDeleteSQL: function(v) {
      var text =  "delete from tms_h5_version_info where update_to_version = '" + v + "';\n\r";
      return text;
    },
    getUpdateJson: function (v, t, url, md5) {
        var json = ',"' + v + '": {"lastVersion": "' + t + '","md5": "' + md5 + '","modulesName": "' + MOD + '","updateUrl": "' + url + '"}';
        return json;
    },
    files: function (package_config, pkgMD5) {
        var sql = this.getDeleteSQL(Config.from);
        var testSql = this.getDeleteSQL(Config.from);
        var updateJson = '';
        var csv = "";
        var json = {
            "flag": "1",
            "env": "" + (ENV + '').split("_")[0] + ""
        }
        // 添加预发布路径 PRODUCTION_TEST
        var updateUrl = ENV == 'PRODUCTION'?'http://txt.pingan.com.cn/static/paem/cfs-ss/' + MOD + 'html'
        		:(ENV == 'PRODUCTION_TEST'?'https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/cfs-ss/prd_test/' + MOD + 'html':
        			'https://test1-puhui-web.pingan.com.cn:10143/manager/stg/paem/cfs-ss/' + MOD + 'html');

        for (var key in package_config) {
            var from = key;
            var filename = package_config[key].zip;
            var to_version = package_config[key].to;
            var md5 = package_config[key].md5;
            var dest = IMPORT + to_version;

            updateJson += this.getUpdateJson(from, to_version, updateUrl + "/" + to_version + "/" + filename, ursa_key.privateEncrypt(md5,'utf8', 'base64'));

            sql += this.getInsertSQL(from, to_version, updateUrl + "/" + to_version + "/" + filename, md5);

            testSql += this.getInsertSQL(from, to_version, updateUrl +"/" +to_version + "/" + filename, md5);

            csv += this.getCSV(from, updateUrl + "/" + to_version + "/" + filename, to_version, md5);
        }
        if (!fs.existsSync(dest)) {
            fs.mkdirSync(dest);
        }
        json.data = JSON.parse('{' + updateJson.slice(1) + '}');

        fs.writeFileSync(dest + "/" + MOD + ".json", JSON.stringify(json));
        fs.writeFileSync(dest + "/production_dml.sql", sql);
        fs.writeFileSync(dest + "/test_dml.sql", testSql);
        fs.writeFileSync(dest + "/version.csv", csv);
        fs.writeFileSync(dest + "/packages.json", JSON.stringify(package_config));
    }
}

module.exports = exports = {
    /*
        每个升级包文件压缩前触发，这里可以将文件内容进行替换，用来作为替换环境变量
    */
    beforeZip: function (filename) {
        //  if (filename.indexOf("common.js") != -1) {
        //     // 替换环境
        //     var contents = fs.readFileSync(filename, 'utf-8');
        //     contents = contents.replace(/DEVELOPMENT/g,ENV);
        //     fs.writeFileSync(filename, contents);
        // }
    },
    /*
        设置输出包的名字
    */
    setOutputName: function (ver) {
        /*return PROJECT_NAME + "_" + ver + "_" + ENV + "_" + new Date().getTime() + ".zip";*/
    },
    /*
        整个增量包打包时触发，需要打包附属文件的话在这里处理
        这里可以拿到json映射文件，可以用来拼sql
    */
    beforePackage: function (pathname,json,pkgMD5) {
        Create.files(json,pkgMD5);
        //fs.writeFileSync(path.join(pathname,"test.txt"), "HELLOWORLD", "UTF-8");
    },
    /*
        打包结束时触发
    */
    onEnd: function (json) {
    }
}
